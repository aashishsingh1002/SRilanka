export const ENTITY_NAME = 'packageProfile';
export const PKG_GET_URL = '/mtn/deal/ref/pkgprofile';
export const PKG_POST_URL = '/mtn/deal/ref/storepkgprofile1';
export const PKG_UPDATE_URL = 'mtn/deal/ref/editpkgprofile';
