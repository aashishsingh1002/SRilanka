import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';

// Children
import { ENTITY_NAME, DEVICES_LISTS } from './devices-constants';
import DevicesTable from './devices-table';

// Helpers
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../../axios-epc';
import Loader from '../../../UI/Loader/Loader';
import { getUiFields, getVersions } from '../common/utils';
import MenuSelection from '../common/MenuSelection';

const Devices = () => {
  // selectors
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const openDrawer = useSelector((state) => state.drawerData.open);

  // states
  const [version, setVersion] = useState('');
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState('');
  const [schema, setSchema] = useState([]);

  const uiFields = async (id) => {
    try {
      const { entity } = DEVICES_LISTS.find((list) => list.id === id);
      const result = await getUiFields({ userInfo, entity, version });
      setSchema(result);
      setLoading(false);
    } catch (e) {
      setLoading(false);
    }
  };

  const onSelect = (value) => {
    setSchema([]);
    setSelected(value);
    setLoading(true);
    uiFields(value);
  };

  const initialize = async () => {
    try {
      const entity = ENTITY_NAME;
      const version = await getVersions({ userInfo, entity });
      setVersion(version);
      setLoading(false);
    } catch {
      setLoading(false);
    }
  };

  // componentDidMount
  useEffect(() => {
    initialize();
  }, []);

  return (
    <div
      style={{
        margin: '0 auto',
        width: openDrawer ? `calc(100vw - 343px)` : 'calc(100vw - 141px)',
      }}
    >
      <div style={{ padding: '20px 0', fontSize: '24px', fontWeight: '600' }}>
        <MenuSelection
          customOnChange={onSelect}
          disabled={loading}
          lists={DEVICES_LISTS}
          label='Select Device'
        />
      </div>
      {loading && <Loader />}
      {!loading && selected && schema.length > 0 && (
        <DevicesTable setLoading={setLoading} schema={schema} id={selected} />
      )}
    </div>
  );
};

export default Devices;
