import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getUiFields, getVersions } from "../../BulkUpload/common/utils";
import axios from "../../../axios-epc";

import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";

import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import CategoryIcon from "@material-ui/icons/Category";
import NoteIcon from "@material-ui/icons/Note";

const SummaryPricing = (props) => {
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  //const data = useSelector((state) => state.summary.generalData);
  const { releaseId } = useSelector((state) => state.releaseData.releaseData);
  const { packageId } = useSelector((state) => state.packageData.packageData);

  const [columns, setColumns] = useState([]);
  const [allPricingComponents, setAllPricingComponent] = useState([]);

  const init = async () => {
    const entity = "offerability";
    const version = await getVersions({ userInfo, entity });
    const result = await getUiFields({ userInfo, entity, version });
    setColumns(result);
  };

  const getAllComponents = () => {
    if (releaseId) {
      if (props.id) {
        return axios
          .get(
            process.env.REACT_APP_URL +
              "pricing/direct?id=" +
              props.id +
              "&releaseId=" +
              props.releaseData.releaseId
          )
          .then((res) => {
            const {
              listOfDiscountComponents = [],
              listOfRentalComponents = [],
            } = res.data.data;

            setAllPricingComponent([
              ...listOfDiscountComponents,
              ...listOfRentalComponents,
            ]);
          })
          .catch((error) => {});
      } else {
        return Promise.resolve();
      }
    } else {
      return Promise.resolve();
    }
  };

  useEffect(() => {
    getAllComponents();
  }, []);

  if (!allPricingComponents.length) {
    return (
      <div
        style={{
          background: "rgb(255, 255, 255)",
          borderRadius: "5px",
          padding: "20px",
          width: "100%",
          boxShadow: "rgb(0 0 0 / 8%) 0px 4px 10px",
        }}
      >
        No pricing details found
      </div>
    );
  }

  return (
    <div style={{ width: "100%" }}>
      {allPricingComponents.map((component, i) => (
        <Card
          style={{
            display: "inline-block",
            width: "30%",
          }}
          key={i}
        >
          <CardHeader
            subheader={
              component.componentType ? component.componentType : "DISCOUNT"
            }
          />
          <CardContent style={{ overflow: "visible", paddingTop: 0 }}>
            {component.componentType ? (
              <List>
                <ListItem button>
                  <ListItemIcon>
                    <CategoryIcon style={{ color: "#fc0a5b" }} />
                  </ListItemIcon>
                  <ListItemText
                    primary={"Type: " + component.componentSubType}
                  />
                </ListItem>
                <ListItem button>
                  <ListItemIcon>
                    <NoteIcon style={{ color: "#a87f32" }} />
                  </ListItemIcon>
                  <ListItemText
                    primary={"List Price: " + component.componentValue}
                  />
                </ListItem>
              </List>
            ) : (
              <List>
                <ListItem button>
                  <ListItemIcon>
                    <CategoryIcon style={{ color: "#fc0a5b" }} />
                  </ListItemIcon>
                  <ListItemText
                    primary={"Applied On: " + component.discountAppliedOn}
                  />
                </ListItem>
                <ListItem button>
                  <ListItemIcon>
                    <NoteIcon style={{ color: "#a87f32" }} />
                  </ListItemIcon>
                  <ListItemText
                    primary={"List Price: " + component.discountValue}
                  />
                </ListItem>
              </List>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default SummaryPricing;
