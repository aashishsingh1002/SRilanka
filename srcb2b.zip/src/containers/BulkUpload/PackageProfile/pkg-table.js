import React, { useState, useEffect, useRef } from 'react';
import { TextField, ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';
import moment from 'moment';
import { PKG_GET_URL, PKG_POST_URL, PKG_UPDATE_URL } from './pkg-constants';
import axios from '../../../axios-epc';
import MaterialTable, { MTableToolbar } from '@material-table/core';
import { TABLE_CONFIG, THEME_OVERRIDE, TABLE_ICONS } from './pkg-config';
import { useSelector, useDispatch } from 'react-redux';
import GetAppIcon from '@material-ui/icons/GetApp';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import Select from 'react-select';
// import Select from "@material-ui/core/Select";
// import MenuItem from "@material-ui/core/MenuItem";
import { fetchDealCaptureDD } from '../../../store/actions/actionCreators';
import ExportButton from '../common/ExportButton';
import { CustomPaginationComponent } from '../common/table-config';
import { saveAsExcel } from '../common/utils';
import { objAppendOnUpdate } from '../../../helpers/functions';
import Snackbar from '../../../UI/Snackbar/Snackbar';

const theme = createMuiTheme({
  overrides: THEME_OVERRIDE,
});

const useStyles = (theme) => ({});

const PkgTable = ({ setLoading, schema }) => {
  const dispatch = useDispatch();
  const selectTable = useRef();

  // selectors
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const dropdowns = useSelector((state) => state.dropdownData);

  // States
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loadingTable, setLoadingTable] = useState(true);
  const [selectedRows, setSelectedRows] = useState([]);
  const [flag, setFlag] = useState('');
  const [openSnack, setOpenSnack] = useState(false);
  const [messageSnack, setMessagesnack] = useState('');

  const customStyles = {
    container: (provided) => ({
      ...provided,
      width: 150,
    }),
  };
  const customStyles2 = {
    container: (provided) => ({
      ...provided,
      width: 400,
    }),
  };
  // Functions
  const getData = () => {
    return axios
      .get(PKG_GET_URL)
      .then((res) => {
        if (res) {
          const { data } = res.data;
          const mapData = data.map((row) => ({ ...row, tableData: '' }));
          setData(mapData);
        }
        setLoadingTable(false);
      })
      .catch((error) => {
        setLoading(false);
        setLoadingTable(false);
      });
  };

  const mapColumns = () => {
    let tmpColumns = schema.map((row) => {
      return {
        title: row.uiName,
        field: row.refName,
        sorting: false,
        // cellStyle: { width: "30%" },
        render: (rowData) => {
          return (
            row.refName &&
            rowData[row.refName] && (
              <span
                style={{
                  display: 'block',
                  width: row.refName === 'basePackages' ? '40vw' : '10vw',
                }}
              >
                {' '}
                {rowData[row.refName]}
              </span>
            )
          );
        },
        editComponent: (props) => {
          if (props.columnDef.tableData.columnOrder === 0) {
            return <span>{props.value}</span>;
          }

          const convertDD = (arr) => arr.map((d) => ({ value: d, label: d }));
          if (row.refName === 'basePackages') {
            const flag = props.rowData.mtmFlag;
            let filterFlag = null;
            if (flag) {
              if (flag === 'M2M Price Plan') {
                filterFlag = 'Y';
              } else if (flag === 'Normal Price Plan') {
                filterFlag = 'N';
              }
            }

            const basepkgList = dropdowns.basepkg
              .filter((pkg) => {
                if (filterFlag) {
                  return filterFlag === pkg.MTM_FLAG;
                }
                return true;
              })
              .map(({ PACKAGE1, MTM_FLAG }) => ({
                value: PACKAGE1,
                label: PACKAGE1,
                flag: MTM_FLAG,
              }));
            // console.log(basepkgList.filter((x) => x.flag === flag));
            let basepkgDefVal = [];

            if (props.value) {
              basepkgDefVal = Array.isArray(props.value)
                ? convertDD(props.value)
                : convertDD([props.value]);
            }
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Select
                  styles={customStyles2}
                  menuPortalTarget={document.body}
                  isMulti
                  defaultValue={basepkgDefVal}
                  onChange={(event) => {
                    // if (event != null) {
                    //   if (flag === "") {
                    //     setFlag(
                    //       event
                    //         .map((x) => {
                    //           return x.flag;
                    //         })
                    //         .toString()
                    //     );
                    //   } else {
                    //     console.log("do nothing");
                    //   }

                    //   if (flag === "N") {
                    //     console.log("do nothing");
                    //   }
                    //   if (flag === "Y") {
                    //     console.log("do nothing");
                    //   }
                    // }

                    const onChangeVal =
                      event && event.length ? event.map((e) => e.value) : [];
                    props.onChange(onChangeVal);
                  }}
                  options={basepkgList}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }

          if (row.refName === 'mtmFlag') {
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Select
                  styles={customStyles}
                  menuPortalTarget={document.body}
                  defaultValue={props.value}
                  onChange={(event) => {
                    props.onChange(event.value);
                  }}
                  options={row.refLovs.split(',').map((item) => ({
                    value: item,
                    label: item,
                  }))}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }

          return (
            <TextField
              style={{
                width: row.refName === 'basePackages' ? '40vw' : '10vw',
                margin: 10,
                fontSize: 12,
              }}
              fullWidth
              value={props.value}
              onChange={(event) => {
                props.onChange(event.target.value);
              }}
            />
          );
        },
      };
    });

    setColumns(tmpColumns);
  };

  // Did Mount
  useEffect(() => {
    dispatch(fetchDealCaptureDD('basepkg'));
  }, []);

  useEffect(() => {
    if (dropdowns.basepkgLoaded) {
      getData().then(() => mapColumns());
    }
  }, [dropdowns]);

  // Render
  return (
    <ThemeProvider theme={theme}>
      <Snackbar
        open={openSnack}
        message={messageSnack}
        onClose={(event, reason) => {
          if (reason === 'clickaway') {
            return;
          }
          setOpenSnack(false);
        }}
      />
      <MaterialTable
        style={{ padding: '20px' }}
        localization={{
          body: {
            emptyDataSourceMessage: '',
          },
        }}
        components={{
          Toolbar: (props) => (
            <div>
              <div
                style={{
                  fontSize: '18px',
                  fontWeight: '600',
                  marginLeft: '24px',
                }}
              >
                {props.title}
              </div>
              <div>
                <MTableToolbar {...props} />
              </div>
            </div>
          ),
          Pagination: (props) => {
            return <CustomPaginationComponent {...props} />;
          },
        }}
        tableRef={selectTable}
        isLoading={loadingTable}
        icons={TABLE_ICONS}
        title={'Package Profile'}
        columns={columns}
        data={data}
        actions={[
          {
            tooltip: 'Export',
            icon: GetAppIcon,
            onClick: () => {
              saveAsExcel({
                schema: schema,
                name: 'Package Profile',
                data: selectedRows,
              });
            },
          },
          {
            icon: () => (
              <ExportButton
                schema={schema}
                name={'Package Profile'}
                data={selectTable.current && selectTable.current.state.data}
              />
            ),
            isFreeAction: true,
          },
        ]}
        onSelectionChange={(rowSelection) => {
          setSelectedRows(rowSelection);
        }}
        options={TABLE_CONFIG}
        editable={{
          onBulkUpdate: (changes) =>
            new Promise((resolve, reject) => {
              setTimeout(() => {
                console.log(changes);
                if (Object.keys(changes).length > 0) {
                  let payload = [];
                  setLoadingTable(true);
                  Object.keys(changes).map((row) => {
                    let payloadData = { ...changes[row].newData };
                    payloadData.createdBy = userInfo.id;
                    payloadData.createdDate = moment().format('DD-MM-YYYY');
                    payloadData.basepackages = payloadData.basePackages;
                    delete payloadData.basePackages;
                    payload.push(payloadData);
                  });
                  axios
                    .post(PKG_UPDATE_URL, payload)
                    .then((response) => {
                      getData().then(() => {
                        setLoadingTable(false);
                        setOpenSnack(true);
                        setMessagesnack('Saved Successfully!');
                        resolve();
                      });
                    })
                    .catch((error) => {
                      setLoadingTable(false);
                      resolve();
                    });
                } else resolve();
              }, 1000);
            }),
          onRowAdd: (newData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              payload.profileId = null;
              payload.createdBy = userInfo.id;
              payload.createdDate = moment().format('DD-MM-YYYY');
              payload.basepackages = newData.basePackages;
              delete payload.basePackages;
              setLoadingTable(true);
              axios
                .post(PKG_POST_URL, [payload])
                .then((response) => {
                  if (response) {
                    // let pkgData = [...data, newData];
                    // setData(pkgData);
                  }

                  getData().then(() => {
                    setLoadingTable(false);
                    setOpenSnack(true);
                    setMessagesnack('Saved Successfully!');
                  });
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);

                  resolve();
                });
            }),
          onRowUpdate: (newData, oldData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              console.log(newData);
              payload.createdBy = userInfo.id;
              payload.createdDate = moment().format('DD-MM-YYYY');
              payload.basepackages = payload.basePackages;
              delete payload.basePackages;
              if (payload.basepackages) {
                payload.basepackages = Array.isArray(payload.basepackages)
                  ? payload.basepackages
                  : [payload.basepackages];
              }

              const modPayloadData = objAppendOnUpdate(payload, userInfo.id, {
                oldArr: data,
                identifier: 'refId',
                val: payload['refId'],
              });

              setLoadingTable(true);
              axios
                .post(PKG_UPDATE_URL, [modPayloadData])
                .then((response) => {
                  const dataUpdate = [...data];
                  const index = oldData.tableData.id;
                  dataUpdate[index] = newData;
                  setData(dataUpdate);
                  getData().then(() => {
                    setLoadingTable(false);
                    setOpenSnack(true);
                    setMessagesnack('Saved Successfully!');
                  });

                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
        }}
      />
    </ThemeProvider>
  );
};

export default withStyles(useStyles)(PkgTable);
