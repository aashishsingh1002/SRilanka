import React, { Component } from 'react';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from 'axios';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../../UI/Loader/Loader';
import Grid from '@material-ui/core/Grid';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import RentalPricing from './RentalPricing';
import RentalMatrix from './RentalMatrix';
import DiscountMatrix from './DiscountMatrix';
import DiscountPricing from './DiscountPricing';
import PricingComponents from './PricingComponents';
import Tarrif from './Tarrif';

const useStyles = (theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    boldText: {
        // fontWeight: 'bold'
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '96%',
        flexShrink: 0,
    },

});

class Pricing extends Component {

    _isMounted = false;

    state = {
        loading: true,
        componentType: 'Rental',
        computationType: 'Direct',
        rentalVersion: '',
        offerVersion: '',
        discountVersion: '',
        discountedItemsDataVersion: '',
        discountUsageGroupVersion: '',
        allPricingComponents: [],
        compKey: 'app',
        rentalData: {},
        discountData: {}
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidMount() {
        this._isMounted = true;
        this.versions().then(() => {
            this.getAllComponents().then(() => {
                this.setState({ loading: false })
            })
        })
    }

    getAllComponents() {
        if (this.props.releaseData.releaseId) {
            if (this.props.id) {
                return axios
                    .get(
                        process.env.REACT_APP_URL +
                        "pricing/direct?id=" +
                        this.props.id + '&releaseId=' +
                        this.props.releaseData.releaseId
                    )
                    .then(res => {
                        console.log("response getAllComponents");
                        console.log(res.data.data);
                        let allPricingComponents = []
                        allPricingComponents.push(...res.data.data.listOfDiscountComponents)
                        allPricingComponents.push(...res.data.data.listOfRentalComponents)
                        console.log(allPricingComponents)
                        this.setState({
                            allPricingComponents: allPricingComponents
                        })
                    })
                    .catch(error => {
                        console.log(error)
                        if (this._isMounted)
                            this.setState({ loading: false })
                    });
            } else {
                return Promise.resolve();
            }
        } else {
            return Promise.resolve();
        }
    }

    versions() {
        return axios
            .all([
                axios.get(
                    process.env.REACT_APP_URL +
                    "config/version?entityName=offerability", {
                        headers: {
                            opId: this.props.userInfo.opId,
                            buId: this.props.userInfo.buId
                        }
                    }
                ),
                axios.get(
                    process.env.REACT_APP_URL +
                    "config/version?entityName=package.rental", {
                        headers: {
                            opId: this.props.userInfo.opId,
                            buId: this.props.userInfo.buId
                        }
                    }
                ),
                axios.get(
                    process.env.REACT_APP_URL +
                    "config/version?entityName=package.discount", {
                        headers: {
                            opId: this.props.userInfo.opId,
                            buId: this.props.userInfo.buId
                        }
                    }
                ),
                axios.get(
                    process.env.REACT_APP_URL +
                    "config/version?entityName=discountedItemsData", {
                        headers: {
                            opId: this.props.userInfo.opId,
                            buId: this.props.userInfo.buId
                        }
                    }
                ),
                axios.get(
                    process.env.REACT_APP_URL +
                    "config/version?entityName=discountUsageGroup", {
                        headers: {
                            opId: this.props.userInfo.opId,
                            buId: this.props.userInfo.buId
                        }
                    }
                )
            ])
            .then(
                axios.spread(
                    (
                        offerVersion,
                        rentalVersion,
                        discountVersion,
                        discountedItemsDataVersion,
                        discountUsageGroupVersion
                    ) => {
                        this.setState({
                            rentalVersion: rentalVersion.data.data.version,
                            offerVersion: offerVersion.data.data.version,
                            discountVersion: discountVersion.data.data.version,
                            discountedItemsDataVersion: discountedItemsDataVersion.data.data.version,
                            discountUsageGroupVersion: discountUsageGroupVersion.data.data.version
                        });
                    }
                )
            )
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });

    }

    delRentalComp = (delCompID) => {
        this.setState({
            loading: true
        })
        console.log(process.env.REACT_APP_URL +
            "/pricing/direct/delete?componentId=" + delCompID +
            "&packageId=" +
            this.props.id +
            "&releaseID=" +
            this.props.releaseData.releaseId,
        )
        axios
            .get(
                process.env.REACT_APP_URL +
                "/pricing/direct/delete?componentId=" + delCompID +
                "&packageId=" +
                this.props.id +
                "&releaseID=" +
                this.props.releaseData.releaseId,
                {
                    headers: {
                        "Content-Type": "application/json",
                        Accept: "application/json"
                    }
                }
            )
            .then(res => {
                console.log(res);
                let allPricingComponents = this.state.allPricingComponents
                let removeIndex = allPricingComponents
                    .map(function (item) {
                        return item.componentId
                    })
                    .indexOf(delCompID);
                allPricingComponents.splice(removeIndex, 1);
                let compKey = this.state.compKey.length > 10 ? 'app' : this.state.compKey + '1'
                this.setState({
                    allPricingComponents: allPricingComponents,
                    compKey: compKey,
                    loading: false
                })
            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });

    }
    delDiscComp = (delCompID) => {
        this.setState({
            loading: true
        })

        axios
            .get(
                process.env.REACT_APP_URL +
                "discount/direct/delete?componentId=" + delCompID +
                "&packId=" +
                this.props.id +
                "&releaseID=" +
                this.props.releaseData.releaseId,
                {
                    headers: {
                        "Content-Type": "application/json",
                        Accept: "application/json"
                    }
                }
            )
            .then(res => {
                console.log(res);
                let allPricingComponents = this.state.allPricingComponents
                let removeIndex = allPricingComponents
                    .map(function (item) {
                        return item.discountId;
                    })
                    .indexOf(delCompID);
                allPricingComponents.splice(removeIndex, 1);
                let compKey = this.state.compKey.length > 10 ? 'app' : this.state.compKey + '1'
                this.setState({
                    allPricingComponents: allPricingComponents,
                    compKey: compKey,
                    loading: false
                })

            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });




    }

    updateComponentDiscount = (obj, delCompId) => {

        let allPricingComponents = this.state.allPricingComponents

        let removeIndex = allPricingComponents
            .map(function (item) {
                return item.discountId;
            })
            .indexOf(delCompId);
        allPricingComponents.splice(removeIndex, 1);
        console.log(removeIndex)

        let compKey = this.state.compKey.length > 10 ? 'app' : this.state.compKey + '1'
        allPricingComponents.push(obj)
        this.setState({
            allPricingComponents: allPricingComponents,
            compKey: compKey
        })
    }

    updateComponent = (obj, delCompId) => {

        let allPricingComponents = this.state.allPricingComponents

        let removeIndex = allPricingComponents
            .map(function (item) {
                console.log(item.componentId)
                return item.componentId;
            })
            .indexOf(delCompId);
        allPricingComponents.splice(removeIndex, 1);
        console.log(removeIndex)

        let compKey = this.state.compKey.length > 10 ? 'app' : this.state.compKey + '1'
        allPricingComponents.push(obj)
        this.setState({
            allPricingComponents: allPricingComponents,
            compKey: compKey
        })
    }

    addComponent = (obj) => {

        let allPricingComponents = this.state.allPricingComponents
        let compKey = this.state.compKey.length > 10 ? 'app' : this.state.compKey + '1'
        allPricingComponents.push(obj)
        this.setState({
            allPricingComponents: allPricingComponents,
            compKey: compKey
        })
    }
    editComponent = (component) => {
        if (component.componentType) {
            this.setState({
                loading: true, componentType: 'Rental',
                computationType: 'Direct',
            });
            axios
                .get(
                    process.env.REACT_APP_URL +
                    "pricing/direct/component?id=" + this.props.id
                    + '&compId=' +
                    component.componentId + '&releaseId=' +
                    this.props.releaseData.releaseId
                )
                .then(res => {
                    console.log(res.data.data);
                    if (this._isMounted)
                        this.setState({ loading: false, rentalData: res.data.data })

                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });

        }
        else {
            this.setState({
                loading: true, componentType: 'Discount',
                computationType: 'Direct',
            });
            axios
                .get(
                    process.env.REACT_APP_URL +
                    "discount/direct/component?componentId=" +
                    component.discountId +
                    "&packId=" +
                    this.props.id +
                    "&releaseID=" +
                    this.props.releaseData.releaseId, {
                        headers: {
                            opId: this.props.userInfo.opId,
                        }
                    }
                )
                .then(res => {
                    console.log(res.data.data);
                    if (res.data.data) {
                        // this.disableWatchers();
                        // this.componentIdDiscount = componentId;
                        // Object.keys(res.data.data).forEach(key => {
                        //     this.$set(this.formDataDiscount, key, res.data.data[key]);
                        // });
                        // if (this.formDataDiscount.discountAppliedOn == 'RC' || this.formDataDiscount.discountAppliedOn == 'NRC') {

                        //     let discountedItem = this.formDataDiscount.discountedItem.substring(0, this.formDataDiscount.discountedItem.lastIndexOf('_', this.formDataDiscount.discountedItem.lastIndexOf('_') - 1))
                        //     this.$set(this.formDataDiscount, 'discountedItem', discountedItem + '/' + this.formDataDiscount.discountedItem);
                        // }
                        console.log(res.data.data);
                        let obj = {
                            ...res.data.data,
                            componentIdDiscount: component.discountId
                        }
                        if (this._isMounted)
                            this.setState({ loading: false, discountData: obj })


                    }
                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });

        }

    }

    render() {
        const { classes } = this.props;
        let pricingComponent = null;
        if (this.state.componentType == 'Rental' && this.state.computationType == 'Direct')
            pricingComponent = <RentalPricing
                rentalVersion={this.state.rentalVersion}
                userInfo={this.props.userInfo}
                releaseData={this.props.releaseData}
                id={this.props.id}
                entity={this.props.entity}
                addComponent={this.addComponent}
                rentalData={this.state.rentalData}
                updateComponent={this.updateComponent}
            />
        else if (this.state.componentType == 'Rental' && this.state.computationType == 'Matrix')
            pricingComponent = <RentalMatrix
                offerVersion={this.state.offerVersion}
                userInfo={this.props.userInfo}
                releaseData={this.props.releaseData}
                id={this.props.id}
                entity={this.props.entity}
            />
        else if (this.state.componentType == 'Discount' && this.state.computationType == 'Matrix')
            pricingComponent = <DiscountMatrix
                offerVersion={this.state.offerVersion}
                userInfo={this.props.userInfo}
                releaseData={this.props.releaseData}
                id={this.props.id}
                entity={this.props.entity}
            />
        else if (this.state.componentType == 'Discount' && this.state.computationType == 'Direct')
            pricingComponent = <DiscountPricing
                discountVersion={this.state.discountVersion}
                discountedItemsDataVersion={this.state.discountedItemsDataVersion}
                discountUsageGroupVersion={this.state.discountUsageGroupVersion}
                userInfo={this.props.userInfo}
                releaseData={this.props.releaseData}
                id={this.props.id}
                entity={this.props.entity}
                discountData={this.state.discountData}
                addComponent={this.addComponent}
                updateComponent={this.updateComponentDiscount}

            />

        else if (this.state.componentType == 'Tariff')
            pricingComponent = <Tarrif
                releaseData={this.props.releaseData}
                userInfo={this.props.userInfo}
                entity={this.props.entity}
                id={this.props.id} />

        let pricing = <React.Fragment>
            <Card style={{ overflow: 'visible' }}>
                <CardHeader
                    className={classes.cardHeader}
                    classes={{
                        subheader: classes.subheader,
                    }}

                    subheader={'Exisiting Components'} />

                <CardContent style={{ overflow: 'visible' }}>

                    <PricingComponents pricingComponents={this.state.allPricingComponents}
                        key={this.state.compKey}
                        editComp={this.editComponent}
                        delRentalComp={this.delRentalComp}
                        delDiscComp={this.delDiscComp}
                    />

                </CardContent>

            </Card>
            <Card style={{ overflow: 'visible', marginTop: '1%' }}>
                <CardHeader
                    className={classes.cardHeader}
                    classes={{
                        subheader: classes.subheader,
                    }}

                    subheader={'Create New Component'} />

                <CardContent style={{ overflow: 'visible' }}>
                    <Grid container alignContent="flex-end" spacing={2} style={{ overflow: 'visible' }}>
                        <Grid item xs={4} sm={4} md={2} style={{
                            display: 'flex',
                            alignItems: 'center'
                        }}>
                            < Typography variant="subtitle1" > Type of component</ Typography>
                        </Grid>
                        <Grid item xs={8} sm={8} md={10}>

                            <RadioGroup row aria-label="position" name="position"
                                defaultValue="top" value={this.state.componentType}
                                onChange={(event) => {
                                    this.setState({
                                        componentType: event.target.value
                                    })
                                }}>
                                <FormControlLabel
                                    value={'Rental'} control={<Radio style={{ color: '#ff1921' }} />} label="Rental"
                                />
                                <FormControlLabel
                                    value="Discount" control={<Radio style={{ color: '#ff1921' }} />} label="Discount"
                                />
                                <FormControlLabel value="Tariff" control={<Radio style={{ color: '#ff1921' }} />} label="Tariff" />
                            </RadioGroup>
                        </Grid>
                    </Grid>

                    <Grid container alignContent="flex-end" spacing={2} >
                        <Grid item xs={4} sm={4} md={2} style={{
                            display: 'flex',
                            alignItems: 'center'
                        }}>
                            < Typography variant="subtitle1" > Computation Type</ Typography>

                        </Grid>
                        <Grid item xs={8} sm={8} md={10}>

                            <RadioGroup row aria-label="position" name="position"
                                defaultValue="top" value={this.state.computationType}
                                onChange={(event) => {
                                    this.setState({
                                        computationType: event.target.value
                                    })
                                }}>
                                <FormControlLabel
                                    value={'Direct'} control={<Radio style={{ color: '#ff1921' }} />} label="Direct"
                                />
                                <FormControlLabel value="Matrix" control={<Radio style={{ color: '#ff1921' }} />} label="Matrix" />
                            </RadioGroup>
                        </Grid>
                    </Grid>

                </CardContent>
            </Card>

            <Box mt={2}>
                {pricingComponent}

            </Box>

        </React.Fragment>

        if (this.state.loading)
            pricing = <Loader />

        return pricing;
    }


}


export default withStyles(useStyles)(WithErrorHandler(Pricing, axios));


