import React, { Component } from 'react';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import Loader from '../../UI/Loader/Loader';
import MaterialTable, { MTableToolbar } from '@material-table/core';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import moment from 'moment';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
// import Button from "@material-ui/core/Button";
import Button from '../../UI/Button/Button';
import InputLabel from '@material-ui/core/InputLabel';
import Checkbox from '@material-ui/core/Checkbox';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import Modal from '../../UI/Modal/Modal';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableBody from '@material-ui/core/TableBody';
import TableHead from '@material-ui/core/TableHead';
import Table from '@material-ui/core/Table';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import { CustomPaginationComponent } from './common/table-config';

const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
  CheckBoxIcon: forwardRef((props, ref) => (
    <CheckBoxIcon {...props} ref={ref} />
  )),
};

const theme = createMuiTheme({
  overrides: {
    MuiTableCell: {
      root: {
        padding: '0px',
        paddingLeft: '10px',
      },
    },
    MuiPaper: {
      width: '100%',
    },
    MuiInputBase: {
      input: {
        fontSize: 14,
      },
    },
  },
});

const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4.5vh',
  },
  subheader: {
    color: 'white',
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
  table: {
    minWidth: 650,
  },
});

class IlulaDeals extends Component {
  _isMounted = false;

  state = {
    setUcId: '',
    loading: true,
    ilulaDealData: [],
    derivedData: [],
    version: '',
    schema: [],
    columns: [],
    isSelected: false,
    modalOpen: false,
    dealId: [],
  };
  handleOpen() {
    this.setState({ modalOpen: true });
  }
  handleClose = () => {
    this.setState({ modalOpen: false });
  };
  componentWillUnmount() {
    this._isMounted = false;
  }

  constructor(props) {
    super(props);
    this.selectTable = React.createRef();
  }

  async saveAsExcel() {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Ilula Deals');
    let sheetColumns = [];
    this.state.schema.forEach((row) => {
      sheetColumns.push({
        header: row.uiName,
        key: row.refName,
        width: 25,
      });
    });

    worksheet.columns = sheetColumns;

    this.selectTable.current.state.data.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), 'Ilula.xlsx');
  }

  componentDidMount() {
    this._isMounted = true;
    this.versions().then(() => {
      this.uiFields().then(() => {
        this.getUcIdLocalStorage();
        this.getIlulaDealData().then(() => {
          {
            console.log(this.state.schema);
          }
          let columns = this.state.schema.map((row) => {
            return {
              title: row.uiName,
              field: row.refName,
              sorting: false,
              cellStyle: { width: '20%' },
              render: (rowData) => {
                return (
                  row.refName &&
                  rowData[row.refName] && (
                    <span
                      style={{
                        display: 'block',
                        width: row.maxlength ? row.maxlength + 'vw' : '10vw',
                        wordBreak: 'break-all',
                      }}
                    >
                      {' '}
                      {rowData[row.refName]}
                    </span>
                  )
                );
              },
              editComponent: (props) => (
                <TextField
                  style={{
                    width: '20vw',
                    margin: 10,
                    fontSize: 12,
                  }}
                  fullWidth
                  value={props.value}
                  onChange={(event) => {
                    props.onChange(event.target.value);
                  }}
                />
              ),
            };
          });
          console.log(columns);
          this.setState({ columns, loading: false });
        });
      });
    });
  }
  getUcIdLocalStorage() {
    let UcIdLc = localStorage.getItem('UcId');
    console.log(UcIdLc);
    this.setState({
      setUcId: localStorage.getItem('UcId'),
    });
    console.log(this.state.setUcId);
  }
  versions() {
    return axios
      .get('config/version?entityName=ilulaDeals', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields() {
    if (
      localStorage.getItem('bulkUploadIlulaDeals') &&
      localStorage.bulkUploadIlulaDeals_version &&
      localStorage.bulkUploadIlulaDeals_version == this.state.version
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem('bulkUploadIlulaDeals')),
        });
      } catch (e) {
        localStorage.removeItem('bulkUploadIlulaDeals');
      }
      return Promise.resolve();
    } else {
      return axios
        .get('config?entityName=ilulaDeals', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          let schema = [];
          schema = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted) this.setState({ schema: schema });
          localStorage.setItem('bulkUploadDealCapture', JSON.stringify(schema));
          localStorage.bulkUploadDealCapture_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  // axios.get("mtn/deal/basicInfo/data?releaseId="+this.props.releaseData.releaseId")
  // .then(res => {
  //     console.log(res);
  //     console.log(res.data);
  //   })

  getIlulaDealData() {
    return axios
      .get('mtn/ilula?releaseId=' + this.props.releaseData.releaseId, {
        headers: {
          ucId: this.props.data ? this.props.data : this.state.setUcId,
        },
      })
      .then((res) => {
        console.log('deal res');
        console.log(res);
        if (res) {
          this.setState({
            ilulaDealData: res.data.data.map((row) => {
              return { ...row, tableData: '' };
            }),
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  getDerivedData(dealId) {
    return axios
      .get('mtn/deal/basicInfo?releaseId=' + this.props.releaseData.releaseId, {
        headers: {
          opId: this.props.userInfo.opId,
          dealId: dealId[0],
        },
      })
      .then((res) => {
        console.log(res);
        if (res) {
          this.setState({
            derivedData: res.data.data.map((row) => {
              return { ...row, tableData: '' };
            }),
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  render() {
    {
      console.log('Value of releaseId');
      console.log(this.props.releaseData.releaseId);
    }

    const { classes } = this.props;

    let dealCapture = (
      <div
        style={{
          width: this.props.openDrawer
            ? `calc(100vw - 343px)`
            : 'calc(100vw - 141px)',
        }}
      >
        {this.props.releaseData.releaseId ? (
          <ThemeProvider theme={theme}>
            <div
              style={{ padding: '20px 0', fontSize: '24px', fontWeight: '600' }}
            ></div>
            {/* <div>
              ilula Deals you are inside release{" "}
              {this.props.releaseData.releaseId}
            </div> */}
            <MaterialTable
              style={{ padding: '20px' }}
              tableRef={this.selectTable}
              isLoading={this.state.loadingTable}
              icons={tableIcons}
              title={'iLula deals'}
              columns={this.state.columns}
              data={this.state.ilulaDealData}
              actions={[
                {
                  icon: () => (
                    <Button
                      style={{ padding: '6px 36px' }}
                      //   variant="contained"
                      //   style={{
                      //     marginLeft: "20px",
                      //     background: "#546D7A",
                      //     color: "white",
                      //     textTransform: "none",
                      //   }}
                      onClick={() => {
                        this.saveAsExcel();
                      }}
                    >
                      {/* <SaveAlt style={{ marginRight: "10px" }} /> */}
                      Export
                    </Button>
                  ),
                  isFreeAction: true,
                },
              ]}
              options={{
                selection: false,
                pageSize: 4,
                pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
                toolbar: true,
                paging: true,
                rowStyle: {
                  fontSize: '14px',
                  padding: 10,
                  background: 'rgba(0,0,0,0.04)',
                },
                headerStyle: {
                  fontSize: '13px',
                  fontWeight: 'bold',
                  textTransform: 'capitalize',
                  lineHeight: '1.2em',
                },
                // search: false,
                searchFieldAlignment: 'left',
                searchFieldVariant: 'outlined',
                showTitle: false,
                searchFieldStyle: {
                  borderRadius: 50,
                  border: '1px solid rgba(0, 0, 0, 0.04)',
                  background: 'rgba(0, 0, 0, 0.04)',
                  height: 40,
                  width: 320,
                },
              }}
              components={{
                Toolbar: (props) => (
                  <div>
                    <div
                      style={{
                        fontSize: '18px',
                        fontWeight: '600',
                        marginLeft: '24px',
                      }}
                    >
                      {props.title}
                    </div>
                    <div>
                      <MTableToolbar {...props} />
                    </div>
                  </div>
                ),
                Pagination: (props) => {
                  return <CustomPaginationComponent {...props} />;
                },
              }}
            />
            <div style={{ textAlign: 'center' }}>
              <Button
                style={{ padding: '6px 36px', margin: '16px 0' }}
                // variant="contained"
                // style={{ background: "#02bfa0", marginTop: "3%" }}
                type='submit'
                className={classes.btn}
                onClick={() => this.props.history.push('./ExtendedDeals')}
              >
                Back
              </Button>
            </div>
          </ThemeProvider>
        ) : (
          'Outside Release'
        )}
      </div>
    );

    if (this.state.loading) dealCapture = <Loader />;

    return dealCapture;
  }
}

const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
    openDrawer: state.drawerData.open,
    data: state.dealCaptureData.ucIdData.toString(),
  };
};

export default connect(mapStateToProps)(
  withStyles(useStyles)(WithErrorHandler(IlulaDeals, axios))
);
