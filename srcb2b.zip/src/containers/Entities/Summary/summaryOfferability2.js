import React, { Component } from "react";
import Grid from "@material-ui/core/Grid";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import { withStyles } from "@material-ui/core/styles";
import Loader from "../../../UI/Loader/Loader";
import axios from "../../../axios-epc";
import WithErrorHandler from "../../../HOC/WithErrorHandler/WithErrorHandler";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import AppsIcon from "@material-ui/icons/Apps";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import MultiSelect from "../../../UI/Input/MultiSelect";
import Input from "../../../UI/Input/Input";
import Popover from "@material-ui/core/Popover";
// import Button from '@material-ui/core/Button';
import Button from "../../../UI/Button/Button";
import Modal from "../../../UI/Modal/Modal";
import Typography from "@material-ui/core/Typography";
import moment from "moment";
import Divider from "@material-ui/core/Divider";
import ModalOfferability from "../../../UI/Modal/ModalOfferability";
import { Autocomplete } from "@material-ui/lab";
import TextField from "@material-ui/core/TextField";
import Snackbar from "../../../UI/Snackbar/Snackbar";

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
    paddingBottom: "0",
  },
  subheader: {
    color: "rgba(0, 0, 0, 0.87)",
    fontSize: "18px",
    fontWeight: "600",
    // color: "white",
    // fontWeight: 'bold'
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "96%",
    flexShrink: 0,
  },
});

class Offerability extends Component {
  _isMounted = false;
  state = {
    loading: true,
    version: "",
    offerKeys: [],
    schema: [],
    refUiMap: {},
    selectedIndex: 0,
    selOfferability: "",
    selectedType: [],
    show: false,
    showonSave: false,
    modalContent: null,
    packageOfferData: {},
    anchorEl: null,
    open: false,
    message: false,
    allMessage: [],
  };
  componentWillUnmount() {
    this._isMounted = false;
  }

  versions() {
    return axios
      .get("config/version?entityName=offerability", {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        console.log("version is" + res.data.data.version);
        this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields() {
    if (
      localStorage.getItem("offerability") &&
      localStorage.getItem("offerabilityKeys") &&
      localStorage.offerability_version &&
      localStorage.offerability_version == this.state.version
    ) {
      console.log("fetching from local storage");
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem("offerability")),
          offerKeys: JSON.parse(localStorage.getItem("offerabilityKeys")),
          refUiMap: JSON.parse(localStorage.getItem("offerabilityUiRefMap")),
        });
      } catch (e) {
        localStorage.removeItem("offerability");
        localStorage.removeItem("offerabilityKeys");
        localStorage.removeItem("offerabilityUiRefMap");
      }
      return Promise.resolve();
    } else {
      console.log("fetching from api");
      return axios
        .get("config?entityName=offerability", {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          // res.data = {
          //   statusMsg: "SUCCESS",
          //   statuscode: "00",
          //   statusDescription: null,
          //   data: [
          //     {
          //       refId: 1575,
          //       entityName: "offerability",
          //       pattern: null,
          //       errorMsg: null,
          //       refName: "offerField1",
          //       uiName: "Customer Segment",
          //       refLovs: "EBU,CBU,Both",
          //       refType: "SelectInput",
          //       displayOrder: "1",
          //       isDisplay: "Y",
          //       uiGroup: null,
          //       groupName: null,
          //       opId: "PLM",
          //       buId: "MTN",
          //       isDisabled: null,
          //       isMandatory: null,
          //       defaultValue: null,
          //       maxLength: null,
          //       minLength: null,
          //       fieldDescription: null,
          //     },
          //     {
          //       refId: 935,
          //       entityName: "offerability",
          //       pattern: null,
          //       errorMsg: null,
          //       refName: "customerSegmentId",
          //       uiName: "Price Plan Family",
          //       refLovs: "Made For Entrepreneur,Made For Business,DUM_MP",
          //       refType: "SelectInput",
          //       displayOrder: "6",
          //       isDisplay: "Y",
          //       uiGroup: null,
          //       groupName: null,
          //       opId: "PLM",
          //       buId: "MTN",
          //       isDisabled: null,
          //       isMandatory: null,
          //       defaultValue: null,
          //       maxLength: null,
          //       minLength: null,
          //       fieldDescription: null,
          //     },
          //   ],
          // };
          let schema = [];
          schema = res.data.data.map(function (el) {
            if (el.refType == "SelectInput" || el.refType == "MultiSelect") {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(",");
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });

          let offerKeys = [];
          let refUiMap = {};
          console.log(res.data.data);
          res.data.data.forEach((el) => {
            let offerabilityType = {};
            offerabilityType.value = el.refLovs ? el.refLovs : "";
            offerabilityType.type = el.refType;
            offerKeys.push(el.refName);
            refUiMap[el.refName] = el.uiName;
          });

          this.setState({
            schema: schema,
            offerKeys: offerKeys,
            refUiMap: refUiMap,
          });
          localStorage.setItem("offerability", JSON.stringify(schema));
          localStorage.setItem("offerabilityKeys", JSON.stringify(offerKeys));
          localStorage.setItem(
            "offerabilityUiRefMap",
            JSON.stringify(refUiMap)
          );
          localStorage.offerability_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  componentDidMount = () => {
    this._isMounted = true;
    this.setState({ loading: true });
    this.versions().then(() => {
      this.uiFields().then(() => {
        console.log(this.state.schema);
        this.state.schema.map((formElement) => {
          if (formElement.refType == "Date")
            this.setState({
              [formElement.uiName]: formElement.defaultValue
                ? moment(formElement.defaultValue).format("DD-MMM-YY")
                : moment().format("DD-MMM-YY"),
            });
          else if (
            formElement.refType == "TextInput" ||
            "TextArea" ||
            "SelectInput"
          ) {
            console.log(formElement.uiName);
            console.log([formElement.defaultValue]);

            this.setState({
              [formElement.uiName]: [formElement.defaultValue],
            });
          }
        });

        this.packageOfferabilityData().then(() => {
          if (this._isMounted) {
            this.state.schema.map((obj) => {
              if (obj.refType == "MultiSelect")
                this.setState({ [obj.uiName]: [] });
              // else
              //     this.setState({ [obj.uiName]: null })
            });
            if (Object.keys(this.state.packageOfferData).length > 0) {
              Object.keys(this.state.refUiMap).forEach((key) => {
                if (this.state.packageOfferData[key]) {
                  let offer = this.state.refUiMap[key];
                  console.log(offer);
                  if (
                    this.state.packageOfferData[key].length > 0 &&
                    this.state.packageOfferData[key][0]
                  )
                    this.setState((prevState) => {
                      return {
                        [offer]: [...prevState.packageOfferData[key]],
                      };
                    });
                }
              });
            }
            let defaultSegment = null;
            const group = this.props.userInfo.group;
            const isCBU = group.includes("CBU") || group.includes("BOTH");
            const isEBU = group.includes("EBU");

            if (isEBU) {
              defaultSegment = "EBU";
            } else if (isCBU) {
              defaultSegment = "Both";
            }

            console.log("this.props.packageSegment", this.props.packageSegment);
            this.setState({
              loading: false,
              selOfferability: this.state.schema[0].uiName,
              "Customer Segment": defaultSegment,
            });
          }
        });
      });
    });
  };

  handleListItemClick = (event, index, key) => {
    this.setState({ selectedIndex: index, selOfferability: key.uiName });
  };

  cartesianProduct(arr) {
    return arr.reduce(
      function (a, b) {
        return a
          .map(function (x) {
            return b.map(function (y) {
              return x.concat([y]);
            });
          })
          .reduce(function (a, b) {
            return a.concat(b);
          }, []);
      },
      [[]]
    );
  }

  packageOfferabilityData() {
    if (this.props.releaseData.releaseId) {
      if (this.props.id) {
        return axios
          .get(
            "/package/offerability?id=" +
              this.props.id +
              "&releaseId=" +
              this.props.releaseData.releaseId,
            {
              headers: {
                createdBy: this.props.userInfo.id,
                opId: this.props.userInfo.opId,
              },
            }
          )
          .then((res) => {
            console.log(res.data.data);
            this.setState({
              packageOfferData: res.data.data,
            });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      } else {
        return Promise.resolve();
      }
    } else {
      return Promise.resolve();
    }
  }
  modalContentOnSave = (event) => {
    let offerabilitiesValues = [];
    let uiName = "";

    // this.state.schema.forEach((key) => {
    //   uiName = key.uiName;
    //   this.state[key.uiName].length !== 0 && key.uiName === "Customer Segment"
    //     ? offerabilitiesValues.push(
    //         this.state[key.uiName] + " as the " + uiName
    //       )
    //     : console.log("do nothing");

    //   key.uiName === "Customer Segment"
    //     ? this.setState({
    //         allMessage: offerabilitiesValues,
    //       })
    //     : console.log("do nothing");
    // });

    const hasSegment = this.state["Customer Segment"];
    const hasNoPPF =
      Array.isArray(this.state["Price Plan Family"]) &&
      !this.state["Price Plan Family"].filter((i) => i).length;

    if (!this.state["Price Plan Family"] || hasNoPPF || !hasSegment) {
      let errMsg = "Please select a Customer Segment and Price Plan Family";
      if (hasSegment && hasNoPPF) {
        errMsg = "Please select a Price Plan Family";
      } else if (!hasNoPPF && !hasSegment) {
        errMsg = "Please select a Customer Segment";
      }
      this.setState({
        showError: true,
        showErrorMsg: errMsg,
      });
    } else {
      this.savePkgOfferDetailsHandler();
    }

    // offerabilitiesValues.length > 0
    //   ? this.setState({ message: true, showonSave: true })
    //   : this.savePkgOfferDetailsHandler();

    // this.savePkgOfferDetailsHandler();
  };
  savePkgOfferDetailsHandler = (event) => {
    //event.preventDefault();
    if (this.props.id) {
      let offerabilitiesValues = [];
      this.state.schema.forEach((key) => {
        offerabilitiesValues.push(this.state[key.uiName]);
      });
      console.log(offerabilitiesValues);
      offerabilitiesValues.forEach((part, index, theArray) => {
        if (theArray[index] instanceof Array && theArray[index].length === 0) {
          theArray[index][0] = null;
          this.setState({
            [part]: [],
          });
        } else if (typeof theArray[index] === "string") {
          theArray[index] = [theArray[index]];
        } else if (theArray[index] == null) theArray[index] = [];
      });
      let crossMatrix = this.cartesianProduct(offerabilitiesValues);
      let offerJson = [];
      crossMatrix.filter((row) => {
        let oneOfferRule = {};
        let date = moment().format("DD-MMM-YY");
        oneOfferRule.opid = this.props.userInfo.opId;
        oneOfferRule.buid = this.props.userInfo.buId;
        oneOfferRule.createdBy = this.props.userInfo.id;
        oneOfferRule.createdDate = date;
        oneOfferRule.startDate = date;
        oneOfferRule.endDate = "31-Dec-31";
        oneOfferRule.version = "1.0";
        oneOfferRule.offerabilityRuleId = "OFPK1";
        oneOfferRule.offerabilityRule = "OFPK1";
        oneOfferRule.packageProductId = this.props.id;
        oneOfferRule.packageId = this.props.id;
        oneOfferRule.packageProductIdentifier = this.props.entity;

        row.forEach((val, index) => {
          let key = this.state.offerKeys[index];
          oneOfferRule[key] = val;
        });
        offerJson.push(oneOfferRule);
      });
      console.log(offerJson);
      let payload = {};
      let listOfPPmOfferabilityAud = [];
      listOfPPmOfferabilityAud = offerJson;
      payload.id = this.props.id;
      payload.releaseId = this.props.releaseData.releaseId;
      payload.listOfPPmOfferabilityAud = listOfPPmOfferabilityAud;
      console.log(payload);
      this.setState({ loading: true, showonSave: false });
      axios
        .post("/package/offerability", payload)
        .then((response) => {
          console.log(response.data.data);
          // if (this._isMounted)
          let payloadRelData = {};
          payloadRelData.releaseId = this.props.releaseData.releaseId;
          payloadRelData.id = this.props.id;
          payloadRelData.listOfOfferabilities = response.data.data;
          axios
            .post("/package/offerability/releaseEntity", payloadRelData)
            .then((response) => {
              console.log(response);
              this.setState({
                loading: false,
                showonSave: false,
                message: false,
                openSnack: true,
                messageSnack: "Saved Successfully!",
              });
            });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      let modalContent = (
        <Typography variant="h6">
          {" "}
          Submit Basic {this.props.entity} Details first.{" "}
        </Typography>
      );
      this.setState({ modalContent: modalContent, show: true });
    }
  };

  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };
  closeHandler = () => {
    this.setState({ showonSave: false });
  };
  deleteOfferabilityHandler = () => {
    this.setState({
      loading: true,
    });
    axios
      .get(
        "package/offerability/delete?id=" +
          this.props.id +
          "&releaseID=" +
          this.props.releaseData.releaseId
      )
      .then((res) => {
        console.log(res.data.data);
        if (this._isMounted) {
          this.state.schema.map((obj) => {
            if (obj.refType == "MultiSelect")
              this.setState({ [obj.uiName]: [] });
            else this.setState({ [obj.uiName]: null });
          });
          this.setState({
            loading: false,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  inputHelper(formElement, isDisabled) {
    console.log("fs", formElement);
    formElement = formElement[0];
    if (formElement) {
      if (formElement.refType === "MultiSelect")
        return (
          <Autocomplete
            multiple
            options={formElement.refLovs}
            value={this.state[formElement.uiName]}
            renderInput={(params) => (
              <TextField
                {...params}
                label={this.state.selOfferability}
                placeholder={"Select an option"}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            )}
            onChange={(event, value) => {
              this.setState({ [formElement.uiName]: value });
            }}
          />
        );
      // return (
      //   <MultiSelect
      //     refLovs={formElement.refLovs}
      //     value={this.state[formElement.uiName]}
      //     {...formElement}
      //     changed={(selected) => {
      //       console.log(selected);
      //       let addSelectedVal = [];
      //       addSelectedVal.push(selected);
      //       if (!(selected instanceof Array)) selected = [selected];
      //       this.setState({
      //         [formElement.uiName]: selected,
      //         selectedType: addSelectedVal,
      //         message: formElement.uiName,
      //       });
      //     }}
      //   />
      // );
      else {
        let refLovs = formElement.refLovs;
        if (formElement.uiName === "Customer Segment") {
          refLovs = formElement.refLovs.filter((ref) => {
            const group = this.props.userInfo.group;
            const isCBU = group.includes("CBU") || group.includes("BOTH");
            const isEBU = group.includes("EBU");

            // const pkgSegment = this.props.packageSegment;
            // const isEBU = pkgSegment === 'EBU';
            // const isCBU = pkgSegment === 'CBU' || pkgSegment === 'Both';
            if (isEBU && ref === "EBU") return true;
            if (isCBU && (ref === "CBU" || ref === "Both")) return true;
            if (!isEBU && !isCBU) {
              return true;
            }
          });
        }
        return (
          <>
            <label
              style={{
                color: "rgba(0, 0, 0, 0.54)",
                fontSize: "14px",
                fontWeight: "400",
                transform: "translate(0, 1.5px) scale(0.75)",
                transformOrigin: "top left",
                lineHeight: "1",
                display: "block",
              }}
            >
              {this.state.selOfferability}
              <span
                style={{
                  color: "red",
                  marginLeft: "5px",
                  fontWeight: "bold",
                }}
              >
                *
              </span>
            </label>
            <Input
              table
              key={formElement.refName}
              {...formElement}
              refLovs={refLovs}
              value={this.state[formElement.uiName]}
              disabled={
                (formElement.isDisabled == "Y" ? true : false) || isDisabled
              }
              required={formElement.isMandatory == "Y" ? true : false}
              changed={(event) => {
                console.log("event", event);
                if (!event || !event.target) {
                  this.setState({
                    [formElement.uiName]: event,
                  });
                } else {
                  if (event.target.type !== "checkbox") {
                    console.log(event);
                    console.log(event.target.value);
                    this.setState({
                      [formElement.uiName]: event.target.value,
                    });
                  } else {
                    console.log(event.target.checked);
                    this.setState({
                      [formElement.uiName]: event.target.checked,
                    });
                  }
                }
              }}
            />
          </>
        );
      }
    }
  }

  render() {
    const { classes, access } = this.props;
    const isDisabled = access && access === "R";
    let offerability = <Loader />;
    let selectedOfferability = null;

    if (!this.state.loading) {
      selectedOfferability = this.inputHelper(
        this.state.schema.filter((obj) => {
          if (obj.uiName === this.state.selOfferability) {
            return obj;
          }
        }),
        isDisabled
      );
      offerability = (
        <div style={{ width: "100%" }}>
          <form
            // onSubmit={this.savePkgOfferDetailsHandler}
            onSubmit={this.modalContentOnSave}
            style={{ overflow: "visible" }}
          >
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Card>
                  <CardContent>
                    {
                      <List
                        component="nav"
                        aria-labelledby="nested-list-subheader"
                        style={{
                          width: "100%",
                          // maxHeight: "20vh",
                          overflow: "auto",
                        }}
                      >
                        {this.state.schema.map((key) => {
                          return (
                            <React.Fragment key={key.refName}>
                              {
                                <ListItem>
                                  <ListItemText
                                    primary={key.uiName}
                                    // secondary={
                                    //   key.refType == "MultiSelect"
                                    //     ? this.state[key.uiName].join()
                                    //     : this.state[key.uiName]
                                    // }

                                    secondary={
                                        key.refType == "MultiSelect"
                                          ? this.state[key.uiName]
                                          : this.state[key.uiName]
                                      }
                                  />
                                </ListItem>
                              }
                              <Divider />
                            </React.Fragment>
                          );
                        })}
                      </List>
                    }
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </form>
        </div>
      );
    }
    return offerability;
  }
}

export default withStyles(useStyles)(WithErrorHandler(Offerability, axios));
