import en from './en'
import es from './es'


const translations = {
    en: en,
    es: es,
};
export default translations;