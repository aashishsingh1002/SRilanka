import React from 'react'
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';

export default function DropDown(props) {
    

    return (
      
            <Select onChange={(event) => {props.onChange(event.target.value)}}>
                                        
                                    {props.refLovs.split(',').map(val =>(
                                              <MenuItem value={val} >{val}</MenuItem>

                                               ))}

                                        </Select>
        
    )
}
