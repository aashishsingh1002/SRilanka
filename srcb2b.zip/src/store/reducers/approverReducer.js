import * as actionTypes from '../actions/actionTypes';

const initialState = {
    approversData: {},
};

const setApproverMap = (state, action) => {
    return {
        ...state,
        approversData: { ...action.approversData },
    }
};


const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.APPROVER_MAP: return setApproverMap(state, action);
        default:
            return state;
    }
};

export default reducer;