import React, { Component } from 'react';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import LastPageIcon from '@material-ui/icons/LastPage';
import { connect } from 'react-redux';
import Loader from '../../UI/Loader/Loader';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Tooltip from '@material-ui/core/Tooltip';
import Box from '@material-ui/core/Box';
import ExtendedProfile from './ExtendedProfile';
import ExtendedBundle from './ExtendedBundle';
import Paper from '@material-ui/core/Paper';

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4.5vh',
  },
  subheader: {
    color: 'white',
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
});

class ExtendedDeals extends Component {
  _isMounted = false;

  state = {
    loading: false,
    typeRatePlan: 'profile',
    editRpData: {},
    dealData: '',
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount() {
    this.getDealData().then(() => {
      this.setState({ loading: false });
    });
  }
  getDealData() {
    return axios
      .get(
        process.env.REACT_APP_URL +
          `mtn/deal/basicInfo/LeadDealsOnly?releaseId=${this.props.releaseData.releaseId}`
      )
      .then((res) => {
        this.setState({ dealData: res.data.data });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  backToDealCapture = () => {
    this.props.history.push('/bulkUploadDealCapture');
  };

  editCrp = (data) => {
    this.setState({
      typeRatePlan: 'bundle',
    });
    this.setState({
      editRpData: data,
    });
  };

  render() {
    const { classes } = this.props;

    let ratePlanComponent = null;
    if (this.state.typeRatePlan == 'profile')
      ratePlanComponent = <ExtendedProfile />;
    else if (this.state.typeRatePlan == 'bundle')
      ratePlanComponent = <ExtendedBundle />;

    let ratePlan = (
      <>
        <div style={{ padding: '20px 0', fontSize: '18px', fontWeight: '600' }}>
          Deal Extension
        </div>
        <div>
          <Paper>
            <CardContent>
              <div>Type</div>
              <RadioGroup
                row
                aria-label='position'
                name='position'
                value={this.state.typeRatePlan}
                onChange={(event) => {
                  this.setState({
                    typeRatePlan: event.target.value,
                  });
                }}
                style={{ marginBottom: '2%' }}
              >
                <FormControlLabel
                  value={'profile'}
                  control={<Radio style={{ color: '#ffcc00' }} />}
                  label='Profile'
                />
                <FormControlLabel
                  disabled={this.state.dealData === 'N' ? true : false}
                  value='bundle'
                  control={<Radio style={{ color: '#ffcc00' }} />}
                  label='Price Plan'
                />
              </RadioGroup>

              <Box mt={2}>{ratePlanComponent}</Box>
            </CardContent>
          </Paper>
        </div>
      </>
    );
    let ratePlan2 = (
      <Card style={{ overflow: 'visible' }}>
        <CardHeader
          className={classes.cardHeader}
          classes={{
            subheader: classes.subheader,
          }}
          action={
            this.props.releaseData.releaseId && (
              <React.Fragment>
                <div>
                  <LightTooltip title='Back To Deal Capture' arrow>
                    <LastPageIcon
                      onClick={this.backToDealCapture}
                      style={{ color: 'white', cursor: 'pointer' }}
                    />
                  </LightTooltip>
                </div>
              </React.Fragment>
            )
          }
          subheader={
            this.props.releaseData.releaseId
              ? 'Deal Extension You are inside release ' +
                this.props.releaseData.releaseId
              : 'Rate Plan package/configuration'
          }
        />

        <CardContent>
          <div>Type</div>
          <RadioGroup
            row
            aria-label='position'
            name='position'
            value={this.state.typeRatePlan}
            onChange={(event) => {
              this.setState({
                typeRatePlan: event.target.value,
              });
            }}
            style={{ marginBottom: '2%' }}
          >
            <FormControlLabel
              value={'profile'}
              control={<Radio style={{ color: '#3f74c5' }} />}
              label='Profile'
            />
            <FormControlLabel
              value='bundle'
              control={<Radio style={{ color: '#3f74c5' }} />}
              label='Price Plan'
            />
          </RadioGroup>

          <Box mt={2}>{ratePlanComponent}</Box>
        </CardContent>
      </Card>
    );

    if (this.state.loading) ratePlan = <Loader />;

    return ratePlan;
  }
}

const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
  };
};

export default connect(mapStateToProps)(
  withStyles(useStyles)(WithErrorHandler(ExtendedDeals, axios))
);
