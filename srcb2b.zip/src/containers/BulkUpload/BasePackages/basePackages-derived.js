import React, { useEffect, useRef, useState } from 'react';
import MaterialTable from '@material-table/core';
import { TABLE_ICONS } from './basePackages-config';
import { Button } from '@material-ui/core';
import { SaveAlt } from '@material-ui/icons';
import axios from '../../../axios-epc';
import { DERIVED_URL } from './basePackages-constants';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';

const DerivedData = ({
  selected,
  columns = [],
  schema = [],
  selection = [],
}) => {
  const [loading, setLoading] = useState(false);
  //   const [columns, setColumns] = useState([]);
  const [data, setData] = useState([]);
  const selectTable = useRef();

  const filterList = (result) => {
    const list = [];
    result.map((curr) => {
      if (selection.includes(curr.basePackage)) {
        list.push({
          ...curr,
          tableData: '',
        });
      }
    });
    return list;
  };

  const getData = () => {
    if (!selected) {
      return;
    }
    setLoading(true);
    return axios
      .get(selected.DERIVED_URL)
      .then((res) => {
        if (res) {
          const { data } = res.data;
          const mapData = filterList(data); //data.map((row) => ({ ...row, tableData: "" }));
          setData(mapData);
          setLoading(false);
        }
      })
      .catch((error) => {
        setLoading(false);
      });
  };

  const saveAsExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Derived Data');
    let sheetColumns = schema.map((row) => ({
      header: row.uiName,
      key: row.refName,
      width: 25,
    }));

    worksheet.columns = sheetColumns;

    selectTable.current.state.data.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    setLoading(true);
    const buf = await workbook.xlsx.writeBuffer();
    setLoading(false);

    saveAs(new Blob([buf]), `${'Base Package Derived Data'}.xlsx`);
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <MaterialTable
      tableRef={selectTable}
      isLoading={loading}
      icons={TABLE_ICONS}
      title={'Derived Data'}
      columns={columns}
      data={data}
      actions={[
        {
          icon: () => (
            <Button
              variant='contained'
              style={{
                marginLeft: '20px',
                background: '#546D7A',
                color: 'white',
                textTransform: 'none',
              }}
              onClick={() => {
                saveAsExcel();
              }}
            >
              <SaveAlt style={{ marginRight: '10px' }} />
              Export
            </Button>
          ),
          isFreeAction: true,
        },
      ]}
      options={{
        pageSize: selection.length < 10 ? selection.length : 10,
        search: false,
        paging: true,
        toolbar: true,
        rowStyle: {
          fontSize: '15px',
          padding: 8,
        },
        headerStyle: {
          fontWeight: 'bold',
        },
      }}
    />
  );
};

export default DerivedData;
