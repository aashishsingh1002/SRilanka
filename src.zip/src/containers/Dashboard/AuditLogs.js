import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
// import Table from '../../UI/Table/TablePadded'
import Tooltip from '@material-ui/core/Tooltip';
import { withStyles } from '@material-ui/core/styles';

import Button from '@material-ui/core/Button';

import MaterialTable from 'material-table';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';

const tableIcons = {
	Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
	Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
	Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
	Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
	DetailPanel: forwardRef((props, ref) => (
		<ChevronRight {...props} ref={ref} />
	)),
	Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
	Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
	Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
	FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
	LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
	NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
	PreviousPage: forwardRef((props, ref) => (
		<ChevronLeft {...props} ref={ref} />
	)),
	ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
	Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
	SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
	ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
	ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const LightTooltip = withStyles((theme) => ({
	tooltip: {
		backgroundColor: '#525354',
		color: 'white',
		boxShadow: theme.shadows[1],
		fontSize: 14,
	},
}))(Tooltip);

const columns = {
	user: 'User ID',
	role: 'Role',
	approved: 'Action',
	remarks: 'Remarks',
	medium: 'Medium',
	time: 'Time',
};

const theme = createMuiTheme({
	overrides: {
		MuiTable: {
			root: {
				tableLayout: 'fixed',
			},
		},
		MuiTableCell: {
			root: {
				padding: '10px',
				paddingLeft: '10px',
			},
		},
		MuiPaper: {
			width: '100%',
		},
	},
});

class AuditLogs extends Component {
	_isMounted = false;

	state = {
		show: true,
		loading: true,
		actions: [
			{
				icon: () => (
					<Button
						variant="contained"
						style={{
							marginLeft: '20px',
							background: '#546D7A',
							color: 'white',
							textTransform: 'none',
						}}
						onClick={() => {
							// this.saveAsExcel()
							this.setState({ loading: true });
							axios
								.get(
									'custom/pdf?releaseId=' + this.props.releaseData.releaseId,
									{ responseType: 'blob' }
								)
								.then((res) => {
									console.log(res);
									console.log(res.data);

									this.setState({ loading: false });
									var headers = res.headers;
									var blob = new Blob([res.data], {
										type: headers['content-type'],
									});

									var link = document.createElement('a');
									link.href = window.URL.createObjectURL(blob);
									link.download =
										'Literature_' + this.props.releaseData.externalReleaseId;
									link.click();
								})
								.catch((error) => {
									console.log(error);
									if (this._isMounted) this.setState({ loading: false });
								});
						}}>
						<SaveAlt style={{ marginRight: '10px' }} />
						Export
					</Button>
				),
				isFreeAction: true,
			},
		],
		columns: [
			{
				title: 'User ID',
				field: 'user',
				sorting: false,
				cellStyle: { width: '15%' },
			},
			{
				title: 'Role',
				field: 'role',
				sorting: false,
				cellStyle: { width: '15%' },
			},
			{
				title: 'Action',
				field: 'approved',
				sorting: false,
				cellStyle: { width: '15%' },
			},
			{
				title: 'Remarks',
				field: 'remarks',
				sorting: false,

				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: '12px',
									overflow: 'auto',
									maxHeight: '40vh',
									whiteSpace: 'pre-wrap',
								}}>
								{rowData.remarks}
							</pre>
						}>
						<span>
							{' '}
							{rowData.remarks
								? rowData.remarks.length > 25
									? rowData.remarks.substring(0, 25) + '...'
									: rowData.remarks
								: ''}
						</span>
					</Tooltip>
				),
				cellStyle: { width: '25%' },
			},
			{
				title: 'Medium',
				field: 'medium',
				sorting: false,
				cellStyle: { width: '5%' },
			},
			{
				title: 'Time',
				field: 'time',
				sorting: false,
				cellStyle: { width: '25%' },
			},
		],
		data: [],
	};

	async saveAsExcel() {
		const workbook = new ExcelJS.Workbook();
		const worksheet = workbook.addWorksheet('Literature');
		let sheetColumns = [];
		Object.keys(columns).map((key) => {
			sheetColumns.push({
				header: columns[key],
				key: key,
				width: 25,
			});
		});

		worksheet.columns = sheetColumns;

		this.selectTable.current.state.data.map((row) => {
			worksheet.addRow(row);
		});

		worksheet.getRow(1).font = {
			bold: true,
		};

		worksheet.spliceRows(1, 0, ...new Array(7));
		const A2 = worksheet.getCell('A2');
		A2.value = 'ePCN No : ' + this.props.releaseData.externalReleaseId;
		A2.font = {
			bold: true,
		};

		const A3 = worksheet.getCell('A3');
		A3.value = 'ePCN Objective : ' + this.props.releaseData.remarks;
		A3.font = {
			bold: true,
		};

		const A4 = worksheet.getCell('A4');
		A4.value =
			'Launch Approver Note : ' + this.props.releaseData.launchApproverNote;
		A4.font = {
			bold: true,
		};

		const A5 = worksheet.getCell('A5');
		A5.value = 'Creation Date : ' + this.props.releaseData.createdOn;
		A5.font = {
			bold: true,
		};

		this.setState({ loading: true });
		const buf = await workbook.xlsx.writeBuffer();
		this.setState({ loading: false });

		saveAs(
			new Blob([buf]),
			'Literature_' + this.props.releaseData.externalReleaseId + '.xlsx'
		);
	}

	modalCloseHandler = () => {
		this.setState({ show: false });
		this.props.showAuditLogs();
	};

	componentWillUnmount() {
		this._isMounted = false;
	}
	constructor(props) {
		super(props);
		this.selectTable = React.createRef();
	}
	componentDidMount() {
		this._isMounted = true;

		axios
			.get('custom/auditLogs?releaseId=' + this.props.releaseData.releaseId)
			.then((res) => {
				if (this._isMounted) {
					let data = [...res.data.data];
					this.setState({ loading: false, data: data });
				}
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});

		console.log('mounted' + this.props.releaseData.releaseId);
	}

	render() {
		let auditLogs = (
			<Modal
				show={this.state.show}
				size={'xl'}
				modalClosed={this.modalCloseHandler}
				title={'ePCN Id ' + this.props.releaseData.externalReleaseId}>
				{this.state.loading ? (
					<div style={{ minHeight: '30vh' }}>
						{' '}
						<Loader />{' '}
					</div>
				) : (
					<ThemeProvider theme={theme}>
						<MaterialTable
							tableRef={this.selectTable}
							actions={this.state.actions}
							icons={tableIcons}
							title={'ePCN Audit Logs'}
							columns={this.state.columns}
							data={this.state.data}
							options={{
								pageSize: 30,
								pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
								toolbar: true,
								paging: true,
								rowStyle: {
									fontSize: '14px',
									// fontWeight: "600"
								},
								headerStyle: {
									fontWeight: 'bold',
								},
							}}
						/>
					</ThemeProvider>
				)}
			</Modal>
		);

		return auditLogs;
	}
}

export default WithErrorHandler(AuditLogs, axios);
