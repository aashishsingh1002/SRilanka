import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  packageEdit: [],
  productEdit: [],
};

export const bulkEditSlice = createSlice({
  name: 'bulkEdit',
  initialState,

  reducers: {
    savePackageEdit: (state, { payload }) => {
      state.packageEdit = payload;
    },
    saveProductEdit: (state, { payload }) => {
      state.productEdit = payload;
    },
  },
});

export const { savePackageEdit, saveProductEdit } = bulkEditSlice.actions;

export default bulkEditSlice.reducer;
