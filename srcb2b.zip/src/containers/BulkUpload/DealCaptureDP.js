import React, { useState } from 'react';
import DateFnsUtils from '@date-io/date-fns';
import { format } from 'date-fns';
import * as moment from 'moment';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';

import { createMuiTheme, ThemeProvider } from '@material-ui/core';

const defaultMaterialTheme = createMuiTheme({
  overrides: {
    MuiPickersToolbar: {
      toolbar: {
        backgroundColor: '#ffcc00',
      },
    },
    MuiPickersYear: {
      root: {
        '&:focus, &:hover, &:active': {
          color: '#ffcc00',
        },
      },
      yearSelected: {
        color: '#ffcc00',
        '&:focus, &:hover, &:active': {
          color: '#ffcc00',
        },
      },
    },
    MuiPickersMonth: {
      root: {
        '&:focus, &:hover, &:active': {
          color: '#ffcc00',
        },
      },

      monthSelected: {
        color: '#ffcc00',
        '&:focus, &:hover, &:active': {
          color: '#ffcc00',
        },
      },
    },
    MuiPickersDay: {
      daySelected: {
        backgroundColor: '#ffcc00',
        '&:focus, &:hover, &:active': {
          backgroundColor: '#ffcc00',
        },
      },
    },
  },
});

const DealCaptureDatePicker = ({
  value,
  onChange = () => {},
  style = {},
  enableMinDate,
  minDate,
  noDefaultValue,
}) => {
  // const [date, setDate] = useState(value);
  console.log(value);
  //console.log(moment.format('DD-MM-YYYY'))
  const todayDate = new Date();
  //console.log(moment(todayDate).format('DD-MM-YYYY'))
  // console.log(todayDate)
  const formattedDate = moment(value, 'DD-MM-YYYY').format(); //ankit
  const [date, setDate] = useState(value ? formattedDate : moment().format()); //ankit

  const options = enableMinDate
    ? {
        minDate: minDate
          ? moment(minDate, 'DD-MM-YYYY').format()
          : moment().format(),
        // defaultValue: !noDefaultValue ? date : null,
      }
    : {};

  return (
    <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <ThemeProvider theme={defaultMaterialTheme}>
        <KeyboardDatePicker
          style={{ width: '12vw' }}
          // defaultValue={new Date().getDate()+"-"+(new Date().getMonth()+1)+"-"+new Date().getFullYear()}

          defaultValue={date}
          {...options}
          InputProps={{ readOnly: true }}
          variant='inline'
          format='dd-MM-yyyy'
          value={noDefaultValue && !value ? null : date}
          onChange={(e) => {
            const formatted = format(e, 'dd-MM-yyyy');
            onChange(formatted);
            setDate(e);
          }}
        />
      </ThemeProvider>
    </MuiPickersUtilsProvider>
  );
};

export default DealCaptureDatePicker;
