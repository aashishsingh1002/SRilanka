import React from 'react';
import ExpansionPanel from '../../UI/ExpansionPanel/ExpansionPanel';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import SubdirectoryArrowRightIcon from '@material-ui/icons/SubdirectoryArrowRight';
import { connect } from 'react-redux';
import * as actionTypes from '../../store/actions/actionTypes';
import { withRouter } from 'react-router-dom';


const ProductsData = (props) => {
    return (
        <ExpansionPanel heading='Products'>
            {(props.products != null && props.products.length > 0) ?
                < List
                    component="nav"
                    aria-labelledby="nested-list-subheader"
                    style={{ width: '100%', maxHeight: '30vh', overflow: 'auto' }}
                >
                    {props.products.map(product => {
                        return <React.Fragment key={product.productId}>
                            <ListItem >
                                <ListItemText primary={product.productDesc + ' (' +
                                    product.productId + ')'} />
                                <SubdirectoryArrowRightIcon onClick={(event) => {
                                    event.stopPropagation()
                                    props.changeProductActiveStep(0)
                                    props.onProductEnter(product)
                                    props.history.push('/productConfiguration')
                                }} style={{ color: '#ff1921', cursor: 'pointer' }} />
                            </ListItem>

                            <Divider />
                        </React.Fragment>

                    })}
                </List>
                : null}
        </ExpansionPanel>

    );
}


const mapDispatchToProps = dispatch => {
    return {
        onProductEnter: (productData) => dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
        changeProductActiveStep: (activeStep) => dispatch({ type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP, activeStep: activeStep }),

    };
};

export default connect(null, mapDispatchToProps)(withRouter(ProductsData));