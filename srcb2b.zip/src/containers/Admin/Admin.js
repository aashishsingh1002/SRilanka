import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import Plan from './Plan/Plan';
import PlanNew from './Plan/PlanNew';
import Product from './Product/Product';
import Offerability from './Offerability/Offerability';
import Contract from './Contract/Contract';
import ContractProfile from './ContractProfile/ContractProfile';
import Attribute from './Attribute/Attribute';
import RatePlan from './RatePlan/RatePlan';
import Rental from './Rental/Rental';
import Discount from './Discount/Discount';
import User from './User/User';
import WorkFlow from './WorkFlow/WorkFlow';
import { Fade } from 'react-awesome-reveal';

class Admin extends Component {
  state = {
    plan: true,
  };
  render() {
    return (
      <Fade top>
        <Grid
          container
          alignContent='flex-start'
          spacing={2}
          style={{ overflow: 'visible' }}
        >
          <Plan />
          {/* <PlanNew /> */}
          <Product />
          <Offerability />
          <Contract />
          {/* <ContractProfile /> */}
          <Attribute />
          <RatePlan />
          <Rental />
          {/* <Discount /> */}
          <User />
          <WorkFlow />
        </Grid>
      </Fade>
    );
  }
}

export default Admin;
