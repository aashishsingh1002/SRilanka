import axios from "axios";
import { call, put, takeEvery, takeLatest } from "redux-saga/effects";
import {
  FETCH_BUNDLE,
  FETCH_BUNDLE_FAILED,
  FETCH_BUNDLE_REQUEST,
  FETCH_BUNDLE_SUCCESS,
  FETCH_GENERAL,
  FETCH_GENERAL_FAILED,
  FETCH_GENERAL_REQUEST,
  FETCH_GENERAL_SUCCESS,
} from "../actions/actionTypes";

function getAPI(url, payload) {
  return axios.request({
    method: "get",
    url: `${process.env.REACT_APP_URL}${url}`,
    headers: {
      opId: payload.userInfo.opId,
      createdBy: payload.userInfo.id,
    },
  });
}

function* fetchGeneral(action) {
  yield put({ type: FETCH_GENERAL_REQUEST });
  try {
    const url = `package/basicDetails?packageId=${action.payload.productId}&releaseID=${action.payload.releaseId}`;
    const payload = yield call(getAPI, url, action.payload);
    const { data } = payload.data;
    yield put({
      type: FETCH_GENERAL_SUCCESS,
      payload: data,
    });
  } catch (e) {
    yield put({ type: FETCH_GENERAL_FAILED, message: e.message });
  }
}

function* fetchBundle(action) {
  yield put({ type: FETCH_BUNDLE_REQUEST });
  try {
    const url = `mtn/product/bundle?id=${action.payload.id}&releaseId=${action.payload.releaseId}`;
    const payload = yield call(getAPI, url, action.payload);
    const { data } = payload.data;
    yield put({
      type: FETCH_BUNDLE_SUCCESS,
      payload: data,
    });
  } catch (e) {
    yield put({ type: FETCH_BUNDLE_FAILED, message: e.message });
  }
}

export function* summarySagaWatcher() {
  yield takeEvery(FETCH_GENERAL, fetchGeneral);
  yield takeEvery(FETCH_BUNDLE, fetchBundle);
}
