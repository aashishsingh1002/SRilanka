// import React, { Component } from 'react';
// import axios from '../../../axios-epc';
// import Grid from '@material-ui/core/Grid';
// // import Button from '@material-ui/core/Button';
// import Loader from '../../../UI/Loader/Loader';
// import Button from '../../../UI/Button/Button';
// import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
// import Box from '@material-ui/core/Box';
// import CustomInput from '../../../UI/Input/Input';
// import TextField from '@material-ui/core/TextField';
// import Card from '@material-ui/core/Card';
// import CardHeader from '@material-ui/core/CardHeader';
// import CardContent from '@material-ui/core/CardContent';
// import { withStyles } from '@material-ui/core/styles';
// import List from '@material-ui/core/List';
// import ListItem from '@material-ui/core/ListItem';
// import ListItemText from '@material-ui/core/ListItemText';
// import Divider from '@material-ui/core/Divider';
// import Accordion from '@material-ui/core/Accordion';
// import AccordionDetails from '@material-ui/core/AccordionDetails';
// import AccordionSummary from '@material-ui/core/AccordionSummary';
// import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
// import Typography from '@material-ui/core/Typography';
// import DeleteIcon from '@material-ui/icons/Delete';
// import moment from 'moment';
// import MenuItem from '@material-ui/core/MenuItem';
// import FormControl from '@material-ui/core/FormControl';
// import Select from '@material-ui/core/Select';
// import Input from '@material-ui/core/Input';
// import Input2 from '../../../UI/Input/Input';
// import Modal from '../../../UI/Modal/Modal';
// import ListItemIcon from '@material-ui/core/ListItemIcon';
// import AppsIcon from '@material-ui/icons/Apps';
// import Checkbox from '@material-ui/core/Checkbox';
// import Snackbar from '../../../UI/Snackbar/Snackbar';
// import { withRouter } from 'react-router-dom';
// import MaterialTable from '@material-table/core';
// import { TABLE_ICONS } from '../../BulkUpload/common/table-config'; //../BulkUpload/common/table-config
// // import ConfirmDelete from '../../Decommissioning/ConfirmDelete';
// import { ThreeSixtySharp } from '@material-ui/icons';


// const ITEM_HEIGHT = 48;
// const ITEM_PADDING_TOP = 8;
// const MenuProps = {
//   PaperProps: {
//     style: {
//       maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
//       width: 250,
//     },
//   },
// };
// const useStyles = (theme) => ({
//   cardHeader: {
//     // background: "#546D7A",
//     // height: "4.5vh",
//   },
//   subheader: {
//     color: 'rgba(0, 0, 0, 0.87)',
//     fontSize: '18px',
//     fontWeight: '600',
//     // color: "white",
//     // fontWeight: 'bold'
//   },
//   heading: {
//     fontSize: theme.typography.pxToRem(15),
//     // flexBasis: "96%",
//     flexGrow: 1,
//     flexShrink: 0,
//   },
//   btn: {
//     textTransform: 'unset !important',
//   },
// });

// class Attribute extends Component {
//   _isMounted = false;

//   state = {
//     attrGrps: {},
//     loading: true,
//     selAttrGrp: null,
//     selAttrGrps: {},
//     errors: [],
//     show: false,
//     modalContent: null,
//     openSnack: false,
//     messageSnack: '',
//     productFlags: [],
//     attributeFlags: [],
//     productFlagFields: {},
//     // attributeFlagFields: {},
//     attributeFlagFields: [],
//     relationshipDD: [],
//     allColumns: [],
//   };

//   componentWillUnmount() {
//     this._isMounted = false;
//   }
//   componentDidMount() {
//     this._isMounted = true;
//     this.attributeGrpData().then(() => {
//       this.getRelationshipDropdown();
//       this.getProductFlags();
//       this.getAttributeFlags();
//       this.getAttributesHandler();
//       this.retrieveFlagConfiguration();
//       this.retrieveAttrFlagConfiguration();
//       this.packageAttributeData().then(() => {
//         this.setState({ loading: false });
//       });
//     });
//   }

//   getProductFlagsConfig() {
//     if (this.props.releaseData.releaseId) {
//       return axios
//         .get(
//           'mtn/siebel/config/productFlag?release=' +
//             this.props.releaseData.releaseId,
//           {
//             headers: {
//               opId: this.props.userInfo.opId,
//             },
//           }
//         )
//         .then((res) => {
//           console.log('get product flag', res);
//           if (this._isMounted) this.setState({ productFlags: res.data.data });
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     } else {
//       return Promise.resolve();
//     }
//   }

//   getProductFlags() {
//     // entity =productFlag
//     if (this.props.releaseData.releaseId) {
//       return axios
//         .get('config/entity?entityName=productFlags', {
//           headers: {
//             opId: this.props.userInfo.opId,
//             buId: this.props.userInfo.buId,
//           },
//         })
//         .then((res) => {
//           let schema = [];
//           schema = res.data.data.map(function (el) {
//             if (el.refType === 'SelectInput' || el.refType === 'MultiSelect') {
//               if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
//               else if (el.refLovs == null) el.refLovs = [];
//             }
//             return el;
//           });
//           if (this._isMounted) this.setState({ productFlags: schema });
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     } else {
//       return Promise.resolve();
//     }
//   }

//   getAttributeFlags() {
//     // entity = attributeFlags
//     if (this.props.releaseData.releaseId) {
//       return axios
//         .get('config/entity?entityName=attributeFlags', {
//           headers: {
//             opId: this.props.userInfo.opId,
//             buId: this.props.userInfo.buId,
//           },
//         })
//         .then((res) => {
//           console.log(res);
//           if (this._isMounted) this.setState({ attributeFlags: res.data.data });
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     } else {
//       return Promise.resolve();
//     }
//   }

//   getRelationshipDropdown() {
//     if (this.props.releaseData.releaseId && this.props.id) {
//       return axios
//         .get('mtn/siebel/config/relationship', {
//           headers: {
//             id: this.props.id,
//           },
//         })
//         .then((res) => {
//           if (this._isMounted && res.data.data.length) {
//             this.setState({ relationshipDD: res.data.data });
//           }
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     } else {
//       return Promise.resolve();
//     }
//   }

//   retrieveFlagConfiguration() {
//     if (this.props.releaseData.releaseId && this.props.id) {
//       return axios
//         .get(
//           'mtn/siebel/config/productFlag?releaseId=' +
//             this.props.releaseData.releaseId,
//           {
//             headers: {
//               id: this.props.id,
//             },
//           }
//         )
//         .then((res) => {
//           if (this._isMounted && res.data.data.length) {
//             this.setState({
//               productFlagFields: res.data.data[0],
//             });
//           }
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     } else {
//       return Promise.resolve();
//     }
//   }

//   retrieveAttrFlagConfiguration() {
//     if (this.props.releaseData.releaseId && this.props.id) {
//       return axios
//         .get(
//           'mtn/siebel/config/attrFlag?releaseId=' +
//             this.props.releaseData.releaseId,
//           {
//             headers: {
//               id: this.props.id,
//             },
//           }
//         )
//         .then((res) => {
//           if (this._isMounted && res.data.data.length) {
//             this.setState({
//               attributeFlagFields: res.data.data,
//             });
//           }
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     } else {
//       return Promise.resolve();
//     }
//   }

//   attributeGrpData() {
//     if (this.props.releaseData.releaseId) {
//       return axios
//         .get('package/attrGrp?releaseId=' + this.props.releaseData.releaseId, {
//           headers: {
//             opId: this.props.userInfo.opId,
//           },
//         })
//         .then((res) => {
//           let attrGrpsMap = {};
//           res.data.data.map((attributeGrp) => {
//             attrGrpsMap[attributeGrp.attrGrpName] = attributeGrp.attrGrpId;
//           });
//           if (this._isMounted) this.setState({ attrGrps: attrGrpsMap });
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     } else {
//       return Promise.resolve();
//     }
//   }

//   getAttributesHandler = (attrGrp) => {
//     console.log(attrGrp);
//     this.setState({ selAttrGrp: attrGrp });
//     if (attrGrp) {
//       this.setState({ loading: true });
//       if (Object.keys(this.state.selAttrGrps).length > 0) {
//         let modalContent = (
//           <Typography variant='h6'>
//             You have already selected one product class,kindly delete that
//             product class to add new.
//           </Typography>
//         );

//         this.setState({
//           modalContent: modalContent,
//           show: true,
//           loading: false,
//           selAttrGrp: null,
//         });
//       } else {
//         console.log('inside else of getattributeHandler');
//         axios
//           .get(
//             'package/attrGrp/attributes?attrGrpId=' +
//               this.state.attrGrps[attrGrp] +
//               '&releaseId=' +
//               this.props.releaseData.releaseId,
//             {
//               headers: {
//                 opId: this.props.userInfo.opId,
//               },
//             }
//           )
//           .then((res) => {
//             let obj = {};
//             console.log(
//               'package/attrGrp/attributes?attrGrpId=' +
//                 this.state.attrGrps[attrGrp] +
//                 '&releaseId=' +
//                 this.props.releaseData.releaseId
//             );
//             console.log(res.data.data);
//             obj['attrGrp'] = res.data.data.attrGrp;
//             obj['attrGrp']['attrGrpDescription'] =
//               res.data.data.attrGrp.attrGrpName;
//             obj['attributes'] = res.data.data.listOfPpmAttributes;
//             console.log(obj);
//             if (this._isMounted)
//               this.setState((prevState) => {
//                 return {
//                   loading: false,
//                   selAttrGrp: null,
//                   selAttrGrps: {
//                     ...prevState.selAttrGrps,
//                     [res.data.data.attrGrp.attrGrpName]: obj,
//                   },
//                 };
//               });
//             console.log(this.state.selAttrGrps);

//             axios
//               .get('mtn/siebel/config/PcAttrFlag', {
//                 headers: {
//                   productClass: attrGrp,
//                 },
//               })
//               .then((res) => {
//                 this.setState({
//                   // attributeFlagFields: res.data.data[0],
//                   attributeFlagFields: res.data.data,
//                 });
//               })
//               .catch((error) => {
//                 console.log(error);
//                 this.setState({ loading: false });
//               });
//           })

//           .catch((error) => {
//             console.log(error);
//             if (this._isMounted) this.setState({ loading: false });
//           });
//       }
//     }
//   };

//   packageAttributeData() {
//     if (this.props.id) {
//       return axios
//         .get(
//           'package/attrGrp/mapping?id=' +
//             this.props.id +
//             '&releaseID=' +
//             this.props.releaseData.releaseId
//         )
//         .then((res) => {
//           console.log('attr');
//           console.log(res);
//           if (Object.keys(res.data.data).length > 0) {
//             let selAttrGrps = {};
//             Object.keys(res.data.data).forEach((key) => {
//               let obj = {};
//               let date = moment().format('DD-MMM-YY');
//               obj['attrGrp'] = {};
//               obj['attrGrp'].attrGrpAllocateValue = 'PRODUCT';
//               obj['attrGrp'].attrGrpDescription = key;
//               obj['attrGrp'].attrGrpId = this.state.attrGrps[key];
//               obj['attrGrp'].attrGrpName = key;
//               obj['attrGrp'].buid = this.props.userInfo.buId;
//               obj['attrGrp'].createdBy = this.props.userInfo.id;
//               obj['attrGrp'].createdDate = date;
//               // obj["attrGrp"].endDate = "31-Dec-31";
//               obj['attrGrp'].opid = this.props.userInfo.opId;
//               obj['attrGrp'].startDate = date;
//               obj['attrGrp'].updatedBy = this.props.userInfo.id;
//               obj['attrGrp'].updatedDate = date;
//               obj['attributes'] = [];
//               res.data.data[key].filter((attribute) => {
//                 if (attribute.ppmAttrValueType === 'MULTI-SELECT')
//                   this.setState({
//                     [attribute['attrGrpDescription'] +
//                     attribute['productAttributeKey']]:
//                       attribute.productAttributeValue.split(','),
//                   });
//                 else
//                   this.setState({
//                     [attribute['attrGrpDescription'] +
//                     attribute['productAttributeKey']]:
//                       attribute.productAttributeValue,
//                   });

//                 let attrGrpAttr = attribute;
//                 attrGrpAttr.ppmAttrType = attrGrpAttr.ppmAttrValueType;
//                 // if (attrGrpAttr.ppmAttrValueType == "MULTI-SELECT")
//                 //     attrGrpAttr.defaultValue = attrGrpAttr.defaultValue.split(
//                 //         ","
//                 //     );

//                 attrGrpAttr.ppmAttrName = attribute.productAttributeKey;
//                 obj['attributes'].push(attrGrpAttr);
//               });

//               selAttrGrps[key] = obj;
//             });
//             if (this._isMounted) this.setState({ selAttrGrps: selAttrGrps });
//           }
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     } else {
//       return Promise.resolve();
//     }
//   }

//   saveProductFlag() {
//     if (this.props.id) {
//       const payload = {
//         epcId: this.props.id,
//         releaseId: this.props.releaseData.releaseId,
//         listOfSiebelProductFlagsAud: [
//           {
//             epcId: this.props.id,
//             opId: this.props.userInfo.opId,
//             buId: this.props.userInfo.buId,
//             createdBy: this.props.userInfo.id,
//             createdDate: moment().format('DD-MM-YYYY'),
//             // billable: 'N',
//             // readOnlyFlag: 'N',
//             // trackAsAssest: 'N',
//             // hiddenFlag: 'N',
//             // priceOverride: 'N',
//             ...this.state.productFlagFields,
//           },
//         ],
//       };
//       axios
//         .post('mtn/siebel/config/productFlag', payload, {})
//         .then((response) => {})
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     }
//   }

//   saveAttrFlag() {
//     if (this.props.id) {
//       const payload = {
//         epcId: this.props.id,
//         releaseId: this.props.releaseData.releaseId,
//         listOfSiebelAttrFlagsAud: this.state.attributeFlagFields.map((x) => {
//           return {
//             attrName: x.attrName,
//             defaultValue: x.defaultValue,
//             displayName: x.displayName,
//             hiddenFlag: x.hiddenFlag,
//             parentProductClass: x.parentProductClass,
//             productClass: x.productClass,
//             readOnlyFlag: x.readOnlyFlag,
//             requiredFlag: x.requiredFlag,
//             refId: x.refId,
//             productCode: null,
//             version: x.version ? x.version : '1.0_release',
//             endDate: null,
//             epcId: this.props.id,
//             opId: this.props.userInfo.opId,
//             buId: this.props.userInfo.buId,
//             createdBy: this.props.userInfo.id,
//             createdDate: moment().format('DD-MM-YYYY'),
//           };
//         }),
//       };
//       axios
//         .post('mtn/siebel/config/attrFlag', payload, {})
//         .then((response) => {})
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     }
//   }

//   savePkgAttrDetailsHandler = (event) => {
//     event.preventDefault();
//     if (this.props.id) {
//       this.saveProductFlag();
//       this.saveAttrFlag();
//       let errors = [];
//       Object.keys(this.state.selAttrGrps).map((attrGrp) => {
//         this.state.selAttrGrps[attrGrp][['attributes']].map((attribute) => {
//           if (
//             !document.getElementById(
//               attribute.attrGrpDescription + attribute.ppmAttrName
//             ).validity.valid
//           ) {
//             errors.push(
//               attribute.attrGrpDescription + ' - ' + attribute.ppmAttrName
//             );
//           }
//         });
//       });
//       this.setState({ errors: errors });
//       // if (errors.length === 0) {
//       this.setState({ loading: true });
//       let payload = {};
//       let ppmProdAttrGroupsAudWrapper = [];
//       let ppmProdAttributesAudWrapper = [];
//       Object.keys(this.state.selAttrGrps).forEach((key) => {
//         let obj = this.state.selAttrGrps[key].attrGrp;
//         obj.productId = this.props.id;
//         obj.version = '1.0';
//         obj.attrGrpMapId = this.state.selAttrGrps[key].attrGrp.attrGrpId;
//         obj.buId = this.state.selAttrGrps[key].attrGrp.buid
//           ? this.state.selAttrGrps[key].attrGrp.buid
//           : this.props.userInfo.buId;
//         obj.opId = this.state.selAttrGrps[key].attrGrp.opid
//           ? this.state.selAttrGrps[key].attrGrp.opid
//           : this.props.userInfo.opId;
//         ppmProdAttrGroupsAudWrapper.push(obj);

//         this.state.selAttrGrps[key].attributes.map((attribute) => {
//           console.log(attribute);
//           console.log(key);
//           let objAttr = { ...obj, ...attribute };
//           objAttr.isMandatory = 'Y';
//           objAttr.productAttributeId = attribute.ppmAttrId;
//           objAttr.productAttributeKey = attribute.ppmAttrName;
//           // objAttr.productAttributeValue = attribute.ppmAttrName;
//           objAttr.ppmAttrValueType = attribute.ppmAttrType;

//           if (attribute.ppmAttrType === 'MULTI-SELECT') {
//             // objAttr.defaultValue = attribute.defaultValue.join();
//             objAttr.productAttributeValue = this.state[
//               attribute.attrGrpDescription + attribute.ppmAttrName
//             ]
//               ? this.state[
//                   attribute.attrGrpDescription + attribute.ppmAttrName
//                 ].join()
//               : objAttr.defaultValue;
//           } else
//             objAttr.productAttributeValue = this.state[
//               attribute.attrGrpDescription + attribute.ppmAttrName
//             ]
//               ? this.state[attribute.attrGrpDescription + attribute.ppmAttrName]
//               : objAttr.defaultValue;
//           objAttr.ppmAttrValue = attribute.ppmAttrValue;
//           ppmProdAttributesAudWrapper.push(objAttr);
//         });
//       });
//       payload.releaseId = this.props.releaseData.releaseId;
//       payload.id = this.props.id;
//       payload.ppmProdAttrGroupsAudWrapper = ppmProdAttrGroupsAudWrapper;
//       payload.ppmProdAttributesAudWrapper = ppmProdAttributesAudWrapper;
//       console.log(payload);
//       axios
//         .post('package/attrGrp/mapping', payload, {
//           headers: {
//             opId: this.props.userInfo.opId,
//           },
//         })
//         .then((response) => {
//           console.log(response);
//           if (this._isMounted)
//             this.setState({
//               loading: false,
//               openSnack: true,
//               messageSnack: 'Attribute Details Saved Successfully',
//             });
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//       //}
//       // else {
//       //     let modalContent = <List
//       //         style={{ maxHeight: 200, overflow: 'auto' }}
//       //         component="nav"
//       //         aria-labelledby="nested-list-subheader"
//       //     >
//       //         {errors.map((error) => {
//       //             return (
//       //                 <ListItem button key={error}>
//       //                     <ListItemIcon>
//       //                         <AppsIcon style={{ color: '#3f74c5' }} />
//       //                     </ListItemIcon>
//       //                     <ListItemText primary={'Attribute ' + error + ' is required.'} />
//       //                 </ListItem>
//       //             )
//       //         })
//       //         }
//       //     </List>
//       //     this.setState({ modalContent: modalContent, show: true })
//       // }
//     } else {
//       let modalContent = (
//         <Typography variant='h6'>
//           {' '}
//           Submit Basic {this.props.entity} Details first on General screen.{' '}
//         </Typography>
//       );
//       this.setState({ modalContent: modalContent, show: true });
//     }
//   };
//   errorConfirmedHandler = () => {
//     this.setState({ show: false });
//   };
//   render() {
//     const { classes, access } = this.props;
//     let attribute = (
//       <React.Fragment>
//         {console.log(this.state.selAttrGrp)}
//         <Loader hide={this.state.loading ? false : true} />
//         <Modal
//           show={this.state.show}
//           modalClosed={this.errorConfirmedHandler}
//           title={'Something Went Wrong!'}
//         >
//           {this.state.modalContent}
//         </Modal>
//         <Grid
//           container
//           alignItems='flex-end'
//           spacing={2}
//           style={{ display: !this.state.loading ? 'block' : 'none' }}
//         >
//           <Snackbar
//             open={this.state.openSnack}
//             message={this.state.messageSnack}
//             onClose={(event, reason) => {
//               if (reason === 'clickaway') {
//                 return;
//               }
//               this.setState({ openSnack: false });
//             }}
//           />
//           <Grid item xs={12}>
//             <Card>
//               <CardHeader
//                 className={classes.cardHeader}
//                 classes={{
//                   subheader: classes.subheader,
//                 }}
//                 subheader={'Selected Product Class'}
//               />

//               <CardContent>
//                 {console.log('this.state.selAttrGrps', this.state.selAttrGrps)}
//                 {Object.keys(this.state.selAttrGrps).length ? (
//                   <form>
//                     {Object.keys(this.state.selAttrGrps).map((attrGrp) => {
//                       return (
//                         <Accordion key={attrGrp}>
//                           <AccordionSummary
//                             aria-controls='panel1bh-content'
//                             id='panel1bh-header'
//                           >
//                             <ExpandMoreIcon />
//                             <Typography className={classes.heading}>
//                               {attrGrp}
//                             </Typography>
//                           </AccordionSummary>
//                           <AccordionDetails style={{ display: 'block' }}>
//                             <List
//                               component='nav'
//                               aria-labelledby='nested-list-subheader'
//                               style={{
//                                 width: '100%',
//                                 maxHeight: '30vh',
//                                 overflow: 'auto',
//                               }}
//                             >
//                               {this.state.selAttrGrps[attrGrp][
//                                 ['attributes']
//                               ].map((attribute) => {
//                                 let input = (
//                                   <TextField
//                                     style={{ minWidth: '20%' }}
//                                     placeholder={attribute.ppmAttrName}
//                                     defaultValue={attribute.defaultValue}
//                                     id={
//                                       attribute.attrGrpDescription +
//                                       attribute.ppmAttrName
//                                     }
//                                     value={
//                                       this.state[
//                                         attribute.attrGrpDescription +
//                                           attribute.ppmAttrName
//                                       ]
//                                     }
//                                     onChange={(event) =>
//                                       this.setState({
//                                         [attribute.attrGrpDescription +
//                                         attribute.ppmAttrName]:
//                                           event.target.value,
//                                       })
//                                     }
//                                     required={true}
//                                   />
//                                 );

//                                 if (attribute.ppmAttrType === 'LIST') {
//                                   input = (
//                                     <FormControl style={{ minWidth: '20%' }}>
//                                       <Select
//                                         name={attribute.ppmAttrName}
//                                         defaultValue={attribute.defaultValue}
//                                         MenuProps={MenuProps}
//                                         displayEmpty
//                                         value={
//                                           this.state[
//                                             attribute.attrGrpDescription +
//                                               attribute.ppmAttrName
//                                           ]
//                                         }
//                                         onChange={(event) => {
//                                           console.log(event.target.value);
//                                           this.setState({
//                                             [attribute.attrGrpDescription +
//                                             attribute.ppmAttrName]:
//                                               event.target.value,
//                                           });
//                                         }}
//                                         input={
//                                           <Input
//                                             required={true}
//                                             id={
//                                               attribute.attrGrpDescription +
//                                               attribute.ppmAttrName
//                                             }
//                                           />
//                                         }
//                                         renderValue={(selected) => {
//                                           if (selected) {
//                                             if (selected.length === 0) {
//                                               return (
//                                                 <em>{attribute.ppmAttrName}</em>
//                                               );
//                                             }

//                                             return selected;
//                                           }
//                                         }}
//                                         inputProps={{
//                                           'aria-label': 'Without label',
//                                         }}
//                                       >
//                                         <MenuItem disabled value=''>
//                                           <em>{attribute.ppmAttrName}</em>
//                                         </MenuItem>
//                                         {attribute.ppmAttrValue &&
//                                           attribute.ppmAttrValue
//                                             .split(',')
//                                             .map((name) => (
//                                               <MenuItem key={name} value={name}>
//                                                 {name}
//                                               </MenuItem>
//                                             ))}
//                                       </Select>
//                                     </FormControl>
//                                   );
//                                 } else if (
//                                   attribute.ppmAttrType === 'MULTI-SELECT'
//                                 ) {
//                                   input = (
//                                     <FormControl style={{ minWidth: '20%' }}>
//                                       <Select
//                                         multiple
//                                         value={
//                                           this.state[
//                                             attribute.attrGrpDescription +
//                                               attribute.ppmAttrName
//                                           ]
//                                             ? this.state[
//                                                 attribute.attrGrpDescription +
//                                                   attribute.ppmAttrName
//                                               ]
//                                             : []
//                                         }
//                                         onChange={(event) => {
//                                           console.log(event.target.value);
//                                           this.setState({
//                                             [attribute.attrGrpDescription +
//                                             attribute.ppmAttrName]:
//                                               event.target.value,
//                                           });
//                                         }}
//                                         input={
//                                           <Input
//                                             required={true}
//                                             id={
//                                               attribute.attrGrpDescription +
//                                               attribute.ppmAttrName
//                                             }
//                                           />
//                                         }
//                                         renderValue={(selected) => {
//                                           if (selected) {
//                                             if (selected.length === 0) {
//                                               return <em>Value</em>;
//                                             }
//                                             console.log(selected);
//                                             if (selected) {
//                                               selected = selected.filter(
//                                                 function (value) {
//                                                   return value !== undefined;
//                                                 }
//                                               );

//                                               return selected.join();
//                                             } else return '';
//                                           }
//                                         }}
//                                         MenuProps={MenuProps}
//                                       >
//                                         {attribute.ppmAttrValue
//                                           .split(',')
//                                           .map((name) => (
//                                             <MenuItem key={name} value={name}>
//                                               <Checkbox
//                                                 style={{ color: '#3f74c5' }}
//                                                 checked={
//                                                   this.state[
//                                                     attribute.attrGrpDescription +
//                                                       attribute.ppmAttrName
//                                                   ]
//                                                     ? this.state[
//                                                         attribute.attrGrpDescription +
//                                                           attribute.ppmAttrName
//                                                       ].indexOf(name) > -1
//                                                     : false
//                                                 }
//                                               />
//                                               <ListItemText primary={name} />
//                                             </MenuItem>
//                                           ))}
//                                       </Select>
//                                     </FormControl>
//                                   );
//                                 }
//                                 return (
//                                   <React.Fragment key={attribute.ppmAttrName}>
//                                     {/* {attribute.ppmAttrName} */}
//                                     <ListItem>
//                                       <ListItemText
//                                         primary={attribute.ppmAttrName}
//                                       />
//                                       {input}
//                                     </ListItem>
//                                     <Divider />
//                                   </React.Fragment>
//                                 );
//                               })}
//                             </List>
//                           </AccordionDetails>
//                         </Accordion>
//                       );
//                     })}
//                   </form>
//                 ) : (
//                   <div>No selected product class</div>
//                 )}
//               </CardContent>
//             </Card>
//           </Grid>

//           <Grid item xs={12}>
//             <Card>
//               <CardHeader
//                 className={classes.cardHeader}
//                 classes={{
//                   subheader: classes.subheader,
//                 }}
//                 subheader={'Product Flags Configuration'}
//               />

//               <CardContent style={{ paddingBottom: '60px' }}>
//                 <Grid container spacing={2}>
//                   {this.state.productFlags.map((formElement) => {
//                     let override = {};
//                     if (formElement.refName === 'relationship') {
//                       if (
//                         this.props.history.location.pathname ===
//                         '/productConfiguration'
//                       ) {
//                         return <></>;
//                       }
//                       override = {
//                         refType: 'SelectInput',
//                         refLovs: this.state.relationshipDD,
//                       };
//                     }
//                     return formElement.refType !== 'SelectInput' ||
//                       formElement.refType !== 'MultiSelect' ? (
//                       <Input2
//                         //resize
//                         key={formElement.refName}
//                         access='R'
//                         {...formElement}
//                         {...override}
//                         // readOnly={true}
//                         // disabled={formElement.isDisabled == "Y" ? true : false}
//                         // required={formElement.isMandatory == "Y" ? true : false}
//                         value={
//                           this.state.productFlagFields[formElement.refName]
//                         }
//                         changed={(event) => {
//                           console.log(event);
//                           if (!event.target) {
//                             this.setState({
//                               productFlagFields: {
//                                 ...this.state.productFlagFields,
//                                 [formElement.refName]: event,
//                               },
//                             });
//                           } else {
//                             if (event.target.type !== 'checkbox') {
//                               console.log(event.target.value);
//                               this.setState({
//                                 productFlagFields: {
//                                   ...this.state.productFlagFields,
//                                   [formElement.refName]: event.target.value,
//                                 },
//                               });
//                             } else
//                               this.setState({
//                                 productFlagFields: {
//                                   ...this.state.productFlagFields,
//                                   [formElement.refName]:
//                                     event.target.checked === true ? 'Y' : 'N',
//                                 },
//                               });
//                           }
//                         }}
//                       />
//                     ) : (
//                       <CustomInput
//                         resize
//                         refType='SelectInput'
//                         value={
//                           this.state.productFlagFields[formElement.refName]
//                         }
//                         changed={(event) => {
//                           console.log(event);
//                           if (!event.target) {
//                             this.setState({
//                               productFlagFields: {
//                                 ...this.state.productFlagFields,
//                                 [formElement.refName]: event,
//                               },
//                             });
//                           } else {
//                             if (event.target.type !== 'checkbox') {
//                               console.log(event.target.value);
//                               this.setState({
//                                 productFlagFields: {
//                                   ...this.state.productFlagFields,
//                                   [formElement.refName]: event.target.value,
//                                 },
//                               });
//                             } else
//                               this.setState({
//                                 productFlagFields: {
//                                   ...this.state.productFlagFields,
//                                   [formElement.refName]:
//                                     event.target.checked === true ? 'Y' : 'N',
//                                 },
//                               });
//                           }
//                         }}
//                         access={access}
//                       />
//                     );
//                   })}
//                 </Grid>
//               </CardContent>
//             </Card>
//           </Grid>

//           <Grid item xs={12}>
//             {/* style={{ display: 'none' }} */}
//             <Card>
//               <CardHeader
//                 className={classes.cardHeader}
//                 classes={{
//                   subheader: classes.subheader,
//                 }}
//                 subheader={'Attribute Flags Configuration'}
//               />

//               <CardContent>
//                 {console.log('columns', this.state.attributeFlags)}
//                 {console.log('data', this.state.attributeFlagFields)}

//                 {this.state.attributeFlagFields.map((value, i) => (
//                   <Grid container spacing={2}>
//                     {this.state.attributeFlags.map((formElement) => (
//                       <Input2
//                         key={formElement.refName}
//                         access={access}
//                         {...formElement}
//                         disabled={formElement.isDisabled == 'Y' ? true : false}
//                         required={formElement.isMandatory == 'Y' ? true : false}
//                         value={
//                           value[formElement.refName]
//                           // this.state.attributeFlagFields &&
//                           // this.state.attributeFlagFields[formElement.refName]
//                         }
//                         changed={(event) => {
//                           console.log(event);

//                           if (!event.target) {
//                             this.setState({
//                               attributeFlagFields:
//                                 this.state.attributeFlagFields.map(
//                                   (attr2, k) => {
//                                     console.log('1', attr2, k, i);

//                                     if (k === i) {
//                                       return {
//                                         ...attr2,

//                                         [formElement.refName]: event,
//                                         //set here
//                                       };
//                                     }
//                                     return attr2;
//                                   }
//                                 ),
//                             });
//                           } else {
//                             if (event.target.type !== 'checkbox')
//                               this.setState({
//                                 attributeFlagFields:
//                                   this.state.attributeFlagFields.map(
//                                     (attr2, k) => {
//                                       console.log('2', attr2, k, i);
//                                       console.log('event', event);
//                                       console.log('value', value);

//                                       if (k === i) {
//                                         return {
//                                           ...attr2,
//                                           [formElement.refName]:
//                                             event.target.value,
//                                         };
//                                       }
//                                       return attr2;
//                                     }
//                                   ),
//                               });
//                             else
//                               this.setState({
//                                 attributeFlagFields:
//                                   this.state.attributeFlagFields.map(
//                                     (attr2, k) => {
//                                       console.log('3', attr2, k, i);

//                                       if (k === i) {
//                                         return {
//                                           ...attr2,
//                                           [formElement.refName]:
//                                             event.target.value,
//                                         };
//                                       }
//                                       return attr2;
//                                     }
//                                   ),
//                               });
//                           }
//                         }}
//                       />
//                     ))}
//                   </Grid>
//                 ))}
//                 {/* <MaterialTable
//                   icons={TABLE_ICONS}
//                   columns={this.state.allColumns}
//                   data={
//                     this.state.attributeFlagFields
//                       ? this.state.attributeFlagFields
//                       : []
//                   }
//                   options={{
//                     paging: false,
//                     showTitle: false,
//                     search: false,
//                   }}
//                   components={{
//                     Toolbar: (props) => (
//                       <div
//                         style={{
//                           textAlign: 'right',
//                           padding: '10px',
//                         }}
//                       >
//                         <Button
//                           style={{
//                             background: '#546D7A',
//                             color: '#fff',
//                           }}
//                           onClick={() => this.addRow()}
//                         >
//                           ADD
//                         </Button>
//                       </div>
//                     ),
//                   }}
//                 /> */}
//               </CardContent>
//             </Card>
//           </Grid>
//         </Grid>
//       </React.Fragment>
//     );

//     return attribute;
//   }
// }

// export default withRouter(
//   withStyles(useStyles)(WithErrorHandler(Attribute, axios))
// );
