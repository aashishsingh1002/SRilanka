import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import axios from '../../../axios-epc';

export const getVersions = async ({ userInfo, entity }) => {
  try {
    const result = await axios.get(`config/version?entityName=${entity}`, {
      headers: {
        opId: userInfo.opId,
        buId: userInfo.buId,
      },
    });
    const { version } = result.data.data;
    return version;
  } catch (err) {
    throw new Error(err);
  }
};

const getStorage = (entity) => {
  try {
    return JSON.parse(localStorage.getItem(entity));
  } catch (e) {
    localStorage.removeItem(entity);
  }
};

const mapSchema = (data = []) => {
  return data.map(function (el) {
    if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
      if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
      else if (el.refLovs == null) el.refLovs = [];
    }
    return el;
  });
};

export const getUiFields = async ({ userInfo, entity, version }) => {
  try {
    const storageVersion = `${entity}_version`;
    if (
      localStorage.getItem(entity) &&
      localStorage[storageVersion] &&
      localStorage[storageVersion] === version
    ) {
      return getStorage(entity);
    } else {
      const res = await axios.get(`config?entityName=${entity}`, {
        headers: {
          opId: userInfo.opId,
          buId: userInfo.buId,
        },
      });

      const tmpSchema = mapSchema(res.data.data);
      localStorage.setItem(entity, JSON.stringify(tmpSchema));
      localStorage[storageVersion] = version;

      return tmpSchema;
    }
  } catch (err) {
    throw new Error(err);
  }
};

export const saveAsExcel = async ({
  schema = [],
  name = '',
  data = [],
  derived = false,
}) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(name);
  let sheetColumns = schema.map((row) => ({
    header: row.uiName ? row.uiName : row.title,
    key: row.refName ? row.refName : row.field,
    width: 25,
  }));

  worksheet.columns = sheetColumns;

  data.map((row) => {
    worksheet.addRow(row);
  });

  worksheet.getRow(1).font = { bold: true };

  const appendName = derived ? 'Derived_Export' : 'UI_Export';
  const buf = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buf]), `${name}_${appendName}.xlsx`);

  return true;
};
