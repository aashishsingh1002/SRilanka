import { useState, useEffect } from "react";
import axios from "axios";
import { useSelector } from "react-redux";

const useAPI = (url, config = {}) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);

  useEffect(() => {
    let unmounted = false;
    let source = axios.CancelToken.source();
    let headers = {};
    // if (config.withDefaultHeaders) {
    const { opId, buId } = userInfo;
    headers = { ...headers, opId, buId };
    // }
    axios
      .get(`${process.env.REACT_APP_URL}${url}`, {
        cancelToken: source.token,
        headers,
      })
      .then((res) => {
        if (!unmounted) {
          if (res) {
            setData(res.data.data);
          }
          setLoading(false);
        }
      })
      .catch((error) => {
        setLoading(false);
      });

    return () => {
      unmounted = true;
      source.cancel("Cancelling in cleanup");
    };
  }, []);

  return [data, loading];
};

export default useAPI;
