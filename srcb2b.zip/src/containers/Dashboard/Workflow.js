
import React, { Component } from "react";
import ModalAction from "../../UI/ModalAction/ModalAction";
import Loader from "../../UI/Loader/Loader";
import axios from "../../axios-epc";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import { withStyles } from "@material-ui/core/styles";
import Accordion from "@material-ui/core/Accordion";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Autocomplete from "@material-ui/lab/Autocomplete";
import TextField from "@material-ui/core/TextField";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';

const useStyles = (theme) => ({
  center: {
    textAlign: "center",
  },
  root: {
    "& .MuiPaper-root": {
      width: "100%",
    },
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "33.33%",
    flexShrink: 0,
  },
});

class Workflow extends Component {
  _isMounted = false;
  state={
    approvers:{}
  }
  constructor(props) {
    super(props);
    let workflow = {};
    let smsNotiData = {};
    
console.log('apps',this.state.approvers)
    // Object.keys(props.approvers).forEach((key) => {
    //   props.approvers[key].filter((el) => {
    //     smsNotiData[el["grpName"]] = {
    //       primarymail: el["primarysignatory"][0]
    //         ? el["primarysignatory"][0]
    //         : null,
    //       secondarymail: el["primarysignatory"][1]
    //         ? el["primarysignatory"][1]
    //         : null,
    //     };
    //     if (el["disabled"] == "true") workflow[el["varName"]] = "Mandatory";
    //     else workflow[el["varName"]] = "FYI";
    //   });
    // });
    // cellStyle: { width: '20%' }
    this.state = {
      showModal: false,
      show: true,
      loading: true,
      expanded: false,
      worklowVariables: {  },
      smsNotiData: {  },
      data: [],
     // role: localStorage.getItem("SelectedType"),
    };
  }
  workflowVariableChangeHandler(event, varName) {
    let worklowVariables = {
      ...this.state.worklowVariables,
    };
    worklowVariables[varName] = event.target.value;
    this.setState({ worklowVariables: worklowVariables });
  }

  modalCloseHandler = () => {
    this.setState({ show: false });
    this.props.showWorkflow();
  };

  componentWillUnmount() {
    this._isMounted = false;
  }



  approversDataHandler(productId) {
    return axios
      .get("/b2b-workflow/approvers/v2?replicationStatus="+productId, {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
          // lob: 'Postpaid',
          // circle: 'Hobs',
          //circle: this.props.userInfo.circle,
					//	role: localStorage.getItem("SelectedType")
          //role: this.props.userInfo.group[0]
          authUserId: this.props.userInfo.id,
            authGroupId: this.props.userInfo.group[0],
            Authorization: 'Bearer ' + this.props.userInfo.jwt
        },
      })
      .then((res) => {
        console.log(res);
        if (res) {
          let workflow = {};
          let smsNotiData = {};
console.log(res.data.data)
          Object.keys(res.data.data).forEach((key) => {
            res.data.data[key].filter((el) => {
              smsNotiData[el['grpName']] = {
                primarymail: el['primarysignatory'][0]
                  ? el['primarysignatory'][0]
                  : null,
                secondarymail: el['primarysignatory'][1]
                  ? el['primarysignatory'][1]
                  : null,
              };
              if (el['disabled'] == 'true')
                workflow[el['varName']] = 'Mandatory';
              else workflow[el['varName']] = 'FYI';
            });
          });
          this.setState({
            approvers: { ...res.data.data },
            worklowVariables: workflow,
            smsNotiData,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }


  componentDidMount = () => {
    this._isMounted = true;
    this.approversDataHandler(this.props.releaseData.replicationStatus).then(()=>{
    if (this._isMounted) this.setState({ loading: false });
  });
    console.log("mounted" + this.props.releaseData.releaseId);
    console.log(this.state.approvers);
  };
  changeHandler = (panel) => (event, isExpanded) => {
    this.setState({ expanded: isExpanded ? panel : false });
  };
  initiateApprovalHandler = () => {
    console.log(this.props.releaseData.pendingWith);
    if (this.props.releaseData.pendingWith == "WorkFlow Not Initiated") {
      this.setState({ loading: true });
      let roles = [];
      Object.keys(this.state.approvers).map((role) => {
        this.state.approvers[role].map((approver) => {
          let obj = {};
          obj.taskName = approver.role;
          obj.primaryMail =
            this.state.smsNotiData[approver.grpName].primarymail;
          obj.secondaryMail =
            this.state.smsNotiData[approver.grpName].secondarymail;
          obj.varName = approver.varName;
          obj.value =
            this.state.worklowVariables[approver.varName].toLowerCase();
            obj.medium='email'
          roles.push(obj);
        });
      });
      let payloadWorkflowStart = {};
      payloadWorkflowStart.replicationStatus=this.props.releaseData.replicationStatus
      payloadWorkflowStart.releaseNbr=this.props.releaseData.releaseNbr;
      payloadWorkflowStart.approvers=roles
      let url = 'b2b-workflow/initiate/workflow';
      console.log(url);
      console.log("url hit");
      console.log("opid" + this.props.userInfo.opId);
      console.log('payloadvar',payloadWorkflowStart)
      axios
        .post(url,payloadWorkflowStart,{headers:{buId: this.props.userInfo.buId,
          opId: this.props.userInfo.opId,
          authUserId:this.props.userInfo.id,
          authGroupId:this.props.userInfo.group[0],
          Authorization: 'Bearer ' + this.props.userInfo.jwt,}} )
        .then((response) => {
          debugger;
          this.modalCloseHandler();
          window.location.reload();
        })
        .catch((error) => {
          console.log(error);
          this.setState({ loading: false });
        });
    } else this.setState({ showModal: true });
  };
  render() {
    const { classes } = this.props;
    let panels = [];
    {console.log('np',this.state.approvers)}
    this.state.approvers && Object.keys(this.state.approvers).forEach((key) => {
      let panel = null;
      panel = (
        <Accordion
          key={key}
          expanded={this.state.expanded === key}
          onChange={this.changeHandler(key)}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1bh-content"
            id="panel1bh-header"
          >
            <Typography className={classes.heading}>{key}</Typography>
          </AccordionSummary>
          <AccordionDetails style={{ display: "block" }}>
            <TableContainer component={Paper} style={{ overflow: "visible" }}>
              <Table aria-label="collapssible table">
                <TableHead>
                  <TableRow>
                    <TableCell>Group</TableCell>
                    <TableCell>Primary Signatory</TableCell>
                    <TableCell>Secondary Signatory</TableCell>
                    <TableCell>Mandatory/FYI/NA</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Object.keys(this.state.approvers).length>0 && this.state.approvers[key].map((row) => {
                    return (
                      <TableRow className={classes.root} key={row.grpName}>
                        <TableCell style={{ width: "15%" }}>
                          {row.grpName}
                        </TableCell>

                        <TableCell style={{ width: "25%" }}>
                          <Autocomplete
                            disableClearable
                            value={
                              this.state.smsNotiData[row.grpName].primarymail
                            }
                            options={row.primarysignatory}
                            onChange={(event, selected) => {
                              let smsNotiData = {
                                ...this.state.smsNotiData,
                              };
                              let approveData = {
                                ...smsNotiData[[row.grpName]],
                              };
                              approveData.primarymail = selected;
                              smsNotiData[row.grpName] = approveData;
                              this.setState({ smsNotiData: smsNotiData });
                            }}
                            renderInput={(params) => (
                              <TextField {...params} margin="normal" />
                            )}
                          />
                        </TableCell>

                        <TableCell style={{ width: "25%" }}>
                          <Autocomplete
                            disableClearable
                            onChange={(event, selected) => {
                              let smsNotiData = {
                                ...this.state.smsNotiData,
                              };
                              let approveData = {
                                ...smsNotiData[[row.grpName]],
                              };
                              approveData.secondarymail = selected;
                              smsNotiData[row.grpName] = approveData;
                              this.setState({ smsNotiData: smsNotiData });
                            }}
                            value={
                              this.state.smsNotiData[row.grpName].secondarymail
                            }
                            options={row.primarysignatory}
                            renderInput={(params) => (
                              <TextField {...params} margin="normal" />
                            )}
                          />
                        </TableCell>

                        <TableCell style={{ width: "35%" }}>
                          <RadioGroup
                            row
                            aria-label="position"
                            name="position"
                            onChange={(event) =>
                              this.workflowVariableChangeHandler(
                                event,
                                row["varName"]
                              )
                            }
                            value={this.state.worklowVariables[row["varName"]]}
                          >
                            <FormControlLabel
                              value={"Mandatory"}
                              control={<Radio style={{ color: "#ff1921" }} />}
                              label="Mandatory"
                              disabled={row.disabled == "true" ? true : false}
                            />
                            <FormControlLabel
                              value="FYI"
                              control={<Radio style={{ color: "#ff1921" }} />}
                              label="FYI"
                              disabled={row.disabled == "true" ? true : false}
                            />
                            <FormControlLabel
                              disabled={row.disabled == "true" ? true : false}
                              value="NA"
                              control={<Radio style={{ color: "#ff1921" }} />}
                              label="NA"
                            />
                          </RadioGroup>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </AccordionDetails>
        </Accordion>
      );
      panels.push(panel);
    });
    let modalChild = panels;
    if (this.state.showModal)
      modalChild = (
        <Typography variant="h5" className={classes.center}>
          {" "}
          WorkFlow Already Initiated
        </Typography>
      );
    else if (this.state.loading)
      modalChild = (
        <div style={{ minHeight: "25vh" }}>
          {" "}
          <Loader />{" "}
        </div>
      );

    let workflow = (
      <ModalAction
        show={this.state.show}
        modalClosed={this.modalCloseHandler}
        data={this.props.releaseData}
        actionText={"Initiate Approval"}
        title={"Release Id " + this.props.releaseData.externalReleaseId}
        action={this.initiateApprovalHandler}
      >
        <div className={classes.root} style={{ minHeight: "25vh" }}>
          {modalChild}
        </div>
      </ModalAction>
    );

    

    return workflow;
  }
}

export default withStyles(useStyles)(WithErrorHandler(Workflow, axios));







