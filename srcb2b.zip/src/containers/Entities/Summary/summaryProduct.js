import React, { Component } from "react";
import axios from "axios";
import Loader from "../../../UI/Loader/Loader";
import WithErrorHandler from "../../../HOC/WithErrorHandler/WithErrorHandler";
import Input from "../../../UI/Input/Input";
import Grid from "@material-ui/core/Grid";
// import Button from "@material-ui/core/Button";
import moment from "moment";
import { connect } from "react-redux";
import * as actionTypes from "../../../store/actions/actionTypes";
import { withStyles } from "@material-ui/core/styles";
import Snackbar from "../../../UI/Snackbar/Snackbar";
import Button from "../../../UI/Button/Button";

const useStyles = () => ({
  btn: {
    textTransform: "unset !important",
  },
});

class BasicDetails extends Component {
  _isMounted = false;

  state = {
    messageSnack: "",
    openSnack: false,
    version: "",
    versionCts: "",
    loading: true,
    categories: [],
    types: [],
    subTypes: [],
    schema: [],
    postRequest: true,
    categoryWatch: true,
    typeWatch: true,
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState["productCategoryId"] !== this.state["productCategoryId"]) {
      if (!this.state.categoryWatch) {
        this.setState({ categoryWatch: true });
      } else {
        let typesLov = [];
        this.state.types.map((type) => {
          if (type.refName.startsWith(this.state["productCategoryId"]))
            typesLov.push(
              type.refName.substr(this.state["productCategoryId"].length + 1)
            );
        });
        console.log(typesLov);

        let schema = [...this.state.schema];

        schema.map((el) => {
          if (el.refName == "productTypeId") {
            el.refLovs = typesLov;
          }
          if (el.refName == "productSubTypeId") {
            el.refLovs = [];
          }
        });

        this.setState({
          schema: schema,
          ["productTypeId"]: "",
          ["productSubTypeId"]: "",
        });
      }
    } else if (prevState["productTypeId"] !== this.state["productTypeId"]) {
      if (!this.state.typeWatch) {
        this.setState({ typeWatch: true });
      } else {
        if (this.state["productTypeId"]) {
          let subtypesLov = [];
          this.state.subTypes.map((subType) => {
            if (
              subType.refName.startsWith(
                this.state["productCategoryId"] +
                  "-" +
                  this.state["productTypeId"]
              )
            )
              subtypesLov.push(
                subType.refName.substr(
                  (
                    this.state["productCategoryId"] +
                    "-" +
                    this.state["productTypeId"]
                  ).length + 1
                )
              );
          });
          console.log(subtypesLov);

          let schema = [...this.state.schema];

          schema.map((el) => {
            if (el.refName == "productSubTypeId") {
              el.refLovs = subtypesLov;
            }
          });

          this.setState({ schema: schema, ["productSubTypeId"]: "" });
        }
      }
    }
  }
  componentDidMount() {
    this._isMounted = true;
    this.versions().then(() => {
      this.uiFields().then(() => {
        this.fieldsLov().then(() => {
          let categoryLovs = [];
          this.state.categories.map((category) => {
            categoryLovs.push(category.refName);
          });
          let schema = [...this.state.schema];
          schema.map((el) => {
            if (el.refName == "productCategoryId") {
              el.refLovs = categoryLovs;
            }
          });
          this.setState({
            schema: schema,
          });
          this.state.schema.map((formElement) => {
            if (formElement.refType == "Date")
              this.setState({
                [formElement.refName]: formElement.defaultValue
                  ? moment(formElement.defaultValue).format("DD-MMM-YY")
                  : moment().format("DD-MMM-YY"),
              });
            else if (formElement.refType == "TextInput" || "TextArea")
              this.setState({
                [formElement.refName]: formElement.defaultValue,
              });
          });
          this.ifInProduct().then(() => {
            this.setState({ loading: false });
          });
        });
      });
    });
  }

  ifInProduct() {
    if (this.props.productData.productId) {
      return axios
        .get(
          process.env.REACT_APP_URL +
            "product/basicDetails?productId=" +
            this.props.productData.productId +
            "&releaseID=" +
            this.props.releaseData.releaseId,
          {
            headers: {
              opId: this.props.userInfo.opId,
              createdBy: this.props.userInfo.id,
            },
          }
        )
        .then((res) => {
          console.log("response data");
          console.log(res);
          let typesLov = [];
          this.state.types.map((type) => {
            if (type.refName.startsWith(res.data.data.productCategoryId))
              typesLov.push(
                type.refName.substr(res.data.data.productCategoryId.length + 1)
              );
          });
          let subtypesLov = [];
          this.state.subTypes.map((subType) => {
            if (
              subType.refName.startsWith(
                res.data.data.productCategoryId +
                  "-" +
                  res.data.data.productTypeId
              )
            )
              subtypesLov.push(
                subType.refName.substr(
                  (
                    res.data.data.productCategoryId +
                    "-" +
                    res.data.data.productTypeId
                  ).length + 1
                )
              );
          });

          let schema = [...this.state.schema];
          console.log(typesLov);
          console.log(subtypesLov);
          schema.map((el) => {
            if (el.refName == "productSubTypeId") {
              el.refLovs = subtypesLov;
            }
            if (el.refName == "productTypeId") {
              el.refLovs = typesLov;
            }
          });

          this.setState({
            schema: schema,
            ["productSubTypeId"]: "",
            categoryWatch: false,
            typeWatch: false,
            postRequest: false,
          });

          Object.keys(res.data.data).forEach((key) => {
            this.setState({ [key]: res.data.data[key] });
          });
          this.props.onProductEnter(res.data.data);
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      return Promise.resolve();
    }
  }



  
  versions() {
    return axios
      .all([
        axios.get(
          process.env.REACT_APP_URL + "config/version?entityName=product.cts",
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
            },
          }
        ),
        axios.get(
          process.env.REACT_APP_URL +
            "config/version?entityName=product.basicDetails",
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
            },
          }
        ),
      ])
      .then(
        axios.spread((ctsVersion, basicDetailsVersion) => {
          if (this._isMounted)
            this.setState({
              version: basicDetailsVersion.data.data.version,
              versionCts: ctsVersion.data.data.version,
            });
        })
      )
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  fieldsLov() {
    if (
      localStorage.getItem("productCategories") &&
      localStorage.getItem("productSubTypes") &&
      localStorage.getItem("productTypes") &&
      localStorage.productCts_version &&
      localStorage.productCts_version == this.state.versionCts
    ) {
      console.log("fetching cts from local storage");
      try {
        this.setState({
          categories: JSON.parse(localStorage.getItem("productCategories")),
          subTypes: JSON.parse(localStorage.getItem("productSubTypes")),
          types: JSON.parse(localStorage.getItem("productTypes")),
        });
      } catch (e) {
        localStorage.removeItem("productCategories");
        localStorage.removeItem("productSubTypes");
        localStorage.removeItem("productTypes");
      }
      return Promise.resolve();
    } else {
      console.log("fetching cst from api");
      return axios
        .all([
          axios.get(
            process.env.REACT_APP_URL +
              "config?entityName=product.categoryList",
            {
              headers: {
                opId: this.props.userInfo.opId,
                buId: this.props.userInfo.buId,
              },
            }
          ),
          axios.get(
            process.env.REACT_APP_URL + "config?entityName=product.subTypeList",
            {
              headers: {
                opId: this.props.userInfo.opId,
                buId: this.props.userInfo.buId,
              },
            }
          ),
          axios.get(
            process.env.REACT_APP_URL + "config?entityName=product.typeList",
            {
              headers: {
                opId: this.props.userInfo.opId,
                buId: this.props.userInfo.buId,
              },
            }
          ),
        ])
        .then(
          axios.spread((resCategories, resSubTypes, resTypes) => {
            let types = resTypes.data.data;
            localStorage.setItem("productTypes", JSON.stringify(types));
            let subTypes = resSubTypes.data.data;
            localStorage.setItem("productSubTypes", JSON.stringify(subTypes));
            let categories = resCategories.data.data;
            localStorage.setItem(
              "productCategories",
              JSON.stringify(categories)
            );
            if (this._isMounted)
              this.setState({
                categories: categories,
                subTypes: subTypes,
                types: types,
              });
            localStorage.productCts_version = this.state.versionCts;
          })
        )
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  uiFields() {
    if (
      localStorage.getItem("productBasic") &&
      localStorage.productBasic_version &&
      localStorage.productBasic_version == this.state.version
    ) {
      console.log("fetching from local storage");
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem("productBasic")),
        });
      } catch (e) {
        localStorage.removeItem("productBasic");
      }
      return Promise.resolve();
    } else {
      console.log("fetching from api");
      return axios
        .get(
          process.env.REACT_APP_URL + "config?entityName=product.basicDetails",
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
            },
          }
        )
        .then((res) => {
          let schema = res.data.data;
          schema = schema.filter((el) => {
            if (el.refType == "SelectInput" || el.refType == "MultiSelect") {
              if (el.refLovs != null)
                el.refLovs = el.refLovs.split(",").map((item) => item.trim());
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          localStorage.setItem("productBasic", JSON.stringify(schema));
          localStorage.productBasic_version = this.state.version;
          if (this._isMounted) this.setState({ schema: schema });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  saveProDetailsHandler = (event) => {
    event.preventDefault();
    this.setState({ loading: true });
    let payload = {};
    let date = moment().format("DD-MMM-YY");
    let tcarePpmProductAud = {};
    if (this.props.productData.productNbr) {
      tcarePpmProductAud = { ...this.props.productData };
    }
    this.state.schema.map((formElement) => {
      if (formElement.refType == "Date")
        tcarePpmProductAud[formElement.refName] = moment(
          this.state[formElement.refName]
        ).format("DD-MMM-YY");
      else if (formElement.refType == "Checkbox")
        tcarePpmProductAud[formElement.refName] = this.state[
          formElement.refName
        ]
          ? "Y"
          : "N";
      else if (formElement.refType == "TextInput" || "TextArea")
        tcarePpmProductAud[formElement.refName] = this.state[
          formElement.refName
        ]
          ? this.state[formElement.refName].trim()
          : null;
      else
        tcarePpmProductAud[formElement.refName] =
          this.state[formElement.refName];
    });
    tcarePpmProductAud.buId = this.props.userInfo.buId;
    tcarePpmProductAud.opId = this.props.userInfo.opId;
    tcarePpmProductAud.createdBy = this.props.userInfo.id;
    tcarePpmProductAud.createdDate = date;

    if (this.state.postRequest) {
      tcarePpmProductAud.version = "1.0";
      payload.tcarePpmProductAud = tcarePpmProductAud;
      payload.releaseId = this.props.releaseData.releaseId;
      console.log("post");
      console.log(payload);
      axios
        .post(process.env.REACT_APP_URL + "product/basicDetails", payload)
        .then((response) => {
          console.log("new gen product");
          console.log(response);
          let proDetails = { ...response.data.data };
          this.props.onProductEnter(proDetails);

          let searchItems = [
            response.data.data.productId + "/" + response.data.data.productDesc,
          ].concat(this.props.searchItems);
          this.props.setSearchItems(searchItems);

          this.state.schema.map((formElement) => {
            this.setState({
              [formElement.refName]: response.data.data[formElement.refName],
            });
          });
          this.setState({
            postRequest: false,
            loading: false,
            openSnack: true,
            messageSnack: "Product Details Saved Successfully",
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      tcarePpmProductAud.updatedDate = date;
      tcarePpmProductAud.updatedBy = this.props.userInfo.id;
      tcarePpmProductAud.productNbr = this.props.productData.productNbr;
      payload.tcarePpmProductAud = tcarePpmProductAud;
      payload.releaseId = this.props.releaseData.releaseId;

      console.log("put");
      console.log(payload);

      axios
        .post(
          process.env.REACT_APP_URL + "product/basicDetails/update",
          payload
        )
        .then((response) => {
          console.log(response);
          let proDetails = { ...response.data.data };
          this.setState({ loading: false });
          this.props.onProductEnter(proDetails);
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  };

  render() {
    const { classes } = this.props;
    //const isDisabled = access && access === "R";
    const access = "R";

    let basicDetails = (
      <form
        onSubmit={this.saveProDetailsHandler}
        style={{ overflow: "visible" }}
      >
        <Grid
          container
          alignItems="flex-end"
          spacing={4}
          style={{ overflow: "visible" }}
        >
          <Snackbar
            open={this.state.openSnack}
            message={this.state.messageSnack}
            onClose={(event, reason) => {
              if (reason === "clickaway") {
                return;
              }
              this.setState({ openSnack: false });
            }}
          />
          {this.state.schema.map((formElement) => (
            <Input
              key={formElement.refName}
              {...formElement}
              access={access}
              disabled
              value={this.state[formElement.refName]}
              InputProps={{ readOnly: true }}
              disabled={formElement.isDisabled == "Y" ? true : false}
              //   required={formElement.isMandatory == "Y" ? true : false}
              minDate={
                formElement.refName === "endDate" && this.state.startDate
              }
              readonly
              changed={(event) => {
                if (!event.target) {
                  this.setState({
                    [formElement.refName]: event,
                  });
                } else {
                  if (event.target.type !== "checkbox")
                    this.setState({
                      [formElement.refName]: event.target.value,
                    });
                  else {
                    console.log(event.target.checked);
                    this.setState({
                      [formElement.refName]: event.target.checked,
                    });
                  }
                }
              }}
            />
          ))}
        </Grid>
      </form>
    );

    if (this.state.loading) basicDetails = <Loader />;
    return basicDetails;
  }
}

const mapStateToProps = (state) => {
  return {
    searchItems: state.searchData.searchItems,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onProductEnter: (productData) =>
      dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
    setSearchItems: (searchItems) =>
      dispatch({
        type: actionTypes.SET_SEARCH_ITEMS,
        searchItems: searchItems,
        entity: "PRODUCT",
      }),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(BasicDetails, axios)));
