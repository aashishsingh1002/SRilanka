import React, { Component } from "react";
import Grid from "@material-ui/core/Grid";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import { withStyles } from "@material-ui/core/styles";
import Loader from "../../UI/Loader/Loader";
import axios from "../../axios-epc";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import AppsIcon from "@material-ui/icons/Apps";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import MultiSelect from "../../UI/Input/MultiSelect";
import Input from "../../UI/Input/Input";
import Tooltip from '@material-ui/core/Tooltip';

// import Button from "@material-ui/core/Button";
import Button from "../../UI/Button/Button";
import Modal from "../../UI/Modal/Modal";
import Typography from "@material-ui/core/Typography";
import moment from "moment";
import Divider from "@material-ui/core/Divider";
import { connect } from "react-redux";
import * as actionTypes from "../../store/actions/actionTypes";
import StyledButton from "../../UI/Button/Button";
import SearchIcon from '@mui/icons-material/Search';

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
    paddingBottom: 0,
  },
  subheader: {
    color: "rgba(0, 0, 0, 0.87)",
    fontSize: "16px",
    fontWeight: "600",
    // color: "white",
    // fontWeight: 'bold'
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "96%",
    flexShrink: 0,
  },
});

class Offerability extends Component {
  _isMounted = false;
  state = {
    loading: true,
    version: "",
    offerKeys: [],
    schema: [],
    refUiMap: {},
    selectedIndex: 0,
    selOfferability: "",
    show: false,
    modalContent: null,
    packageOfferData: {},
    offerablitiyLovs: {},
    accountId: "",
		accountName: "",
		listofAccounts: [],

  };
  componentWillUnmount() {
    this._isMounted = false;
  }

  versions() {
    return axios
      .get("config/version?entityName=offerability", {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        console.log("version is" + res.data.data.version);
        this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields() {
    if (
      localStorage.getItem("offerabilityASD") &&
      localStorage.getItem("offerabilityKeys") &&
      localStorage.offerability_version &&
      localStorage.offerability_version == this.state.version
    ) {
      console.log("fetching from local storage");
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem("offerability")),
          offerKeys: JSON.parse(localStorage.getItem("offerabilityKeys")),
          refUiMap: JSON.parse(localStorage.getItem("offerabilityUiRefMap")),
        });
      } catch (e) {
        localStorage.removeItem("offerability");
        localStorage.removeItem("offerabilityKeys");
        localStorage.removeItem("offerabilityUiRefMap");
      }
      return Promise.resolve();
    } else {
      console.log("fetching from api");
      return axios
        .get("config?entityName=offerability", {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          let schema = [];

          // filter all with children
          const withParent = res.data.data.filter((d) => !!d.parentRefName);

          // combine all children first

          schema = res.data.data.map(function (el) {
            if (el.refType == "SelectInput" || el.refType == "MultiSelect") {
              if (el.refLovs != null) {
                if (typeof el.refLovs === "object") {
                  el.savedRefLovs = el.refLovs;
                  el.refLovs = []; //Object.values(el.refLovs).flat();
                } else {
                  el.refLovs = el.refLovs.split(",");
                }
              } else if (el.refLovs == null) {
                el.refLovs = [];
              }
            }
            return el;
          });

          let offerKeys = [];
          let refUiMap = {};
          res.data.data.forEach((el) => {
            let offerabilityType = {};
            offerabilityType.value = el.refLovs ? el.refLovs : "";
            offerabilityType.type = el.refType;
            offerKeys.push(el.refName);
            refUiMap[el.refName] = el.uiName;
          });

          this.setState({
            schema: schema,
            offerKeys: offerKeys,
            refUiMap: refUiMap,
          });
          localStorage.setItem("offerability", JSON.stringify(schema));
          localStorage.setItem("offerabilityKeys", JSON.stringify(offerKeys));
          localStorage.setItem(
            "offerabilityUiRefMap",
            JSON.stringify(refUiMap)
          );
          localStorage.offerability_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  offerabilityLovData() {
    if (this.props.entity === "PACKAGE" && this.props.id) {
      console.log("required");

      return axios
        .get("ratePlan/dependentLovs?param=package.offerability", {
          headers: {
            opId: this.props.userInfo.opId,
          },
        })
        .then((res) => {
          console.log(res);
          this.setState({
            offerablitiyLovs: res.data.data,
          });
        })
        .catch((error) => {
          console.log(error);
          this.setState({ loading: false });
        });
    } else {
      console.log("not required");
      return Promise.resolve();
    }
  }
  componentDidMount = () => {
    this._isMounted = true;
    this.setState({ loading: true });
    this.versions().then(() => {
      this.uiFields().then(() => {
        this.offerabilityLovData().then(() => {
          if (this.props.entity === "PACKAGE" && this.props.id) {
            let offerabilities =
              this.state.offerablitiyLovs[this.props.planData.catalogId];
            if (offerabilities && offerabilities.length > 0) {
              let schema = [];
              this.state.schema.map((formElement) => {
                if (offerabilities.includes(formElement.uiName))
                  schema.push(formElement);
              });
              this.setState({
                schema,
              });
            }
          }
          this.state.schema.map((formElement) => {
            if (formElement.refType == "Date")
              this.setState({
                [formElement.uiName]: formElement.defaultValue
                  ? moment(formElement.defaultValue).format("DD-MMM-YY")
                  : moment().format("DD-MMM-YY"),
              });
            else if (
              formElement.refType == "TextInput" ||
              "TextArea" ||
              "SelectInput"
            ) {
              this.setState({
                [formElement.uiName]: [formElement.defaultValue],
              });
            }
          });
          this.packageOfferabilityData().then(() => {
            if (this._isMounted) {
              this.state.schema.map((obj) => {
                if (obj.refType == "MultiSelect")
                  this.setState({ [obj.uiName]: [] });
                // else
                //     this.setState({ [obj.uiName]: null })
              });
              if (Object.keys(this.state.packageOfferData).length > 0) {
                Object.keys(this.state.refUiMap).forEach((key) => {
                  if (this.state.packageOfferData[key]) {
                    let offer = this.state.refUiMap[key];
                    console.log(offer);
                    if (
                      this.state.packageOfferData[key].length > 0 &&
                      this.state.packageOfferData[key][0]
                    )
                      this.setState((prevState) => {
                        return {
                          [offer]: [...prevState.packageOfferData[key]],
                        };
                      });
                  }
                });
              }

              this.setState({
                loading: false,
                selOfferability: this.state.schema[0].uiName,
              });
            }
          });
        });
      });
    });
  };

  handleListItemClick = (event, index, key) => {
    this.setState({ selectedIndex: index, selOfferability: key.uiName });
  };

  cartesianProduct(arr) {
    return arr.reduce(
      function (a, b) {
        return a
          .map(function (x) {
            return b.map(function (y) {
              return x.concat([y]);
            });
          })
          .reduce(function (a, b) {
            return a.concat(b);
          }, []);
      },
      [[]]
    );
  }

  packageOfferabilityData() {
    if (this.props.releaseData.releaseId) {
      if (this.props.id) {
        return axios
          .get(
            "/package/offerability?id=" +
              this.props.id +
              "&releaseId=" +
              this.props.releaseData.releaseId,
            {
              headers: {
                createdBy: this.props.userInfo.id,
                opId: this.props.userInfo.opId,
              },
            }
          )
          .then((res) => {
            console.log(res.data.data);
            this.setState({
              packageOfferData: res.data.data,
            });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      } else {
        return Promise.resolve();
      }
    } else {
      return Promise.resolve();
    }
  }

  savePkgOfferDetailsHandler = (event) => {
    event.preventDefault();
    if (this.props.id) {
      let offerabilitiesValues = [];
      this.state.schema.forEach((key) => {
        offerabilitiesValues.push(this.state[key.uiName]);
      });
      console.log(offerabilitiesValues);
      offerabilitiesValues.forEach((part, index, theArray) => {
        if (theArray[index] instanceof Array && theArray[index].length == 0) {
          theArray[index][0] = "ANY";
          this.setState({
            [part]: ["ANY"],
          });
        } else if (typeof theArray[index] === "string") {
          theArray[index] = [theArray[index]];
        } else if (theArray[index] == null) theArray[index] = ["ANY"];
      });

      let crossMatrix = this.cartesianProduct(offerabilitiesValues);
      let offerJson = [];
      crossMatrix.filter((row, index) => {
        let val = index + 1;
        let oneOfferRule = {};
        let date = moment().format("DD-MMM-YY");
        oneOfferRule.opid = this.props.userInfo.opId;
        oneOfferRule.buid = this.props.userInfo.buId;
        oneOfferRule.createdBy = this.props.userInfo.id;
        oneOfferRule.createdDate = date;
        oneOfferRule.startDate = date;
        oneOfferRule.endDate = "31-Dec-31";
        oneOfferRule.version = "1.0";
        oneOfferRule.offerabilityRuleId = "OFPK" + val;
        oneOfferRule.offerabilityRule = "OFPK" + val;
        oneOfferRule.packageProductId = this.props.id;
        oneOfferRule.packageId = this.props.id;
        oneOfferRule.packageProductIdentifier = this.props.entity;

        row.forEach((val, index) => {
          let key = this.state.offerKeys[index];
          oneOfferRule[key] = val;
        });
        offerJson.push(oneOfferRule);
      });
      console.log(offerJson);
      let payload = {};
      let listOfPPmOfferabilityAud = [];
      listOfPPmOfferabilityAud = offerJson;
      payload.id = this.props.id;
      payload.releaseId = this.props.releaseData.releaseId;
      payload.listOfPPmOfferabilityAud = listOfPPmOfferabilityAud;
      console.log(payload);
      this.setState({ loading: true });
      axios
        .post("/package/offerability", payload)
        .then((response) => {
          console.log(response.data.data);
          // if (this._isMounted)
          let payloadRelData = {};
          payloadRelData.releaseId = this.props.releaseData.releaseId;
          payloadRelData.id = this.props.id;
          payloadRelData.listOfOfferabilities = response.data.data;
          axios
            .post("/package/offerability/releaseEntity", payloadRelData)
            .then((response) => {
              console.log(response);
              this.setState({ loading: false });
            });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      let modalContent = (
        <Typography variant="h6">
          {" "}
          Submit Basic {this.props.entity} Details first.{" "}
        </Typography>
      );
      this.setState({ modalContent: modalContent, show: true });
    }
  };

  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };

  deleteOfferabilityHandler = () => {
    this.setState({
      loading: true,
    });
    axios
      .get(
        "package/offerability/delete?id=" +
          this.props.id +
          "&releaseID=" +
          this.props.releaseData.releaseId
      )
      .then((res) => {
        console.log(res.data.data);
        if (this._isMounted) {
          this.state.schema.map((obj) => {
            if (obj.refType == "MultiSelect")
              this.setState({ [obj.uiName]: [] });
            else this.setState({ [obj.uiName]: null });
          });
          this.setState({
            loading: false,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  checkChildrenValues(parent, selected) {
    // if parent unselect a value, child should be removed
    const child = this.state.schema.find((d) => d.parentRefName === parent);

    if (child) {
      const childValues = this.state[child.uiName];
      const allowedValues = Object.entries(child.savedRefLovs).reduce(
        (prev, [key, value]) => {
          const listInclude = selected.includes(key);
          const list = listInclude ? [...prev, ...value] : prev;
          return list;
        },
        []
      );

      const filteredChildValues = childValues.filter((itemName) => {
        return allowedValues.includes(itemName);````````       
      });

      this.setState({
        [child.uiName]: filteredChildValues,
      });

      // loop until no children is found
      this.checkChildrenValues(child.refName, filteredChildValues);
    }
  }

  inputHelper(formElement) {
    formElement = formElement[0];
    if (formElement) {
      if (formElement.refName === 'offerField3') {
				return (
					<Grid container spacing={1}>
						<Grid item xs={6} >
              <div style={{marginRight: '-350px' }}>
							<Input
              	style={{
									height: '2rem',
									width: '3rem',
									margin: 'auto 0 auto auto',
									textTransform: 'none',
									background: '#ff1921',
								}}
								refType="TextInput"
								uiName="Account ID"
								value={this.state.accountId}
								changed={(e) => {
									this.setState({
										accountId: e.target.value,
									});
								}}
							/>
              </div>
						</Grid>
            
						<Grid item xs={6}>
            <div style={{marginRight: '-350px' }}>
							<Input
								refType="TextInput"
								uiName="Account Name"
								value={this.state.accountName}
								changed={(e) => {
									this.setState({
										accountName: e.target.value,
									});
								}}
							/>
                  </div>
						</Grid>
        
						<Grid align='center' item xs={12} style={{ margin: 'auto' }}>
							<StyledButton
								style={{
									height: '2rem',
									width: '3rem',
									margin: 'auto 0 auto auto',
									textTransform: 'none',
									background: '#ff1921',
								}}
								onClick={() => this.searchAccountId(formElement.uiName)}>
								<SearchIcon />
								Search
							</StyledButton>
						</Grid>
						{this.state.listofAccounts.length > 0 && (
							<Grid item xs={12}>
								<Typography>List of Accounts</Typography>
								<MultiSelect
									value={this.state[formElement.uiName]}
									changed={(e) => {
										this.setState({
											[formElement.uiName]: e,
										});
									}}
									refLovs={this.state.listofAccounts}
								/>
							</Grid>
						)}
					</Grid>
				);
			}
 else if (formElement.refType == "MultiSelect") {
        let refLovs = formElement.refLovs;

        // if has parent filter values
        const connectedTo = formElement.parentRefName;
        if (connectedTo) {
          const parent = this.state.schema.find(
            (d) => d.refName === connectedTo
          );

          const selected = this.state[parent.uiName];

          refLovs = Object.entries(formElement.savedRefLovs).reduce(
            (prev, [key, value]) => {
              const list = selected.includes(key) ? [...prev, ...value] : prev;
              return list;
            },
            []
          );
        }






        return (
          <MultiSelect
            value={this.state[formElement.uiName]}
            {...formElement}
            refLovs={refLovs}
            changed={(selected) => {
              console.log(selected);
              if (!(selected instanceof Array)) selected = [selected];

              this.checkChildrenValues(formElement.refName, selected);

              this.setState({
                [formElement.uiName]: selected,
              });
            }}
          />
        );
      } else {
        return (
          <Input
            table
            key={formElement.refName}
            {...formElement}
            value={this.state[formElement.uiName]}
            disabled={formElement.isDisabled == "Y" ? true : false}
            required={formElement.isMandatory == "Y" ? true : false}
            changed={(event) => {
              if (!event.target) {
                this.setState({
                  [formElement.uiName]: event,
                });
              } else {
                if (event.target.type !== "checkbox")
                  this.setState({
                    [formElement.uiName]: event.target.value,
                  });
                else {
                  console.log(event.target.checked);
                  this.setState({
                    [formElement.uiName]: event.target.checked,
                  });
                }
              }
            }}
          />
        );
      }
    }
  }

  searchAccountId = (uiName) => {
		this.setState({
			loading: true,
			[uiName]: [],
		});
		return axios
			.get(
				`package/offerability/accountId?accId=${this.state.accountId}&accName=${this.state.accountName}`,
				{
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
					},
				}
			)
			.then((res) => {
				console.log(res);
				const listofAccounts = res.data.data.accountCategoryId;
				this.setState({
					listofAccounts,
					loading: false,
				});
			});
	};

  render() {
    const { classes } = this.props;
    let offerability = <Loader relative />;
    let selectedOfferability = null;

    if (!this.state.loading) {
      selectedOfferability = this.inputHelper(
        this.state.schema.filter((obj) => {
          if (obj.uiName == this.state.selOfferability) {
            return obj;
          }
        })
      );
      offerability = (
        <React.Fragment>
          <Modal
            show={this.state.show}
            modalClosed={this.errorConfirmedHandler}
            title={"Something Went Wrong!"}
          >
            {this.state.modalContent}
          </Modal>
          <form
            onSubmit={this.savePkgOfferDetailsHandler}
            style={{ overflow: "visible" }}
          >
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6}>
                <Card style={{ height: "100%" }}>
                  <CardHeader
                    className={classes.cardHeader}
                    classes={{
                      subheader: classes.subheader,
                    }}
                    subheader={"Offerability List"}
                  />

                  <CardContent style={{ maxHeight: "40vh", overflow: "auto" }}>
                    <div className={classes.root}>
                      <List component="nav">
                        {this.state.schema.map((key, index) => {
                          return (
                            <ListItem
                              key={key.refName}
                              button
                              selected={this.state.selectedIndex === index}
                              onClick={(event) =>
                                this.handleListItemClick(event, index, key)
                              }
                            >
                              {" "}
                              <ListItemIcon>
                                <AppsIcon />
                              </ListItemIcon>
                              <ListItemText primary={key.uiName} />
                            </ListItem>
                          );
                        })}
                      </List>
                    </div>
                  </CardContent>
                </Card>
              </Grid>

              <Grid item xs={12} sm={6}>
                <Card style={{ height: "100%", overflow: "visible" }}>
                  <CardHeader
                    className={classes.cardHeader}
                    classes={{
                      subheader: classes.subheader,
                    }}
                    subheader={this.state.selOfferability}
                  />

                  <CardContent
                    style={{ maxHeight: "40vh", overflow: "visible" }}
                  >
                    {selectedOfferability}
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12}>
                <Card>
                  <CardHeader
                    className={classes.cardHeader}
                    classes={{
                      subheader: classes.subheader,
                    }}
                    subheader={"Selected Offerability"}
                  />

                  {/* <CardContent>
                    {
                      <List
                        component="nav"
                        aria-labelledby="nested-list-subheader"
                        style={{
                          // width: "100%",
                          // maxHeight: "20vh",
                          // overflow: "auto",
                          width: '100%',
													maxHeight: '20vh',
													overflow: 'auto',
													display: 'flex',
													flexFlow: 'wrap',
                        }}
                      >
                        {this.state.schema.map((key) => {
                          return (
                            <React.Fragment key={key.refName}>
                              {
                                <ListItem>
                                  <ListItemText
                                    primary={key.uiName}
                                    secondary={
                                      key.refType == "MultiSelect"
                                        ? this.state[key.uiName].join()
                                        : this.state[key.uiName]
                                    }
                                  />
                                </ListItem>
                              }
                              <Divider />
                            </React.Fragment>
                          );
                        })}
                      </List>
                    }
                  </CardContent> */}

<CardContent>
										{
											<List
												component="nav"
												aria-labelledby="nested-list-subheader"
												style={{
													width: '100%',
													maxHeight: '20vh',
													overflow: 'auto',
													display: 'flex',
													flexFlow: 'wrap',
												}}>
												{this.state.schema.map((key) => {
													return (
														<React.Fragment key={key.refName}>
															{
																<>
																	<Tooltip
																		arrow
																		placement="bottom-start"
																		style={{
																			'& div': {
																				margin: '0rem!important',
																			},
																		}}
																		interactive
																		title={this.state[key.uiName].join(', ')}>
																		<ListItem
																			style={{
																				display: 'inline-flex',
																				width: '20%',
																			}}>
																			<ListItemText
																				className={classes.listItem}
																				primary={key.uiName}
																				secondary={
																					key.refType == 'MultiSelect'
																						? this.state[key.uiName].join()
																						: this.state[key.uiName]
																				}
																			/>
																		</ListItem>
																	</Tooltip>
																	<Divider />
																</>
															}
														</React.Fragment>
													);
												})}
											</List>
										}
									</CardContent>
                </Card>
              </Grid>

              {this.props.releaseData.releaseId && (
                <div
                  style={{
                    display: "flex",
                    justifyContent: "flex-end",
                    alignItems: "center",
                    width: "100%",
                    marginTop: "1%",
                  }}
                >
                  {/* <Button
                    // variant="contained"
                    onClick={() => {
                      if (this.props.entity === 'PACKAGE')
                        this.props.changePackageActiveStep(3);
                      else this.props.changeProductActiveStep(2);
                    }}
                    style={{
                      textTransform: 'none',
                      paddingLeft: 0,
                      background: '#fff',
                      color: '#ff1921',
                    }}
                    className={classes.btn}
                  >
                    Back
                  </Button> */}
                  <StyledButton
                    // variant="contained"
                    type="submit"
                    style={{
                      //   background: "#02bfa0",
                      textTransform: "none",
                      marginLeft: "auto",
                      background: "#5dc17f",
                    }}
                  >
                    Save
                  </StyledButton>

                  {/* <Button variant="contained" color="secondary"
                                style={{
                                    background: 'red', textTransform: 'none'
                                }}
                                onClick={this.deleteOfferabilityHandler}
                            >
                                Delete
                     </Button> */}
                </div>
              )}
            </Grid>
          </form>
        </React.Fragment>
      );
    }
    return offerability;
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    changeProductActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
        activeStep: activeStep,
      }),
  };
};

export default connect(
  null,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(Offerability, axios)));
