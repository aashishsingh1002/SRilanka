import React from "react";
import { useSelector } from "react-redux";

const Drawer = (props) => {
  const openDrawer = useSelector((state) => state.drawerData.open);

  return (
    <div
      style={{
        margin: "0 auto",
        width: openDrawer ? `calc(100vw - 343px)` : "calc(100vw - 141px)",
      }}
    >
      {props.children}
    </div>
  );
};

export default Drawer;
