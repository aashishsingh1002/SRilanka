import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Divider from "@material-ui/core/Divider";
import { getUiFields, getVersions } from "../../BulkUpload/common/utils";

const SummaryOfferability = () => {
  const dispatch = useDispatch();

  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const data = useSelector((state) => state.summary.generalData);
  const { releaseId } = useSelector((state) => state.releaseData.releaseData);
  const { packageId } = useSelector((state) => state.packageData.packageData);

  const [columns, setColumns] = useState([]);

  const init = async () => {
    const entity = "offerability";
    const version = await getVersions({ userInfo, entity });
    const result = await getUiFields({ userInfo, entity, version });
    setColumns(result);
  };

  useEffect(() => {
    init();
  }, []);
  return (
    <List
      component="nav"
      aria-labelledby="nested-list-subheader"
      style={{
        width: "100%",
        overflow: "auto",
      }}
    >
      {columns.map((key) => {
        return (
          <React.Fragment key={key.refName}>
            {
              <ListItem>
                <ListItemText
                  primary={key.uiName}
                  secondary={
                    key.refType === "MultiSelect"
                      ? this.state[key.uiName].join()
                      : this.state[key.uiName]
                  }
                />
              </ListItem>
            }
            <Divider />
          </React.Fragment>
        );
      })}
    </List>
  );
};

export default SummaryOfferability;
