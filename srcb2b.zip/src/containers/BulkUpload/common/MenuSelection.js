import React, { useState } from "react";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";

const MenuSelection = ({
  customOnChange,
  disabled = false,
  lists = [],
  label = "",
}) => {
  const [selected, setSelected] = useState("");

  const onChange = (e) => {
    const { value } = e.target;
    if (customOnChange) {
      customOnChange(value);
    }
    setSelected(value);
  };

  return (
    <Select
      displayEmpty
      value={selected}
      onChange={onChange}
      disabled={disabled}
    >
      <MenuItem value="" disabled>
        {label}
      </MenuItem>
      {lists.map((list) => (
        <MenuItem key={list.id} value={list.id}>
          {list.name}
        </MenuItem>
      ))}
    </Select>
  );
};

export default MenuSelection;
