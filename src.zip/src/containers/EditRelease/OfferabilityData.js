import React from 'react';
import ExpansionPanel from '../../UI/ExpansionPanel/ExpansionPanel';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';


const OfferabilityData = (props) => {
    return (
        <ExpansionPanel heading='Offerability'>
            {(props.offerability) ?
                < List
                    component="nav"
                    aria-labelledby="nested-list-subheader"
                    style={{ width: '100%', maxHeight: '30vh', overflow: 'auto' }}
                >
                    {Object.keys(props.offerability).map(offerability => {
                        return <React.Fragment key={offerability}>
                            {props.offerability[offerability] && props.offerability[offerability].length > 0
                                && props.offerability[offerability][0] != null ?
                                <React.Fragment>
                                    <ListItem >
                                        <ListItemText primary={props.refUiMap[offerability] ? props.refUiMap[offerability] : offerability}
                                            secondary={props.offerability[offerability].join()} />
                                    </ListItem>
                                    <Divider />
                                </React.Fragment>
                                : null}

                        </React.Fragment>

                    })}
                </List>
                : null}
        </ExpansionPanel>


    );
}

export default OfferabilityData;