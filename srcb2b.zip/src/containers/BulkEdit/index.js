import React, { useState } from "react";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import MaterialTable, { MTableToolbar } from "@material-table/core";
import {
  CustomPaginationComponent,
  TABLE_ICONS,
} from "../../common/table-config";
import Button from "@material-ui/core/Button";
import LoadingButton from "@mui/lab/LoadingButton";
import axios from "../../axios-epc";
import { useSelector } from "react-redux";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";

const Index = () => {
  const releaseData = useSelector((state) => state.releaseData.releaseData);
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const [selectedOption, setSelectedOption] = useState("package");
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  const searchData = (optionVal) => {
    console.log(releaseData);
    setLoading(true);
    return axios
      .get(
        `${optionVal}/basicDetails/search?releaseID=${releaseData.releaseId}`,
        {
          headers: {
            opId: userInfo.opId,
          },
        }
      )
      .then((res) => {
        setLoading(false);
        console.log(res);
        let searchItems = [];
        Object.keys(res.data.data).forEach((key) => {
          searchItems.push({ package: key + "/" + res.data.data[key] });
        });

        console.log(searchItems);
        console.log("searchItems");
        setData(searchItems);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const columns = [
    {
      title: selectedOption === "package" ? "Packages" : "Products",
      field: "package",
    },
  ];

  return (
    <div>
      <Paper style={{ padding: "20px", width: "100%", margin: "10px 0 " }}>
        <div>Select option</div>
        <RadioGroup
          row
          aria-label="position"
          name="position"
          value={selectedOption}
          onChange={(event) => {
            setSelectedOption(event.target.value);
            setData([]);
          }}
          style={{ marginBottom: "2%" }}
        >
          <FormControlLabel
            value="package"
            control={<Radio style={{ color: "#ff1921" }} />}
            label="Bundles"
          />
          <FormControlLabel
            value="product"
            control={<Radio style={{ color: "#ff1921" }} />}
            label="Products"
          />
        </RadioGroup>
        <div style={{ textAlign: "right" }}>
          <LoadingButton
            loading={loading}
            onClick={() => searchData(selectedOption)}
            loadingPosition="end"
            style={{
              textTransform: "capitalize",
              background: "#5dc17f",
              fontWeight: "600",
              marginLeft: "10px",
              color: "#fff",
              fontSize: "16px",
              borderRadius: "50px",
              padding: "6px 24px",
            }}
          >
            Serach
          </LoadingButton>
        </div>
      </Paper>
      {data.length !== 0 && (
        <div>
          <MaterialTable
            //   editable={​​​​​{​​​​​isEditable: rowData => rowData.name !== 'ucId'}​​​​​}​​​​​
            style={{ padding: "20px", marginTop: "10px" }}
            // tableRef={this.selectTable}
            //   isLoading={this.state.loadingTable}
            icons={TABLE_ICONS}
            title={``}
            columns={columns}
            data={data}
            // lookup={this.state.columns.map((x) => {
            //   return x.refLovs;
            // })}
            // actions={[
            //   {
            //     tooltip: 'Export',
            //     icon: GetAppIcon,
            //     onClick: (evt, data) => {
            //       this.saveAsSelectedExcel();
            //     },
            //   },
            //   {
            //     icon: () => (
            //       <Button
            //         variant='contained'
            //         style={{
            //           textTransform: 'capitalize',
            //           background: '#ffcc00',
            //           letterSpacing: '-1px',
            //           fontWeight: '600',
            //           color: '#000',
            //           fontSize: '16px',
            //           borderRadius: '50px',
            //           padding: '6px 32px',
            //           '&:hover': {
            //             opacity: 0.8,
            //             background: '#ffcc00',
            //           },
            //         }}
            //         onClick={() => {
            //           this.saveAsExcel();
            //         }}
            //       >
            //         <SaveAlt style={{ marginRight: '10px' }} />
            //         Export
            //       </Button>
            //     ),
            //     isFreeAction: true,
            //   },
            // ]}
            editable={{}}
            options={{
              selection: true,
              pageSize: 5,
              pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
              toolbar: true,
              paging: true,
              rowStyle: {
                fontSize: "14px",
                padding: 10,
                background: "rgba(0,0,0,0.04)",
              },
              headerStyle: {
                fontSize: "13px",
                fontWeight: "bold",
                textTransform: "capitalize",
                lineHeight: "1.2em",
              },
              // search: false,
              searchFieldAlignment: "left",
              searchFieldVariant: "outlined",
              showTitle: false,
              searchFieldStyle: {
                borderRadius: 50,
                border: "1px solid rgba(0, 0, 0, 0.04)",
                background: "rgba(0, 0, 0, 0.04)",
                height: 40,
                width: 320,
              },
            }}
            onSelectionChange={(selection) => {
              console.log(selection);
              //  this.setState({
              //    selectedRows: selection,
              //  });
              //  console.log(this.state.selectedRows);
              //  this.setState({ isSelected: !!selection.length });
            }}
            components={{
              Toolbar: (props) => (
                <div>
                  <div
                    style={{
                      fontSize: "18px",
                      fontWeight: "600",
                      marginLeft: "24px",
                    }}
                  >
                    {props.title}
                  </div>
                  <div>
                    <MTableToolbar {...props} />
                  </div>
                </div>
              ),
              Pagination: (props) => {
                return <CustomPaginationComponent {...props} />;
              },
            }}
          />
          <div style={{ textAlign: "right", margin: "10px 0" }}>
            <LoadingButton
              loading={loading}
              //onClick={()=>searchData(selectedOption)}
              loadingPosition="end"
              style={{
                textTransform: "capitalize",
                background: "#5dc17f",
                fontWeight: "600",
                //  marginLeft: '10px',
                color: "#fff",
                fontSize: "16px",
                borderRadius: "50px",
                padding: "6px 24px",
                marginLeft: "20px",
              }}
            >
              Proceed
            </LoadingButton>
          </div>
        </div>
      )}
    </div>
  );
};

export default WithErrorHandler(Index, axios);
