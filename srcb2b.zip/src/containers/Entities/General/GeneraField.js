import {
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Select,
} from "@material-ui/core";
import React, { useState } from "react";
import styled from "styled-components";
const StyledRequired = styled.span`
  color: #f00;
  marginleft: 5px;
  fontweight: 600;
`;

const StyledFormControl = styled(FormControl)`
  margin-top: 16px;
  margin-bottom: 16px;
`;

// for parent dependency
const GeneralField = ({ field, onSelect, filter, noFilter, disabled }) => {
  const { entityUiName, entityName, data: lists, required } = field;
  const [selected, setSelected] = useState("");

  const onChange = (e) => {
    const { value } = e.target;
    setSelected(value);
    onSelect(entityName, value);
  };

  const filteredLists = lists.filter((list) => {
    if (noFilter) return true;
    if (!filter) return false;
    return list.refName.includes(filter);
  });

  return (
    <Grid item xs={3}>
      <span>
        {entityUiName}
        {required && <StyledRequired>*</StyledRequired>}
      </span>
      <StyledFormControl fullWidth>
        {/* <InputLabel id="">{entityUiName}</InputLabel> */}
        <Select
          required={required}
          disabled={disabled}
          label={entityUiName}
          value={selected}
          onChange={(val) => onChange(val)}
        >
          <MenuItem value="">&nbsp;</MenuItem>
          {filteredLists.map((list) => (
            <MenuItem key={list.uiName} value={list.uiName}>
              {list.uiName}
            </MenuItem>
          ))}
        </Select>
      </StyledFormControl>
    </Grid>
  );
};

export default GeneralField;
