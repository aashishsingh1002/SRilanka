import React, { Component } from 'react';
import { connect } from 'react-redux';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Loader from '../../UI/Loader/Loader';
import BasicDetails from './BasicDetails'
import Box from '@material-ui/core/Box';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Divider from '@material-ui/core/Divider';
import { withStyles } from '@material-ui/core/styles';
import ProductsData from './ProductsData';
import PricingData from './PricingData';
import AttributesData from './AttributesData';
import OfferabilityData from './OfferabilityData';
import ContractData from './ContractData';
import TextField from '@material-ui/core/TextField';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import AddIcon from '@material-ui/icons/Add';
import * as actionTypes from '../../store/actions/actionTypes';
import DeleteIcon from '@material-ui/icons/Delete';



const useStyles = (theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    boldText: {
        // fontWeight: 'bold'
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '94%',
        flexShrink: 0,
    },

});


class EditRelease extends Component {
    _isMounted = false;
    state = {
        loading: true,
        releaseDetails: {},
        expanded: false,
        version: '',
        offerKeys: [],
        schema: [],
        refUiMap: {},
        searchPkg: '',
        searchGenPro: '',
        packages: [],
        genericProducts: []
    }
    componentWillUnmount() {
        this._isMounted = false;
    }

    versions() {
        return axios
            .get(
                "config/version?entityName=offerability",
                {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId

                    }
                }
            )
            .then(res => {
                console.log("version is" + res.data.data.version);
                this.setState({ version: res.data.data.version })
            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false });

            });
    }

    uiFields() {
        if (
            localStorage.getItem("offerability") &&
            localStorage.getItem("offerabilityKeys") &&
            localStorage.offerability_version &&
            localStorage.offerability_version == this.state.version
        ) {
            console.log("fetching from local storage");
            try {
                this.setState({
                    schema: JSON.parse(localStorage.getItem("offerability")),
                    offerKeys: JSON.parse(localStorage.getItem("offerabilityKeys")),
                    refUiMap: JSON.parse(
                        localStorage.getItem("offerabilityUiRefMap"))
                });
            } catch (e) {
                localStorage.removeItem("offerability");
                localStorage.removeItem("offerabilityKeys");
                localStorage.removeItem("offerabilityUiRefMap");
            }
            return Promise.resolve();
        } else {
            console.log("fetching from api");
            return axios
                .get("config?entityName=offerability", {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId
                    }
                })
                .then(res => {
                    let schema = []
                    schema = res.data.data.map(function (el) {
                        if (el.refType == "SelectInput" || el.refType == "MultiSelect") {
                            if (el.refLovs != null) el.refLovs = el.refLovs.split(",");
                            else if (el.refLovs == null) el.refLovs = [];
                        }
                        return el;
                    });

                    let offerKeys = []
                    let refUiMap = {}
                    console.log(res.data.data)
                    res.data.data.forEach((el) => {
                        let offerabilityType = {};
                        offerabilityType.value = el.refLovs ? el.refLovs : "";
                        offerabilityType.type = el.refType;
                        offerKeys.push(el.refName);
                        refUiMap[el.refName] = el.uiName;
                    });

                    this.setState({
                        schema: schema,
                        offerKeys: offerKeys,
                        refUiMap: refUiMap
                    });
                    localStorage.setItem("offerability", JSON.stringify(schema));
                    localStorage.setItem(
                        "offerabilityKeys",
                        JSON.stringify(offerKeys)
                    );
                    localStorage.setItem(
                        "offerabilityUiRefMap",
                        JSON.stringify(refUiMap)
                    );
                    localStorage.offerability_version = this.state.version;
               })
                .catch(error => {
                    console.log(error);
                    if (this._isMounted)
                        this.setState({ loading: false });

                });
        }
    }


    releaseDataHandler = () => {
        return axios
            .get(
                "dashboard/edit?releaseId=" +
                this.props.releaseData.releaseId,
                {
                    headers: {
                        Accept: "application/json,text/plan,*/*",
                        buId: this.props.userInfo.buId,
                        channelId: "CSA",
                        language: "ENG",
                        opId: this.props.userInfo.opId
                    }
                }
            )
            .then(res => {
                console.log("release data");
                console.log(res.data.data);
                let getCurrentReleaseData = res.data.data;
                if (getCurrentReleaseData.genericProducts == null)
                    getCurrentReleaseData.genericProducts = [];
                if (getCurrentReleaseData.packages == null)
                    getCurrentReleaseData.packages = [];

                if (this._isMounted)
                    this.setState({
                        loading: false, releaseDetails: getCurrentReleaseData,
                        packages: [...getCurrentReleaseData.packages],
                        genericProducts: [...getCurrentReleaseData.genericProducts]
                    });
                console.log('mounted')
                console.log(getCurrentReleaseData)
            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false });

            });

    }
    changeHandler = (panel) => (event, isExpanded) => {
        this.setState({ expanded: isExpanded ? panel : false });
    };
    componentDidMount = () => {
        this._isMounted = true;
        this.setState({ loading: true });
        this.releaseDataHandler().then(() => {
            this.versions().then(() => {
                this.uiFields().then(() => {
                    if (this._isMounted) {
                        this.setState({ loading: false });
                        console.log(this.state.refUiMap)
                    }
                })
            })
        })
    }

    searchPkgHandler = (event) => {
        this.setState({ searchPkg: event.target.value })
        let packages = []
        if (event.target.value.length == 0) {
            packages = [...this.state.releaseDetails.packages]
            this.setState({ packages: packages })
        } else {
            packages = this.state.releaseDetails.packages.filter(function (item) {
                return (item.packageId.toUpperCase().includes(event.target.value.toUpperCase())
                    || item.packageName.toUpperCase().includes(event.target.value.toUpperCase()));
            });
            this.setState({ packages: packages })
        }

    }

    searchGenProHandler = (event) => {
        this.setState({ searchGenPro: event.target.value })
        let genPro = []
        if (event.target.value.length == 0) {
            genPro = [...this.state.releaseDetails.genericProducts]
            this.setState({ genericProducts: genPro })
        } else {
            genPro = this.state.releaseDetails.genericProducts.filter(function (item) {
                return (item.productId.toUpperCase().includes(event.target.value.toUpperCase())
                    || item.productName.toUpperCase().includes(event.target.value.toUpperCase()));
            });
            this.setState({ genericProducts: genPro })
        }

    }

    render() {
        const { classes } = this.props;

        let editRelease = <Loader />

        if (!this.state.loading)
            editRelease = <React.Fragment>
                <BasicDetails releaseData={this.props.releaseData} userInfo={this.props.userInfo} />
                <Box mt={2}>
                    <Card >
                        <CardHeader
                            className={classes.cardHeader}
                            classes={{
                                subheader: classes.subheader,
                            }}
                            subheader="Item Details" />

                        <CardContent>
                            <Grid container spacing={3}>

                                <Grid item xs={12} >
                                    <div>
                                        <span className={classes.boldText}
                                            style={{ fontSize: '1.2rem' }}>Packages</span>
                                        <span
                                            onClick={() => {
                                                this.props.changePackageActiveStep(0)
                                                this.props.onPackageEnter({})
                                                this.props.history.push('/planConfiguration')
                                            }}
                                            style={{
                                                color: 'green', marginLeft: '1%',
                                                cursor: 'pointer'
                                            }}>
                                            <AddIcon style={{ fontSize: '.8rem' }} />
                                            Packages</span>
                                        <span style={{ float: 'right' }}>
                                            <TextField placeholder='Search Packages' value={this.state.searchPkg} onChange={this.searchPkgHandler} /></span>

                                    </div>
                                    <Box mt={5}  >
                                        {this.state.packages.length > 0 ?
                                            this.state.packages.map(pkg => {
                                                return <Accordion key={pkg.packageId} expanded={this.state.expanded === pkg.packageId} onChange={this.changeHandler(pkg.packageId)}>
                                                    <AccordionSummary
                                                        aria-controls="panel1bh-content"
                                                        id="panel1bh-header"
                                                    >
                                                        <ExpandMoreIcon />
                                                        <Typography className={classes.heading}>
                                                            {pkg.packageName} ({pkg.packageId})</Typography>
                                                        <ExitToAppIcon onClick={(event) => {
                                                            event.stopPropagation()
                                                            this.props.changePackageActiveStep(0)
                                                            this.props.onPackageEnter(pkg)
                                                            this.props.history.push('/planConfiguration')

                                                        }} style={{ color: '#ff1921', marginRight: '10px' }} />

                                                        <DeleteIcon style={{ color: 'red' }} onClick={(event) => {
                                                            event.stopPropagation()
                                                            this.setState({ loading: true })
                                                            let payload = {};
                                                            let tcarePpmPackageAud = {};
                                                            tcarePpmPackageAud.packageNbr = pkg.packageNbr;
                                                            payload.tcarePpmPackageAud = tcarePpmPackageAud;
                                                            console.log(payload);
                                                            axios
                                                                .delete("package/basicDetails", {
                                                                    data: payload
                                                                })
                                                                .then(response => {
                                                                    console.log(response);
                                                                    if (this._isMounted)
                                                                        this.setState(prevState => ({
                                                                            packages: prevState.packages.filter(pack => pack.packageNbr
                                                                                !== pkg.packageNbr),
                                                                            loading: false
                                                                        }));

                                                                })
                                                                .catch(error => {
                                                                    console.log(error);
                                                                    if (this._isMounted)
                                                                        this.setState({ loading: false });

                                                                });
                                                        }} />
                                                    </AccordionSummary>
                                                    <AccordionDetails style={{ display: 'block' }}>
                                                        <AttributesData attribute={pkg.attribute} />
                                                        <ProductsData products={pkg.products} />
                                                        <PricingData pricing={pkg.pricing} />
                                                        <OfferabilityData offerability={pkg.offerability} refUiMap={this.state.refUiMap} />
                                                        <ContractData contract={pkg.contract} />
                                                    </AccordionDetails>
                                                </Accordion>

                                            })
                                            :
                                            <React.Fragment >
                                                <Divider />
                                                <Box my={1} >
                                                    <Typography style={{ textAlign: 'center' }}>
                                                        Package Not Found</Typography>
                                                </Box>
                                                <Divider />
                                            </React.Fragment>
                                        }
                                    </Box>

                                </Grid>

                                <Grid item xs={12} >
                                    <div>
                                        <span className={classes.boldText}
                                            style={{ fontSize: '1.2rem' }}>Generic Products</span>
                                        <span
                                            onClick={() => {
                                                this.props.changeProductActiveStep(0)
                                                this.props.onProductEnter({})
                                                this.props.history.push('/productConfiguration')
                                            }}
                                            style={{
                                                color: 'green', marginLeft: '1%',
                                                cursor: 'pointer'
                                            }}
                                        >
                                            <AddIcon style={{ fontSize: '.8rem' }} />
                                            Generic Products</span>
                                        <span style={{ float: 'right' }}>
                                            <TextField placeholder='Search Generic Products' value={this.state.searchGenPro} onChange={this.searchGenProHandler} />

                                        </span>

                                    </div>
                                    <Box mt={5} >
                                        {this.state.genericProducts.length > 0 ?
                                            this.state.genericProducts.map(genPro => {
                                                return <Accordion key={genPro.productId} expanded={this.state.expanded === genPro.productId} onChange={this.changeHandler(genPro.productId)}>
                                                    <AccordionSummary
                                                        aria-controls="panel1bh-content"
                                                        id="panel1bh-header"
                                                    >
                                                        <ExpandMoreIcon />
                                                        <Typography className={classes.heading}>
                                                            {genPro.productName} ({genPro.productId})</Typography>
                                                        <ExitToAppIcon onClick={(event) => {
                                                            event.stopPropagation()
                                                            this.props.changeProductActiveStep(0)
                                                            this.props.onProductEnter(genPro)
                                                            this.props.history.push('/productConfiguration')
                                                        }} style={{ color: '#ff1921' }} />

                                                    </AccordionSummary>
                                                    <AccordionDetails style={{ display: 'block' }}>
                                                        <AttributesData attribute={genPro.attribute} />
                                                        <PricingData pricing={genPro.pricing} />
                                                        <OfferabilityData offerability={genPro.offerability} refUiMap={this.state.refUiMap} />
                                                        <ContractData contract={genPro.contract} />
                                                    </AccordionDetails>
                                                </Accordion>

                                            })
                                            :
                                            <React.Fragment >
                                                <Divider />
                                                <Box my={1} >
                                                    <Typography style={{ textAlign: 'center' }}>
                                                        Generic Products Not Found</Typography>
                                                </Box>
                                                <Divider />
                                            </React.Fragment>
                                        }
                                    </Box>

                                </Grid>

                            </Grid>
                        </CardContent>

                    </Card>
                </Box>
            </React.Fragment>

        return editRelease
    }
}


const mapStateToProps = state => {
    return {
        releaseData: state.releaseData.releaseData,
        userInfo: state.login.loggedInUserInfo,
    };
}

const mapDispatchToProps = dispatch => {
    return {
        onPackageEnter: (packageData) => dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
        changePackageActiveStep: (activeStep) => dispatch({ type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP, activeStep: activeStep }),
        onProductEnter: (productData) => dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
        changeProductActiveStep: (activeStep) => dispatch({ type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP, activeStep: activeStep }),

    };
};

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(useStyles)(WithErrorHandler(EditRelease, axios)));