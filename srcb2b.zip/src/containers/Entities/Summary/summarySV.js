// import React, { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { getUiFields, getVersions } from "../../BulkUpload/common/utils";
// import TextField from "@material-ui/core/TextField";
// import { TABLE_ICONS } from "../../BulkUpload/common/table-config";
// import MaterialTable from "@material-table/core";
// import axios from "../../../axios-epc";

// const SummarySV = () => {
//   const dispatch = useDispatch();

//   const userInfo = useSelector((state) => state.login.loggedInUserInfo);
//   const { releaseId } = useSelector((state) => state.releaseData.releaseData);
//   const { packageId } = useSelector((state) => state.packageData.packageData);

//   const [loading, setLoading] = useState(true);
//   const [columns, setColumns] = useState([]);

//   const [serviceOptionId, setServiceOptionId] = useState();
//   const [data, setData] = useState([]);

//   const init = async () => {
//     const entity = "daConfiguration";
//     const version = await getVersions({ userInfo, entity });
//     const result = await getUiFields({ userInfo, entity, version });

//     setColumns(result);
//     getList();
//   };

//   const getList = () => {
//     if (releaseId) {
//       return axios
//         .get("mtn/DA?releaseId=" + releaseId, {
//           headers: {
//             productId: packageId,
//           },
//         })
//         .then((res) => {
//           if (res) {
//             const { data = [] } = res.data;
//             if (data.length) {
//               setServiceOptionId(data[0].serviceOptionId);
//               setData(data);
//             }
//           }
//         })
//         .catch(() => {});
//     }
//   };

//   useEffect(() => {
//     init();
//   }, []);

//   return (
//     <div style={{ width: "100%" }}>
//       <div style={{ marginBottom: "10px" }}>
//         <div
//           style={{
//             marginRight: "8px",
//             display: "flex",
//             alignItems: "center",
//           }}
//         >
//           Service Option Id:
//         </div>

//         <TextField
//           disabled={true}
//           style={{ fontsize: "20px" }}
//           value={serviceOptionId}
//         />
//       </div>
//       <MaterialTable
//         icons={TABLE_ICONS}
//         columns={columns.filter((d) => d.groupName === "UI Input")}
//         data={data}
//         options={{
//           showTitle: false,
//           search: false,
//         }}
//       />
//     </div>
//   );
// };

// export default SummarySV;
