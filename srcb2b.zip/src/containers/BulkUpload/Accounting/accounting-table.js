import React, { useState, useEffect } from 'react';
import { TextField, ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';
import moment from 'moment';
import {
  ACCOUNTING_GET_URL,
  ACCOUNTING_POST_URL,
} from './accounting-constants';
import axios from '../../../axios-epc';
import MaterialTable from 'material-table';
import { TABLE_CONFIG, THEME_OVERRIDE, TABLE_ICONS } from './accounting-config';
import { useSelector } from 'react-redux';

const theme = createMuiTheme({
  overrides: THEME_OVERRIDE,
});

const useStyles = (theme) => ({});

const AccountingTable = ({ setLoading, schema }) => {
  // selectors
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);

  // States
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loadingTable, setLoadingTable] = useState(true);

  // Functions
  const getData = () => {
    return axios
      .get(ACCOUNTING_GET_URL)
      .then((res) => {
        if (res) {
          const { data } = res.data;
          const mapData = data.map((row) => ({ ...row, tableData: '' }));
          setData(mapData);
        }
        setLoadingTable(false);
      })
      .catch((error) => {
        setLoading(false);
        setLoadingTable(false);
      });
  };

  const mapColumns = () => {
    let tmpColumns = schema.map((row) => {
      return {
        title: row.uiName,
        field: row.refName,
        sorting: false,
        // cellStyle: { width: "30%" },
        render: (rowData) => {
          return (
            row.refName &&
            rowData[row.refName] && (
              <span
                style={{
                  display: 'block',
                  width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                }}
              >
                {' '}
                {rowData[row.refName]}
              </span>
            )
          );
        },
        editComponent: (props) => (
          <TextField
            style={{
              width: '20vw',
              margin: 10,
              fontSize: 12,
            }}
            fullWidth
            value={props.value}
            onChange={(event) => {
              props.onChange(event.target.value);
            }}
          />
        ),
      };
    });

    setColumns(tmpColumns);
  };

  // Did Mount
  useEffect(() => {
    getData().then(() => mapColumns());
  }, []);

  // Render
  return (
    <ThemeProvider theme={theme}>
      <MaterialTable
        isLoading={loadingTable}
        icons={TABLE_ICONS}
        title={'Accounting'}
        columns={columns}
        data={data}
        options={TABLE_CONFIG}
        editable={{
          onBulkUpdate: (changes) =>
            new Promise((resolve, reject) => {
              setTimeout(() => {
                console.log(changes);
                if (Object.keys(changes).length > 0) {
                  let payload = [];
                  setLoadingTable(true);
                  Object.keys(changes).map((row) => {
                    let payloadData = { ...changes[row].newData };
                    payloadData.createdBy = userInfo.id;
                    payloadData.createdDate = moment().format('DD-MM-YYYY');
                    payload.push(payloadData);
                  });
                  axios
                    .post(ACCOUNTING_POST_URL, payload)
                    .then((response) => {
                      getData().then(() => {
                        setLoadingTable(false);
                        resolve();
                      });
                    })
                    .catch((error) => {
                      setLoadingTable(false);
                      resolve();
                    });
                } else resolve();
              }, 1000);
            }),
          onRowAdd: (newData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              payload.createdBy = userInfo.id;
              payload.createdDate = moment().format('DD-MM-YYYY');
              setLoadingTable(true);
              axios
                .post(ACCOUNTING_POST_URL, [payload])
                .then((response) => {
                  if (response) {
                    let tmpData = [...data, newData];
                    setData(tmpData);
                  }
                  setLoadingTable(false);
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
          onRowUpdate: (newData, oldData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              console.log(newData);
              payload.createdBy = userInfo.id;
              payload.createdDate = moment().format('DD-MM-YYYY');
              setLoadingTable(true);
              axios
                .post(ACCOUNTING_POST_URL, [payload])
                .then((response) => {
                  const dataUpdate = [...data];
                  const index = oldData.tableData.id;
                  dataUpdate[index] = newData;
                  setData(dataUpdate);
                  setLoadingTable(false);
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
        }}
      />
    </ThemeProvider>
  );
};

export default withStyles(useStyles)(AccountingTable);
