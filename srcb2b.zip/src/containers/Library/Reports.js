import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import IconButton from '@material-ui/core/IconButton';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../UI/Loader/Loader';
import { withStyles } from '@material-ui/core/styles';
import * as actionTypes from '../../store/actions/actionTypes';
import Box from '@material-ui/core/Box';
import MenuBookIcon from '@material-ui/icons/MenuBook';
import Chip from '@material-ui/core/Chip';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Button from '@material-ui/core/Button';
import MaterialTable from 'material-table';
import Table from "../../UI/Table/Table";
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core'
import { createMuiTheme } from '@material-ui/core/styles';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js'
import { saveAs } from 'file-saver'
import Title from "../../UI/Typography/Title";

const tableIcons = {
    Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
    Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
    Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
    DetailPanel: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
    Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
    Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
    FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
    LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
    NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    PreviousPage: forwardRef((props, ref) => <ChevronLeft {...props} ref={ref} />),
    ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
    SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
    ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
    ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />)
};


const theme = createMuiTheme({
    overrides: {
        MuiTable: {
            root: {
                tableLayout: 'fixed',
            },
        },
        MuiTableCell: {
            root: {
                padding: '7px',
                paddingLeft: '10px'
            },
        },
        MuiPaper: {
            width: '100%'
        }
    },
});


const useStyles = (theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
    },

});



// const columns = {
//     "Description": "CRM Name",
//     "Category": "Category",
//     "ugcType": "UGC Type",
//     "ugcSubType1": "UGC SubType",
//     "ugcSubType2": "UGC SubSubType",
//     "ugcUsageGrpCode": "UGC Description",
//     "typeId": "Type Id",
//     "jurisdiction": "Jurisdiction",
//     "componentId": 'Component Id',
//     "Rates": "Rate",
//     "uom": "UOM",
//     "countries": 'Slab',
//     "createdBy": "Created By",
//     "creationDate": "Creation Date",
// }

class Reports extends Component {
    _isMounted = false;
    state = {
        data: [],
        show: false,
        loading: false,
        reportTitle:"",
        reportId:'',
        actions: [
            {
                icon: () => (
                    <Button
                        variant="contained" style={{
                            //marginLeft: '27vw',
                            display:'block',
                            background: '#546D7A', color: 'white', textTransform: 'none'
                        }}
                        onClick={() => {
                            this.saveAsExcel()
                        }}
                    >
                        <SaveAlt style={{ marginRight: '10px' }} />Export
                      </Button>
                ),
                isFreeAction: true,

            }
        ],
        columns: []
    }

    modalCloseHandler = () => {
        this.setState({ show: false, })
    }



    async saveAsExcel() {
    //     const workbook = new ExcelJS.Workbook();
    //     const worksheet = workbook.addWorksheet(this.state.reportTitle);
    //     let sheetColumns = []
    //     Object.keys(this.state.columns).map(key => {
    //         sheetColumns.push({
    //             header: this.state.columns[key],
    //             key: key, width: 25
    //         })
    //     })

    //     worksheet.columns = sheetColumns

    //     this.selectTable.current.state.data.map(row => {
    //         worksheet.addRow(row);
    //     })

    //     // worksheet.getRow(1).fill = {
    //     //     type: 'pattern',
    //     //     pattern: 'solid',
    //     //     fgColor: { argb: 'cccccc' },
    //     //     font: { bold: true }
    //     // }

    //     worksheet.getRow(1).font = {
    //         bold: true
    //     }

    //     this.setState({ loading: true })
    //     const buf = await workbook.xlsx.writeBuffer()
    //     this.setState({ loading: false })


    //     saveAs(new Blob([buf]), this.state.reportTitle+'.xlsx');
    return axios
    .get(
        `b2b-report/download/${this.state.reportId}`,
        {
            headers: {
                buId: this.props.userInfo.buId,
                opId: this.props.userInfo.opId,
                authUserId:this.props.userInfo.id,
                authGroupId:this.props.userInfo.group[0],
                Authorization: 'Bearer ' + this.props.userInfo.jwt,
            },responseType: 'blob',
        },
        
    )
    .then(res => {

				this.setState({ loading: false });
				var headers = res.headers;
				var blob = new Blob([res.data], {
					type: headers['content-type'],
				});

				var link = document.createElement('a');
				link.href = window.URL.createObjectURL(blob);
				link.download =
					this.state.reportTitle;
				link.click();
    }).catch(error => {
        if (this._isMounted)
            this.setState({ loading: false });
    });
      
}

    reportHandler = (reportId) => {
        return axios
            .get(
                "/b2b-report/"+reportId,
                {
                    headers: {
                        buId: this.props.userInfo.buId,
                        opId: this.props.userInfo.opId,
                        authUserId:this.props.userInfo.id,
                        authGroupId:this.props.userInfo.group[0],
                        Authorization: 'Bearer ' + this.props.userInfo.jwt,
                    }
                }
            )
            .then(res => {
                
                if (this._isMounted) {
                    let reportData = res.data.data[reportId];
                    let row = reportData[0];
                    let columns = [];
                    Object.keys(row).forEach(name => columns.push({title:name.replaceAll("_"," ").trim(), field: name}));
                    this.setState({data: reportData, columns: columns});
                }

            })
            .catch(error => {
                if (this._isMounted)
                    this.setState({ loading: false });
            });
    }

    constructor(props) {
        super(props)
        this.selectTable = React.createRef();

       
    }

    componentDidMount = () => {
        this._isMounted = true;
        this.props.onReleaseExit();
        const params = new URLSearchParams(this.props.location.search);

        this.setState({ loading: true, reportTitle : params.get("name").replaceAll("_"," "), reportId:params.get("id") });
        this.reportHandler(params.get("id")).then(() => {
            if (this._isMounted) {
                this.setState({ loading: false });
            }
        })
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidUpdate = (previousProps, previousState) => {
        const params = new URLSearchParams(this.props.location.search);
        if(params.get("id") !== previousState.reportId) {
            this.setState({loading: true, reportId:params.get("id"), reportTitle : params.get("name").replaceAll("_"," "),data:[],columns:[] });
            this.reportHandler(params.get("id")).then(() => {
                if (this._isMounted) {
                    this.setState({ loading: false});
                }
            })
        }
    }

    render() {

        const { classes } = this.props;

        let ratePlanReport = <div>
            <div style={this.state.loading ? { display: 'none' } : { display: 'block' }}>
                
                <ThemeProvider theme={theme}>
                <Title>{this.state.reportTitle}</Title>
                    <Table
                       // tableRef={this.selectTable}
                        actions={this.state.actions}
                        icons={tableIcons}
                        title={this.state.reportTitle}
                        columns={this.state.columns}
                        data={this.state.data}
                        pageSize={10}
									fontSize={"14px"}
                        // options={{
                        //     filtering: true,
                        //     pageSize: 10,
                        //     pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
                        //     toolbar: true,
                        //     paging: true,
                        //     rowStyle: {
                        //         fontSize: '14px',
                        //         // fontWeight: "600"
                        //     },
                        //     headerStyle: {
                        //         fontWeight: 'bold',
                        //     }

                        // }}
                    />
                </ThemeProvider>
            </div>
            {//this.state.loading && <Loader />
            }

        </div>
        return this.state.columns.length > 0 ? ratePlanReport : this.state.loading?<Loader />:<div style={{marginTop:'40px'}}><p style={{textAlign:'center'}}>No Data Found!</p></div>;
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.login.loggedInUserInfo,
    };
}

const mapDispatchToProps = dispatch => {
    return {
        onReleaseExit: () => dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),

    };
};
export default connect(mapStateToProps, mapDispatchToProps)(withStyles(useStyles)(WithErrorHandler(withRouter(Reports), axios)));
