// return fields in order
export const retrieveFields = (data, parent) => {
  const fields = [];
  const dataLength = data.length;
  const mappedData = modifyData(data);

  let lookField = parent;
  let parentName = null;
  for (let i = 0; i < dataLength; i++) {
    const obj = retrieveField(mappedData, lookField);
    fields.push({ ...obj, parentField: parentName });
    lookField = obj.entityChild;
    parentName = obj.entityName;
  }

  return fields;
};

const modifyData = (data) => {
  return data.map((obj) => {
    return Object.entries(obj).map(([key, values]) => {
      return {
        entityName: key,
        ...values,
      };
    })[0];
  });
};

const retrieveField = (data = [], key = "") => {
  const foundEntity = data.find(({ entityName }) => entityName === key);
  return foundEntity;
};
