import React from 'react';
import ExpansionPanel from '../../UI/ExpansionPanel/ExpansionPanel';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';


const AttributesData = (props) => {
    return (
        <ExpansionPanel heading='Attribute Groups'>
            {(props.attribute != null && Object.keys(props.attribute).length > 0) ?
                Object.keys(props.attribute).map(attribute => {
                    return <ExpansionPanel heading={attribute} key={attribute}>
                        < List
                            component="nav"
                            aria-labelledby="nested-list-subheader"
                            style={{ width: '100%', maxHeight: '30vh', overflow: 'auto' }}
                        >
                            {props.attribute[attribute].map(attribute => {
                                return <React.Fragment key={attribute.productAttributeId}>
                                    <ListItem >
                                        <ListItemText primary={attribute.productAttributeId}
                                            secondary={attribute.productAttributeKey} />
                                    </ListItem>
                                    <Divider />
                                </React.Fragment>

                            })}
                        </List>

                    </ExpansionPanel>
                })

                : null}


        </ExpansionPanel>

    );
}

export default AttributesData;