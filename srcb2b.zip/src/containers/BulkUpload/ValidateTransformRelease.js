import React from 'react';
import { useSelector } from 'react-redux';
import BasicDetails from './BasicDetails';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import { useState } from 'react';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import AppsIcon from '@material-ui/icons/Apps';
import axios from '../../axios-epc';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import GetAppIcon from '@material-ui/icons/GetApp';
import { Paper } from '@material-ui/core';

const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Paper p={3}>
          <Typography>{children}</Typography>
        </Paper>
      )}
    </div>
  );
};

const ValidateTransformRelease = () => {
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const openDrawer = useSelector((state) => state.drawerData.open);
  const releaseData = useSelector((state) => state.releaseData.releaseData);

  const [activeTab, setActiveTab] = useState(0);
  const [selValidationLog, setSelValidationLog] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChangeTab = (newValue) => {
    setActiveTab(newValue ? newValue : 0);
  };

  const saveAsExcel = async (response, valLog) => {
    const workbook = new ExcelJS.Workbook();
    let worksheet = null;
    let columns = {};
    let fileName = null;
    Object.keys(response.data.data[0]).map((key) => {
      let val = key.replace(/([A-Z])/g, ' $1');
      val = val.charAt(0).toUpperCase() + val.slice(1);
      columns[key] = val;
    });

    console.log(columns);

    if (valLog === 'DEAL') {
      worksheet = workbook.addWorksheet('Deal Validation Logs');
      fileName = 'Deal Validation Logs';
    } else if (valLog === 'INSURANCE') {
      worksheet = workbook.addWorksheet('Device Validation Logs');
      fileName = 'Device Validation Logs';
    } else if (valLog === 'SKEW') {
      worksheet = workbook.addWorksheet('Sku Validation Logs');
      fileName = 'Sku Validation Logs';
    } else if (valLog === 'TRANSFORM') {
      worksheet = workbook.addWorksheet('Transformed Output');
      fileName = 'Transformed Output';
    }
    let sheetColumns = [];

    Object.keys(columns).map((key) => {
      sheetColumns.push({
        header: columns[key],
        key: key,
        width: 25,
      });
    });
    worksheet.columns = sheetColumns;
    response.data.data.map((row) => {
      worksheet.addRow(row);
    });

    const options = {
      formatterOptions: {
        delimiter: '|',
        transform: (row) => {
          let newArray = [''];

          for (var i = 0; i < row.length; i++) {
            var arr = [];
            arr.push(row[i]);
            newArray.push(arr);
          }
          newArray.push(['']);
          console.log(newArray);

          return newArray;
        },
      },
    };
    setLoading(false);
    if (valLog === 'TRANSFORM') {
      worksheet.spliceRows(0, 1);
      workbook.csv.writeBuffer(options).then(function (buffer) {
        saveAs(
          new Blob([buffer], { type: 'application/octet-stream' }),
          fileName + '.csv'
        );
      });
    } else {
      worksheet.getRow(1).font = {
        bold: true,
      };
      const buf = await workbook.xlsx.writeBuffer();
      saveAs(new Blob([buf]), fileName + '.xlsx');
    }
  };

  const downloadValidationLogs = (event, index, valLog) => {
    setSelValidationLog(index);

    axios
      .get(
        'mtn/getErrorLog?releaseId=' +
          releaseData.releaseId +
          '&entity=' +
          valLog
      )
      .then((response) => {
        if (response) {
          saveAsExcel(response, valLog);
        } else {
          setLoading(false);
        }
      })
      .catch((error) => {});
  };
  return (
    <>
      <BasicDetails releaseData={releaseData} userInfo={userInfo} />
      <div style={{ padding: '0 24px' }}>
        <div style={{ padding: '20px 0', fontSize: '18px', fontWeight: '600' }}>
          Validate and transform
        </div>
        <div>
          <div
            style={{
              background: '#fff',
              marginBottom: '24px',
              maxWidth: '600px',
              borderRadius: '50px',
              padding: '4px',
            }}
          >
            {/* <AppBar position="static"> */}
            <div
              style={{
                display: 'flex',
                textAlign: 'center',
                fontWeight: '600',
              }}
            >
              <div
                style={{
                  flexBasis: '50%',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                onClick={() => handleChangeTab(0)}
              >
                <div
                  style={
                    activeTab === 0
                      ? {
                          background: '#ffc800',
                          padding: '8px',
                          borderRadius: '50px',
                          width: '100%',
                        }
                      : {}
                  }
                >
                  Validation logs
                </div>
              </div>
              <div
                style={{
                  flexBasis: '50%',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                onClick={() => handleChangeTab(1)}
              >
                <div
                  style={
                    activeTab === 1
                      ? {
                          background: '#ffc800',
                          padding: '8px',
                          borderRadius: '50px',
                          width: '100%',
                        }
                      : {}
                  }
                >
                  Transformed output
                </div>
              </div>
            </div>
            {/* <Tabs
                value={activeTab}
                indicatorColor="white"
                variant="fullWidth"
                onChange={handleChangeTab}
              >
                <Tab
                  label="Validation logs"
                  style={{
                    background: "#fffff",
                    color: "#000",
                    textTransform: "none",
                    //   fontWeight: "bold",
                  }}
                />
                <Tab
                  label="Transformed output"
                  style={{
                    background: "#ffffff",
                    color: "#000000",
                    textTransform: "none",
                    //   fontWeight: "bold",
                  }}
                />
              </Tabs> */}
            {/* </AppBar> */}
          </div>
          <TabPanel value={activeTab} index={0}>
            <List component='nav'>
              <ListItem
                style={{ cursor: 'pointer' }}
                selected={selValidationLog === 0}
                onClick={(event) => downloadValidationLogs(event, 0, 'DEAL')}
              >
                <div
                  style={{
                    cursor: 'pointer',
                    border: '1px solid #999',
                    width: '100%',
                    display: 'flex',
                    padding: '10px',
                    borderRadius: '4px',
                  }}
                >
                  <ListItemText primary={'Deal validation logs'} />
                  <ListItemIcon>
                    <GetAppIcon />
                  </ListItemIcon>
                </div>
              </ListItem>
              <ListItem
                selected={selValidationLog === 1}
                onClick={(event) =>
                  downloadValidationLogs(event, 1, 'INSURANCE')
                }
              >
                <div
                  style={{
                    cursor: 'pointer',
                    border: '1px solid #999',
                    width: '100%',
                    display: 'flex',
                    padding: '10px',
                    borderRadius: '4px',
                  }}
                >
                  <ListItemText primary={'Device pricing validation logs'} />
                  <ListItemIcon>
                    <GetAppIcon />
                  </ListItemIcon>
                </div>
              </ListItem>
              <ListItem
                style={{ cursor: 'pointer' }}
                selected={selValidationLog === 2}
                onClick={(event) => downloadValidationLogs(event, 2, 'SKEW')}
              >
                <div
                  style={{
                    cursor: 'pointer',
                    border: '1px solid #999',
                    width: '100%',
                    display: 'flex',
                    padding: '10px',
                    borderRadius: '4px',
                  }}
                >
                  <ListItemText primary={'Sku validation logs'} />
                  <ListItemIcon>
                    <GetAppIcon />
                  </ListItemIcon>
                </div>
              </ListItem>
              {/* <Divider /> */}
            </List>
          </TabPanel>
          <TabPanel value={activeTab} index={1}>
            <List component='nav'>
              <ListItem
                style={{ cursor: 'pointer' }}
                selected={selValidationLog === 0}
                onClick={(event) =>
                  downloadValidationLogs(event, 0, 'TRANSFORM')
                }
              >
                <div
                  style={{
                    cursor: 'pointer',
                    border: '1px solid #999',
                    width: '100%',
                    display: 'flex',
                    padding: '10px',
                    borderRadius: '4px',
                  }}
                >
                  <ListItemText primary={'Download transformed output'} />
                  <ListItemIcon>
                    <GetAppIcon />
                  </ListItemIcon>
                </div>
              </ListItem>
            </List>
          </TabPanel>
        </div>
      </div>
    </>
  );
};

export default ValidateTransformRelease;
