import React, { Component } from 'react';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from 'axios';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import AddIcon from '@material-ui/icons/Add';
import LastPageIcon from '@material-ui/icons/LastPage';
import { connect } from 'react-redux';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../UI/Loader/Loader';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import moment from 'moment';
import CustomInput from '../../UI/Input/Input';
import Box from '@material-ui/core/Box';
import MultiSelect from '../../UI/Input/MultiSelect';
import IconButton from '@material-ui/core/IconButton';
import SearchIcon from '@material-ui/icons/Search';
import Typography from '@material-ui/core/Typography';
import Modal from '../../UI/Modal/Modal';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import DeleteIcon from '@material-ui/icons/Delete';
import Paper from '@material-ui/core/Paper';
import Title from '../../UI/Typography/Title';
import StyledButton from '../../UI/Button/Button';

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    // backgroundColor: "#525354",
    // color: "white",
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
  },
  subheader: {
    fontSize: '20px',
    color: '#393939',
    // color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
});

class Events extends Component {
  _isMounted = false;

  state = {
    selEvent: '',
    show: false,
    modalContent: null,
    loading: false,
    eventAppliedOn: '',
    eventDesc: '',
    eventName: '',
    eventType: '',
    version: '',
    categories: [],
    categoryOptions: [],
    types: [],
    typesOptions: [],
    subTypes: [],
    subTypesOptions: [],
    selCategories: [],
    selTypes: [],
    selSubtypes: [],
    products: [],
    selProduct: '',
    bundleItemsProducts: {},
    bundleItems: [],
    selbundleItem: null,
    attributes: {},
    attributeValue: '',
    events: [],
    eventId: '',
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    this.versionsHandler().then(() => {
      this.fieldsLov().then(() => {
        this.attributeData().then(() => {
          this.getEvents().then(() => {
            let categoryOptions = [];
            let typesOptions = [];
            let subTypesOptions = [];

            this.state.categories.map((category) => {
              categoryOptions.push(category.uiName);
            });
            this.state.types.map((type) => {
              typesOptions.push(type.uiName);
            });
            this.state.subTypes.map((subType) => {
              subTypesOptions.push(subType.uiName);
            });

            this.setState({
              categoryOptions: Array.from(new Set(categoryOptions)),
              typesOptions: Array.from(new Set(typesOptions)),
              subTypesOptions: Array.from(new Set(subTypesOptions)),
            });
            console.log(this.state.attributes);
          });
        });
      });
    });
  }

  getEvents = () => {
    return axios
      .get(
        process.env.REACT_APP_URL +
          'attribute/event/list?releaseId=' +
          this.props.releaseData.releaseId,
        {
          headers: {
            opId: this.props.userInfo.opId,
            authUserId: this.props.userInfo.id,
            // Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        }
      )
      .then((res) => {
        console.log(res);
        let events = [];
        Object.keys(res.data.data).map((event) => {
          events.push(event + '/' + res.data.data[event]);
        });
        this.setState({
          events: events,
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  searchProducts = () => {
    this.setState({
      loading: false,
      selProduct: null,
    });
    let payload = {};
    payload.releaseId = this.props.releaseData.releaseId;
    payload.categoryList = this.state.selCategories;
    payload.typeList = this.state.selTypes;
    payload.subTypeList = this.state.selSubtypes;
    console.log(payload);
    axios
      .post(process.env.REACT_APP_URL + 'package/bundle/ctsProducts', payload, {
        headers: {
          opId: this.props.userInfo.opId,
          authUserId: this.props.userInfo.id,
          // Authorization: 'Bearer ' + this.props.userInfo.jwt
        },
      })
      .then((res) => {
        console.log(res.data.data);
        let products = [];
        if (res.data.data.length > 0) {
          res.data.data.map((product) => {
            products.push(product.productId + '/' + product.productDesc);
          });
          if (this._isMounted)
            this.setState({ loading: false, products: products });
        } else {
          let modalContent = (
            <Typography variant='h6'>No Products Found.</Typography>
          );
          if (this._isMounted)
            this.setState({
              modalContent: modalContent,
              show: true,
              loading: false,
              products: [],
            });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  fieldsLov() {
    if (
      localStorage.getItem('productCategories') &&
      localStorage.getItem('productSubTypes') &&
      localStorage.getItem('productTypes') &&
      localStorage.productCts_version &&
      localStorage.productCts_version == this.state.version
    ) {
      console.log('fetching cts from local storage');
      try {
        this.setState({
          categories: JSON.parse(localStorage.getItem('productCategories')),
          subTypes: JSON.parse(localStorage.getItem('productSubTypes')),
          types: JSON.parse(localStorage.getItem('productTypes')),
        });
      } catch (e) {
        localStorage.removeItem('productCategories');
        localStorage.removeItem('productSubTypes');
        localStorage.removeItem('productTypes');
      }
      return Promise.resolve();
    } else {
      console.log('fetching cst from api');
      return axios
        .all([
          axios.get(
            process.env.REACT_APP_URL +
              'config?entityName=product.categoryList',
            {
              headers: {
                opId: this.props.userInfo.opId,
                buId: this.props.userInfo.buId,
                authUserId: this.props.userInfo.id,
                // Authorization: 'Bearer ' + this.props.userInfo.jwt
              },
            }
          ),
          axios.get(
            process.env.REACT_APP_URL + 'config?entityName=product.subTypeList',
            {
              headers: {
                opId: this.props.userInfo.opId,
                buId: this.props.userInfo.buId,
                authUserId: this.props.userInfo.id,
                // Authorization: 'Bearer ' + this.props.userInfo.jwt
              },
            }
          ),
          axios.get(
            process.env.REACT_APP_URL + 'config?entityName=product.typeList',
            {
              headers: {
                opId: this.props.userInfo.opId,
                buId: this.props.userInfo.buId,
                authUserId: this.props.userInfo.id,
                // Authorization: 'Bearer ' + this.props.userInfo.jwt
              },
            }
          ),
        ])
        .then(
          axios.spread((resCategories, resSubTypes, resTypes) => {
            let types = resTypes.data.data;
            localStorage.setItem('productTypes', JSON.stringify(types));
            let subTypes = resSubTypes.data.data;
            localStorage.setItem('productSubTypes', JSON.stringify(subTypes));
            let categories = resCategories.data.data;
            localStorage.setItem(
              'productCategories',
              JSON.stringify(categories)
            );
            if (this._isMounted)
              this.setState({
                categories: categories,
                subTypes: subTypes,
                types: types,
              });
            localStorage.productCts_version = this.state.version;
          })
        )
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  versionsHandler() {
    return axios
      .get(
        process.env.REACT_APP_URL + 'config/version?entityName=product.cts',
        {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            authUserId: this.props.userInfo.id,
            // Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        }
      )
      .then((res) => {
        if (this._isMounted) this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  attributeData() {
    if (this.props.releaseData.releaseId) {
      return axios
        .get(
          process.env.REACT_APP_URL +
            'attribute/basicDetails?releaseId=' +
            this.props.releaseData.releaseId,
          {
            headers: {
              opId: this.props.userInfo.opId,
              authUserId: this.props.userInfo.id,
              // Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        )
        .then((res) => {
          console.log('attr');
          console.log(res);
          let attributes = {};
          res.data.data.forEach((attribute) => {
            attributes[attribute.ppmAttrName] = attribute;
          });
          if (this._isMounted)
            this.setState({
              attributes: attributes,
            });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      return Promise.resolve();
    }
  }

  backToRelease = () => {
    this.props.history.push('/editRelease');
  };

  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };

  saveEvent = () => {
    this.setState({ loading: true });
    console.log(this.state.bundleItemsProducts);
    let date = moment().format('DD-MMM-YYYY');
    let payload = {};
    let paramDetailsVo = [];
    let ppmEventMasterAud = {
      buId: this.props.userInfo.buId,
      createdBy: this.props.userInfo.id,
      createdDate: date,
      endDate: '30-DEC-2030',
      eventDesc: this.state.eventDesc,
      eventName: this.state.eventName,
      eventType: this.state.eventType,
      opId: this.props.userInfo.opId,
      startDate: date,
      triggerConstraints: this.state.eventName,
    };
    if (this.state.eventId) ppmEventMasterAud.eventId = this.state.eventId;

    Object.keys(this.state.bundleItemsProducts).map((entity) => {
      let obj = {
        attrName: this.state.bundleItemsProducts[entity].attrName,
        attrValue: this.state.bundleItemsProducts[entity].attrValue,
        attributeId: this.state.bundleItemsProducts[entity].attributeId,
      };
      paramDetailsVo.push(obj);
    });
    payload.paramDetailsVo = paramDetailsVo;
    payload.ppmEventMasterAud = ppmEventMasterAud;
    payload.releaseId = this.props.releaseData.releaseId;
    console.log(payload);
    console.log(process.env.REACT_APP_URL + 'attribute/event/create');
    axios
      .post(process.env.REACT_APP_URL + 'attribute/event/create', payload, {
        headers: {
          authUserId: this.props.userInfo.id,
          // Authorization: 'Bearer ' + this.props.userInfo.jwt
        },
      })
      .then((response) => {
        console.log(response);
        let events = [...this.state.events];
        if (
          !events.includes(
            response.data.data.eventId + '/' + this.state.eventName
          )
        )
          events.push(response.data.data.eventId + '/' + this.state.eventName);
        this.setState({
          loading: false,
          eventId: response.data.data.eventId,
          events: events,
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  render() {
    const { classes } = this.props;

    let events = (
      <div>
        <Modal
          show={this.state.show}
          modalClosed={this.errorConfirmedHandler}
          title={'Something Went Wrong!'}
        >
          {this.state.modalContent}
        </Modal>
        <div>
          <Title>
            <div style={{ display: 'flex' }}>
              {this.props.releaseData.releaseId
                ? 'Events ( Release ' + this.props.releaseData.releaseId + ' )'
                : 'Events'}

              {this.props.releaseData.releaseId && (
                <React.Fragment>
                  <div style={{ marginLeft: 'auto' }}>
                    <StyledButton
                      style={{
                        // background: '#02bfa0',
                        // marginTop: '1%',
                        // marginBottom: '1%',
                        // textTransform: 'none',
                        // marginLeft: '20px',
                        background: '#5dc17f',
                      }}
                      onClick={() => {
                        this.setState({
                          eventId: '',
                          eventType: null,
                          eventAppliedOn: null,
                          eventDesc: null,
                          eventName: null,
                          bundleItemsProducts: {},
                          selbundleItem: null,
                          attributeValue: null,
                          selProduct: null,
                        });
                      }}
                    >
                      New Event
                    </StyledButton>
                    {/* <StyledButton
                      style={{
                        background: "none",
                        border: "2px solid #ff1921",
                        color: "#ff1921",
                        marginLeft: "10px",
                      }}
                      onClick={this.backToRelease}
                    >
                      Back To Release
                    </StyledButton> */}
                  </div>
                </React.Fragment>
              )}
            </div>
          </Title>

          <Grid
            container
            alignContent='flex-start'
            spacing={2}
            style={{ overflow: 'visible' }}
          >
            <CustomInput
              refType='SelectInput'
              refLovs={this.state.events}
              uiName={'Available Events'}
              value={this.state.selEvent}
              changed={(event) => {
                this.setState({ loading: true });
                axios
                  .get(
                    process.env.REACT_APP_URL +
                      'attribute/event/basicDetails?releaseId=' +
                      this.props.releaseData.releaseId +
                      '&eventId=' +
                      event.split('/')[0],
                    {
                      headers: {
                        opId: this.props.userInfo.opId,
                        authUserId: this.props.userInfo.id,
                        // Authorization: 'Bearer ' + this.props.userInfo.jwt
                      },
                    }
                  )
                  .then((res) => {
                    console.log(res);
                    let bundleItemsProducts = {};
                    res.data.data.paramDetailsVo.map((event) => {
                      bundleItemsProducts[event.attributeId] = event;
                    });
                    this.setState({
                      eventId: res.data.data.eventDetails.eventId,
                      loading: false,
                      eventType: res.data.data.eventDetails.eventType,
                      eventName: res.data.data.eventDetails.eventName,
                      eventDesc: res.data.data.eventDetails.eventDesc,
                      bundleItemsProducts: bundleItemsProducts,
                    });
                  })
                  .catch((error) => {
                    console.log(error);
                    if (this._isMounted) this.setState({ loading: false });
                  });
              }}
            />
          </Grid>
          <Grid
            container
            alignContent='flex-start'
            spacing={2}
            style={{ overflow: 'visible', marginTop: '2vh' }}
          >
            <CustomInput
              refType='SelectInput'
              refLovs={['Include', 'Exclude']}
              uiName={'Event Type'}
              value={this.state.eventType}
              changed={(event) => {
                this.setState({
                  eventType: event,
                });
              }}
            />

            <CustomInput
              refType='TextInput'
              uiName={'Event Name'}
              value={this.state.eventName}
              changed={(event) => {
                this.setState({
                  eventName: event.target.value,
                });
              }}
            />
            <CustomInput
              refType='TextInput'
              uiName={'Event Description'}
              value={this.state.eventDesc}
              changed={(event) => {
                this.setState({
                  eventDesc: event.target.value,
                });
              }}
            />

            <CustomInput
              refType='SelectInput'
              refLovs={[
                'Attribute',
                'Product',
                'Promotion',
                'Package',
                'Bundle',
              ]}
              uiName={'Rule Applied On'}
              value={this.state.eventAppliedOn}
              changed={(value) => {
                this.setState({
                  eventAppliedOn: value,
                  selbundleItem: null,
                });
                let url = '';
                if (value == 'Package')
                  url = 'package/basicDetails/searchPackages?releaseID=';
                else if (value == 'Bundle')
                  url = 'package/basicDetails/searchBundles?releaseID=';
                else if (value == 'Promotion')
                  url = 'package/basicDetails/searchPromotions?releaseID=';
                let bundleItems = [];

                if (value == 'Attribute') {
                  bundleItems = [...Object.keys(this.state.attributes)];
                  this.setState({ bundleItems: bundleItems });
                } else if (value != 'Product') {
                  this.setState({ loading: true });
                  axios
                    .get(
                      process.env.REACT_APP_URL +
                        url +
                        this.props.releaseData.releaseId,
                      {
                        headers: {
                          opId: this.props.userInfo.opId,
                          authUserId: this.props.userInfo.id,
                          // Authorization: 'Bearer ' + this.props.userInfo.jwt
                        },
                      }
                    )

                    .then((res) => {
                      console.log(res);
                      Object.keys(res.data.data).map((item) => {
                        bundleItems.push(item + '/' + res.data.data[item]);
                      });
                      if (this._isMounted)
                        this.setState({
                          loading: false,
                          bundleItems: bundleItems,
                        });
                    })
                    .catch((error) => {
                      console.log(error);
                      if (this._isMounted) this.setState({ loading: false });
                    });
                }
              }}
            />
          </Grid>

          {this.state.eventAppliedOn && (
            <Card style={{ overflow: 'visible', marginTop: '4vh' }}>
              <CardHeader
                className={classes.cardHeader}
                classes={{
                  subheader: classes.subheader,
                }}
                subheader={'Filter ' + this.state.eventAppliedOn}
              />

              <CardContent>
                {this.state.eventAppliedOn == 'Product' && (
                  <div>
                    <Grid container alignContent='flex-start' spacing={2}>
                      <Grid item xs={12} sm={6} md={3}>
                        <Box>
                          <span style={{}}>Category</span>
                        </Box>

                        <Box mt={2}>
                          <MultiSelect
                            refLovs={this.state.categoryOptions}
                            value={this.state.selCategories}
                            changed={(selected) => {
                              this.setState({ selCategories: selected });
                            }}
                            placeholder={'Categories'}
                          />
                        </Box>
                      </Grid>

                      <Grid item xs={12} sm={6} md={3}>
                        <Box>
                          <span style={{}}>Type</span>
                        </Box>
                        <Box mt={2}>
                          <MultiSelect
                            refLovs={this.state.typesOptions}
                            value={this.state.selTypes}
                            changed={(selected) => {
                              this.setState({ selTypes: selected });
                            }}
                            placeholder={'Types'}
                          />
                        </Box>
                      </Grid>

                      <Grid item xs={10} sm={6} md={3}>
                        <Box>
                          <span style={{}}>Sub Type</span>
                        </Box>
                        <Box mt={2}>
                          <MultiSelect
                            refLovs={this.state.subTypesOptions}
                            value={this.state.selSubtypes}
                            changed={(selected) => {
                              this.setState({ selSubtypes: selected });
                            }}
                            placeholder={'Sub Types'}
                          />
                        </Box>
                      </Grid>
                      {this.props.releaseData.releaseId && (
                        <Grid item xs={2} sm={6} md={3}>
                          <Box mt={1}>
                            <IconButton onClick={this.searchProducts}>
                              <SearchIcon />
                            </IconButton>
                          </Box>
                        </Grid>
                      )}
                    </Grid>
                    {this.state.products.length > 0 && (
                      <Grid
                        container
                        alignItems='flex-end'
                        spacing={2}
                        style={{ marginTop: '2vh' }}
                      >
                        <Grid item xs={12} sm={6}>
                          <Box>
                            <span style={{}}>Products</span>
                          </Box>
                          <Box mt={1}>
                            <CustomInput
                              resize
                              refType='SelectInput'
                              value={this.state.selProduct}
                              changed={(value) => {
                                if (value) {
                                  if (
                                    value.split('/')[0] in
                                    this.state.bundleItemsProducts
                                  ) {
                                    let modalContent = (
                                      <Typography variant='h6'>
                                        Product Already Selected.
                                      </Typography>
                                    );
                                    this.setState({
                                      modalContent: modalContent,
                                      show: true,
                                    });
                                  } else {
                                    let proDetails = {};
                                    let productId = value.split('/')[0];
                                    proDetails.attrName = 'Product';
                                    proDetails.attrValue = value.split('/')[1];
                                    proDetails.attributeId =
                                      value.split('/')[0];
                                    this.setState((prevState) => {
                                      return {
                                        bundleItemsProducts: {
                                          ...prevState.bundleItemsProducts,
                                          [productId]: proDetails,
                                        },
                                      };
                                    });
                                  }
                                  this.setState({ selProduct: null });
                                }
                              }}
                              refLovs={this.state.products}
                            />
                          </Box>
                        </Grid>
                      </Grid>
                    )}
                  </div>
                )}
                {this.state.eventAppliedOn != 'Product' && (
                  <div>
                    <Grid container alignContent='flex-start' spacing={2}>
                      <CustomInput
                        refType='SelectInput'
                        uiName={this.state.eventAppliedOn}
                        value={this.state.selbundleItem}
                        changed={(value) => {
                          if (value) {
                            this.setState({ selbundleItem: value });
                            if (this.state.eventAppliedOn != 'Attribute') {
                              if (
                                value.split('/')[0] in
                                this.state.bundleItemsProducts
                              ) {
                                let modalContent = (
                                  <Typography variant='h6'>
                                    {this.state.eventAppliedOn} Already
                                    Selected.
                                  </Typography>
                                );
                                this.setState({
                                  modalContent: modalContent,
                                  show: true,
                                });
                              } else {
                                let bundleDetails = {};
                                let bundleId = value.split('/')[0];
                                bundleDetails.attrName =
                                  this.state.eventAppliedOn;
                                bundleDetails.attrValue = value.split('/')[1];
                                bundleDetails.attributeId = value.split('/')[0];
                                this.setState((prevState) => {
                                  return {
                                    bundleItemsProducts: {
                                      ...prevState.bundleItemsProducts,
                                      [bundleId]: bundleDetails,
                                    },
                                    selbundleItem: null,
                                  };
                                });
                              }
                            }
                          }
                        }}
                        refLovs={this.state.bundleItems}
                      />

                      {this.state.eventAppliedOn == 'Attribute' && (
                        <React.Fragment>
                          <Grid item xs={12} sm={3}>
                            <Box mt={1}>
                              <span>Attribute Value</span>
                            </Box>
                            <Box mt={1}>
                              {this.state.attributes[
                                this.state.selbundleItem
                              ] &&
                              this.state.attributes[this.state.selbundleItem]
                                .ppmAttrType == 'LIST' ? (
                                <CustomInput
                                  table
                                  refType='SelectInput'
                                  refLovs={
                                    this.state.attributes[
                                      this.state.selbundleItem
                                    ].ppmAttrValue
                                      ? this.state.attributes[
                                          this.state.selbundleItem
                                        ].ppmAttrValue.split(',')
                                      : []
                                  }
                                  value={this.state.attributeValue}
                                  changed={(event) => {
                                    this.setState({
                                      attributeValue: event,
                                    });
                                  }}
                                />
                              ) : (
                                <CustomInput
                                  table
                                  refType='TextInput'
                                  value={this.state.attributeValue}
                                  changed={(event) => {
                                    this.setState({
                                      attributeValue: event.target.value,
                                    });
                                  }}
                                />
                              )}
                            </Box>
                          </Grid>
                          <Grid item xs={2}>
                            <Box mt={4}>
                              <Button
                                onClick={() => {
                                  if (
                                    this.state.selbundleItem in
                                    this.state.bundleItemsProducts
                                  ) {
                                    let modalContent = (
                                      <Typography variant='h6'>
                                        {this.state.eventAppliedOn} Already
                                        Selected.
                                      </Typography>
                                    );
                                    this.setState({
                                      modalContent: modalContent,
                                      show: true,
                                    });
                                  } else {
                                    let bundleDetails = {};
                                    let bundleId = this.state.selbundleItem;
                                    bundleDetails.attrName = 'Attribute';
                                    bundleDetails.attrValue =
                                      this.state.attributeValue;
                                    bundleDetails.attributeId =
                                      this.state.selbundleItem;
                                    this.setState((prevState) => {
                                      return {
                                        bundleItemsProducts: {
                                          ...prevState.bundleItemsProducts,
                                          [bundleId]: bundleDetails,
                                        },
                                        selbundleItem: null,
                                        attributeValue: null,
                                      };
                                    });
                                  }
                                }}
                                style={{
                                  background: 'orange',
                                  textTransform: 'none',
                                }}
                              >
                                Add
                              </Button>
                            </Box>
                          </Grid>
                        </React.Fragment>
                      )}
                    </Grid>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
          <Card style={{ overflow: 'visible', marginTop: '4vh' }}>
            <CardHeader
              className={classes.cardHeader}
              classes={{
                subheader: classes.subheader,
              }}
              subheader={'Rule Applied On'}
            />

            <CardContent>
              <TableContainer component={Paper} style={{ height: '30vh' }}>
                <Table className={classes.table} size='small'>
                  <TableHead>
                    <TableRow>
                      <TableCell>Applied On</TableCell>
                      <TableCell>Id</TableCell>
                      <TableCell>Value</TableCell>
                      <TableCell>Delete</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {Object.keys(this.state.bundleItemsProducts).map((key) => {
                      return (
                        <TableRow key={key}>
                          <TableCell
                            style={{
                              width: '20%',
                            }}
                          >
                            {this.state.bundleItemsProducts[key].attrName}
                          </TableCell>
                          <TableCell
                            style={{
                              width: '30%',
                            }}
                          >
                            {key}
                          </TableCell>
                          <TableCell
                            style={{
                              width: '30%',
                            }}
                          >
                            {this.state.bundleItemsProducts[key].attrValue}
                          </TableCell>
                          <TableCell style={{ width: '5%' }}>
                            <DeleteIcon
                              onClick={(event) => {
                                event.stopPropagation();
                                let bundleItemsProducts = {
                                  ...this.state.bundleItemsProducts,
                                };
                                delete bundleItemsProducts[key];
                                this.setState({
                                  bundleItemsProducts: bundleItemsProducts,
                                });
                              }}
                              style={{ color: 'red', cursor: 'pointer' }}
                            />
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
          {this.props.releaseData.releaseId && (
            <div
              style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <StyledButton
                onClick={this.saveEvent}
                style={{
                  marginTop: '12px',
                  padding: '6px 32px',
                  background: '#5dc17f',
                  //   background: "#02bfa0",
                  //   marginTop: "1%",
                  //   marginBottom: "1%",
                  //   textTransform: "none",
                }}

                // variant="contained"
              >
                Save
              </StyledButton>
            </div>
          )}
        </div>
      </div>
      // <Card style={{ overflow: "visible" }}>
      //   <Modal
      //     show={this.state.show}
      //     modalClosed={this.errorConfirmedHandler}
      //     title={"Something Went Wrong!"}
      //   >
      //     {this.state.modalContent}
      //   </Modal>
      //   <CardHeader
      //     className={classes.cardHeader}
      //     classes={{
      //       subheader: classes.subheader,
      //     }}
      //     action={
      //       this.props.releaseData.releaseId && (
      //         <React.Fragment>
      //           <div>
      //             <LightTooltip title="New Event" arrow>
      //               <AddIcon
      //                 onClick={() => {
      //                   this.setState({
      //                     eventId: "",
      //                     eventType: null,
      //                     eventAppliedOn: null,
      //                     eventDesc: null,
      //                     eventName: null,
      //                     bundleItemsProducts: {},
      //                     selbundleItem: null,
      //                     attributeValue: null,
      //                     selProduct: null,
      //                   });
      //                 }}
      //                 style={{
      //                   color: "white",
      //                   marginRight: "10px",
      //                   cursor: "pointer",
      //                 }}
      //               />
      //             </LightTooltip>

      //             <LightTooltip title="Back To Release" arrow>
      //               <LastPageIcon
      //                 onClick={this.backToRelease}
      //                 style={{ color: "white", cursor: "pointer" }}
      //               />
      //             </LightTooltip>
      //           </div>
      //         </React.Fragment>
      //       )
      //     }
      //     subheader={
      //       this.props.releaseData.releaseId
      //         ? "Events You are inside release " +
      //           this.props.releaseData.releaseId
      //         : "Events"
      //     }
      //   />

      //   <CardContent style={{ marginTop: "2%", marginBottom: "2%" }}>
      //     <Grid
      //       container
      //       alignContent="flex-start"
      //       spacing={2}
      //       style={{ overflow: "visible" }}
      //     >
      //       <CustomInput
      //         refType="SelectInput"
      //         refLovs={this.state.events}
      //         uiName={"Available Events"}
      //         value={this.state.selEvent}
      //         changed={(event) => {
      //           this.setState({ loading: true });
      //           axios
      //             .get(
      //               process.env.REACT_APP_URL +
      //                 "attribute/event/basicDetails?releaseId=" +
      //                 this.props.releaseData.releaseId +
      //                 "&eventId=" +
      //                 event.split("/")[0],
      //               {
      //                 headers: {
      //                   opId: this.props.userInfo.opId,
      //                   authUserId: this.props.userInfo.id,
      //                   // Authorization: 'Bearer ' + this.props.userInfo.jwt
      //                 },
      //               }
      //             )
      //             .then((res) => {
      //               console.log(res);
      //               let bundleItemsProducts = {};
      //               res.data.data.paramDetailsVo.map((event) => {
      //                 bundleItemsProducts[event.attributeId] = event;
      //               });
      //               this.setState({
      //                 eventId: res.data.data.eventDetails.eventId,
      //                 loading: false,
      //                 eventType: res.data.data.eventDetails.eventType,
      //                 eventName: res.data.data.eventDetails.eventName,
      //                 eventDesc: res.data.data.eventDetails.eventDesc,
      //                 bundleItemsProducts: bundleItemsProducts,
      //               });
      //             })
      //             .catch((error) => {
      //               console.log(error);
      //               if (this._isMounted) this.setState({ loading: false });
      //             });
      //         }}
      //       />
      //     </Grid>
      //     <Grid
      //       container
      //       alignContent="flex-start"
      //       spacing={2}
      //       style={{ overflow: "visible", marginTop: "2vh" }}
      //     >
      //       <CustomInput
      //         refType="SelectInput"
      //         refLovs={["Include", "Exclude"]}
      //         uiName={"Event Type"}
      //         value={this.state.eventType}
      //         changed={(event) => {
      //           this.setState({
      //             eventType: event,
      //           });
      //         }}
      //       />

      //       <CustomInput
      //         refType="TextInput"
      //         uiName={"Event Name"}
      //         value={this.state.eventName}
      //         changed={(event) => {
      //           this.setState({
      //             eventName: event.target.value,
      //           });
      //         }}
      //       />
      //       <CustomInput
      //         refType="TextInput"
      //         uiName={"Event Description"}
      //         value={this.state.eventDesc}
      //         changed={(event) => {
      //           this.setState({
      //             eventDesc: event.target.value,
      //           });
      //         }}
      //       />

      //       <CustomInput
      //         refType="SelectInput"
      //         refLovs={[
      //           "Attribute",
      //           "Product",
      //           "Promotion",
      //           "Package",
      //           "Bundle",
      //         ]}
      //         uiName={"Rule Applied On"}
      //         value={this.state.eventAppliedOn}
      //         changed={(value) => {
      //           this.setState({
      //             eventAppliedOn: value,
      //             selbundleItem: null,
      //           });
      //           let url = "";
      //           if (value == "Package")
      //             url = "package/basicDetails/searchPackages?releaseID=";
      //           else if (value == "Bundle")
      //             url = "package/basicDetails/searchBundles?releaseID=";
      //           else if (value == "Promotion")
      //             url = "package/basicDetails/searchPromotions?releaseID=";
      //           let bundleItems = [];

      //           if (value == "Attribute") {
      //             bundleItems = [...Object.keys(this.state.attributes)];
      //             this.setState({ bundleItems: bundleItems });
      //           } else if (value != "Product") {
      //             this.setState({ loading: true });
      //             axios
      //               .get(
      //                 process.env.REACT_APP_URL +
      //                   url +
      //                   this.props.releaseData.releaseId,
      //                 {
      //                   headers: {
      //                     opId: this.props.userInfo.opId,
      //                     authUserId: this.props.userInfo.id,
      //                     // Authorization: 'Bearer ' + this.props.userInfo.jwt
      //                   },
      //                 }
      //               )

      //               .then((res) => {
      //                 console.log(res);
      //                 Object.keys(res.data.data).map((item) => {
      //                   bundleItems.push(item + "/" + res.data.data[item]);
      //                 });
      //                 if (this._isMounted)
      //                   this.setState({
      //                     loading: false,
      //                     bundleItems: bundleItems,
      //                   });
      //               })
      //               .catch((error) => {
      //                 console.log(error);
      //                 if (this._isMounted) this.setState({ loading: false });
      //               });
      //           }
      //         }}
      //       />
      //     </Grid>

      //     {this.state.eventAppliedOn && (
      //       <Card style={{ overflow: "visible", marginTop: "4vh" }}>
      //         <CardHeader
      //           className={classes.cardHeader}
      //           classes={{
      //             subheader: classes.subheader,
      //           }}
      //           subheader={"Filter " + this.state.eventAppliedOn}
      //         />

      //         <CardContent>
      //           {this.state.eventAppliedOn == "Product" && (
      //             <div>
      //               <Grid container alignContent="flex-start" spacing={2}>
      //                 <Grid item xs={12} sm={6} md={3}>
      //                   <Box>
      //                     <span style={{}}>Category</span>
      //                   </Box>

      //                   <Box mt={2}>
      //                     <MultiSelect
      //                       refLovs={this.state.categoryOptions}
      //                       value={this.state.selCategories}
      //                       changed={(selected) => {
      //                         this.setState({ selCategories: selected });
      //                       }}
      //                       placeholder={"Categories"}
      //                     />
      //                   </Box>
      //                 </Grid>

      //                 <Grid item xs={12} sm={6} md={3}>
      //                   <Box>
      //                     <span style={{}}>Type</span>
      //                   </Box>
      //                   <Box mt={2}>
      //                     <MultiSelect
      //                       refLovs={this.state.typesOptions}
      //                       value={this.state.selTypes}
      //                       changed={(selected) => {
      //                         this.setState({ selTypes: selected });
      //                       }}
      //                       placeholder={"Types"}
      //                     />
      //                   </Box>
      //                 </Grid>

      //                 <Grid item xs={10} sm={6} md={3}>
      //                   <Box>
      //                     <span style={{}}>Sub Type</span>
      //                   </Box>
      //                   <Box mt={2}>
      //                     <MultiSelect
      //                       refLovs={this.state.subTypesOptions}
      //                       value={this.state.selSubtypes}
      //                       changed={(selected) => {
      //                         this.setState({ selSubtypes: selected });
      //                       }}
      //                       placeholder={"Sub Types"}
      //                     />
      //                   </Box>
      //                 </Grid>
      //                 {this.props.releaseData.releaseId && (
      //                   <Grid item xs={2} sm={6} md={3}>
      //                     <Box mt={1}>
      //                       <IconButton onClick={this.searchProducts}>
      //                         <SearchIcon />
      //                       </IconButton>
      //                     </Box>
      //                   </Grid>
      //                 )}
      //               </Grid>
      //               {this.state.products.length > 0 && (
      //                 <Grid
      //                   container
      //                   alignItems="flex-end"
      //                   spacing={2}
      //                   style={{ marginTop: "2vh" }}
      //                 >
      //                   <Grid item xs={12} sm={6}>
      //                     <Box>
      //                       <span style={{}}>Products</span>
      //                     </Box>
      //                     <Box mt={1}>
      //                       <CustomInput
      //                         resize
      //                         refType="SelectInput"
      //                         value={this.state.selProduct}
      //                         changed={(value) => {
      //                           if (value) {
      //                             if (
      //                               value.split("/")[0] in
      //                               this.state.bundleItemsProducts
      //                             ) {
      //                               let modalContent = (
      //                                 <Typography variant="h6">
      //                                   Product Already Selected.
      //                                 </Typography>
      //                               );
      //                               this.setState({
      //                                 modalContent: modalContent,
      //                                 show: true,
      //                               });
      //                             } else {
      //                               let proDetails = {};
      //                               let productId = value.split("/")[0];
      //                               proDetails.attrName = "Product";
      //                               proDetails.attrValue = value.split("/")[1];
      //                               proDetails.attributeId =
      //                                 value.split("/")[0];
      //                               this.setState((prevState) => {
      //                                 return {
      //                                   bundleItemsProducts: {
      //                                     ...prevState.bundleItemsProducts,
      //                                     [productId]: proDetails,
      //                                   },
      //                                 };
      //                               });
      //                             }
      //                             this.setState({ selProduct: null });
      //                           }
      //                         }}
      //                         refLovs={this.state.products}
      //                       />
      //                     </Box>
      //                   </Grid>
      //                 </Grid>
      //               )}
      //             </div>
      //           )}
      //           {this.state.eventAppliedOn != "Product" && (
      //             <div>
      //               <Grid container alignContent="flex-start" spacing={2}>
      //                 <CustomInput
      //                   refType="SelectInput"
      //                   uiName={this.state.eventAppliedOn}
      //                   value={this.state.selbundleItem}
      //                   changed={(value) => {
      //                     if (value) {
      //                       this.setState({ selbundleItem: value });
      //                       if (this.state.eventAppliedOn != "Attribute") {
      //                         if (
      //                           value.split("/")[0] in
      //                           this.state.bundleItemsProducts
      //                         ) {
      //                           let modalContent = (
      //                             <Typography variant="h6">
      //                               {this.state.eventAppliedOn} Already
      //                               Selected.
      //                             </Typography>
      //                           );
      //                           this.setState({
      //                             modalContent: modalContent,
      //                             show: true,
      //                           });
      //                         } else {
      //                           let bundleDetails = {};
      //                           let bundleId = value.split("/")[0];
      //                           bundleDetails.attrName =
      //                             this.state.eventAppliedOn;
      //                           bundleDetails.attrValue = value.split("/")[1];
      //                           bundleDetails.attributeId = value.split("/")[0];
      //                           this.setState((prevState) => {
      //                             return {
      //                               bundleItemsProducts: {
      //                                 ...prevState.bundleItemsProducts,
      //                                 [bundleId]: bundleDetails,
      //                               },
      //                               selbundleItem: null,
      //                             };
      //                           });
      //                         }
      //                       }
      //                     }
      //                   }}
      //                   refLovs={this.state.bundleItems}
      //                 />

      //                 {this.state.eventAppliedOn == "Attribute" && (
      //                   <React.Fragment>
      //                     <Grid item xs={12} sm={3}>
      //                       <Box mt={1}>
      //                         <span>Attribute Value</span>
      //                       </Box>
      //                       <Box mt={1}>
      //                         {this.state.attributes[
      //                           this.state.selbundleItem
      //                         ] &&
      //                         this.state.attributes[this.state.selbundleItem]
      //                           .ppmAttrType == "LIST" ? (
      //                           <CustomInput
      //                             table
      //                             refType="SelectInput"
      //                             refLovs={
      //                               this.state.attributes[
      //                                 this.state.selbundleItem
      //                               ].ppmAttrValue
      //                                 ? this.state.attributes[
      //                                     this.state.selbundleItem
      //                                   ].ppmAttrValue.split(",")
      //                                 : []
      //                             }
      //                             value={this.state.attributeValue}
      //                             changed={(event) => {
      //                               this.setState({
      //                                 attributeValue: event,
      //                               });
      //                             }}
      //                           />
      //                         ) : (
      //                           <CustomInput
      //                             table
      //                             refType="TextInput"
      //                             value={this.state.attributeValue}
      //                             changed={(event) => {
      //                               this.setState({
      //                                 attributeValue: event.target.value,
      //                               });
      //                             }}
      //                           />
      //                         )}
      //                       </Box>
      //                     </Grid>
      //                     <Grid item xs={2}>
      //                       <Box mt={4}>
      //                         <Button
      //                           onClick={() => {
      //                             if (
      //                               this.state.selbundleItem in
      //                               this.state.bundleItemsProducts
      //                             ) {
      //                               let modalContent = (
      //                                 <Typography variant="h6">
      //                                   {this.state.eventAppliedOn} Already
      //                                   Selected.
      //                                 </Typography>
      //                               );
      //                               this.setState({
      //                                 modalContent: modalContent,
      //                                 show: true,
      //                               });
      //                             } else {
      //                               let bundleDetails = {};
      //                               let bundleId = this.state.selbundleItem;
      //                               bundleDetails.attrName = "Attribute";
      //                               bundleDetails.attrValue =
      //                                 this.state.attributeValue;
      //                               bundleDetails.attributeId =
      //                                 this.state.selbundleItem;
      //                               this.setState((prevState) => {
      //                                 return {
      //                                   bundleItemsProducts: {
      //                                     ...prevState.bundleItemsProducts,
      //                                     [bundleId]: bundleDetails,
      //                                   },
      //                                   selbundleItem: null,
      //                                   attributeValue: null,
      //                                 };
      //                               });
      //                             }
      //                           }}
      //                           style={{
      //                             background: "orange",
      //                             textTransform: "none",
      //                           }}
      //                         >
      //                           Add
      //                         </Button>
      //                       </Box>
      //                     </Grid>
      //                   </React.Fragment>
      //                 )}
      //               </Grid>
      //             </div>
      //           )}
      //         </CardContent>
      //       </Card>
      //     )}
      //     <Card style={{ overflow: "visible", marginTop: "4vh" }}>
      //       <CardHeader
      //         className={classes.cardHeader}
      //         classes={{
      //           subheader: classes.subheader,
      //         }}
      //         subheader={"Rule Applied On"}
      //       />

      //       <CardContent>
      //         <TableContainer component={Paper} style={{ height: "30vh" }}>
      //           <Table className={classes.table} size="small">
      //             <TableHead>
      //               <TableRow>
      //                 <TableCell>Applied On</TableCell>
      //                 <TableCell>Id</TableCell>
      //                 <TableCell>Value</TableCell>
      //                 <TableCell>Delete</TableCell>
      //               </TableRow>
      //             </TableHead>
      //             <TableBody>
      //               {Object.keys(this.state.bundleItemsProducts).map((key) => {
      //                 return (
      //                   <TableRow key={key}>
      //                     <TableCell
      //                       style={{
      //                         width: "20%",
      //                       }}
      //                     >
      //                       {this.state.bundleItemsProducts[key].attrName}
      //                     </TableCell>
      //                     <TableCell
      //                       style={{
      //                         width: "30%",
      //                       }}
      //                     >
      //                       {key}
      //                     </TableCell>
      //                     <TableCell
      //                       style={{
      //                         width: "30%",
      //                       }}
      //                     >
      //                       {this.state.bundleItemsProducts[key].attrValue}
      //                     </TableCell>
      //                     <TableCell style={{ width: "5%" }}>
      //                       <DeleteIcon
      //                         onClick={(event) => {
      //                           event.stopPropagation();
      //                           let bundleItemsProducts = {
      //                             ...this.state.bundleItemsProducts,
      //                           };
      //                           delete bundleItemsProducts[key];
      //                           this.setState({
      //                             bundleItemsProducts: bundleItemsProducts,
      //                           });
      //                         }}
      //                         style={{ color: "red", cursor: "pointer" }}
      //                       />
      //                     </TableCell>
      //                   </TableRow>
      //                 );
      //               })}
      //             </TableBody>
      //           </Table>
      //         </TableContainer>
      //       </CardContent>
      //     </Card>
      //     {this.props.releaseData.releaseId && (
      //       <div
      //         style={{
      //           display: "flex",
      //           justifyContent: "center",
      //           alignItems: "center",
      //         }}
      //       >
      //         <Button
      //           onClick={this.saveEvent}
      //           style={{
      //             background: "#02bfa0",
      //             marginTop: "1%",
      //             marginBottom: "1%",
      //             textTransform: "none",
      //           }}
      //           variant="contained"
      //         >
      //           Save
      //         </Button>
      //       </div>
      //     )}
      //   </CardContent>
      // </Card>
    );

    if (this.state.loading) events = <Loader />;

    return events;
  }
}

const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
  };
};

export default connect(mapStateToProps)(
  withStyles(useStyles)(WithErrorHandler(Events, axios))
);
