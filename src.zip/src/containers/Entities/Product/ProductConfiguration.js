import React, { Component } from 'react';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Divider from '@material-ui/core/Divider';
import { connect } from 'react-redux';
import LastPageIcon from '@material-ui/icons/LastPage';
import AddIcon from '@material-ui/icons/Add';
import * as actionTypes from '../../../store/actions/actionTypes';
import StepConnector from '@material-ui/core/StepConnector';
import clsx from 'clsx';
import SettingsIcon from '@material-ui/icons/Settings';
import BrightnessAutoIcon from '@material-ui/icons/BrightnessAuto';
import LocalOfferIcon from '@material-ui/icons/LocalOffer';
import BasicDetails from './BasicDetails'
import Attribute from '../Attribute';
import axios from '../../../axios-epc';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import Offerability from '../Offerability';
import Tooltip from '@material-ui/core/Tooltip';
import MenuBookIcon from '@material-ui/icons/MenuBook';
import MonetizationOnIcon from '@material-ui/icons/MonetizationOn';
import Pricing from '../Pricing/Pricing';
import Contract from '../Contract';


const LightTooltip = withStyles((theme) => ({
    tooltip: {
        backgroundColor: '#525354',
        color: 'white',
        boxShadow: theme.shadows[1],
        fontSize: 14,
    },
}))(Tooltip);

const useColorlibStepIconStyles = makeStyles({
    root: {
        backgroundColor: '#546D7A',
        zIndex: 1,
        color: '#fff',
        width: 50,
        height: 50,
        display: 'flex',
        borderRadius: '50%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    active: {
        background: '#ff1921'
    }

});

const useStyles = (theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    boldText: {
        // fontWeight: 'bold'
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '96%',
        flexShrink: 0,
    },

});

const ColorlibConnector = withStyles({
    alternativeLabel: {
        top: 22,
    },
    line: {
        height: 3,
        border: 0,
        backgroundColor: '#eaeaf0',
        borderRadius: 1,
    },
})(StepConnector);

class ProductConfiguration extends Component {


    componentDidMount() {
        this.searchItems();

    }

    getSteps() {
        return ['General', 'Attributes', 'Pricing', 'Offerability', 'Contracts'];
    }

    searchItems() {
        return axios
            .get(
                "product/basicDetails/search?releaseID=" +
                this.props.releaseData.releaseId,
                {
                    headers: {
                        opId: this.props.userInfo.opId
                    }
                }
            )
            .then(res => {
                console.log(res);
                let searchItems = [];
                Object.keys(res.data.data).forEach(key => {
                    searchItems.push(key + "/" + res.data.data[key]);
                });
                console.log(searchItems)
                console.log('searchItems')

                this.props.setSearchItems(searchItems);
            })
            .catch(error => {
                console.log(error)

            });
    }
    getStepContent(step) {
        switch (step) {
            case 0:
                return <BasicDetails userInfo={this.props.userInfo}
                    productData={this.props.productData}
                    releaseData={this.props.releaseData} />
            case 1:
                return <Attribute releaseData={this.props.releaseData}
                    userInfo={this.props.userInfo}
                    id={this.props.productData.productId}
                    entity='Product' />;
            case 2:
                return <Pricing userInfo={this.props.userInfo}
                    releaseData={this.props.releaseData}
                    id={this.props.productData.productId}
                    entity='Product' />;
            case 3:
                return <Offerability userInfo={this.props.userInfo}
                    releaseData={this.props.releaseData}
                    id={this.props.productData.productId}
                    entity='PRODUCT' />;
            case 4:
                return <Contract
                    releaseData={this.props.releaseData}
                    userInfo={this.props.userInfo}
                    id={this.props.productData.productId}
                    entity='Product'
                />;
            default:
                return 'Unknown step';
        }
    }
    stepHandler = (step) => {
        this.props.changeProductActiveStep(step);
    };

    backToRelease = () => {
        this.props.history.push('/editRelease')
    }

    ColorlibStepIcon(props) {
        const classes = useColorlibStepIconStyles();
        const { active, completed } = props;

        const icons = {
            1: <SettingsIcon />,
            2: <BrightnessAutoIcon />,
            3: <MonetizationOnIcon />,
            4: <LocalOfferIcon />,
            5: <MenuBookIcon />,

        }
        return (
            <div
                className={clsx(classes.root, {
                    [classes.active]: active,
                    [classes.completed]: completed,
                })}
            >
                {icons[String(props.icon)]}
            </div>
        );
    }


    render() {
        const { classes } = this.props;

        return <Card style={{ overflow: 'visible' }}>
            <CardHeader
                className={classes.cardHeader}
                classes={{
                    subheader: classes.subheader,
                }}
                action={
                    this.props.releaseData.releaseId &&
                    <React.Fragment>
                        <LightTooltip title='New Product' arrow>
                            <AddIcon onClick={() => {
                                console.log(this.props.productKey)
                                this.props.changeProductActiveStep(0)
                                this.props.onProductEnter({})
                                this.props.changeProductKey(this.props.productKey + '1')
                                this.props.history.push('/productConfiguration')

                            }}
                                style={{ color: 'white', marginRight: '10px', cursor: 'pointer' }} />
                        </LightTooltip>
                        <LightTooltip title='Back To ePCN' arrow>
                            <LastPageIcon onClick={this.backToRelease}
                                style={{ color: 'white', cursor: 'pointer' }} />
                        </LightTooltip>
                    </React.Fragment>
                }
                subheader={this.props.releaseData.releaseId ? "Products You are inside ePCN " + this.props.releaseData.releaseId : 'Products'} />

            <CardContent style={{ minHeight: '60vh', overflow: 'visible' }}>

                <div >
                    <Stepper nonLinear alternativeLabel
                        activeStep={this.props.activeStep}
                        connector={<ColorlibConnector />}>
                        {this.getSteps().map((label, index) => (
                            <Step key={label}>
                                <StepLabel style={{ cursor: 'pointer' }} onClick={() => {
                                    this.stepHandler(index)
                                }} StepIconComponent={this.ColorlibStepIcon}>{label}</StepLabel>

                            </Step>
                        ))}
                    </Stepper>
                    <Divider />
                    <div key={this.props.productKey}>

                        <div style={{ marginTop: '4%' }}>
                            {this.getStepContent(this.props.activeStep)}
                        </div>

                    </div>
                </div>
            </CardContent>
        </Card>
    }
}

const mapStateToProps = state => {
    return {
        releaseData: state.releaseData.releaseData,
        userInfo: state.login.loggedInUserInfo,
        productData: state.productData.productData,
        productKey: state.productData.productKey,
        activeStep: state.productData.activeStep
    };
}

const mapDispatchToProps = dispatch => {
    return {
        changeProductKey: (productKey) => dispatch({ type: actionTypes.CHANGE_PRODUCT_KEY, productKey: productKey }),
        onProductEnter: (productData) => dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
        changeProductActiveStep: (activeStep) => dispatch({ type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP, activeStep: activeStep }),
        setSearchItems: (searchItems) => dispatch({ type: actionTypes.SET_SEARCH_ITEMS, searchItems: searchItems, entity: 'PRODUCT' }),

    };
};



export default connect(mapStateToProps, mapDispatchToProps)(withStyles(useStyles)(WithErrorHandler(ProductConfiguration, axios)));