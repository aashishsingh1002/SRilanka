import React from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';

const styles = (theme) => ({
	root: {
		margin: 0,
		padding: theme.spacing(2),
	},
	closeButton: {
		position: 'absolute',
		right: theme.spacing(1),
		top: theme.spacing(1),
		color: 'white',
	},
	dialogPaper: {
		minHeight: '30vh',
	},
});

const useStyles = makeStyles((theme) => ({
	btn: {
		textTransform: 'unset !important',
	},
}));

const DialogTitle = withStyles(styles)((props) => {
	const { children, classes, onClose, ...other } = props;
	return (
		<MuiDialogTitle disableTypography className={classes.root} {...other}>
			<Typography variant="h6">{children}</Typography>
			{onClose ? (
				<IconButton
					aria-label="close"
					className={classes.closeButton}
					onClick={onClose}>
					<CloseIcon />
				</IconButton>
			) : null}
		</MuiDialogTitle>
	);
});

const DialogContent = withStyles((theme) => ({
	root: {
		padding: theme.spacing(2),
	},
}))(MuiDialogContent);

const DialogActions = withStyles((theme) => ({
	root: {
		margin: 0,
		padding: theme.spacing(1),
	},
}))(MuiDialogActions);

const ModalAction = withStyles(styles)((props) => {
	const classes = useStyles();

	return (
		<div>
			<Dialog
				classes={{ paper: props.classes.dialogPaper }}
				disableBackdropClick={true}
				fullWidth
				maxWidth={props.size ? props.size : 'md'}
				onClose={props.modalClosed}
				aria-labelledby="customized-dialog-title"
				style={{
					transform: 'scale(.8)',
				}}
				BackdropProps={{ style: { backgroundColor: 'transparent' } }}
				open={props.show}>
				<DialogTitle
					id="customized-dialog-title"
					onClose={props.modalClosed}
					style={{ background: '#546D7A', color: 'white' }}>
					{props.title}
				</DialogTitle>
				<DialogContent>{props.children}</DialogContent>
				<DialogActions>
					<Button
						onClick={props.modalClosed}
						color="primary"
						className={classes.btn}>
						{props.closeText}
					</Button>
					<Button
						onClick={props.action}
						color="primary"
						className={classes.btn}
						disabled={props.disableButton ?? false}>
						{props.actionText}
					</Button>
				</DialogActions>
			</Dialog>
		</div>
	);
});

export default ModalAction;
