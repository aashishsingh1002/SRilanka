import React from 'react';
import ReactDOM from "react-dom";
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';

const styles = (theme) => ({
    root: {
        margin: 0,
        padding: theme.spacing(2),
    },
    closeButton: {
        position: 'absolute',
        right: theme.spacing(1),
        top: theme.spacing(1),
        color: 'white',
    },
    dialogPaper: {
        minHeight: '30vh',
    },


});


const useStyles = makeStyles((theme) => ({

    btn: {
        textTransform: 'unset !important'
    }


}));

const DialogTitle = withStyles(styles)((props) => {
    const { children, classes, onClose, ...other } = props;
    return (
        <MuiDialogTitle disableTypography className={classes.root} {...other}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
                <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                    <CloseIcon />
                </IconButton>
            ) : null}
        </MuiDialogTitle>
    );
});

const DialogContent = withStyles((theme) => ({
    root: {
        padding: theme.spacing(2),
    },
}))(MuiDialogContent);

const DialogActions = withStyles((theme) => ({
    root: {
        margin: 0,
        padding: theme.spacing(1),
    },
}))(MuiDialogActions);


const UserConfirmation = (message, callback) => {
    const container = document.createElement("div");
    container.setAttribute("custom-confirmation-navigation", "");
    document.body.appendChild(container);

    const closeModal = (callbackState) => {
        ReactDOM.unmountComponentAtNode(container);
        document.body.removeChild(container);
        callback(callbackState);
    };

    ReactDOM.render(
        <Dialog
            disableBackdropClick={true} fullWidth maxWidth='md'
            onClose={() => closeModal(false)} aria-labelledby="customized-dialog-title"
            style={{
                transform: 'scale(.8)',
            }}
            BackdropProps={{ style: { backgroundColor: "transparent" } }}
            open={true}>
            <DialogTitle id="customized-dialog-title" onClose={() => closeModal(false)}
                style={{ background: '#546D7A', color: 'white' }}>
                Alert!
            </DialogTitle>
            <DialogContent >
                < Typography variant="h6"> {message}</Typography >

            </DialogContent>
            <DialogActions>
                <Button onClick={() => closeModal(false)} color="primary"
                    style={{ textTransform: 'none' }}>
                    No
                    </Button>
                <Button onClick={() => {
                    closeModal(true)
                }}
                    color="primary"
                    style={{ textTransform: 'none' }}>
                    Yes

                </Button>

            </DialogActions>
        </Dialog>,
        container

    );
}; export default UserConfirmation;

