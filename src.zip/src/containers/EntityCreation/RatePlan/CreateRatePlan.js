import React, { Component } from 'react';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from 'axios';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import AddIcon from '@material-ui/icons/Add';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../../UI/Loader/Loader';
import Input from '../../../UI/Input/Input';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box';
import MultiSelect from '../../../UI/Input/MultiSelect';
import CustomInput from '../../../UI/Input/Input';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import moment from 'moment';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import Divider from '@material-ui/core/Divider';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import DeleteIcon from '@material-ui/icons/Delete';
import VisibilityIcon from '@material-ui/icons/Visibility';

const LightTooltip = withStyles((theme) => ({
	tooltip: {
		backgroundColor: '#525354',
		color: 'white',
		boxShadow: theme.shadows[1],
		fontSize: 14,
	},
}))(Tooltip);

const useStyles = (theme) => ({
	cardHeader: {
		background: '#546D7A',
		height: '4.5vh',
	},
	subheader: {
		color: 'white',
		// fontWeight: 'bold'
	},
	boldText: {
		// fontWeight: 'bold'
	},
	center: {
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
	},
	//changed
	heading: {
		fontSize: theme.typography.pxToRem(15),
		margin: '0 auto 0 0',
	},
});

class CreateRatePlan extends Component {
	_isMounted = false;

	state = {
		ratePlanVersion: '',
		discountUsageGroupVersion: '',
		discountedItemsDataVersion: '',
		discountUsageGroup: {},
		discountedItemsData: {},
		loading: true,
		ratePlanGroups: {},
		schema: [],
		country: [],
		zones: [],
		ratesApplies: '',
		selZone: [],
		selCountry: [],
		jurisdiction: [],
		selJurisdiction: [],
		tapCodes: [],
		seltapCodes: [],
		countryCodes: [],
		selcountryCodes: [],
		usageGrps: {},
		ratesObj: {},
		show: false,
		modalContent: null,
		expanded: false,
		serviceTypeWatch: true,
		serviceSubTypeWatch: true,
		zoneWatch: true,
		countryWatch: true,
		countryCodesWatch: true,
		serviceSubSubTypeWatch: true,
		editing: false,
		ccmidUpdate: '',
	};

	changeHandler = (panel) => (event, isExpanded) => {
		this.setState({ expanded: isExpanded ? panel : false });
	};

	componentWillUnmount() {
		this._isMounted = false;
	}

	componentDidUpdate(prevProps, prevState) {
		if (prevState['selZone'] !== this.state['selZone']) {
			if (!this.state.zoneWatch) {
				this.setState({
					zoneWatch: true,
				});
				return;
			} else {
				if (this.state['selZone']) {
					console.log(this.state['selZone']);
					let countries = [];
					this.state['selZone'].map((zone) => {
						countries.push(...this.state.discountedItemsData['zones'][zone]);
					});
					console.log(countries);
					this.setState({
						selCountry: countries,
					});
				}
			}
		} else if (prevState['selCountry'] !== this.state['selCountry']) {
			if (!this.state.countryWatch) {
				this.setState({
					countryWatch: true,
				});
				return;
			} else {
				if (this.state['selCountry']) {
					if (this.state['icmRateplanCategory'] == 'IR') {
						let tapCodes = [];
						this.state['selCountry'].map((country) => {
							if (this.state.discountedItemsData['ir'][country]) {
								tapCodes.push(...this.state.discountedItemsData['ir'][country]);
							}
						});

						this.setState({
							tapCodes: tapCodes,
							seltapCodes: tapCodes,
						});
					} else if (this.state['icmRateplanCategory'] == 'ISD') {
						let countryCodes = [];
						this.state['selCountry'].map((country) => {
							if (this.state.discountedItemsData['isd'][country]) {
								countryCodes.push(
									...this.state.discountedItemsData['isd'][country]
								);
							}
						});
						console.log(countryCodes);
						this.setState({
							countryCodes: countryCodes,
							selcountryCodes: countryCodes,
						});
					}
				}
			}
		}

		if (
			prevState['icmRateplanCategory'] !== this.state['icmRateplanCategory']
		) {
			if (!this.state.serviceTypeWatch) {
				this.setState({
					serviceTypeWatch: true,
				});
				return;
			} else {
				if (this.state['icmRateplanCategory']) {
					let serviceSubTypes = [];
					let schema = [...this.state.schema];
					serviceSubTypes = Object.keys(
						this.state.discountUsageGroup[this.state.icmRateplanCategory]
					);
					schema.map((el) => {
						if (el.refName == 'icmSubCategory') {
							el.refLovs = [];
							el.refLovs = serviceSubTypes;
						}
						if (el.refName == 'ugcSubType2') {
							el.refLovs = [];
						}
					});
					this.setState({
						schema: schema,
						icmSubCategory: null,
						ugcSubType2: [],
						ratesApplies: null,
						selZone: [],
						icmCurrency: null,
						icmUom: null,
					});
				}
			}
		} else if (prevState['icmSubCategory'] !== this.state['icmSubCategory']) {
			if (!this.state.serviceSubTypeWatch) {
				this.setState({
					serviceSubTypeWatch: true,
				});
				return;
			} else {
				if (this.state['icmSubCategory']) {
					let serviceSubSubType = [];
					let schema = [...this.state.schema];
					serviceSubSubType = Object.keys(
						this.state.discountUsageGroup[this.state.icmRateplanCategory][
							this.state.icmSubCategory
						]
					);
					schema.map((el) => {
						if (el.refName == 'ugcSubType2') {
							el.refLovs = [];
							el.refLovs = serviceSubSubType;
						}
					});

					this.setState({
						ugcSubType2: [],
						schema: schema,
						ratesApplies: null,
						selZone: [],
						icmCurrency: null,
						icmUom: null,
					});
				}
			}
		} else if (prevState['selcountryCodes'] !== this.state['selcountryCodes']) {
			if (!this.state.countryCodesWatch) {
				this.setState({
					countryCodesWatch: true,
				});
				return;
			} else {
				if (this.state['selcountryCodes']) {
					let jurisdiction = [];

					this.state['selcountryCodes'].map((countryCode) => {
						if (this.state.discountedItemsData['countryCodes'][countryCode]) {
							jurisdiction.push(
								...this.state.discountedItemsData['countryCodes'][countryCode]
							);
						}
					});

					jurisdiction = Array.from(new Set(jurisdiction));

					this.setState({
						jurisdiction: jurisdiction,
						selJurisdiction: jurisdiction,
					});
				}
			}
		} else if (prevState['ugcSubType2'] !== this.state['ugcSubType2']) {
			if (!this.state.serviceSubSubTypeWatch) {
				this.setState({
					serviceSubSubTypeWatch: true,
				});
				return;
			} else {
				if (this.state['ugcSubType2']) {
					this.setState({
						ratesApplies: null,
						selZone: [],
					});
				}
			}
		}
	}

	componentDidMount() {
		this._isMounted = true;
		this.versions().then(() => {
			this.uiFields().then(() => {
				this.state.schema.map((formElement) => {
					if (formElement.refType == 'Date')
						this.setState({
							[formElement.refName]: formElement.defaultValue
								? moment(formElement.defaultValue).format('DD-MMM-YY')
								: moment().format('DD-MMM-YY'),
						});
					else if (formElement.refType == 'TextInput' || 'TextArea')
						this.setState({
							[formElement.refName]: formElement.defaultValue,
						});
				});
				this.discountUsageGroupLovsData().then(() => {
					this.discountedItemsDataLovsData().then(() => {
						let country = [];
						let ratePlanGroups = {};
						console.log(this.state.discountedItemsData);
						let zones = Object.keys(this.state.discountedItemsData['zones']);
						Object.keys(this.state.discountedItemsData['zones']).filter(
							(el) => {
								country = country.concat(
									this.state.discountedItemsData['zones'][el]
								);
							}
						);
						console.log(zones);
						console.log(country);

						this.state.schema.map((el) => {
							// if (el.refType == "MultiSelect")
							//     this.$set(this.formData, el.refName, []);
							// else this.$set(this.formData, el.refName, "");
							if (!(el.uiGroup in ratePlanGroups)) {
								let arr = [];
								this.state.schema.map((elem) => {
									if (elem.uiGroup == el.uiGroup) {
										arr.push(elem);
									}
								});
								ratePlanGroups[el.uiGroup] = arr;
							}
						});
						console.log(ratePlanGroups);
						this.setState({
							loading: false,
							ratePlanGroups: ratePlanGroups,
							zones: zones,
							country: country,
						});
						if (Object.keys(this.props.editRpData).length > 0) {
							console.log(this.props.editRpData);
							Object.keys(this.props.editRpData['basic']).forEach((key) => {
								this.setState({
									[key]: this.props.editRpData['basic'][key],
								});
							});
							this.setState({
								usageGrps: this.props.editRpData['usageGrps'],
								ratesObj: this.props.editRpData['ratesObj'],
								editing: true,
								ccmidUpdate: this.props.editRpData['basic'].ccmId,
							});
						}
					});
				});
			});
		});
	}

	versions() {
		return axios
			.all([
				axios.get(
					process.env.REACT_APP_URL + 'config/version?entityName=ratePlan',
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
						},
					}
				),
				axios.get(
					process.env.REACT_APP_URL +
						'config/version?entityName=discountUsageGroup',
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
						},
					}
				),
				axios.get(
					process.env.REACT_APP_URL +
						'config/version?entityName=discountedItemsData',
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
						},
					}
				),
			])
			.then(
				axios.spread(
					(
						ratePlanVersion,
						discountUsageGroupVersion,
						discountedItemsDataVersion
					) => {
						this.setState({
							ratePlanVersion: ratePlanVersion.data.data.version,
							discountedItemsDataVersion:
								discountedItemsDataVersion.data.data.version,
							discountUsageGroupVersion:
								discountUsageGroupVersion.data.data.version,
						});
					}
				)
			)
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	}

	uiFields() {
		if (
			localStorage.getItem('ratePlan') &&
			localStorage.ratePlan_version &&
			localStorage.ratePlan_version == this.state.ratePlanVersion
		) {
			console.log('fetching from local storage');
			try {
				this.setState({ schema: JSON.parse(localStorage.getItem('ratePlan')) });
			} catch (e) {
				localStorage.removeItem('ratePlan');
			}
			return Promise.resolve();
		} else {
			console.log('fetching from api');
			return axios
				.get(process.env.REACT_APP_URL + '/config?entityName=ratePlan', {
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
					},
				})
				.then((res) => {
					let schema = [];
					schema = res.data.data.map(function (el) {
						if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
							if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
							else if (el.refLovs == null) el.refLovs = [];
						}
						return el;
					});
					if (this._isMounted) this.setState({ schema: schema });
					localStorage.setItem('ratePlan', JSON.stringify(schema));
					localStorage.ratePlan_version = this.state.ratePlanVersion;
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	}

	discountUsageGroupLovsData() {
		if (
			localStorage.getItem('discountUsageGroup') &&
			localStorage.discountUsageGroup_version &&
			localStorage.discountUsageGroup_version ==
				this.state.discountUsageGroupVersion
		) {
			console.log('fetching discountUsageGroup from local storage');
			try {
				this.setState({
					discountUsageGroup: JSON.parse(
						localStorage.getItem('discountUsageGroup')
					),
				});
			} catch (e) {
				localStorage.removeItem('discountUsageGroup');
			}
			return Promise.resolve();
		} else {
			console.log('fetching discountUsageGroup from api');
			return axios
				.get(process.env.REACT_APP_URL + 'discount/usageGrps', {
					headers: {
						opId: this.props.userInfo.opId,
					},
				})
				.then((res) => {
					localStorage.setItem(
						'discountUsageGroup',
						JSON.stringify(res.data.data)
					);
					this.setState({
						discountUsageGroup: res.data.data,
					});
					localStorage.discountUsageGroup_version =
						this.state.discountUsageGroupVersion;
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	}

	discountedItemsDataLovsData() {
		if (
			localStorage.getItem('discountedItemsData') &&
			localStorage.discountedItemsData_version &&
			localStorage.discountedItemsData_version ==
				this.state.discountedItemsDataVersion
		) {
			console.log('fetching discountedItemsData from local storage');
			try {
				this.setState({
					discountedItemsData: JSON.parse(
						localStorage.getItem('discountedItemsData')
					),
				});
			} catch (e) {
				localStorage.removeItem('discountedItemsData');
			}
			return Promise.resolve();
		} else {
			console.log('fetching discountedItemsData from api');
			return axios
				.get(process.env.REACT_APP_URL + 'discount/irIsdZone', {
					headers: {
						opId: this.props.userInfo.opId,
					},
				})
				.then((res) => {
					console.log(res);
					localStorage.setItem(
						'discountedItemsData',
						JSON.stringify(res.data.data)
					);
					this.setState({
						discountedItemsData: res.data.data,
					});
					localStorage.discountedItemsData_version =
						this.state.discountedItemsDataVersion;
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	}

	inputHelper(formElement) {
		if (formElement.refType == 'MultiSelect')
			return (
				<Grid item xs={12} sm={4} md={2} key={formElement.refName}>
					<Box>
						<span style={{}}>{formElement.uiName}</span>
					</Box>
					<Box mt={2}>
						<MultiSelect
							refLovs={formElement.refLovs}
							value={this.state[formElement.refName]}
							{...formElement}
							changed={(selected) => {
								console.log(selected);
								if (!(selected instanceof Array)) selected = [selected];

								this.setState({
									[formElement.refName]: selected,
								});
							}}
							// placeholder={offerability}
						/>
					</Box>
				</Grid>
			);
		else
			return (
				<Input
					key={formElement.refName}
					{...formElement}
					value={this.state[formElement.refName]}
					disabled={formElement.isDisabled == 'Y' ? true : false}
					required={formElement.isMandatory == 'Y' ? true : false}
					changed={(event) => {
						if (!event.target) {
							this.setState({
								[formElement.refName]: event,
							});
						} else {
							if (event.target.type !== 'checkbox')
								this.setState({
									[formElement.refName]: event.target.value,
								});
							else {
								console.log(event.target.checked);
								this.setState({
									[formElement.refName]: event.target.checked,
								});
							}
						}
					}}
				/>
			);
	}

	saveRpNormalFlow = () => {
		let usageGrps = { ...this.state.usageGrps };
		let ratesObj = { ...this.state.ratesObj };

		this.state['ugcSubType2'].map((el) => {
			if (
				this.state['icmRateplanCategory'] != 'IR' &&
				this.state['icmRateplanCategory'] != 'ISD'
			) {
				if (
					!(
						this.state['icmRateplanCategory'] +
							'-' +
							this.state['icmSubCategory'] +
							'-' +
							el in
						this.state.usageGrps
					)
				) {
					// console.log("not in");
					let newProp =
						this.state['icmRateplanCategory'] +
						'-' +
						this.state['icmSubCategory'] +
						'-' +
						el;
					usageGrps[newProp] = null;
					usageGrps[newProp] = Array.from(
						new Set(
							this.state.discountUsageGroup[this.state['icmRateplanCategory']][
								this.state['icmSubCategory']
							][el]
						)
					);
					ratesObj[newProp] = {};

					ratesObj[newProp]['icmCurrency'] = this.state.icmCurrency;

					ratesObj[newProp]['icmUom'] = this.state.icmUom;
				}
			}
		});

		this.setState({
			usageGrps: usageGrps,
			ratesObj: ratesObj,
		});
		console.log(usageGrps);
		console.log(ratesObj);
	};

	saveRatesIsd() {
		let usageGrps = { ...this.state.usageGrps };
		let ratesObj = { ...this.state.ratesObj };

		if (this.state.ratesApplies == 'ZONE') {
			this.state.ugcSubType2.map((el) => {
				let newProp =
					this.state['icmRateplanCategory'] +
					'-' +
					this.state['icmSubCategory'] +
					'-' +
					el;

				if (!(newProp in this.state.usageGrps)) {
					let elements = Array.from(
						new Set(
							this.state.discountUsageGroup[this.state['icmRateplanCategory']][
								this.state['icmSubCategory']
							][el]
						)
					);

					let filteredUsageGrps = [];
					this.state.selZone.filter((zone) => {
						elements.filter((usageGrp) => {
							filteredUsageGrps.push(zone + '-' + usageGrp);
						});
					});

					usageGrps[newProp] = [...filteredUsageGrps];
					ratesObj[newProp] = {};
					ratesObj[newProp]['values'] = [...this.state.selZone];
					ratesObj[newProp]['countries'] = [...this.state.selCountry];
					ratesObj[newProp]['appliedTo'] = 'ZONE';
					ratesObj[newProp]['icmCurrency'] = this.state.icmCurrency;
					ratesObj[newProp]['icmUom'] = this.state.icmUom;
				}
			});
		} else if (this.state.ratesApplies == 'COUNTRY') {
			this.state.ugcSubType2.map((el) => {
				let newProp =
					this.state['icmRateplanCategory'] +
					'-' +
					this.state['icmSubCategory'] +
					'-' +
					el;
				if (!(newProp in this.state.usageGrps)) {
					let elements = Array.from(
						new Set(
							this.state.discountUsageGroup[this.state['icmRateplanCategory']][
								this.state['icmSubCategory']
							][el]
						)
					);
					let filteredUsageGrps = [];
					this.state.selCountry.filter((country) => {
						elements.filter((usageGrp) => {
							filteredUsageGrps.push(country + '-' + usageGrp);
						});
					});

					usageGrps[newProp] = [...filteredUsageGrps];
					ratesObj[newProp] = {};
					ratesObj[newProp]['values'] = [...this.state.selCountry];
					ratesObj[newProp]['countries'] = [...this.state.selCountry];
					ratesObj[newProp]['appliedTo'] = 'COUNTRY';
					ratesObj[newProp]['icmCurrency'] = this.state.icmCurrency;
					ratesObj[newProp]['icmUom'] = this.state.icmUom;
				}
			});
		} else if (this.state.ratesApplies == 'COUNTRY-CODE') {
			this.state.ugcSubType2.map((el) => {
				let newProp =
					this.state['icmRateplanCategory'] +
					'-' +
					this.state['icmSubCategory'] +
					'-' +
					el;
				if (!(newProp in this.state.usageGrps)) {
					let elements = Array.from(
						new Set(
							this.state.discountUsageGroup[this.state['icmRateplanCategory']][
								this.state['icmSubCategory']
							][el]
						)
					);

					let filteredUsageGrps = [];
					this.state.selcountryCodes.filter((countryCode) => {
						elements.filter((usageGrp) => {
							filteredUsageGrps.push(countryCode + '-' + usageGrp);
						});
					});

					usageGrps[newProp] = [...filteredUsageGrps];
					ratesObj[newProp] = {};
					ratesObj[newProp]['values'] = [...this.state.selcountryCodes];
					ratesObj[newProp]['countries'] = [...this.state.selCountry];
					ratesObj[newProp]['countryCodes'] = [...this.state.selcountryCodes];
					ratesObj[newProp]['appliedTo'] = 'COUNTRY-CODE';
					ratesObj[newProp]['icmCurrency'] = this.state.icmCurrency;
					ratesObj[newProp]['icmUom'] = this.state.icmUom;
				}
			});
		} else if (this.state.ratesApplies == 'JURISDICTION') {
			this.state.ugcSubType2.map((el) => {
				let newProp =
					this.state['icmRateplanCategory'] +
					'-' +
					this.state['icmSubCategory'] +
					'-' +
					el;
				if (!(newProp in this.state.usageGrps)) {
					let elements = Array.from(
						new Set(
							this.state.discountUsageGroup[this.state['icmRateplanCategory']][
								this.state['icmSubCategory']
							][el]
						)
					);

					let filteredUsageGrps = [];
					this.state.selJurisdiction.filter((jurisdiction) => {
						elements.filter((usageGrp) => {
							filteredUsageGrps.push(jurisdiction + '-' + usageGrp);
						});
					});

					usageGrps[newProp] = [...filteredUsageGrps];
					ratesObj[newProp] = {};
					ratesObj[newProp]['values'] = [...this.state.selJurisdiction];
					ratesObj[newProp]['countries'] = [...this.state.selCountry];
					ratesObj[newProp]['countryCodes'] = [...this.state.selcountryCodes];
					ratesObj[newProp]['jurisdiction'] = [...this.state.selJurisdiction];
					ratesObj[newProp]['appliedTo'] = 'JURISDICTION';
					ratesObj[newProp]['icmCurrency'] = this.state.icmCurrency;
					ratesObj[newProp]['icmUom'] = this.state.icmUom;
				}
			});
		}
		this.setState({
			usageGrps: usageGrps,
			ratesObj: ratesObj,
		});
	}
	saveRatesIr() {
		let usageGrps = { ...this.state.usageGrps };
		let ratesObj = { ...this.state.ratesObj };

		if (this.state.ratesApplies == 'ZONE') {
			this.state.ugcSubType2.map((el) => {
				let newProp =
					this.state['icmRateplanCategory'] +
					'-' +
					this.state['icmSubCategory'] +
					'-' +
					el;

				if (!(newProp in this.state.usageGrps)) {
					let elements = Array.from(
						new Set(
							this.state.discountUsageGroup[this.state['icmRateplanCategory']][
								this.state['icmSubCategory']
							][el]
						)
					);
					let filteredUsageGrps = [];
					this.state.selZone.filter((zone) => {
						elements.filter((usageGrp) => {
							filteredUsageGrps.push(zone + '-' + usageGrp);
						});
					});

					usageGrps[newProp] = [...filteredUsageGrps];
					ratesObj[newProp] = {};
					ratesObj[newProp]['values'] = [...this.state.selZone];
					ratesObj[newProp]['countries'] = [...this.state.selCountry];
					ratesObj[newProp]['appliedTo'] = 'ZONE';
					ratesObj[newProp]['icmCurrency'] = this.state.icmCurrency;
					ratesObj[newProp]['icmUom'] = this.state.icmUom;
				}
			});
		} else if (this.state.ratesApplies == 'COUNTRY') {
			this.state.ugcSubType2.map((el) => {
				let newProp =
					this.state['icmRateplanCategory'] +
					'-' +
					this.state['icmSubCategory'] +
					'-' +
					el;
				if (!(newProp in this.state.usageGrps)) {
					let elements = Array.from(
						new Set(
							this.state.discountUsageGroup[this.state['icmRateplanCategory']][
								this.state['icmSubCategory']
							][el]
						)
					);
					let filteredUsageGrps = [];
					this.state.selCountry.filter((country) => {
						elements.filter((usageGrp) => {
							filteredUsageGrps.push(country + '-' + usageGrp);
						});
					});

					usageGrps[newProp] = [...filteredUsageGrps];
					ratesObj[newProp] = {};
					ratesObj[newProp]['values'] = [...this.state.selCountry];
					ratesObj[newProp]['countries'] = [...this.state.selCountry];
					ratesObj[newProp]['appliedTo'] = 'COUNTRY';
					ratesObj[newProp]['icmCurrency'] = this.state.icmCurrency;
					ratesObj[newProp]['icmUom'] = this.state.icmUom;
				}
			});
		} else if (this.state.ratesApplies == 'TAPCODE') {
			this.state.ugcSubType2.map((el) => {
				let newProp =
					this.state['icmRateplanCategory'] +
					'-' +
					this.state['icmSubCategory'] +
					'-' +
					el;
				if (!(newProp in this.state.usageGrps)) {
					let elements = Array.from(
						new Set(
							this.state.discountUsageGroup[this.state['icmRateplanCategory']][
								this.state['icmSubCategory']
							][el]
						)
					);
					let filteredUsageGrps = [];
					this.state.seltapCodes.filter((tapCode) => {
						elements.filter((usageGrp) => {
							filteredUsageGrps.push(tapCode + '-' + usageGrp);
						});
					});

					usageGrps[newProp] = [...filteredUsageGrps];
					ratesObj[newProp] = {};
					ratesObj[newProp]['values'] = [...this.state.seltapCodes];
					ratesObj[newProp]['countries'] = [...this.state.selCountry];
					ratesObj[newProp]['tapcodes'] = [...this.state.seltapCodes];
					ratesObj[newProp]['appliedTo'] = 'TAPCODE';
					ratesObj[newProp]['icmCurrency'] = this.state.icmCurrency;
					ratesObj[newProp]['icmUom'] = this.state.icmUom;
				}
			});
		}
		this.setState({
			usageGrps: usageGrps,
			ratesObj: ratesObj,
		});
	}

	saveRatePlans = () => {
		this.setState({ loading: true });

		let payload = {};
		let listOfratePlanInput = [];
		let date = moment().format('YYYY-MM-DD');
		let categories = [];
		Object.keys(this.state.ratesObj).forEach((key) => {
			let obj = {};
			obj.rateClass = 'Standard';
			obj.timeband = '24 hours';
			obj.pulse = this.state.ratesObj[key]['icmUom'];
			obj.ccmOpId = this.props.userInfo.opId;
			obj.ccmBuId = this.props.userInfo.buId;
			obj.icmDesc = this.state.icmDesc;
			obj.icmEndDate = moment(this.state.icmEndDate).format('YYYY-MM-DD');
			obj.icmStartDate = moment(this.state.icmStartDate).format('YYYY-MM-DD');

			obj.icmCreatedBy = this.props.userInfo.id;
			obj.icmCreationDate = date;
			obj.icmModifiedBy = this.props.userInfo.id;
			obj.icmModifiedDate = date;

			obj.icmUom = this.state.ratesObj[key]['icmUom'];
			obj.icmCurrency = this.state.ratesObj[key]['icmCurrency'];
			let rp = key.split('-');
			obj.icmRateplanCategory = rp[0];
			obj.icmSubCategory = rp[1];
			categories.push(obj.icmSubCategory);
			obj.ugcSubType2 = rp[2];
			let cgdRates = [];
			if (obj.icmRateplanCategory == 'IR' || obj.icmRateplanCategory == 'ISD') {
				let helperCgd = { ...this.state.ratesObj[key] };
				obj.zone = '';
				if (this.state.ratesObj[key]['appliedTo'] == 'ZONE') {
					obj.zone = this.state.ratesObj[key]['values'].join();
					obj.countries = this.state.ratesObj[key]['countries'];
					obj.countryJurisdIdentifier = 'ZONE';
				} else if (this.state.ratesObj[key]['appliedTo'] == 'COUNTRY') {
					obj.countries = this.state.ratesObj[key]['countries'];
					obj.countryJurisdIdentifier = 'COUNTRY';
				} else if (this.state.ratesObj[key]['appliedTo'] == 'TAPCODE') {
					obj.countries = this.state.ratesObj[key]['countries'];
					obj.tapcodes = this.state.ratesObj[key]['tapcodes'];
					obj.countryJurisdIdentifier = 'TAPCODE';
					delete helperCgd['tapcodes'];
				} else if (this.state.ratesObj[key]['appliedTo'] == 'COUNTRY-CODE') {
					obj.countries = this.state.ratesObj[key]['countries'];
					obj.countryCodes = this.state.ratesObj[key]['countryCodes'];
					obj.countryJurisdIdentifier = 'COUNTRY-CODE';
					delete helperCgd['countryCodes'];
				} else if (this.state.ratesObj[key]['appliedTo'] == 'JURISDICTION') {
					obj.countries = this.state.ratesObj[key]['countries'];
					obj.countryCodes = this.state.ratesObj[key]['countryCodes'];
					obj.jurisdiction = this.state.ratesObj[key]['jurisdiction'];
					obj.countryJurisdIdentifier = 'JURISDICTION';
					delete helperCgd['jurisdiction'];
					delete helperCgd['countryCodes'];
				}

				delete helperCgd['countries'];
				delete helperCgd['values'];
				delete helperCgd['icmUom'];
				delete helperCgd['icmCurrency'];

				if (this.state.ratesObj[key]['appliedTo'] == 'ZONE') {
					delete helperCgd['appliedTo'];

					Object.keys(helperCgd).forEach((usageGrp) => {
						let currentZone = usageGrp.split('-')[0];
						let currentCountries =
							this.state.discountedItemsData['zones'][currentZone];
						currentCountries.filter((el) => {
							let rateObj = {};
							rateObj.usageGroup = usageGrp.replace(currentZone, el);
							rateObj.rates = helperCgd[usageGrp];
							cgdRates.push(rateObj);
						});
					});
				} else {
					delete helperCgd['appliedTo'];

					Object.keys(helperCgd).forEach((usageGrp) => {
						let rateObj = {};
						rateObj.usageGroup = usageGrp;
						rateObj.rates = helperCgd[usageGrp];
						cgdRates.push(rateObj);
					});
				}
			} else {
				let helperCgdrates = { ...this.state.ratesObj[key] };
				delete helperCgdrates['icmUom'];
				delete helperCgdrates['icmCurrency'];

				Object.keys(helperCgdrates).forEach((usageGrp) => {
					let rateObj = {};
					rateObj.usageGroup = usageGrp;
					rateObj.rates = this.state.ratesObj[key][usageGrp];
					cgdRates.push(rateObj);
				});
			}
			obj.cgdRates = cgdRates;
			listOfratePlanInput.push(obj);
		});
		payload.listOfratePlanInput = listOfratePlanInput;
		payload.releaseId = this.props.releaseData.releaseId;
		payload.ccmSubcateg = Array.from(new Set(categories)).join();
		payload.pkgBrand = this.state.pkgBrand;
		console.log(payload);
		let url = 'ratePlan/createRatePlan';
		if (this.state.editing)
			url =
				'ratePlan/copyCRP?releaseId=' +
				this.props.releaseData.releaseId +
				'&ccmId=' +
				this.state.ccmidUpdate;

		axios
			.post(process.env.REACT_APP_URL + url, payload, {
				headers: {
					opId: this.props.userInfo.opId,
				},
			})
			.then((response) => {
				console.log(response);
				this.setState({ loading: false });
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	};

	copy = (item, name) => {
		let ratesObj = { ...this.state.ratesObj };

		let usageGrp = name.split('-');
		let usageName = item.substring(0, item.lastIndexOf('-'));

		let usageGrps = Array.from(
			new Set(
				this.state.discountUsageGroup[usageGrp[0]][usageGrp[1]][usageGrp[2]]
			)
		);

		let derivedUSageGrps = [];
		usageGrps.filter((el) => {
			derivedUSageGrps.push(usageName + '-' + el);
		});
		console.log(ratesObj);
		console.log(ratesObj[name]);

		console.log(ratesObj[name]['values']);

		console.log(ratesObj[name]['values']);

		ratesObj[name]['values'].filter((el) => {
			if (el != usageName) {
				derivedUSageGrps.filter((rate) => {
					ratesObj[name][
						el + '-' + rate.substring(rate.lastIndexOf('-') + 1, rate.length)
					] = ratesObj[name][rate];
				});
			}
		});

		this.setState({
			ratesObj: ratesObj,
		});
	};

	disableWatchers() {
		this.setState({
			serviceTypeWatch: false,
			serviceSubTypeWatch: false,
			zoneWatch: false,
			countryWatch: false,
			countryCodesWatch: false,
			serviceSubSubTypeWatch: false,
		});
	}

	enableWatchers() {
		this.setState({
			serviceTypeWatch: true,
			serviceSubTypeWatch: true,
			zoneWatch: true,
			countryWatch: true,
			countryCodesWatch: true,
			serviceSubSubTypeWatch: true,
		});
	}

	viewRatePlan(name) {
		this.disableWatchers();
		// this.clearView();
		let rp = name.split('-');

		let arr = [];
		let currency = this.state.ratesObj[name]['icmCurrency'];
		let uom = this.state.ratesObj[name]['icmUom'];
		arr.push(rp[2]);

		this.setState({
			['icmRateplanCategory']: rp[0],
			['icmSubCategory']: rp[1],
			['icmCurrency']: currency,
			['icmUom']: uom,
			['ugcSubType2']: arr,
		});

		let schema = [...this.state.schema];

		schema.map((el) => {
			if (el.refName == 'icmSubCategory') {
				el.refLovs = [];
				el.refLovs = Object.keys(this.state.discountUsageGroup[rp[0]]);
			} else if (el.refName == 'ugcSubType2') {
				el.refLovs = [];
				el.refLovs = Object.keys(this.state.discountUsageGroup[rp[0]][rp[1]]);
			}
		});

		if (rp[0] == 'ISD' || rp[0] == 'IR') {
			this.setState({
				ratesApplies: this.state.ratesObj[name]['appliedTo'],
			});
			console.log(this.state.ratesObj[name]);

			if (this.state.ratesObj[name]['appliedTo'] == 'ZONE') {
				console.log(this.state.ratesObj[name]);
				this.setState({
					selZone: this.state.ratesObj[name]['values'],
				});
			} else if (this.state.ratesObj[name]['appliedTo'] == 'COUNTRY') {
				this.setState({
					selCountry: this.state.ratesObj[name]['countries'],
				});
			} else if (this.state.ratesObj[name]['appliedTo'] == 'TAPCODE') {
				this.setState({
					selCountry: this.state.ratesObj[name]['countries'],
					seltapCodes: this.state.ratesObj[name]['tapcodes'],
				});
			} else if (this.state.ratesObj[name]['appliedTo'] == 'COUNTRY-CODE') {
				this.setState({
					selCountry: this.state.ratesObj[name]['countries'],
					selcountryCodes: this.state.ratesObj[name]['countryCodes'],
				});
			} else if (this.state.ratesObj[name]['appliedTo'] == 'JURISDICTION') {
				this.setState({
					selCountry: this.state.ratesObj[name]['countries'],
					selcountryCodes: this.state.ratesObj[name]['countryCodes'],
					selJurisdiction: this.state.ratesObj[name]['jurisdiction'],
				});
			}
		}
		this.setState(
			{
				schema: schema,
			},
			() => {
				this.enableWatchers();
			}
		);
	}

	render() {
		const { classes } = this.props;

		let zone = (
			<Grid item xs={12} sm={5} md={2}>
				<Box>
					<span> Zone </span>
				</Box>
				<Box mt={2}>
					<MultiSelect
						refLovs={this.state.zones}
						value={this.state.selZone}
						changed={(selected) => {
							this.setState({ selZone: selected });
						}}
						placeholder={'Zone'}
					/>
				</Box>
			</Grid>
		);

		let country = (
			<Grid item xs={12} sm={5} md={2}>
				<Box>
					<span> Country </span>
				</Box>
				<Box mt={2}>
					<MultiSelect
						refLovs={this.state.country}
						value={this.state.selCountry}
						changed={(selected) => {
							this.setState({ selCountry: selected });
						}}
						placeholder={'Country'}
					/>
				</Box>
			</Grid>
		);

		let tapCode = (
			<Grid item xs={12} sm={5} md={2}>
				<Box>
					<span> Tap Code </span>
				</Box>
				<Box mt={2}>
					<MultiSelect
						refLovs={this.state.tapCodes}
						value={this.state.seltapCodes}
						changed={(selected) => {
							this.setState({ seltapCodes: selected });
						}}
						placeholder={'Tap Code'}
					/>
				</Box>
			</Grid>
		);

		let countryCode = (
			<Grid item xs={12} sm={5} md={2}>
				<Box>
					<span> Country Code </span>
				</Box>
				<Box mt={2}>
					<MultiSelect
						refLovs={this.state.countryCodes}
						value={this.state.selcountryCodes}
						changed={(selected) => {
							this.setState({ selcountryCodes: selected });
						}}
						placeholder={'Country Code'}
					/>
				</Box>
			</Grid>
		);

		let jurisdiction = (
			<Grid item xs={12} sm={5} md={2}>
				<Box>
					<span> Jurisdiction </span>
				</Box>
				<Box mt={2}>
					<MultiSelect
						refLovs={this.state.jurisdiction}
						value={this.state.selJurisdiction}
						changed={(selected) => {
							this.setState({ selJurisdiction: selected });
						}}
						placeholder={'Jurisdiction'}
					/>
				</Box>
			</Grid>
		);

		let createRatePlan = (
			<Grid container alignContent="flex-start" spacing={2}>
				{/* <Modal
                show={this.state.show}
                modalClosed={this.errorConfirmedHandler}
                title={'Something Went Wrong!'}
            >
                {this.state.modalContent}
            </Modal> */}
				<Grid item xs={12}>
					<form
					// onSubmit={this.saveRatePlanHandler}
					>
						{Object.keys(this.state.ratePlanGroups).map((key, i) => {
							return (
								<Card
									key={key}
									style={{ marginTop: '1%', overflow: 'visible' }}>
									<CardHeader
										className={classes.cardHeader}
										classes={{
											subheader: classes.subheader,
										}}
										subheader={key}
										action={
											i == 0 && (
												<LightTooltip title="New Rate Plan" arrow>
													<AddIcon
														onClick={() => {
															this.setState({
																usageGrps: {},
																ratesObj: {},
																editing: false,
																ccmidUpdate: '',
															});

															this.state.schema.map((formElement) => {
																if (formElement.refType == 'Date')
																	this.setState({
																		[formElement.refName]:
																			formElement.defaultValue
																				? moment(
																						formElement.defaultValue
																				  ).format('DD-MMM-YY')
																				: moment().format('DD-MMM-YY'),
																	});
																else if (formElement.refType == 'Checkbox')
																	this.setState({
																		[formElement.refName]: 'N',
																	});
																else if (formElement.refType == 'MultiSelect')
																	this.setState({
																		[formElement.refName]: [],
																	});
																else
																	this.setState({
																		[formElement.refName]: '',
																	});
															});
														}}
														style={{
															color: 'white',
															marginRight: '10px',
															cursor: 'pointer',
														}}
													/>
												</LightTooltip>
											)
										}
									/>

									<CardContent>
										<Grid container alignItems="flex-end" spacing={2}>
											{this.state.ratePlanGroups[key].map((formElement) =>
												this.inputHelper(formElement)
											)}
										</Grid>

										{key == 'Rates Details' &&
											this.state['icmRateplanCategory'] &&
											this.state['icmRateplanCategory'] != 'IR' &&
											this.state['icmRateplanCategory'] != 'ISD' && (
												<React.Fragment>
													<div
														style={{
															width: '100%',
														}}
														className={classes.center}>
														<Button
															onClick={this.saveRpNormalFlow}
															variant="outlined"
															color="primary"
															style={{ marginTop: '1.5%' }}>
															Create
														</Button>
													</div>
												</React.Fragment>
											)}

										{key == 'Rates Details' &&
											this.state['ugcSubType2'] &&
											this.state['ugcSubType2'].length > 0 &&
											(this.state['icmRateplanCategory'] == 'IR' ||
												this.state['icmRateplanCategory'] == 'ISD') && (
												<React.Fragment>
													<Grid
														item
														xs={12}
														sm={5}
														style={{ marginTop: '1.5%' }}>
														<Box>
															<span> Rates Applies To </span>
														</Box>
														<Box mt={2}>
															<CustomInput
																resize
																refType="SelectInput"
																value={this.state.ratesApplies}
																changed={(selected) => {
																	this.setState({
																		ratesApplies: selected,
																	});
																}}
																refLovs={
																	this.state['icmRateplanCategory'] == 'IR'
																		? ['ZONE', 'COUNTRY', 'TAPCODE']
																		: [
																				'ZONE',
																				'COUNTRY',
																				'COUNTRY-CODE',
																				'JURISDICTION',
																		  ]
																}
															/>
														</Box>
													</Grid>
													{this.state.ratesApplies && (
														<Grid
															container
															alignItems="flex-end"
															spacing={2}
															style={{ marginTop: '1.5%' }}>
															{zone}
															{this.state.ratesApplies !== 'ZONE' && country}
															{this.state.ratesApplies === 'TAPCODE' && tapCode}
															{(this.state.ratesApplies === 'COUNTRY-CODE' ||
																this.state.ratesApplies === 'JURISDICTION') &&
																countryCode}
															{this.state.ratesApplies === 'JURISDICTION' &&
																jurisdiction}
															<Button
																variant="outlined"
																color="primary"
																style={{ margin: '.8%' }}
																onClick={() => {
																	if (
																		this.state['icmRateplanCategory'] == 'IR'
																	) {
																		this.saveRatesIr();
																	} else this.saveRatesIsd();
																}}>
																Create
															</Button>
														</Grid>
													)}
												</React.Fragment>
											)}
									</CardContent>
								</Card>
							);
						})}

						{Object.keys(this.state.usageGrps).length > 0 && (
							<Card style={{ marginTop: '1%', overflow: 'visible' }}>
								<CardHeader
									className={classes.cardHeader}
									classes={{
										subheader: classes.subheader,
									}}
									subheader={'Rate Plans'}
								/>

								<CardContent>
									{Object.keys(this.state.usageGrps).map((usageGrp) => {
										return (
											<Accordion
												expanded={this.state.expanded === usageGrp}
												onChange={this.changeHandler(usageGrp)}
												key={usageGrp}>
												<AccordionSummary
													aria-controls="panel1bh-content"
													id="panel1bh-header">
													<ExpandMoreIcon />
													<Typography className={classes.heading}>
														{usageGrp}
													</Typography>

													{/* <CustomInput
														style={{ margin: '-20px 0 0 7rem', width: '50%' }}
														placeholder="Fill All Rates"
														value={this.state.fillRates}
														onClick={(e) => e.stopPropagation()}
														changed={(e) => {
															this.setState({
																fillRates: e.target.value,
															});
														}}
														disabled={false}
														required={false}
													/>
													<Button
														variant="outlined"
														size="small"
														style={{ margin: '0 2rem 0 1rem' }}
														onClick={(e) => {
															e.stopPropagation();
															console.log(this);
															let ratesObj = this.state.ratesObj;
															this.state.usageGrps[usageGrp].forEach(
																(item) =>
																	(ratesObj[usageGrp] = {
																		...ratesObj[usageGrp],
																		[item]: this.state.fillRates,
																	})
															);
															this.setState({
																ratesObj,
															});
														}}>
														Apply
													</Button> */}

													<VisibilityIcon
														style={{
															color: 'ff1921',
															marginLeft: '-10px',
															marginRight: '10px',
														}}
														onClick={(event) => {
															event.stopPropagation();
															this.viewRatePlan(usageGrp);
														}}
													/>
													<DeleteIcon
														style={{ color: 'red' }}
														onClick={(event) => {
															event.stopPropagation();
															let usageGrps = { ...this.state.usageGrps };
															let ratesObj = { ...this.state.ratesObj };

															delete usageGrps[usageGrp];
															delete ratesObj[usageGrp];

															this.setState({
																usageGrps: usageGrps,
																ratesObj: ratesObj,
															});
														}}
													/>
												</AccordionSummary>
												<AccordionDetails>
													<List
														component="nav"
														aria-labelledby="nested-list-subheader"
														style={{
															width: '100%',
															maxHeight: '30vh',
															overflow: 'auto',
														}}>
														{this.state.usageGrps[usageGrp].map(
															(usageGrpRates, index) => {
																let input = (
																	<TextField
																		style={{ minWidth: '20%' }}
																		placeholder={usageGrpRates}
																		// id={attribute.attrGrpDescription + attribute.ppmAttrName}
																		value={
																			this.state.ratesObj[usageGrp][
																				usageGrpRates
																			]
																		}
																		onChange={(event) => {
																			let rates = { ...this.state.ratesObj };
																			let usageGrpData = {
																				...this.state.ratesObj[usageGrp],
																			};
																			usageGrpData[usageGrpRates] =
																				event.target.value;
																			rates[usageGrp] = usageGrpData;
																			this.setState({
																				ratesObj: rates,
																			});
																			console.log(event.target.value);
																		}}
																		required={true}
																	/>
																);

																return (
																	<React.Fragment key={usageGrpRates + index}>
																		<ListItem>
																			{index == 0 &&
																				(usageGrp.startsWith('IR') ||
																					usageGrp.startsWith('ISD')) && (
																					<ListItemIcon>
																						<Button
																							variant="outlined"
																							style={{ marginRight: '10px' }}
																							onClick={() =>
																								this.copy(
																									usageGrpRates,
																									usageGrp
																								)
																							}>
																							Copy
																						</Button>
																					</ListItemIcon>
																				)}
																			<ListItemText primary={usageGrpRates} />
																			{input}
																		</ListItem>
																		<Divider />
																	</React.Fragment>
																);
															}
														)}
													</List>
												</AccordionDetails>
											</Accordion>
										);
									})}
								</CardContent>
							</Card>
						)}
						{this.props.releaseData.releaseId && (
							<div
								style={{
									display: 'flex',
									justifyContent: 'center',
									alignItems: 'center',
								}}>
								<Button
									variant="outlined"
									style={{
										color: 'green',
										border: '1px solid green',
										marginTop: '1%',
									}}
									onClick={this.saveRatePlans}>
									Save
								</Button>
								{/* change */}
								<Button
									variant="outlined"
									style={{
										color: 'green',
										border: '1px solid green',
										marginTop: '1%',
									}}
									onClick={console.log()}>
									Clone
								</Button>
							</div>
						)}
					</form>
				</Grid>
			</Grid>
		);

		if (this.state.loading) createRatePlan = <Loader relative />;
		return createRatePlan;
	}
}

export default withStyles(useStyles)(WithErrorHandler(CreateRatePlan, axios));
