import React, { Component } from "react";
import Modal from "../../UI/Modal/Modal";
import Loader from "../../UI/Loader/Loader";
import axios from "../../axios-epc";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Divider from "@material-ui/core/Divider";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import AppsIcon from "@material-ui/icons/Apps";
import ExcelJS from "exceljs/dist/es5/exceljs.browser.js";
import { saveAs } from "file-saver";
import { createMuiTheme } from "@material-ui/core/styles";

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}
const theme = createMuiTheme({
  overrides: {
    MuiDropzoneArea: {
      root: {
        height: "100%",
      },
    },
  },
});

class DealData extends Component {
  _isMounted = false;

  state = {
    show: true,
    loading: false,
    activeTab: 0,
    files: [],
    key: "app",
    openSnack: false,
    selValidationLog: null,
  };

  modalCloseHandler = () => {
    this.setState({ show: false });
    this.props.showDealData();
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount() {
    this._isMounted = true;
  }

  handleChangeTab = (event, newValue) => {
    console.log(newValue);
    this.setState({ activeTab: newValue ? newValue : 0 });
  };

  handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    this.setState({ openSnack: false });
  };

  downloadValidationLogs = (event, index, valLog) => {
    this.setState({
      loading: true,
      selValidationLog: index,
    });
    console.log(valLog);
    axios
      .get( 
        "mtn/modification/valdata?releaseId=" +
          this.props.releaseData.releaseId
      )
      .then((response) => {
        console.log(response);
        if (response) this.saveAsExcel(response, valLog);
        else this.setState({ loading: false });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  async saveAsExcel(response, valLog) {
    const workbook = new ExcelJS.Workbook();
    let worksheet = null;
    let columns = {};
    let fileName = null;
    Object.keys(response.data.data[0]).map((key) => {
      let val = key.replace(/([A-Z])/g, " $1");
      val = val.charAt(0).toUpperCase() + val.slice(1);
      columns[key] = val;
    });

    console.log(columns);

    if (valLog == "DEAL") {
      worksheet = workbook.addWorksheet("Deal Validation Logs");
      fileName = "Deal Validation Logs";
    } else if (valLog == "INSURANCE") {
      worksheet = workbook.addWorksheet("Device Validation Logs");
      fileName = "Device Validation Logs";
    } else if (valLog == "SKEW") {
      worksheet = workbook.addWorksheet("Sku Validation Logs");
      fileName = "Sku Validation Logs";
    } else if (valLog == "TRANSFORM") {
      worksheet = workbook.addWorksheet("Transformed Output");
      fileName = "Transformed Output";
    }
    let sheetColumns = [];

    Object.keys(columns).map((key) => {
      sheetColumns.push({
        header: columns[key],
        key: key,
        width: 25,
      });
    });
    worksheet.columns = sheetColumns;
    response.data.data.map((row) => {
      worksheet.addRow(row);
    });

    const options = {
      formatterOptions: {
        delimiter: "|",
        transform: (row) => {
          let newArray = [""];

          for (var i = 0; i < row.length; i++) {
            var arr = [];
            arr.push(row[i]);
            newArray.push(arr);
          }
          newArray.push([""]);
          console.log(newArray);

          return newArray;
        },
      },
    };
    this.setState({ loading: false });
    if (valLog == "TRANSFORM") {
      worksheet.spliceRows(0, 1);
      workbook.csv.writeBuffer(options).then(function (buffer) {
        saveAs(
          new Blob([buffer], { type: "application/octet-stream" }),
          fileName + ".csv"
        );
      });
    } else {
      worksheet.getRow(1).font = {
        bold: true,
      };
      const buf = await workbook.xlsx.writeBuffer();
      saveAs(new Blob([buf]), fileName + ".xlsx");
    }
  }

  render() {
    const vertical = "top";
    const horizontal = "center";

    let dealData = (
      <Modal
        show={this.state.show}
        modalClosed={this.modalCloseHandler}
        title={"Release Id " + this.props.releaseData.releaseId}
      >
        <Snackbar
          anchorOrigin={{ vertical, horizontal }}
          open={this.state.openSnack}
          autoHideDuration={4000}
          onClose={this.handleClose}
        >
          <Alert onClose={this.handleClose} severity="success">
            Files Uploaded Successfully
          </Alert>
        </Snackbar>
        {this.state.loading ? (
          <div style={{ minHeight: "35vh" }}>
            <Loader />{" "}
          </div>
        ) : (
          <div style={{ minHeight: "35vh" }}>
            <AppBar position="static">
              <Tabs
                value={this.state.activeTab}
                indicatorColor="white"
                variant="fullWidth"
                onChange={this.handleChangeTab}
              >
                <Tab
                  label="Validation Logs"
                  style={{
                    background: "#ffc800",
                    color: "#10628F",
                    fontWeight: "bold",
                  }}
                />
              </Tabs>
            </AppBar>
            <TabPanel value={this.state.activeTab} index={0}>
              <List component="nav">
                <ListItem
                  style={{ cursor: "pointer" }}
                  selected={this.state.selValidationLog === 0}
                  onClick={(event) =>
                    this.downloadValidationLogs(event, 0, "DEAL")
                  }
                >
                  <ListItemIcon>
                    <AppsIcon />
                  </ListItemIcon>
                  <ListItemText primary={"Deal Validation Logs"} />
                </ListItem>
                <Divider />
              </List>
            </TabPanel>
          </div>
        )}
      </Modal>
    );

    return dealData;
  }
}

export default WithErrorHandler(DealData, axios);
