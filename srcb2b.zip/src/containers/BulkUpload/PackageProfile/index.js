import React, { useState, useEffect } from 'react';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../../axios-epc';
import Loader from '../../../UI/Loader/Loader';
import { ENTITY_NAME } from './pkg-constants';
import { useSelector } from 'react-redux';
import PkgTable from './pkg-table';

const PackageProfile = () => {
  // selectors
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const openDrawer = useSelector((state) => state.drawerData.open);

  // states
  const [version, setVersion] = useState('');
  const [loading, setLoading] = useState(true);
  const [schema, setSchema] = useState([]);

  const getVersions = () => {
    return axios
      .get(`config/version?entityName=${ENTITY_NAME}`, {
        headers: {
          opId: userInfo.opId,
          buId: userInfo.buId,
        },
      })
      .then((res) => {
        setVersion(res.data.data.version);
      })
      .catch((error) => setLoading(false));
  };

  const uiFields = () => {
    if (
      localStorage.getItem('packageProfile') &&
      localStorage.packageProfile_version &&
      localStorage.packageProfile_version == version
    ) {
      console.log('fetching from local storage');
      try {
        setSchema(JSON.parse(localStorage.getItem('packageProfile')));
      } catch (e) {
        localStorage.removeItem('packageProfile');
      }
      return Promise.resolve();
    } else {
      console.log('fetching from api');
      return axios
        .get(`config?entityName=${ENTITY_NAME}`, {
          headers: {
            opId: userInfo.opId,
            buId: userInfo.buId,
          },
        })
        .then((res) => {
          let tmpSchema = [];
          tmpSchema = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });

          setSchema(tmpSchema);
          localStorage.setItem('packageProfile', JSON.stringify(tmpSchema));
          localStorage.packageProfile_version = version;
          setLoading(false);
        })
        .catch((error) => {
          console.log(error);
          setLoading(false);
        });
    }
  };

  // componentDidMount
  useEffect(() => {
    getVersions().then(() => uiFields());
  }, []);

  if (loading) return <Loader />;

  return (
    <div
      style={{
        margin: '0 auto',
        width: openDrawer ? `calc(100vw - 343px)` : 'calc(100vw - 141px)',
      }}
    >
      <div
        style={{ padding: '20px 0', fontSize: '24px', fontWeight: '600' }}
      ></div>
      {schema.length > 0 && (
        <PkgTable setLoading={setLoading} schema={schema} />
      )}
    </div>
  );
};

export default WithErrorHandler(PackageProfile, axios);
