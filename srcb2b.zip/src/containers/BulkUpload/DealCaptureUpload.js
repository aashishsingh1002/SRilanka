import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import { DropzoneArea } from 'material-ui-dropzone';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import DeleteIcon from '@material-ui/icons/Delete';
import GetAppIcon from '@material-ui/icons/GetApp';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import { connect } from 'react-redux';
import { fetchDealCaptureDD } from '../../store/actions/actionCreators';
import * as actionTypes from '../../store/actions/actionTypes';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import AppsIcon from '@material-ui/icons/Apps';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';

function Alert(props) {
  return <MuiAlert elevation={6} variant='filled' {...props} />;
}
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}
const theme = createMuiTheme({
  overrides: {
    MuiDropzoneArea: {
      root: {
        height: '100%',
      },
    },
  },
});
// const theme = createMuiTheme({
//   overrides: {
//     MuiDropzoneArea: {
//       root: {
//         minHeight: '20px',
//       },
//       text: {
//         display: 'none',
//       },
//     },
//   },
// });

class DealCaptureUpload extends Component {
  _isMounted = false;

  state = {
    show: true,
    loading: false,
    activeTab: 0,
    files: [],
    key: 'app',
    openSnack: false,
    selValidationLog: null,
    dealCaptureUpload: {},
  };

  constructor(props) {
    super(props);
    this.dropzoneRef = React.createRef();
  }

  modalCloseHandler = () => {
    this.setState({ show: false });
    this.props.showDealCaptureUpload();
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount() {
    this._isMounted = true;
    // Fetch dropdowns
    this.props.fetchDealCaptureDD('devnumber');
    this.props.fetchDealCaptureDD('pcrcost');
    this.props.fetchDealCaptureDD('basepkg');
    this.props.fetchDealCaptureDD('altaspuname');
  }

  handleChangeTab = (event, newValue) => {
    console.log(newValue);
    this.setState({ activeTab: newValue ? newValue : 0 });
  };
  handleChange(file) {
    console.log(file);
    let dealCaptureUpload = {};
    dealCaptureUpload[file.name] = false;
    this.setState({
      files: file,
      dealCaptureUpload: dealCaptureUpload,
    });
  }
  downloadValidationLogs = (event, index) => {
    this.setState({
      loading: true,
      selValidationLog: index,
    });

    axios
      .get('/mtn/deal/basicInfo/DcData?createdBy=' + this.props.userInfo.id)
      .then((response) => {
        console.log(response);

        if (response) this.saveAsValidationLogExcel(response);
        else this.setState({ loading: false });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  async saveAsValidationLogExcel(response) {
    const { worksheetName = '', fileName = '' } = this.props;
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('XMtnDealcaltureUiTab');
    let sheetColumns = [];

    this.props.schema
      .filter((x) => x.groupName === 'UI Input')
      .filter((x) => x.uiName !== 'Alternative Device Aspu Name')
      .filter((x) => x.uiName !== 'Service Provider')
      .filter((x) => x.uiName !== 'UC Id')
      .forEach((row) => {
        sheetColumns.push({
          header: row.uiName,
          key: row.refName,
          width: 25,
        });
      });
    sheetColumns.push({
      header: 'Alternative Device Aspu Name',
      key: 'alternativeDeviceAspuName',
      width: 25,
    });

    sheetColumns.push({
      header: 'Service Provider',
      key: 'serviceProvider',
      width: 25,
    });
    sheetColumns.push({
      header: 'Has Error',
      key: 'isError',
      width: 25,
    });
    sheetColumns.push({
      header: 'Change',
      key: 'change',
      width: 25,
    });

    sheetColumns.push({
      header: 'Validation Complete',
      key: 'valComplete',
      width: 25,
    });
    sheetColumns.push({
      header: 'Created By',
      key: 'createdBy',
      width: 25,
    });
    sheetColumns.push({
      header: 'Release Id',
      key: 'releaseId',
      width: 25,
    });
    worksheet.columns = sheetColumns;

    worksheet.getRow(1).font = {
      bold: true,
    };
    response.data.data.map((row) => {
      worksheet.addRow(row);
    });

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), `Deal_Capture_ValidationLog.xlsx`);
  }

  saveDealCaptureHandler = () => {
    if (
      this.state.files.length > 0 &&
      !this.state.dealCaptureUpload[this.state.files[0].name]
    ) {
      this.setState({
        loading: true,
      });
      let formData = new FormData();
      this.state.files.map((file) => {
        formData.append('file', file);
      });
      console.log('formData');
      for (var pair of formData.entries()) {
        console.log(pair[0]);
        console.log(pair[1]);
      }

      axios
        .post(
          'mtn/deal/basicInfo/uploadDeals?releaseId=' +
            this.props.releaseData.releaseId +
            '&&createdBy=' +
            this.props.userInfo.id,
          formData
        )
        .then((res) => {
          if (res) {
            let dealCaptureUpload = {};
            dealCaptureUpload[this.state.files[0].name] = true;
            this.setState({
              dealCaptureUpload: dealCaptureUpload,
            });
            this.props.loadDealCapture();
          }

          this.setState({
            loading: false,
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  };

  async saveAsExcelDealCapture() {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('XMtnDealcaltureUiTab');
    worksheet.getColumn(3).dataValidation = {
      type: 'list',
      allowBlank: true,
      formulae: ['"One,Two,Three,Four"'],
    };
    // worksheet.getCell('B2:B9999').dataValidation = {
    //   operator: 'greaterThan',
    //   formulae: [0],
    //   allowBlank: false,
    //   showErrorMessage: true,
    //   errorStyle: 'error',
    //   errorTitle: 'PromoPlan can not be blank',
    //   error: 'The value Can not be blank',
    //   prompt: 'The value must between 1.5 and 7',
    // };
    // // Specify Cell must be have a text length less than 15
    // worksheet.getColumn('B2:B9999').dataValidation = {
    //   type: 'textLength',
    //   operator: 'lessThan',
    //   showErrorMessage: true,
    //   allowBlank: true,
    //   formulae: [15],
    // };

    worksheet.dataValidations.add('F2:F9999', {
      type: 'list',
      allowBlank: true,
      formulae: ['"Telesales,Online Store,CVM,All"'],
    });
    // worksheet.dataValidations.add('G2:F9999', {
    //   type: 'list',
    //   allowBlank: true,
    //   formulae: ['"Telesales,Online Store,CVM,All"'],
    // });

    //   if (row.refName === 'prd') {
    //     let a = `'${row.refLovs}'`; //["'1,6,12,24,36'"]
    //     console.log(a);
    //     return worksheet.dataValidations.add('C2:D9999', {
    //       type: 'list',
    //       allowBlank: true,
    //       formulae: ['"1,6,12,24,36"'],
    //     });
    //   }
    //   if (row.refName === 'sim') {
    //     return worksheet.dataValidations.add('E2:D9999', {
    //       type: 'list',
    //       allowBlank: true,
    //       formulae: ['"NEW,CTB,SELL"'],
    //     });
    //   }
    // if(row.refName==='sim'){
    //     return   worksheet.dataValidations.add('Z2:D9999', {
    //         type: 'list',
    //         allowBlank: true,
    //         formulae: ['"Free,Charge"']
    //     })
    //     }
    //   if (row.refName === 'lifecycle') {
    //     return worksheet.dataValidations.add('D2:D9999', {
    //       type: 'list',
    //       allowBlank: true,
    //       formulae: ['"NEW,CTB,SELL"'],
    //     });
    //   }
    // if(row.refName==='quarter'){
    //     let quarterVal='';
    //     quarterVal= "'"+"\""+(this.props.dropdowns.quarter.map((x)=>{
    //        return   x.quarter
    //     }))+ "\""+ "'"
    //     console.log([quarterVal])
    // return   worksheet.dataValidations.add('C2:D9999', {
    //     type: 'list',
    //     allowBlank: true,
    //     formulae:['"1,6,12,24,36"']
    // })
    // }

    // worksheet.dataValidations.add('B2:F9999', {
    //   type: 'whole',
    //   operator: 'notEqual',
    //   showErrorMessage: true,
    //   formulae: [5],
    //   errorStyle: 'error',
    //   errorTitle: 'Five',
    //   error: 'The value must not be Five',
    // });

    // if(row.refName==='sim'){
    //     return   worksheet.dataValidations.add('D2:D9999', {
    //         type: 'list',
    //         allowBlank: true,
    //         formulae: ['"Free,Charge"']

    //     })
    //     }

    // worksheet.dataValidations.add('G2:F9999', {
    //     type: 'list',
    //     allowBlank: true,
    //     {this.props.dropdowns.devnumber.map(
    //         ({ deviceNumber }) => {
    //             formulae:  []
    //         }

    //         )
    //       )}

    // });
    let sheetColumns = [];
    this.props.schema
      .filter((x) => x.groupName === 'UI Input')
      .filter((x) => x.uiName !== 'Alternative Device Aspu Name')
      .filter((x) => x.uiName !== 'Service Provider')
      .filter((x) => x.uiName !== 'UC Id')
      // .filter((x) => x.uiName !== 'Deal Id Suffix')
      .forEach((row) => {
        sheetColumns.push({
          header: row.uiName,
          key: row.refName,
          width: 25,
        });

        console.log('sheetColumns', sheetColumns);
      });

    // sheetColumns.push({ header: 'CreatedBy', key: 'createdBy', width: 25 });
    // sheetColumns.push({ header: 'CreatedDate', key: 'createdDate', width: 25 });
    sheetColumns.push({
      header: 'Alternative Device Aspu Name',
      key: 'alternativeDeviceAspuName',
      width: 25,
    });

    sheetColumns.push({
      header: 'Service Provider',
      key: 'serviceProvider',
      width: 25,
    });
    // sheetColumns.push({
    //   header: 'Deal Id Suffix',
    //   key: 'dealIdSuffix',
    //   width: 25,
    // });
    console.log('sheetColumns', sheetColumns);
    worksheet.columns = sheetColumns;
    worksheet.getRow(1).font = {
      bold: true,
    };

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), 'Deal_Capture_Template.xlsx');
  }
  render() {
    const vertical = 'top';
    const horizontal = 'center';

    let dealCaptureUpload = (
      <Modal
        show={this.state.show}
        modalClosed={this.modalCloseHandler}
        title={'Deal Capture'}
      >
        <Snackbar
          anchorOrigin={{ vertical, horizontal }}
          open={this.state.openSnack}
          autoHideDuration={4000}
          onClose={this.handleClose}
        >
          <Alert onClose={this.handleClose} severity='success'>
            Files Uploaded Successfully
          </Alert>
        </Snackbar>
        {this.state.loading ? (
          <div style={{ minHeight: '35vh' }}>
            <Loader />{' '}
          </div>
        ) : (
          <div style={{ minHeight: '35vh' }}>
            <AppBar position='static'>
              <Tabs
                value={this.state.activeTab}
                indicatorColor='white'
                variant='fullWidth'
                onChange={this.handleChangeTab}
              >
                <Tab
                  label='DEAL CAPTURE Sheet'
                  style={{
                    background: '#ffc800',
                    color: '#10628F',
                    fontWeight: 'bold',
                  }}
                />
                <Tab
                  label='Validation Logs'
                  style={{
                    background: '#ffc800',
                    color: '#10628F',
                    fontWeight: 'bold',
                  }}
                />
              </Tabs>
            </AppBar>
            <TabPanel value={this.state.activeTab} index={0}>
              <div style={{ minHeight: '35vh' }}>
                <div
                  style={
                    this.state.loading
                      ? { display: 'none' }
                      : { display: 'block' }
                  }
                >
                  <Grid container spacing={2}>
                    <Grid item xs={3}>
                      <ThemeProvider theme={theme}>
                        <DropzoneArea
                          ref={this.dropzoneRef}
                          key={this.state.key}
                          onChange={this.handleChange.bind(this)}
                          maxFileSize={52428800}
                          dropzoneText='Upload Files'
                          showPreviewsInDropzone={false}
                          filesLimit={20}
                          style={{ minHeight: '150px' }}
                          acceptedFiles={[
                            'file/xls',
                            'file/xlsx',
                            '.xlsx',
                            'application/vnd.ms-excel',
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            'application/msword',
                          ]}
                          // acceptedFiles={['application/vnd.ms-excel'
                          //     , 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',]}
                        />
                      </ThemeProvider>
                    </Grid>

                    <Grid item xs={9}>
                      <TableContainer component={Paper}>
                        <Table size='small'>
                          <TableHead>
                            <TableRow>
                              <TableCell align='left' style={{ width: '90%' }}>
                                File Name
                              </TableCell>
                              <TableCell align='left' style={{ width: '10%' }}>
                                Delete
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {this.state.files.map((file, index) => (
                              <TableRow key={file.name}>
                                <TableCell align='left'> {file.name}</TableCell>

                                <TableCell align='left'>
                                  <DeleteIcon
                                    onClick={(event) => {
                                      this.dropzoneRef.current.deleteFile(
                                        this.state.files[index],
                                        index
                                      );
                                    }}
                                    style={{ color: 'red', cursor: 'pointer' }}
                                  />
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                      {this.state.files.length > 0 && (
                        <div
                          style={{
                            display: 'flex',
                            flex: '1',
                            justifyContent: 'space-around',
                            marginTop: '30px',
                          }}
                        >
                          <Button
                            variant='contained'
                            size='medium'
                            style={{
                              background: 'pink',
                              textTransform: 'none',
                              float: 'right',
                            }}
                            onClick={() => {
                              let key =
                                this.state.key.length > 10
                                  ? 'app'
                                  : this.state.key + '1';
                              this.setState({ key: key });
                            }}
                          >
                            Clear
                          </Button>
                          <Button
                            variant='contained'
                            size='medium'
                            style={{
                              background: '#02bfa0',
                              textTransform: 'none',
                              float: 'right',
                            }}
                            onClick={this.saveDealCaptureHandler}
                          >
                            Upload
                          </Button>
                        </div>
                      )}
                    </Grid>
                  </Grid>
                  <Grid container spacing={2}>
                    <Grid item xs={3}>
                      <Button
                        variant='contained'
                        style={{
                          textTransform: 'capitalize',
                          background: '#ffcc00',
                          letterSpacing: '-1px',
                          fontWeight: '600',
                          color: '#000',
                          fontSize: '16px',
                          borderRadius: '50px',
                          padding: '6px 32px',
                          '&:hover': {
                            opacity: 0.8,
                            background: '#ffcc00',
                          },
                        }}
                        onClick={(event) => {
                          this.saveAsExcelDealCapture();
                        }}
                      >
                        <GetAppIcon style={{ cursor: 'pointer' }} />
                        Template
                      </Button>
                    </Grid>
                  </Grid>
                  <p
                    style={{
                      fontSize: '16px',
                      marginBottom: '0px',
                      marginTop: '0px',
                      marginLeft: '5px',
                      marginRight: '5px',
                      color: '#FF0000',
                    }}
                  >
                    *Maximum Upload File Size: 50MB
                  </p>
                  <p
                    style={{
                      fontSize: '16px',
                      marginBottom: '0px',
                      marginTop: '0px',
                      marginLeft: '5px',
                      marginRight: '5px',
                      color: '#FF0000',
                    }}
                  >
                    *File Format Allowed: xlsx
                  </p>
                </div>
              </div>
            </TabPanel>
            <TabPanel value={this.state.activeTab} index={1}>
              <List component='nav'>
                <ListItem
                  style={{ cursor: 'pointer' }}
                  selected={this.state.selValidationLog === 0}
                  onClick={(event) => this.downloadValidationLogs(event, 0)}
                >
                  <ListItemIcon>
                    <AppsIcon />
                  </ListItemIcon>
                  <ListItemText primary={'Validation Logs'} />
                </ListItem>

                <Divider />
              </List>
            </TabPanel>
          </div>
        )}
      </Modal>
    );

    return dealCaptureUpload;
  }

  // render() {
  //   let dealCaptureUpload = (
  //     <Modal
  //       show={this.state.show}
  //       modalClosed={this.modalCloseHandler}
  //       size="md"
  //       title={"DealCapture"}
  //     >
  //       <div style={{ minHeight: "25vh" }}>
  //         <div
  //           style={
  //             this.state.loading ? { display: "none" } : { display: "block" }
  //           }
  //         >
  //           <TableContainer component={Paper} style={{ marginTop: "2vh" }}>
  //             <Table size="small">
  //               <TableHead>
  //                 <TableRow>
  //                   <TableCell align="center" style={{ width: "10%" }}>
  //                     Template
  //                   </TableCell>
  //                   <TableCell align="left" style={{ width: "15%" }}>
  //                     Select File{" "}
  //                   </TableCell>
  //                   <TableCell align="left" style={{ width: "35%" }}>
  //                     File Name
  //                   </TableCell>
  //                   <TableCell align="left" style={{ width: "20%" }}>
  //                     Status
  //                   </TableCell>
  //                   <TableCell align="left" style={{ width: "10%" }}>
  //                     Delete
  //                   </TableCell>
  //                   <TableCell align="left" style={{ width: "10%" }}>
  //                     Upload
  //                   </TableCell>
  //                 </TableRow>
  //               </TableHead>
  //               <TableBody>
  //                 <TableRow>
  //                   <TableCell align="center">
  //                     {" "}
  //                     <GetAppIcon
  //                       onClick={(event) => {
  //                         this.saveAsExcelDealCapture();
  //                       }}
  //                       style={{ cursor: "pointer" }}
  //                     />{" "}
  //                   </TableCell>
  //                   <TableCell align="left">
  //                     <ThemeProvider theme={theme}>
  //                       <DropzoneArea
  //                         ref={this.dropzoneRef}
  //                         onChange={this.handleChange.bind(this)}
  //                         maxFileSize={10000000}
  //                         dropzoneText=""
  //                         showPreviewsInDropzone={false}
  //                         filesLimit={1}
  //                         acceptedFiles={[
  //                           "application/vnd.ms-excel",
  //                           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  //                         ]}
  //                       />
  //                     </ThemeProvider>
  //                   </TableCell>

  //                   {this.state.files.length > 0 && (
  //                     <React.Fragment>
  //                       <TableCell align="left">
  //                         {" "}
  //                         {this.state.files[0].name}
  //                       </TableCell>
  //                       <TableCell align="left">
  //                         {!this.state.dealCaptureUpload[
  //                           this.state.files[0].name
  //                         ]
  //                           ? "Not Uploaded"
  //                           : "Uploaded"}
  //                       </TableCell>
  //                       <TableCell align="left">
  //                         {!this.state.dealCaptureUpload[
  //                           this.state.files[0].name
  //                         ] ? (
  //                           <DeleteIcon
  //                             onClick={(event) => {
  //                               this.dropzoneRef.current.deleteFile(
  //                                 this.state.files[0],
  //                                 0
  //                               );
  //                             }}
  //                             style={{ color: "red", cursor: "pointer" }}
  //                           />
  //                         ) : null}
  //                       </TableCell>
  //                       <TableCell align="left" style={{ width: "15%" }}>
  //                         {!this.state.dealCaptureUpload[
  //                           this.state.files[0].name
  //                         ] ? (
  //                           <Button
  //                             variant="contained"
  //                             size="medium"
  //                             style={{
  //                               background: "#02bfa0",
  //                               textTransform: "none",
  //                               float: "right",
  //                             }}
  //                             onClick={this.saveDealCaptureHandler}
  //                           >
  //                             Upload
  //                           </Button>
  //                         ) : null}
  //                       </TableCell>
  //                     </React.Fragment>
  //                   )}
  //                 </TableRow>
  //               </TableBody>
  //             </Table>
  //           </TableContainer>
  //         </div>
  //       </div>
  //       {this.state.loading && <Loader />}
  //     </Modal>
  //   );

  //   return dealCaptureUpload;
  // }
}
const mapDispatchToProps = (dispatch) => {
  return {
    fetchDealCaptureDD: (req) => dispatch(fetchDealCaptureDD(req)),
    setUCId: (data) => dispatch({ type: actionTypes.SET_UCID, data: data }),
  };
};
const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
    openDrawer: state.drawerData.open,
    dropdowns: state.dropdownData,
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(WithErrorHandler(DealCaptureUpload, axios));
