import React, { Component } from 'react';
import axios from '../../../axios-epc';
import Input from '../../../UI/Input/Input';
import Grid from '@material-ui/core/Grid';
// import Button from "@material-ui/core/Button";
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../../UI/Loader/Loader';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import moment from 'moment';
import { connect } from 'react-redux';
import * as actionTypes from '../../../store/actions/actionTypes';
import Button from '../../../UI/Button/Button';
import StyledButton from '../../../UI/Button/Button';
import CopyCloneButton from '../../../common/CopyCloneButton';
//import BulkEdit from './BulkEdit/index';

const useStyles = () => ({
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alignRight: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  btn: {
    textTransform: 'unset !important',
  },
});

class BasicDetails extends Component {
  _isMounted = false;

  state = {
    show: true,
    basicDetailsFieldsOriginal: [],
    basicDetailsFields: [],
    planLovs: {},
    version: '',
    loading: true,
    postRequest: true,
    // isDisabled: false,
    invalid: {
      minChannel: false,
      bundledChannelMinRate: false,
      bundledChannelFcvValueMin: false,
      bundles: false,
      fcvChannel: false,
      packageName: null,
      packageId: null,
    },
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount() {
    this._isMounted = true;
    this.versions().then(() => {
      this.uiFields().then(() => {
        this.packagelovData().then(() => {
          console.log(this.state.basicDetailsFields);
          this.state.basicDetailsFields.map((formElement) => {
            if (formElement.refType == 'Date')
              this.setState({
                [formElement.refName]: formElement.defaultValue
                  ? moment(formElement.defaultValue).format('DD-MMM-YY')
                  : moment().format('DD-MMM-YY'),
              });
            else if (formElement.refType == 'TextInput' || 'TextArea')
              this.setState({
                [formElement.refName]: formElement.defaultValue,
              });
          });
          this.packageData().then(() => {
            this.setState({ loading: false });
          });
        });
      });
    });
  }

  modalCloseHandler = () => {
    this.setState({ show: false });
  };

  lovsChangeHelper = (basicDetailsFields) => {
    this.setState({
      packageCategoryId: '',
    });
    console.log(basicDetailsFields);
    let changedBasicDetailsFields = [...basicDetailsFields];
    changedBasicDetailsFields.map((field) => {
      if (field.refName === 'packageCategoryId') {
        if (
          this.state['catalogId'] &&
          this.state.planLovs[this.state['catalogId']]
        )
          field.refLovs = [...this.state.planLovs[this.state['catalogId']]];
        else field.refLovs = [];
      }
    });
    console.log(changedBasicDetailsFields);

    return changedBasicDetailsFields;
  };

  componentDidUpdate(prevProps, prevState) {
    if (prevState['catalogId'] !== this.state['catalogId']) {
      if (this.state['catalogId']) {
        if (
          this.state['catalogId'] == 'DSL' ||
          this.state['catalogId'] == 'Voice and DSL'
        ) {
          let basicDetailsFields = this.state.basicDetailsFieldsOriginal.filter(
            (field) =>
              field.refName != 'fcvChannel' &&
              field.refName != 'bundles' &&
              field.refName != 'minChannel' &&
              field.refName != 'serviceType' &&
              field.refName != 'facilityType' &&
              field.refName != 'bundledChannelMinRate' &&
              field.refName != 'bundledChannelFcvValueMin' &&
              field.refName != 'minChanneltdm'
          );
          basicDetailsFields = this.lovsChangeHelper(basicDetailsFields);
          console.log(basicDetailsFields);
          this.setState({
            basicDetailsFields: basicDetailsFields,
            throttleSpeed: '',
            dslPlanType: '',
            planSpeed: '',
          });
        } else if (
          this.state['catalogId'] == 'SIP PRI Static' ||
          this.state['catalogId'] == 'SIP PRI Dynamic'
        ) {
          let basicDetailsFields = this.state.basicDetailsFieldsOriginal.filter(
            (field) =>
              field.refName != 'throttleSpeed' &&
              field.refName != 'dslPlanType' &&
              field.refName != 'planSpeed' &&
              field.refName != 'bundledChannelMinRate' &&
              field.refName != 'bundledChannelFcvValueMin' &&
              field.refName != 'minChanneltdm'
          );
          console.log(basicDetailsFields);
          basicDetailsFields = this.lovsChangeHelper(basicDetailsFields);

          this.setState({
            basicDetailsFields: basicDetailsFields,
            fcvChannel: ['', ''],
            bundles: ['', ''],
            minChannel: '',
            serviceType: '',
            facilityType: '',
          });
        } else if (this.state['catalogId'] === 'TDM PRI') {
          let basicDetailsFields = this.state.basicDetailsFieldsOriginal.filter(
            (field) =>
              field.refName !== 'fcvChannel' &&
              field.refName !== 'bundles' &&
              field.refName !== 'minChanneltdm' &&
              field.refName !== 'throttleSpeed' &&
              field.refName !== 'dslPlanType' &&
              field.refName !== 'planSpeed'
          );
          console.log(basicDetailsFields);
          basicDetailsFields = this.lovsChangeHelper(basicDetailsFields);

          this.setState({
            basicDetailsFields: basicDetailsFields,
            bundledChannelMinRate: '',
            bundledChannelFcvValueMin: '',
            minChannel: '',
            serviceType: '',
            facilityType: '',
          });
        } else {
          this.planTypeHelper();
        }
      } else {
        this.planTypeHelper();
      }
    }
  }

  planTypeHelper = () => {
    let basicDetailsFields = this.state.basicDetailsFieldsOriginal.filter(
      (field) =>
        field.refName != 'fcvChannel' &&
        field.refName != 'bundles' &&
        field.refName != 'minChannel' &&
        field.refName != 'serviceType' &&
        field.refName != 'facilityType' &&
        field.refName != 'throttleSpeed' &&
        field.refName != 'dslPlanType' &&
        field.refName != 'planSpeed' &&
        field.refName != 'bundledChannelMinRate' &&
        field.refName != 'bundledChannelFcvValueMin' &&
        field.refName != 'minChanneltdm'
    );
    basicDetailsFields = this.lovsChangeHelper(basicDetailsFields);

    this.setState({
      basicDetailsFields: basicDetailsFields,
      throttleSpeed: '',
      dslPlanType: '',
      planSpeed: '',
      fcvChannel: ['', ''],
      bundles: ['', ''],
      minChannel: '',
      serviceType: '',
      facilityType: '',
    });
  };

  packagelovData() {
    return axios
      .get('ratePlan/dependentLovs?param=package.basicDetails', {
        headers: {
          // opId: this.props.userInfo.opId,
          opId: 'Airtel_Telemedia',
        },
      })
      .then((res) => {
        console.log(res);
        this.setState({
          planLovs: res.data.data,
        });
      })
      .catch((error) => {
        console.log(error);
        this.setState({ loading: false });
      });
  }

  packageData() {
    if (this.props.packageData.packageId) {
      return axios
        .get(
          'package/basicDetails?packageId=' +
            this.props.packageData.packageId +
            '&releaseID=' +
            this.props.releaseData.releaseId,
          {
            headers: {
              createdBy: this.props.userInfo.id,
              opId: this.props.userInfo.opId,
            },
          }
        )
        .then((res) => {
          console.log('inside package');
          console.log(res);
          this.setState({
            packageId: res.data.data.packageId,
            packageName: res.data.data.packageDesc,
          });
          Object.keys(res.data.data).forEach((key) => {
            this.setState({ [key]: res.data.data[key] });
          });
          this.setState({ postRequest: false });
          this.props.onPackageEnter(res.data.data);
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      return Promise.resolve();
    }
  }
  versions() {
    return axios
      .get('config/version?entityName=package.basicDetails', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        if (this._isMounted) this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields = () => {
    if (
      localStorage.getItem('packageBundle') &&
      localStorage.packageBundle_version &&
      localStorage.packageBundle_version == this.state.version
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          basicDetailsFields: JSON.parse(localStorage.getItem('packageBundle')),
          basicDetailsFieldsOriginal: JSON.parse(
            localStorage.getItem('packageBundle')
          ),
        });
      } catch (e) {
        localStorage.removeItem('packageBundle');
      }
      return Promise.resolve();
    } else {
      console.log('fetching from api');

      return axios
        .get('config?entityName=package.basicDetails', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          let basicDetailsFields = [];
          basicDetailsFields = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted)
            this.setState({
              basicDetailsFields: basicDetailsFields,
              basicDetailsFieldsOriginal: [...basicDetailsFields],
            });
          localStorage.setItem(
            'packageBundle',
            JSON.stringify(basicDetailsFields)
          );
          localStorage.packageBundle_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  };

  savePkgDetailsHandler = (event) => {
    event.preventDefault();
    this.setState({ loading: true });
    let payload = {};
    let date = moment().format('DD-MMM-YY');
    let tcarePpmPackageAud = {
      throttleSpeed: '',
      dslPlanType: '',
      planSpeed: '',
      bundles: null,
      fcvChannel: null,
      minChannel: '',
      serviceType: '',
      facilityType: '',
      minChanneltdm: '',
      bundledChannelMinRate: '',
      bundledChannelFcvValueMin: '',
    };
    if (this.props.packageData.packageNbr) {
      tcarePpmPackageAud = { ...this.props.packageData };
      tcarePpmPackageAud.throttleSpeed = '';
      tcarePpmPackageAud.dslPlanType = '';
      tcarePpmPackageAud.planSpeed = '';
      tcarePpmPackageAud.fcvChannel = null;
      tcarePpmPackageAud.bundles = null;
      tcarePpmPackageAud.minChannel = '';
      tcarePpmPackageAud.serviceType = '';
      tcarePpmPackageAud.facilityType = '';
      tcarePpmPackageAud.minChanneltdm = '';
      tcarePpmPackageAud.bundledChannelMinRate = '';
      tcarePpmPackageAud.bundledChannelFcvValueMin = '';
    }
    this.state.basicDetailsFields.map((formElement) => {
      if (formElement.refType == 'Date')
        tcarePpmPackageAud[formElement.refName] = moment(
          this.state[formElement.refName]
        ).format('DD-MMM-YY');
      else if (formElement.refType == 'Checkbox')
        tcarePpmPackageAud[formElement.refName] = this.state[
          formElement.refName
        ]
          ? 'Y'
          : 'N';
      else if (formElement.refType == 'TextInput' || 'TextArea')
        tcarePpmPackageAud[formElement.refName] =
          this.state[formElement.refName];
      else
        tcarePpmPackageAud[formElement.refName] =
          this.state[formElement.refName];
    });
    tcarePpmPackageAud.buId = this.props.userInfo.buId;
    tcarePpmPackageAud.opId = this.props.userInfo.opId;
    tcarePpmPackageAud.createdBy = this.props.userInfo.id;
    tcarePpmPackageAud.createdDate = date;

    if (this.state.postRequest) {
      tcarePpmPackageAud.version = '1.0';
      payload.tcarePpmPackageAud = tcarePpmPackageAud;
      payload.releaseId = this.props.releaseData.releaseId;
      console.log('post');
      console.log(payload);
      axios
        .post('package/basicDetails', payload)
        .then((response) => {
          console.log('pkgcreated');
          let pkgDetails = { ...response.data.data };
          this.props.onPackageEnter(pkgDetails);
          let searchItems = [
            response.data.data.packageId + '/' + response.data.data.packageDesc,
          ].concat(this.props.searchItems);

          this.props.setSearchItems(searchItems);

          this.state.basicDetailsFields.map((formElement) => {
            this.setState({
              [formElement.refName]: response.data.data[formElement.refName],
            });
          });
          this.setState({ postRequest: false, loading: false });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      tcarePpmPackageAud.updatedDate = date;
      tcarePpmPackageAud.updatedBy = this.props.userInfo.id;
      tcarePpmPackageAud.packageNbr = this.props.packageData.packageNbr;
      payload.tcarePpmPackageAud = tcarePpmPackageAud;
      payload.releaseId = this.props.releaseData.releaseId;

      console.log(payload);
      axios
        .post('package/basicDetails/update', payload)
        .then((response) => {
          console.log(response);
          let pkgDetails = { ...response.data.data };
          this.setState({ loading: false });
          this.props.onPackageEnter(pkgDetails);
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  };
  validationCheck = (data, name) => {
    this.setState({
      invalid: {
        ...this.state.invalid,
        [name]: data,
      },
    });
  };

  disableButton = () => {
    const invalidObj = this.state.invalid;
    for (let item in invalidObj) {
      if (invalidObj.hasOwnProperty(item) && invalidObj[item]) return true;
    }
  };

  render() {
    const { classes } = this.props;

    let basicDetails = (
      <div>
        {/* {this.props.releaseData.releaseId && (
          <BulkEdit
            show={this.state.show}
            modalClosed={this.modalCloseHandler}
          />
        )} */}
        <div
          style={{
            marginBottom: '1em',
            display: 'flex',
            justifyContent: 'flex-end',
          }}
        >
          {/* <UploadButton
        uploadUrl={
          '/dashboard/productUpload?releaseId=' +
          this.props.releaseData.releaseId +
          '&createdBy=' +
          this.props.userInfo.id
        }
        headers={{
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        }}
        excelTabName={'product'}
        schema={this.state.schema.filter((x) => x.refName !== 'productId')}
        uploadName={'Product BulkUpload'}
        title='Product Upload'
        //   onSuccess={() => getData()}
      /> */}
          {this.props.releaseData.releaseId && (
            <CopyCloneButton
              id={this.state.packageId}
              name={this.state.packageName}
              genId={null}
              url={'/deploy/copyClone'}
              releaseId={this.props.releaseData.releaseId}
              opId={this.props.userInfo.opId}
              buId={this.props.userInfo.buId}
              createdBy={this.props.userInfo.id}
              identifier={'Package'}
            />
          )}
        </div>
        <form
          onSubmit={this.savePkgDetailsHandler}
          style={{ overflow: 'visible' }}
        >
          <Grid
            container
            alignContent='flex-start'
            spacing={4}
            style={{ overflow: 'visible' }}
          >
            {this.state.basicDetailsFields.map((formElement) => (
              <Input
                key={formElement.refName}
                {...formElement}
                catalogId={this.state.catalogId}
                colSize={
                  ['fcvChannel', 'bundles'].includes(formElement.refName)
                    ? 3
                    : 3
                }
                disabled={formElement.isDisabled == 'Y' ? true : false}
                required={formElement.isMandatory == 'Y' ? true : false}
                value={this.state[formElement.refName]}
                // setDisabled= {(disabled)=>this.setState({isDisabled: disabled})}
                onValidationCheck={this.validationCheck}
                changed={(event) => {
                  if (!event.target) {
                    this.setState({
                      [formElement.refName]: event,
                    });
                  } else {
                    if (event.target.type !== 'checkbox')
                      this.setState({
                        [formElement.refName]: event.target.value,
                      });
                    else
                      this.setState({
                        [formElement.refName]: event.target.checked,
                      });
                  }
                }}
                sliderChange={(event, minMax) => {
                  console.log(minMax);
                  console.log(event.target.value);
                  console.log(event.key);

                  let value = [...this.state[formElement.refName]];

                  if (minMax === 'min') {
                    if (!event.target.value) {
                      console.log('hi');
                      value[0] = '';
                    } else {
                      console.log('hello');

                      value[0] = event.target.value;
                    }
                  } else if (minMax === 'max') value[1] = event.target.value;

                  this.setState({
                    [formElement.refName]: value,
                  });
                }}
              />
            ))}
          </Grid>
          <br></br>
          <div>
            <span
              style={{
                color: 'red',
                marginLeft: '5px',
                fontWeight: 'bold',
              }}
            >
              *
            </span>{' '}
            <span style={{ fontSize: '13px' }}>Mandatory Fields</span>
          </div>

          {this.props.releaseData.releaseId && (
            <div className={classes.alignRight}>
              {/* <Button
              //   variant="contained"
              onClick={() => {
                this.props.changePackageActiveStep(1);
              }}
              style={{
                background: '#fff',
                marginTop: '3%',
                color: '#ff1921',
                marginRight: '20px',
              }}
              className={classes.btn}
            >
              Next
            </Button> */}
              <StyledButton
                //   variant="contained"
                // disabled= {this.state.isDisabled || this.state.invalid}
                style={{
                  //   background: "#02bfa0",
                  marginTop: '3%',
                  background: '#5dc17f',
                }}
                type='submit'
                // disabled={this.state.invalid.minChannel || this.state.invalid.bundledChannelMinRate ||
                //     this.state.invalid.bundledChannelFcvValueMin}
                disabled={this.disableButton()}
                className={classes.btn}
              >
                Save
              </StyledButton>
            </div>
          )}
        </form>
      </div>
    );

    if (this.state.loading) basicDetails = <Loader relative />;
    return basicDetails;
  }
}

const mapStateToProps = (state) => {
  return {
    searchItems: state.searchData.searchItems,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onPackageEnter: (packageData) =>
      dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
    setSearchItems: (searchItems) =>
      dispatch({
        type: actionTypes.SET_SEARCH_ITEMS,
        searchItems: searchItems,
        entity: 'PACKAGE',
      }),
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(BasicDetails, axios)));
