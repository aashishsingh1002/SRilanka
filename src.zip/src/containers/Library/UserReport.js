import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../UI/Loader/Loader';
import { withStyles } from '@material-ui/core/styles';
import * as actionTypes from '../../store/actions/actionTypes';
import Button from '@material-ui/core/Button';
import MaterialTable from 'material-table';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';

const tableIcons = {
	Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
	Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
	Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
	Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
	DetailPanel: forwardRef((props, ref) => (
		<ChevronRight {...props} ref={ref} />
	)),
	Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
	Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
	Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
	FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
	LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
	NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
	PreviousPage: forwardRef((props, ref) => (
		<ChevronLeft {...props} ref={ref} />
	)),
	ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
	Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
	SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
	ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
	ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const theme = createMuiTheme({
	overrides: {
		MuiTable: {
			root: {
				tableLayout: 'fixed',
			},
		},
		MuiTableCell: {
			root: {
				padding: '7px',
				paddingLeft: '10px',
			},
		},
		MuiPaper: {
			width: '100%',
		},
	},
});

const useStyles = (theme) => ({
	cardHeader: {
		background: '#546D7A',
		height: '4.5vh',
	},
	subheader: {
		color: 'white',
	},
});

const columns = {
	'Login ID': 'Login ID',
	Status: 'Status',
	'Primary Contact Number': 'Primary Contact Number',
	'First Name': 'First Name',
	'Last Name': 'Last Name',
	'Email Address': 'Email Address',
	'Group ID': 'Group ID',
	'Group Name': 'Group Name',
	'Primary Approver Email': 'Primary Approver Email',
	'Secondary Approver Email': 'Secondary Approver Email',
	'Group Status': 'Group Status',
};

class UserReport extends Component {
	_isMounted = false;
	state = {
		data: [],
		show: false,
		loading: false,
		actions: [
			{
				icon: () => (
					<Button
						variant="contained"
						style={{
							marginLeft: '20px',
							background: '#546D7A',
							color: 'white',
							textTransform: 'none',
						}}
						onClick={() => {
							this.saveAsExcel();
						}}>
						<SaveAlt style={{ marginRight: '10px' }} />
						Export
					</Button>
				),
				isFreeAction: true,
			},
		],
		columns: [
			{
				title: 'Login ID',
				field: 'Login ID',
			},
			{
				title: 'Status',
				field: 'Status',
				sorting: false,
			},
			{
				title: 'Primary Contact Number',
				field: 'Primary Contact Number',
				sorting: false,
			},
			{
				title: 'First Name',
				field: 'First Name',
				sorting: false,
			},
			{
				title: 'Last Name',
				field: 'Last Name',
				sorting: false,
			},
			{
				title: 'Email Address',
				field: 'Email Address',
				sorting: false,
			},
			{
				title: 'Group ID',
				field: 'Group ID',
				sorting: false,
			},
			{
				title: 'Group Name',
				field: 'Group Name',
				sorting: false,
			},
			{
				title: 'Primary Approver Email',
				field: 'Primary Approver Email',
				sorting: false,
			},
			{
				title: 'Secondary Approver Email',
				field: 'Secondary Approver Email',
				sorting: false,
			},
			{
				title: 'Group Status',
				field: 'Group Status',
				sorting: false,
			},
		],
	};

	modalCloseHandler = () => {
		this.setState({ show: false });
	};

	async saveAsExcel() {
		const workbook = new ExcelJS.Workbook();
		const worksheet = workbook.addWorksheet('User Report');
		let sheetColumns = [];
		Object.keys(columns).map((key) => {
			sheetColumns.push({
				header: columns[key],
				key: key,
				width: 25,
			});
		});

		worksheet.columns = sheetColumns;

		this.selectTable.current.state.data.forEach((row) => {
			worksheet.addRow(row);
		});

		worksheet.getRow(1).font = {
			bold: true,
		};

		this.setState({ loading: true });
		const buf = await workbook.xlsx.writeBuffer();
		this.setState({ loading: false });

		saveAs(new Blob([buf]), 'User Report.xlsx');
	}

	constructor(props) {
		super(props);
		this.selectTable = React.createRef();
	}

	componentDidMount = () => {
		this._isMounted = true;
		this.getUserReportHandler();
		this.props.onReleaseExit();
	};

	componentWillUnmount() {
		this._isMounted = false;
	}

	getUserReportHandler = () => {
		console.log('dashboard/userReportSrilanka');
		this.setState({ loading: true });
		axios
			.get('dashboard/userReportSrilanka', {
				headers: {
					opId: this.props.userInfo.opId,
				},
			})
			.then((res) => {
				console.log(res);
				if (this._isMounted) {
					this.setState({ data: res.data.data });
				}
				this.setState({ loading: false });
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	};

	render() {
		let userReport = (
			<div>
				<div
					style={
						this.state.loading ? { display: 'none' } : { display: 'block' }
					}>
					<ThemeProvider theme={theme}>
						<MaterialTable
							tableRef={this.selectTable}
							actions={this.state.actions}
							icons={tableIcons}
							title={'User Report'}
							columns={this.state.columns}
							data={this.state.data}
							options={{
								filtering: true,
								pageSize: 10,
								pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
								toolbar: true,
								paging: true,
								rowStyle: {},
								headerStyle: {
									fontWeight: 'bold',
								},
							}}
						/>
					</ThemeProvider>
				</div>
				{this.state.loading && <Loader />}
			</div>
		);
		return userReport;
	}
}

const mapStateToProps = (state) => {
	return {
		userInfo: state.login.loggedInUserInfo,
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		onReleaseExit: () =>
			dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
	};
};

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(withRouter(UserReport), axios)));
