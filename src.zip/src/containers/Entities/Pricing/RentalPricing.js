import React, { Component } from 'react';
import axios from '../../../axios-epc';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import Input from '../../../UI/Input/Input';
import Button from '@material-ui/core/Button';
import Loader from '../../../UI/Loader/Loader';
import Modal from '../../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';
import moment from "moment";
import Tooltip from '@material-ui/core/Tooltip';
import AddIcon from '@material-ui/icons/Add';


const LightTooltip = withStyles((theme) => ({
    tooltip: {
        backgroundColor: '#525354',
        color: 'white',
        boxShadow: theme.shadows[1],
        fontSize: 14,
    },
}))(Tooltip);

const useStyles = (theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    boldText: {
        // fontWeight: 'bold'
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '96%',
        flexShrink: 0,
    },

});

class RentalPricing extends Component {
    _isMounted = false;

    state = {
        schemaRental: [],
        rentalGroups: {},
        schemaRentalRc: [],
        schemaRentalNrc: [],
        loading: true,
        show: false,
        modalContent: null,
        componentIdRental: ''

    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidMount() {
        this._isMounted = true;
        this.rentalFields().then(() => {
            let rentalGroups = {}
            let schemaRentalNrc = []
            let schemaRentalRc = []
            this.state.schemaRental.forEach(el => {
                if (!(el.uiGroup in rentalGroups)) {
                    let arr = [];
                    let lovs = [];
                    this.state.schemaRental.forEach(elem => {
                        if (
                            elem.uiGroup == el.uiGroup &&
                            elem.uiGroup != "Price Details"
                        ) {
                            if (
                                elem.refType == "SelectInput" ||
                                elem.refType == "MultiSelect"
                            ) {
                                lovs = elem.refLovs.split(",");
                                elem.refLovs = lovs;

                            }
                            arr.push(elem);
                        }
                    });
                    rentalGroups[el.uiGroup] = arr
                }
            });
            let arrPd = [];

            this.state.schemaRental.forEach(elem => {
                if (elem.uiGroup == "Price Details") {
                    let lovs = [];
                    if (
                        elem.refType == "SelectInput" ||
                        elem.refType == "MultiSelect"
                    ) {
                        lovs = elem.refLovs.split(",");
                        elem.refLovs = lovs;
                    }
                    if (elem.groupName == "mandatory") {
                        arrPd.push(elem);
                    } else if (elem.groupName.includes("RCTYPE_NRC")) {
                        schemaRentalRc.push(elem);
                        schemaRentalNrc.push(elem);
                    } else {
                        if (elem.groupName.includes("RCTYPE")) {
                            schemaRentalRc.push(elem);
                        } else if (elem.groupName.includes("NRC")) {
                            schemaRentalNrc.push(elem);
                        }
                    }
                }
            });
            rentalGroups['Price Details'] = arrPd
            this.setState({
                rentalGroups: rentalGroups,
                schemaRentalNrc: schemaRentalNrc,
                schemaRentalRc: schemaRentalRc,
                loading: false
            })
            if (Object.keys(this.props.rentalData).length > 0) {
                Object.keys(this.props.rentalData).forEach(key => {
                    this.setState({ [key]: this.props.rentalData[key] })
                });
                this.setState({
                    componentIdRental: this.props.rentalData.componentName
                })
            }

        })
    }

    rentalFields() {
        if (
            localStorage.getItem("rental") &&
            localStorage.rental_version &&
            localStorage.rental_version == this.props.rentalVersion
        ) {
            console.log("fetching RENTAL from local storage");
            try {
                this.setState({
                    schemaRental: JSON.parse(localStorage.getItem("rental"))
                })
            } catch (e) {
                localStorage.removeItem("rental");
            }
            return Promise.resolve();
        } else {
            console.log("fetching RENTAL from api");
            return axios
                .get(
                    "config?entityName=package.rental", {
                        headers: {
                            opId: this.props.userInfo.opId,
                            buId: this.props.userInfo.buId
                        }
                    }
                )
                .then(res => {
                    localStorage.setItem("rental", JSON.stringify(res.data.data));
                    this.schemaRental = res.data.data;
                    if (this._isMounted)
                        this.setState({
                            schemaRental: res.data.data
                        })
                    localStorage.rental_version = this.props.rentalVersion;
                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });
        }
    }

    saveDirectRentalHandler = (event) => {
        event.preventDefault();
        if (this.props.id) {
            this.setState({ loading: true })
            let payload = {};
            let date = moment().format("DD-MMM-YY");
            let componentDetails = {};

            this.state.schemaRental.map(formElement => {
                if (formElement.refType == 'Date')
                    componentDetails[formElement.refName] = moment(this.state[formElement.refName]).format("DD-MMM-YY");
                else if (formElement.refType == 'Checkbox')
                    componentDetails[formElement.refName] = this.state[formElement.refName] ? 'Y' : 'N'
                else if (formElement.refType == 'TextInput' || 'TextArea')
                    componentDetails[formElement.refName] = this.state[formElement.refName]
                else
                    componentDetails[formElement.refName] = this.state[formElement.refName]
            })

            componentDetails.chargeCurrency = this.state.currency;
            componentDetails.chargeListPrice = this.state.listPrice;
            componentDetails.rcFrequency = this.state.chargeFrequency;
            componentDetails.createdDate = date;
            componentDetails.endDate = "30-Dec-30";
            componentDetails.startDate = date;
            componentDetails.buId = this.props.userInfo.buId;
            componentDetails.opId = this.props.userInfo.opId;
            componentDetails.createdBy = this.props.userInfo.id;
            componentDetails.customerSegmentId = "ANY";
            componentDetails.customerMarketCode = "ANY";
            componentDetails.customerTypeId = "ANY";
            componentDetails.channelId = "ANY";
            componentDetails.minimum = "0";
            componentDetails.maximum = "0";
            componentDetails.payNow = "N";
            componentDetails.chargeType = "PO";
            componentDetails.productId = this.props.id;
            componentDetails.componentTypeId = "RENTAL";
            componentDetails.priceCompMethod = "DIRECT";
            payload.releaseId = this.props.releaseData.releaseId;
            payload.id = this.props.id;
            payload.componentType = this.props.entity + "Components";
            console.log(payload);
            if (!this.state.componentIdRental) {
                console.log("post request");
                payload.componentDetails = componentDetails;

                axios
                    .post(
                        "pricing/direct",
                        payload
                    )
                    .then(response => {
                        console.log(response.data.data);
                        if (this._isMounted)
                            this.setState(
                                {
                                    loading: false,
                                    componentIdRental: response.data.data
                                })

                        let obj = {};
                        obj.componentId = this.state.componentIdRental;
                        obj.componentType = "Rental";
                        obj.componentSubType = this.state.priceType;
                        obj.componentValue =
                            this.state.listPrice +
                            " " +
                            this.state.currency;
                        obj.componentFrequency = obj.componentSubType == 'RC' ?
                            this.state.chargeFrequency : null

                        this.props.addComponent(obj)

                    })
                    .catch(error => {
                        console.log(error)
                        if (this._isMounted)
                            this.setState({ loading: false })
                    });
            } else {
                console.log("put request");
                componentDetails.productComponentId = this.state.componentIdRental;
                componentDetails.productComponentRefId = this.state.componentIdRental;
                payload.componentDetails = componentDetails;

                axios
                    .post(
                        "pricing/direct",
                        payload
                    )
                    .then(response => {
                        console.log(response.data.data);
                        let obj = {};
                        obj.componentId = response.data.data;
                        obj.componentType = "Rental";
                        obj.componentSubType = this.state.priceType;
                        obj.componentValue =
                            this.state.listPrice +
                            " " +
                            this.state.currency;
                        obj.componentFrequency = obj.componentSubType == 'RC' ? this.state.chargeFrequency : null

                        this.props.updateComponent(obj, this.state.componentIdRental)
                        if (this._isMounted)
                            this.setState(
                                {
                                    loading: false,
                                    componentIdRental: response.data.data
                                })
                    })
                    .catch(error => {
                        console.log(error)
                        if (this._isMounted)
                            this.setState({ loading: false })
                    });
            }
        }
        else {
            let modalContent = < Typography variant="h6"> Submit Basic {this.props.entity} Details first. </ Typography>
            this.setState({ modalContent: modalContent, show: true })

        }
    }

    errorConfirmedHandler = () => {
        this.setState({ show: false });
    }
    render() {
        const { classes } = this.props;
        let pricing = <Grid container alignContent="flex-start" spacing={2}>
            <Modal
                show={this.state.show}
                modalClosed={this.errorConfirmedHandler}
                title={'Something Went Wrong!'}
            >
                {this.state.modalContent}
            </Modal>
            <Grid item xs={12} >
                <form onSubmit={this.saveDirectRentalHandler} >

                    {
                        Object.keys(this.state.rentalGroups).map(key => {
                            return <Card key={key} style={{ marginTop: '1%', overflow: 'visible' }}>
                                <CardHeader
                                    className={classes.cardHeader}
                                    classes={{
                                        subheader: classes.subheader,
                                    }}

                                    subheader={key}
                                    action={
                                        key == 'Basic Details' &&
                                        <LightTooltip title='New Rental Component' arrow>
                                            <AddIcon onClick={() => {
                                                this.setState({
                                                    componentIdRental: ''
                                                })

                                                this.state.schemaRental.map(formElement => {
                                                    if (formElement.refType == 'Date')
                                                        this.setState({
                                                            [formElement.refName]: formElement.defaultValue ?
                                                                moment(formElement.defaultValue).format("DD-MMM-YY") : moment().format("DD-MMM-YY")
                                                        })
                                                    else if (formElement.refType == 'Checkbox')
                                                        this.setState({
                                                            [formElement.refName]: 'N'
                                                        })
                                                    else if (formElement.refType == 'MultiSelect')
                                                        this.setState({
                                                            [formElement.refName]: []
                                                        })
                                                    else
                                                        this.setState({
                                                            [formElement.refName]: ''
                                                        })
                                                })
                                            }}
                                                style={{ color: 'white', marginRight: '10px', cursor: 'pointer' }} />
                                        </LightTooltip>
                                    }
                                />

                                <CardContent >
                                    <Grid container alignItems="flex-end" spacing={2}>
                                        {this.state.rentalGroups[key].map(formElement => (
                                            <Input
                                                key={formElement.refName}
                                                {...formElement}
                                                value={this.state[formElement.refName]}
                                                disabled={formElement.isDisabled == 'Y' ? true : false}
                                                required={formElement.isMandatory == 'Y' ? true : false}
                                                changed={(event) => {
                                                    if (!event.target) {
                                                        this.setState({
                                                            [formElement.refName]:
                                                                event
                                                        })
                                                    } else {
                                                        if (event.target.type !== 'checkbox')
                                                            this.setState({
                                                                [formElement.refName]:
                                                                    event.target.value
                                                            })
                                                        else {
                                                            console.log(event.target.checked)
                                                            this.setState({
                                                                [formElement.refName]:
                                                                    event.target.checked
                                                            })
                                                        }
                                                    }
                                                }} />
                                        ))}
                                    </Grid>
                                    {this.state.priceType == 'RC' && key == 'Price Details' &&
                                        <Grid container alignItems="flex-end" spacing={2} style={{
                                            marginTop: '.5%'
                                        }}>
                                            {this.state.schemaRentalRc.map(formElement => (
                                                <Input
                                                    key={formElement.refName}
                                                    {...formElement}
                                                    value={this.state[formElement.refName]}
                                                    disabled={formElement.isDisabled == 'Y' ? true : false}
                                                    required={formElement.isMandatory == 'Y' ? true : false}
                                                    changed={(event) => {
                                                        if (!event.target) {
                                                            this.setState({
                                                                [formElement.refName]:
                                                                    event
                                                            })
                                                        } else {
                                                            if (event.target.type !== 'checkbox')
                                                                this.setState({
                                                                    [formElement.refName]:
                                                                        event.target.value
                                                                })
                                                            else {
                                                                console.log(event.target.checked)
                                                                this.setState({
                                                                    [formElement.refName]:
                                                                        event.target.checked
                                                                })
                                                            }
                                                        }
                                                    }} />
                                            ))}
                                        </Grid>
                                    }
                                    {this.state.priceType == 'NRC' && key == 'Price Details' &&
                                        <Grid container alignItems="flex-end" spacing={2} style={{
                                            marginTop: '.5%'
                                        }}>
                                            {this.state.schemaRentalNrc.map(formElement => (
                                                <Input
                                                    key={formElement.refName}
                                                    {...formElement}
                                                    value={this.state[formElement.refName]}
                                                    disabled={formElement.isDisabled == 'Y' ? true : false}
                                                    required={formElement.isMandatory == 'Y' ? true : false}
                                                    changed={(event) => {
                                                        if (!event.target) {
                                                            this.setState({
                                                                [formElement.refName]:
                                                                    event
                                                            })
                                                        } else {
                                                            if (event.target.type !== 'checkbox')
                                                                this.setState({
                                                                    [formElement.refName]:
                                                                        event.target.value
                                                                })
                                                            else {
                                                                console.log(event.target.checked)
                                                                this.setState({
                                                                    [formElement.refName]:
                                                                        event.target.checked
                                                                })
                                                            }
                                                        }
                                                    }} />
                                            ))}
                                        </Grid>
                                    }
                                </CardContent>

                            </Card>
                        })
                    }

                    {this.props.releaseData.releaseId && <div style={{
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                    }}>
                        <Button variant="outlined"
                            type='submit'
                            style={{
                                color: 'green', border: '1px solid green'
                                , marginTop: '1%'
                            }}
                        >
                            Save
                        </Button>
                    </div>}
                </form>

            </Grid>


        </Grid>

        if (this.state.loading)
            pricing = <Loader relative />
        return pricing;
    }
}




export default withStyles(useStyles)(WithErrorHandler(RentalPricing, axios));