import React from 'react';
import ExpansionPanel from '../../UI/ExpansionPanel/ExpansionPanel';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';


const ProductsData = (props) => {
    return (
        <ExpansionPanel heading='Products'>
            {(props.products != null && props.products.length > 0) ?
                < List
                    component="nav"
                    aria-labelledby="nested-list-subheader"
                    style={{ width: '100%', maxHeight: '30vh', overflow: 'auto' }}
                >
                    {props.products.map(product => {
                        return <React.Fragment key={product.productId}>
                            <ListItem >
                                <ListItemText primary={product.productDesc + '( ' +
                                    product.productId + ' )'} />
                            </ListItem>
                            <Divider />
                        </React.Fragment>

                    })}
                </List>
                : null}
        </ExpansionPanel>

    );
}

export default ProductsData;