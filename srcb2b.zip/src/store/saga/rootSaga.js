import { all } from "redux-saga/effects";

import {
  dealCaptureSagaWatcher,
  // import other watchers from this file
} from "./dropdownSaga";
import { summarySagaWatcher } from "./summarySaga";
// import watchers from other files
export default function* rootSaga() {
  yield all([
    dealCaptureSagaWatcher(),
    summarySagaWatcher(),
    // add other watchers to the array
  ]);
}
