import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Button from '@material-ui/core/Button';
import PictureAsPdfIcon from '@material-ui/icons/PictureAsPdf';
import Typography from '@material-ui/core/Typography';
// import ReactPDF from '@react-pdf/renderer';
// import { Page, Text, View, Document, StyleSheet, PDFDownloadLink } from '@react-pdf/renderer';

// const styles = StyleSheet.create({
//     page: {
//         flexDirection: 'column',
//     },
//     heading: {
//         color: 'blue',
//         fontSize: 14,
//     },
//     view: {

//     },
//     text: {
//         color: 'black',
//         fontSize: 14,
//     },
//     section: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//         margin: 10,
//         padding: 10,
//         flexGrow: 1
//     }
// });



class Literature extends Component {
    _isMounted = false;

    state = {
        show: true,
        loading: false,
    }

    // MyDocument = () => (
    //     <Document>
    //         <Page orientation='landscape' style={styles.page}>
    //             <View style={styles.section}>
    //                 <View >
    //                     <Text style={styles.heading}>ePCN No.
    //                      <Text style={styles.text}>{this.props.releaseData.externalReleaseId}</Text></Text>
    //                 </View>
    //                 <View>
    //                     <Text style={styles.heading}>Status
    //                     <Text style={styles.text}>{this.props.releaseData.releaseStatus}</Text>
    //                     </Text>
    //                 </View>

    //             </View>
    //         </Page>
    //     </Document>
    // );

    modalCloseHandler = () => {
        this.setState({ show: false })
        this.props.showLiterature()
    }


    componentWillUnmount() {
        this._isMounted = false;
    }
    componentDidMount() {
        this._isMounted = true;
        console.log('mounted' + this.props.releaseData)
    }


    render() {
        let literature = <Modal
            show={this.state.show}
            size='sm'
            modalClosed={this.modalCloseHandler}
            title={"ePCN Id " + this.props.releaseData.externalReleaseId}
        >
            {this.state.loading ? <div style={{ minHeight: '12vh' }}> <Loader /> </div> :
                <React.Fragment>

                    <div style={{
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        marginTop: '4%',
                        minHeight: '12vh'
                    }} >
                        {/* <PDFDownloadLink document={this.MyDocument()} fileName="somename.pdf">
                            {({ blob, url, loading, error }) => (loading ?
                                'Loading document...' : 'Download as Pdf!')}
                        </PDFDownloadLink> */}
                        {/* <Button variant="outlined" color="primary"
                            onClick={() => {
                                ReactPDF.render(<MyDocument />, `example.pdf`);

                            }}
                            style={{
                                textTransform: 'none'
                            }}>
                            <PictureAsPdfIcon style={{
                                marginRight: '10px'
                            }} /> Download as Pdf
                                </Button> */}
                    </div>

                </React.Fragment>

            }
        </Modal>


        return literature

    }

}

export default WithErrorHandler(Literature, axios)