import React, { useState, useEffect, useRef } from 'react';
import { TextField, ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';
import moment from 'moment';
import { DEVICES_LISTS } from './devices-constants';
import axios from '../../../axios-epc';
import MaterialTable, { MTableToolbar } from '@material-table/core';
import { TABLE_CONFIG, THEME_OVERRIDE, TABLE_ICONS } from './devices-config';
import { useSelector } from 'react-redux';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import Modal from '../../../UI/Modal/Modal';
import DerivedData from '../common/Derived';
import ExportButton from '../common/ExportButton';
import UploadButton from '../common/Upload/UploadButton';
import { connect } from 'react-redux';
import { fetchDealCaptureDD } from '../../../store/actions/actionCreators';
import { useDispatch } from 'react-redux';
import { CustomPaginationComponent } from '../common/table-config';
import Dropdown from '../DropDown';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import GetAppIcon from '@material-ui/icons/GetApp';
//import DealCaptureDatePicker from "../../BulkUpload/DealCaptureDP";
import DatePicker from '../../../UI/DatePicker/DatePickerCBU';
// import ExcelJS from "exceljs/dist/es5/exceljs.browser.js";
// import { saveAs } from "file-saver";
import { saveAsExcel } from '../common/utils';
import { Autocomplete } from '@material-ui/lab';
import { objAppendOnUpdate } from '../../../helpers/functions';
import Snackbar from '../../../UI/Snackbar/Snackbar';

const theme = createMuiTheme({
  overrides: THEME_OVERRIDE,
});
const useStyles = (theme) => ({});
const DevicesTable = ({ setLoading, schema, id }) => {
  const dispatch = useDispatch();
  // selectors
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const dropdowns = useSelector((state) => state.dropdownData);
  // States
  const [data, setData] = useState([]);
  const [data2, setData2] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loadingTable, setLoadingTable] = useState(true);
  const [selected, setSelected] = useState();
  const [modalOpen, setModalOpen] = useState(false);
  const [selection, setSelection] = useState([]);
  const selectTable = useRef();
  const [showData, setShowData] = useState([]);
  const [manufacturerData, setManufacturerData] = useState([]);
  const [uniqueData, setUniqueData] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [manufacturerLoaded, setManufacturerLoaded] = useState(false);
  const [uniqueDataLoaded, setUniqueDataLoaded] = useState(false);
  const [openSnack, setOpenSnack] = useState(false);
  const [messageSnack, setMessagesnack] = useState('');

  // Functions
  const noneditable = (rowData) => {
    if (rowData.refName === 'uniqueNumber') {
      return 'never';
      //{(row.refName==='uniqueNumber')?'never':'always'
    }
    if (rowData.refName === 'manufacturer') {
      return 'onAdd';
    }
    if (rowData.refName === 'deviceNumber') {
      return 'onAdd';
    }
    if (
      rowData.refName === 'manufacturer' &&
      rowData.entityName === 'manufacturerTable'
    ) {
      return 'onAdd';
    }
    return 'always';
  };
  const tableValidations = (rowData) => {
    if (!selected) return;
    let shouldReturn = true;
    selected.validations.forEach((row) => {
      if (row.required) {
        if (!rowData[row.name]) {
          shouldReturn = false;
        }
      }
    });
    return shouldReturn;
  };
  // const saveAsExcel = async ({ schema = [], name = "", data = [] }) => {
  //   const workbook = new ExcelJS.Workbook();
  //   const worksheet = workbook.addWorksheet(name);
  //   let sheetColumns = schema.map((row) => ({
  //     header: row.uiName,
  //     key: row.refName,
  //     width: 25,
  //   }));
  //   worksheet.columns = sheetColumns;
  //   data.map((row) => {
  //     worksheet.addRow(row);
  //   });
  //   worksheet.getRow(1).font = { bold: true };
  //   const buf = await workbook.xlsx.writeBuffer();
  //   saveAs(new Blob([buf]), `${name}.xlsx`);
  //   return true;
  // }
  const derivedAction = () => {
    if (selected && selected.name !== 'Manufacturer') {
      return {
        tooltip: 'Show Derived Data',
        icon: CheckBoxIcon,
        onClick: (evt, data) => {
          setModalOpen(true);
        },
      };
    }
  };
  const getUniqueData = () => {
    setLoadingTable(true);
    axios
      .get('/mtn/modification/uniquedata')
      .then((res) => {
        if (res) {
          setUniqueData(res.data.data);
          setUniqueDataLoaded(true);
          // setLoadingTable(false);
        }
      })
      .catch((error) => {});
  };
  const getManufacturerData = () => {
    setLoadingTable(true);
    axios
      .get('/mtn/modification/data')
      .then((res) => {
        if (res) {
          setManufacturerData(res.data.data);
          setManufacturerLoaded(true);
          // setLoadingTable(false);
        }
      })
      .catch((error) => {});
  };
  const getData = () => {
    if (!selected) {
      return Promise.resolve();
    }
    setLoadingTable(true);
    return axios
      .get(selected.GET)
      .then((res) => {
        if (res) {
          const { data } = res.data;
          const mapData = data.map((row) => ({ ...row, tableData: '' }));
          setData(mapData);
        }
        setLoadingTable(false);
      })
      .catch((error) => {
        setLoading(false);
        setLoadingTable(false);
        console.log('err', error);
      });
  };
  const mapColumns = () => {
    let tmpColumns = schema.map((row) => {
      return {
        groupName: row.groupName,
        title: row.uiName,
        field: row.refName,
        validate: tableValidations,
        editable: noneditable(row), //(row.refName==='uniqueNumber')?'never':'always',
        // sorting:(row.refName==='uniqueNumber')?true:false,
        defaultSort: row.refName === 'uniqueNumber' ? 'asc' : 'desc',
        // cellStyle: { width: "30%" },
        render: (rowData) => {
          return (
            row.refName &&
            rowData[row.refName] && (
              <span
                style={{
                  display: 'block',
                  wordBreak: 'break-word',
                  width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                }}
              >
                {' '}
                {rowData[row.refName]}
              </span>
            )
          );
        },

        editComponent: (props) => {
          if (row.refName === 'quarter' && selected.name === 'Device Pricing') {
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '15vw' }}
                  options={
                    dropdowns.Exchangequarters &&
                    dropdowns.Exchangequarters.map((q) => {
                      return q.quarter;
                    })
                  }
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          if (row.refName === 'quarter' && selected.name === 'ASPU') {
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '15vw' }}
                  options={
                    dropdowns.Exchangequarters &&
                    dropdowns.Exchangequarters.map((q) => {
                      return q.quarter;
                    })
                  }
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          if (row.refName === 'monthId') {
            return (
              <div style={{ width: '25vh' }}>
                <DatePicker
                  style={{ width: '15vh' }}
                  value={props.value}
                  onChange={props.onChange}
                />
              </div>
            );
          }

          if (
            row.refName === 'manufacturer' &&
            row.entityName === 'bulkUploadDevices'
          ) {
            console.log(manufacturerData);
            const isSelectRequired = !props.value;
            console.log(props.value);
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '30vw', fontSize: '10px' }}
                  options={manufacturerData}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          if (row.refName === 'deviceNumber') {
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '10vw', fontSize: '10px' }}
                  options={uniqueData.filter((item) => !!item)}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          if (row.refName === 'sim') {
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '10vw' }}
                  options={['SIM0', 'SIM1', 'SIM2']}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          } //Need to Change
          if (row.refName === 'technology') {
            if (!row.refLovs) return '';
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '10vw' }}
                  options={row.refLovs}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          if (row.refName === 'live') {
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '10vw' }}
                  options={row.refLovs}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          if (row.refName === 'currency') {
            console.log(row.refLovs);
            const isSelectRequired = !props.value;
            if (!row.refLovs) return '';
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '10vw' }}
                  options={row.refLovs}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          if (row.refName === 'standardCurrency') {
            console.log(row.refLovs);
            const isSelectRequired = !props.value;
            if (!row.refLovs) return '';
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '10vw' }}
                  options={row.refLovs}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          // if (row.refName === "technology") {
          //   return (
          //     <Autocomplete
          //       style={{ width: "10vw" }}
          //       options={["2G", "3G", "LTE"]}
          //       renderInput={(params) => <TextField {...params} />}
          //       onChange={(event, value) => {
          //         props.onChange(value);
          //       }}
          //     />
          //   );
          // }
          let type = 'text';
          let isRequired = false;
          if (selected.validations) {
            const validation = selected.validations.find(
              (t) => t.name === props.columnDef.field
            );
            if (validation) {
              if (validation.type) {
                type = validation.type;
              }
              isRequired = !!validation.required;
            }
          }
          return (
            <TextField
              // defaultValue={props.value ? props.value : 0}//Ankit
              type={type}
              error={isRequired && !props.value}
              helperText={isRequired && !props.value && 'Required'}
              style={{
                width: '20vw',
                margin: 10,
                fontSize: 12,
              }}
              fullWidth
              value={props.value}
              onChange={(event) => {
                props.onChange(event.target.value);
              }}
            />
          );
        },
      };
    });
    setColumns(tmpColumns);
  };
  // Did Mount
  useEffect(() => {
    getManufacturerData();
    getUniqueData();
    dispatch(fetchDealCaptureDD('Exchangequarters'));
  }, []);
  useEffect(() => {
    if (
      dropdowns.ExchangequartersLoaded &&
      manufacturerLoaded &&
      uniqueDataLoaded
    ) {
      getData().then(() => mapColumns());
    }
  }, [dropdowns, manufacturerLoaded, uniqueDataLoaded]);
  useEffect(() => {
    if (id) {
      const select = DEVICES_LISTS.find((list) => list.id === id);
      setSelected(select);
    }
  }, [id]);
  useEffect(() => {
    if (selected) {
      getData().then(() => mapColumns());
    }
  }, [selected]);
  // Render
  return (
    <ThemeProvider theme={theme}>
      <Snackbar
        open={openSnack}
        message={messageSnack}
        onClose={(event, reason) => {
          if (reason === 'clickaway') {
            return;
          }
          setOpenSnack(false);
        }}
      />
      <Modal
        show={modalOpen}
        modalClosed={() => {
          setModalOpen(false);
        }}
        title={'Derived Data'}
      >
        <DerivedData
          selected={selected}
          columns={columns}
          schema={schema}
          selection={selection}
          identifierPayload={selected && selected.identifierPayload}
          derived={true}
        />
      </Modal>
      <MaterialTable
        style={{ padding: '20px' }}
        tableRef={selectTable}
        isLoading={loadingTable}
        icons={TABLE_ICONS}
        title={`${selected && selected.name}`}
        columns={columns.filter((row) => row.groupName === 'UI Input')}
        data={data}
        options={TABLE_CONFIG}
        actions={[
          derivedAction,
          {
            tooltip: 'Export',
            icon: GetAppIcon,
            onClick: () => {
              saveAsExcel({
                schema: schema.filter((row) => row.groupName === 'UI Input'),
                name: `${selected.name}`,
                data: selectedRows,
              });
            },
          },
          // {
          //   tooltip: "Show Derived Data",
          //   icon: CheckBoxIcon,
          //   onClick: (evt, data) => {
          //     setModalOpen(true);
          //   },
          // },
          {
            icon: () => (
              <UploadButton
                uploadUrl={selected && selected.UPLOAD_URL + userInfo.id}
                valiationUrl={selected && selected.VALIDATION_URL + userInfo.id}
                excelTabName={selected && selected.excelTabName}
                schema={schema.filter((row) => row.groupName === 'UI Input')}
                uploadName={`${selected && selected.name}`}
                title={`${selected && selected.name}`}
                autoCloseOnSuccess={false}
                snackMessageOnSuccess={
                  'Data being Uploaded, Please Check the Validation Logs for Completion and Errors.'
                }
                onClose={() => getData().then(() => setLoadingTable(false))}
                onSuccess={() => null}

                // onSuccess={() =>
                //   getData().then(() => {
                //     setLoadingTable(false);
                //     setOpenSnack(true);
                //     setMessagesnack(
                //       'Data being Uploaded, Please Check the Validation Logs for Completion and Errors.'
                //     );
                //   })
                // }
              />
            ),
            isFreeAction: true,
          },
          {
            icon: () => (
              <ExportButton
                schema={schema.filter((row) => row.groupName === 'UI Input')}
                name={selected && selected.name}
                data={selectTable.current && selectTable.current.state.data}
              />
            ),
            isFreeAction: true,
          },
        ]}
        onSelectionChange={(rowSelection) => {
          console.log(rowSelection);
          if (selected) {
            setSelection(rowSelection.map((r) => r[selected.identifier]));
          }
          setSelectedRows(rowSelection);
        }}
        editable={{
          onBulkUpdate: (changes) =>
            new Promise((resolve, reject) => {
              setTimeout(() => {
                console.log(changes);
                if (Object.keys(changes).length > 0) {
                  let payload = [];
                  setLoadingTable(true);
                  Object.keys(changes).map((row) => {
                    let payloadData = { ...changes[row].newData };
                    const modPayloadData = objAppendOnUpdate(
                      payloadData,
                      userInfo.id,
                      {
                        oldArr: data,
                        identifier: selected.identifier,
                        val: changes[row].newData[selected.identifier],
                      }
                    );
                    payload.push(modPayloadData);
                  });
                  axios
                    // .post(selected.POST, payload)
                    .post(
                      //  selected.name === 'Device' || 'Device Pricing' || 'ASPU'
                      [
                        'Device',
                        'Device Pricing',
                        'ASPU',
                        'Manufacturer',
                      ].includes(selected.name)
                        ? selected.PKG_UPDATE_URL
                        : selected.POST,
                      payload
                    )
                    .then((response) => {
                      getData().then(() => {
                        setLoadingTable(false);
                        setOpenSnack(true);
                        setMessagesnack('Saved Successfully!');
                        resolve();
                      });
                    })
                    .catch((error) => {
                      setLoadingTable(false);
                      resolve();
                    });
                } else resolve();
              }, 1000);
            }),
          onRowAdd: (newData) =>
            new Promise((resolve, reject) => {
              let payload = {
                ...newData,
                createdBy: userInfo.id,
                recordEndDate: '',
                updatedBy: null,
              };
              let aspuResp = [
                {
                  ...newData,
                  monthId: moment(newData.monthId, 'DD-MM-YYYY', true).isValid()
                    ? newData.monthId
                    : moment(newData.monthId).format('DD-MM-YYYY'),
                },
              ];
              console.log(aspuResp);
              setLoadingTable(true);
              console.log(newData);
              console.log('data', data);
              //payload.uniqueNumber ='';
              let arr = [];
              console.log(payload);
              axios
                .post(
                  selected.POST,
                  selected.name === 'ASPU' ? aspuResp : [payload]
                )
                .then((response) => {
                  if (response) {
                    let pkgData = [...data, newData];
                    setData(pkgData);
                    getData().then(() => {
                      setLoadingTable(false);
                      setOpenSnack(true);
                      setMessagesnack('Saved Successfully!');
                      resolve();
                    });
                  }
                  setLoadingTable(false);
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
          onRowUpdate: (newData, oldData) =>
            new Promise((resolve, reject) => {
              let payload = {
                ...newData,
                monthId: moment(newData.monthId, 'DD-MM-YYYY', true).isValid()
                  ? newData.monthId
                  : moment(newData.monthId).format('DD-MM-YYYY'),
              };
              const modPayloadData = objAppendOnUpdate(payload, userInfo.id, {
                oldArr: data,
                identifier: selected.identifier,
                val: payload[selected.identifier],
              });

              console.log(newData);
              setLoadingTable(true);
              axios
                //.post(selected.POST, [payload])	//(selected.name==='devices')?selected.PKG_UPDATE_URL:selected.POST, payload
                .post(
                  // selected.name === 'Device' || 'Device Pricing' || 'ASPU'
                  ['Device', 'Device Pricing', 'ASPU', 'Manufacturer'].includes(
                    selected.name
                  )
                    ? selected.PKG_UPDATE_URL
                    : selected.POST,
                  [modPayloadData]
                )
                .then((response) => {
                  const dataUpdate = [...data];
                  const index = oldData.tableData.id;
                  dataUpdate[index] = newData;
                  setData(dataUpdate);

                  getData().then(() => {
                    setLoadingTable(false);
                    setOpenSnack(true);
                    setMessagesnack('Saved Successfully!');
                    resolve();
                  });
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
        }}
        components={{
          Toolbar: (props) => (
            <div>
              <div
                style={{
                  fontSize: '18px',
                  fontWeight: '600',
                  marginLeft: '24px',
                }}
              >
                {props.title}
              </div>
              <div>
                <MTableToolbar {...props} />
              </div>
            </div>
          ),
          Pagination: (props) => {
            return <CustomPaginationComponent {...props} />;
          },
        }}
        localization={{
          body: {
            emptyDataSourceMessage: '',
          },
        }}
      />
    </ThemeProvider>
  );
};
//export default withStyles(useStyles)(DevicesTable);
export default withStyles(useStyles)(DevicesTable, axios);
