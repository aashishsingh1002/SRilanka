import React, { Component } from "react";
import Button from "@material-ui/core/Button";
import AttachmentIcon from "@material-ui/icons/Attachment";
import { Grid } from "@material-ui/core";
import axios from '../../axios-epc';
import { connect } from 'react-redux';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';

class LibraryReport extends Component {
  _isMounted = false;

  state = {};

  downloadFile = (url,reportName) => {
    this.setState({ loading: true });
    let payload = {};

    return axios
        .get(url, {
            headers: {
                opId: this.props.userInfo.opId,
                
            },
            responseType: 'blob',
        })
        .then((res) => {
            console.log(res);
            console.log(res.data);
            console.log(payload);

            this.setState({ loading: false });
            var headers = res.headers;
            var blob = new Blob([res.data], {
                type: headers['content-type'],
            });

            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = reportName+'.csv';
            link.click();
        })
        .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
        });
};

  render() {
    return (
      <React.Fragment>
        <Grid container>
          <Grid item xs={4}>
            <div
              style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20vh",
              }}
            >
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=DA Offer Id Mapping';
                       
                    this.downloadFile(url,'DA Offer Id Mapping');
                }}
                style={{
                  textTransform: "none",
                  marginRight: 20,
                  width: "320px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "10px",
                  }}
                />{" "}
                DA Offer Id Mapping
              </Button>
            </div>
          </Grid>

          <Grid item xs={4}>
            <div    style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20vh",
              }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=Tac Code';
                       
                    this.downloadFile(url);
                }}
                style={{
                  textTransform: "none",
                  width: "320px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "10px",
                  }}
                />{" "}
                Tac Code
              </Button>
            </div>
          </Grid>

          <Grid item xs={4}>
            <div    style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20vh",
              }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=ISD Country - Country Code';
                       
                    this.downloadFile(url);
                }}
                style={{
                  textTransform: "none",
                  width: "330px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "20px",
                  }}
                />{" "}
                ISD Country - Country Code
              </Button>
            </div>
          </Grid>
        </Grid>


        <Grid container>
          <Grid item xs={4}>
            <div
              style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20px",
              }}
            >
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=VAS Template';
                       
                    this.downloadFile(url);
                }}
                
                style={{
                  textTransform: "none",
                  marginRight: 20,
                  width: "320px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "10px",
                  }}
                />{" "}
                VAS Template
              </Button>
            </div>
          </Grid>

          <Grid item xs={4}>
            <div    style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20px",
              }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=IR Tap Code Master';
                       
                    this.downloadFile(url);
                }}
                style={{
                  textTransform: "none",
                  width: "320px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "10px",
                  }}
                />{" "}
                IR Tap Code Master
              </Button>
            </div>
          </Grid>












          <Grid item xs={4}>
            <div    style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20px",
              }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=Composite Rate Plan';
                       
                    this.downloadFile(url,'Composite Rate Plan');
                }}
                style={{
                  textTransform: "none",
                  width: "330px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "20px",
                  }}
                />{" "}
                Composite Rate Plan
              </Button>
            </div>
          </Grid>
        </Grid>





        <Grid container>
          <Grid item xs={4}>
            <div
              style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20vh",
              }}
            >
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=Construct Guidelines';
                       
                    this.downloadFile(url,'Construct Guidelines');
                }}
                style={{
                  textTransform: "none",
                  marginRight: 20,
                  width: "320px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "10px",
                  }}
                />{" "}
                Construct Guidelines
              </Button>
            </div>
          </Grid>

          <Grid item xs={4}>
            <div    style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20vh",
              }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=Plan Prod Offerability Report';
                       
                    this.downloadFile(url);
                }}
                style={{
                  textTransform: "none",
                  width: "320px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "10px",
                  }}
                />{" "}
                Plan Prod Offerability Report
              </Button>
            </div>
          </Grid>

          <Grid item xs={4}>
            <div    style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20vh",
              }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=Daily EPC Release Report ';
                       
                    this.downloadFile(url);
                }}
                style={{
                  textTransform: "none",
                  width: "330px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "20px",
                  }}
                />{" "}
                Daily EPC Release Report 
              </Button>
            </div>
          </Grid>
        </Grid>

        <Grid container>
          <Grid item xs={4}>
            <div
              style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20px",
              }}
            >
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=Plan Product Account Id  Report';
                       
                    this.downloadFile(url);
                }}
                style={{
                  textTransform: "none",
                  marginRight: 20,
                  width: "320px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "10px",
                  }}
                />{" "}
                Plan Product Account Id  Report
              </Button>
            </div>
          </Grid>

          <Grid item xs={4}>
            <div    style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20px",
              }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=Inactive Account ID Report';
                       
                    this.downloadFile(url);
                }}
                style={{
                  textTransform: "none",
                  width: "320px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "10px",
                  }}
                />{" "}
                Inactive Account ID Report
              </Button>
            </div>
          </Grid>

          <Grid item xs={4}>
            <div    style={{
                display: "flex",
                //justifyContent: "center",
                alignItems: "center",
                minHeight: "20px",
              }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                    const url =
                        'libraryReports/exportCSV?reportName=Daily Federation Relaese Report';
                       
                    this.downloadFile(url);
                }}
                style={{
                  textTransform: "none",
                  width: "330px",
                }}
              >
                <AttachmentIcon
                  style={{
                    marginRight: "20px",
                  }}
                />{" "}
                Daily Federation Relaese Report
              </Button>
            </div>
          </Grid>
        </Grid>




      </React.Fragment>
    );

    return LibraryReport;
  }
}


const mapStateToProps = state => {
    return {
        userInfo: state.login.loggedInUserInfo,
    };
}

// export default LibraryReport;
export default connect(mapStateToProps)(WithErrorHandler(LibraryReport, axios))
