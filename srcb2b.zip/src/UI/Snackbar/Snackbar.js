import React from 'react';
import { Snackbar } from '@material-ui/core';
//import MuiAlert from '@material-ui/lab';
import { Alert } from '@material-ui/lab';

// function Alert(props) {
//   return <MuiAlert elevation={6} variant='filled' {...props} />;
// }

export default function CustomizedSnackbars(props) {
  const vertical = 'top';
  const horizontal = 'center';

  return (
    <Snackbar
      anchorOrigin={{ vertical, horizontal }}
      open={props.open}
      //  autoHideDuration={3000}
      onClose={props.onClose}
    >
      <Alert severity='success' onClose={props.onClose}>
        {props.message}
      </Alert>
    </Snackbar>
  );
}
