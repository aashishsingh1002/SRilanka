// import React, { Component } from "react";
// import WithErrorHandler from "../../../HOC/WithErrorHandler/WithErrorHandler";
// import axios from "../../../axios-epc";
// import Loader from "../../../UI/Loader/Loader";
// import EventAvailableIcon from "@material-ui/icons/EventAvailable";
// import InputAdornment from "@material-ui/core/InputAdornment";
// import TextField from "@material-ui/core/TextField";
// import Grid from "@material-ui/core/Grid";
// import IconButton from "@material-ui/core/IconButton";
// import SearchIcon from "@material-ui/icons/Search";
// import Modal from "../../../UI/Modal/Modal";
// import List from "@material-ui/core/List";
// import Card from "@material-ui/core/Card";
// import CardHeader from "@material-ui/core/CardHeader";
// import CardContent from "@material-ui/core/CardContent";
// import ListItem from "@material-ui/core/ListItem";
// import ListItemIcon from "@material-ui/core/ListItemIcon";
// import ListItemText from "@material-ui/core/ListItemText";
// import Typography from "@material-ui/core/Typography";
// import ExpandMore from "@material-ui/icons/ExpandMore";
// import Divider from "@material-ui/core/Divider";
// import ExpandLess from "@material-ui/icons/ExpandLess";
// import SaveIcon from "@material-ui/icons/Save";
// import { withStyles } from "@material-ui/core/styles";
// import Table from "@material-ui/core/Table";
// import TableBody from "@material-ui/core/TableBody";
// import TableCell from "@material-ui/core/TableCell";
// import TableContainer from "@material-ui/core/TableContainer";
// import TableHead from "@material-ui/core/TableHead";
// import TableRow from "@material-ui/core/TableRow";
// import Paper from "@material-ui/core/Paper";
// // import Button from "@material-ui/core/Button";
// import Button from "../../../UI/Button/Button";
// import moment from "moment";

// const useStyles = (theme) => ({
//   cardHeader: {
//     // background: "#546D7A",
//     // height: "4.5vh",
//   },
//   subheader: {
//     color: "rgba(0, 0, 0, 0.87)",
//     fontSize: "18px",
//     fontWeight: "600",
//     // color: "white",
//     // fontWeight: 'bold'
//   },
//   boldText: {
//     // fontWeight: 'bold'
//   },
//   center: {
//     display: "flex",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   heading: {
//     fontSize: theme.typography.pxToRem(15),
//     flexBasis: "96%",
//     flexShrink: 0,
//   },
//   root: {
//     width: "100%",
//     maxWidth: "99%",
//     backgroundColor: theme.palette.background.paper,
//     position: "relative",
//     overflow: "auto",
//     maxHeight: 300,
//   },
//   listSection: {
//     backgroundColor: "inherit",
//   },
//   ul: {
//     backgroundColor: "inherit",
//     padding: 0,
//   },
// });

// class Events extends Component {
//   _isMounted = false;

//   state = {
//     loading: true,
//     events: [],
//     showEvents: [],
//     show: false,
//     searchEvents: "",
//     showModal: false,
//     modalContent: null,
//   };

//   componentDidMount() {
//     this._isMounted = true;
//     this.getEvents().then(() => {
//       this.getBundledEvent().then(() => {
//         this.setState({
//           loading: false,
//         });
//       });
//     });
//   }

//   getBundledEvent() {
//     return axios
//       .get(
//         "package/events?id=" +
//           this.props.id +
//           "&releaseId=" +
//           this.props.releaseData.releaseId,
//         {
//           headers: {
//             opId: this.props.userInfo.opId,
//           },
//         }
//       )
//       .then((res) => {
//         console.log(res);
//         this.setState({
//           selEvent: res.data.data.eventId,
//         });
//       })
//       .catch((error) => {
//         console.log(error);
//         if (this._isMounted) this.setState({ loading: false });
//       });
//   }

//   getEvents = () => {
//     return axios
//       .get(
//         "attribute/event/list?releaseId=" + this.props.releaseData.releaseId,
//         {
//           headers: {
//             opId: this.props.userInfo.opId,
//           },
//         }
//       )
//       .then((res) => {
//         console.log(res);
//         let events = [];
//         Object.keys(res.data.data).map((event) => {
//           events.push({
//             val: event + "/" + res.data.data[event],
//             show: false,
//             content: [],
//           });
//         });
//         this.setState({
//           events: events,
//           showEvents: events,
//         });
//       })
//       .catch((error) => {
//         console.log(error);
//         if (this._isMounted) this.setState({ loading: false });
//       });
//   };

//   modalCloseHandler = () => {
//     this.setState({
//       show: false,
//     });
//   };

//   searchHandler = (event) => {
//     this.setState({ searchEvents: event.target.value });
//     let searchItems = [];
//     if (event.target.value.length == 0) {
//       searchItems = [...this.state.events];
//       this.setState({ showEvents: searchItems });
//     } else {
//       searchItems = this.state.events.filter(function (item) {
//         return item.val
//           .toUpperCase()
//           .includes(event.target.value.toUpperCase());
//       });
//       this.setState({ showEvents: searchItems });
//     }
//   };

//   eventDetails(item) {
//     console.log(item);
//     let showItem = !item.show;
//     if (!item.show) {
//       axios
//         .get(
//           "attribute/event/basicDetails?releaseId=" +
//             this.props.releaseData.releaseId +
//             "&eventId=" +
//             item.val.split("/")[0],
//           {
//             headers: {
//               opId: this.props.userInfo.opId,
//             },
//           }
//         )
//         .then((res) => {
//           console.log(res.data.data);
//           this.setState({ loading: false });
//           this.setState({
//             showEvents: this.state.showEvents.map((el) =>
//               el.val === item.val
//                 ? {
//                     ...el,
//                     show: showItem,
//                     content: res.data.data.paramDetailsVo,
//                   }
//                 : el
//             ),
//           });
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     } else
//       this.setState({
//         showEvents: this.state.showEvents.map((el) =>
//           el.val === item.val
//             ? {
//                 ...el,
//                 show: showItem,
//               }
//             : el
//         ),
//       });
//   }

//   saveEvent = () => {
//     if (this.props.id) {
//       this.setState({ loading: true });
//       let payload = {};
//       let date = moment().format("DD-MMM-YY");
//       payload.itemId = this.props.id;
//       payload.releaseId = this.props.releaseData.releaseId;
//       payload.itemType = this.props.entity;
//       payload.eventId = this.state.selEvent;
//       payload.createdBy = this.props.userInfo.id;
//       payload.createdDate = date;
//       payload.startDate = date;
//       payload.endDate = "30-Dec-30";
//       payload.opId = this.props.userInfo.opId;
//       payload.buId = this.props.userInfo.buId;
//       console.log(payload);
//       axios
//         .post("package/events", payload)
//         .then((response) => {
//           console.log(response);
//           this.setState({
//             productComponentId: response.data.data,
//             loading: false,
//           });
//         })
//         .catch((error) => {
//           console.log(error);
//           if (this._isMounted) this.setState({ loading: false });
//         });
//     } else {
//       let modalContent = (
//         <Typography variant="h6">
//           {" "}
//           Submit Basic {this.props.entity} Details first on General screen.{" "}
//         </Typography>
//       );
//       this.setState({ modalContent: modalContent, showModal: true });
//     }
//   };

//   errorConfirmedHandler = () => {
//     this.setState({ showModal: false });
//   };

//   render() {
//     const { classes, access } = this.props;
//     const isDisabled = access && access === "R";

//     let events = (
//       <div style={{ width: "100%" }}>
//         <Modal
//           show={this.state.showModal}
//           modalClosed={this.errorConfirmedHandler}
//           title={"Something Went Wrong!"}
//         >
//           {this.state.modalContent}
//         </Modal>
//         <Modal
//           show={this.state.show}
//           modalClosed={this.modalCloseHandler}
//           title={"Rules"}
//         >
//           <List style={{ width: "100%", maxHeight: "30vh", overflow: "auto" }}>
//             <TextField
//               onChange={this.searchHandler}
//               fullWidth
//               value={this.state.searchEvents}
//               InputProps={{
//                 startAdornment: (
//                   <InputAdornment position="start">
//                     <SearchIcon style={{ color: "#3f74c5" }} />
//                   </InputAdornment>
//                 ),
//               }}
//             />
//             {this.state.showEvents.length > 0 ? (
//               this.state.showEvents.map((event) => {
//                 return (
//                   <React.Fragment>
//                     <ListItem key={event}>
//                       <ListItemIcon className={classes.navIcon}>
//                         {event.show ? (
//                           <ExpandLess
//                             style={{ cursor: "pointer" }}
//                             onClick={() => this.eventDetails(event)}
//                           />
//                         ) : (
//                           <ExpandMore
//                             style={{ cursor: "pointer" }}
//                             onClick={() => this.eventDetails(event)}
//                           />
//                         )}
//                       </ListItemIcon>
//                       <ListItemText
//                         style={{ cursor: "pointer" }}
//                         onClick={() => this.eventDetails(event)}
//                         primary={event.val}
//                       />
//                       <SaveIcon
//                         style={{ cursor: "pointer", color: "green" }}
//                         onClick={() => {
//                           this.setState({
//                             selEvent: event.val.split("/")[0],
//                           });
//                         }}
//                       />
//                     </ListItem>
//                     {event.show && (
//                       <TableContainer
//                         component={Paper}
//                         style={{ marginTp: "3vh" }}
//                       >
//                         <Table className={classes.table} size="small">
//                           <TableHead>
//                             <TableRow>
//                               <TableCell>Applied On</TableCell>
//                               <TableCell>Id</TableCell>
//                               <TableCell>Value</TableCell>
//                             </TableRow>
//                           </TableHead>
//                           <TableBody>
//                             {event.content.map((obj) => {
//                               return (
//                                 <TableRow key={obj.attributeId}>
//                                   <TableCell
//                                     style={{
//                                       width: "20%",
//                                     }}
//                                   >
//                                     {obj.attrName}
//                                   </TableCell>
//                                   <TableCell
//                                     style={{
//                                       width: "30%",
//                                     }}
//                                   >
//                                     {obj.attributeId}
//                                   </TableCell>
//                                   <TableCell
//                                     style={{
//                                       width: "30%",
//                                     }}
//                                   >
//                                     {obj.attrValue}
//                                   </TableCell>
//                                 </TableRow>
//                               );
//                             })}
//                           </TableBody>
//                         </Table>
//                       </TableContainer>
//                     )}

//                     <Divider />
//                   </React.Fragment>
//                 );
//               })
//             ) : (
//               <Typography
//                 variant="h6"
//                 className={classes.center}
//                 style={{
//                   marginTop: "1.5%",
//                 }}
//               >
//                 {" "}
//                 No Rules Found.
//               </Typography>
//             )}
//           </List>
//         </Modal>

//         <Card>
//           <CardHeader
//             className={classes.cardHeader}
//             classes={{
//               subheader: classes.subheader,
//             }}
//             subheader={"Rules"}
//           />

//           <CardContent>
//             <Grid container spacing={1} alignItems="flex-end">
//               <Grid item sm={4}>
//                 <TextField
//                   onChange={this.searchHandlerUpgrade}
//                   disabled
//                   fullWidth
//                   value={this.state.selEvent}
//                   InputProps={{
//                     startAdornment: (
//                       <InputAdornment position="start">
//                         <EventAvailableIcon style={{ color: "orange" }} />
//                       </InputAdornment>
//                     ),
//                   }}
//                 />
//               </Grid>
//               {/* <Grid item xs={1}>
//                 <IconButton
//                   disabled={isDisabled}
//                   onClick={() => {
//                     this.setState({
//                       show: true,
//                     });
//                   }}
//                 >
//                   <SearchIcon />
//                 </IconButton>
//               </Grid> */}
//             </Grid>
//           </CardContent>
//         </Card>
//       </div>
//     );
//     if (this.state.loading) events = <Loader />;

//     return events;
//   }
// }

// export default withStyles(useStyles)(WithErrorHandler(Events, axios));
