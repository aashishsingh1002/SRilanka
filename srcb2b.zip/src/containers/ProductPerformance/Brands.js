import React, { Component } from 'react';
import { Pie } from "react-chartjs-2";


class Brands extends Component {

    state = {
        data: [
            {
                packageId: "PKG_1",
                packageName: "Test 1",
                description: "Test 1",
                brand: "Infinity",
                subscriber: [20, 10, 30, 50, 10, 10, 40, 33, 21, 50, 10, 30],
                revenue: [1, 5, 5, 30, 2, 2, 15, 5, 4, 10, 5, 8],
            },
            {
                packageId: "PKG_2",
                packageName: "Test 2",
                description: "Test 2",
                brand: "Infinity family",
                subscriber: [10, 40, 33, 21, 50, 13, 31, 10, 22, 51, 40, 33],
                revenue: [2, 15, 20, 10, 23, 40, 15, 2, 3, 21, 15, 20],
            },
            {
                packageId: "PKG_3",
                packageName: "Test 3",
                description: "Test 3",
                brand: "Infinity",
                subscriber: [13, 31, 10, 22, 51, 62, 111, 110, 150, 52, 13, 31],
                revenue: [4, 6, 2, 3, 7, 30, 25, 30, 34, 12, 4, 5],
            },
            {
                packageId: "PKG_4",
                packageName: "Test 4",
                description: "Test 4",
                brand: "Hotspot & Dongle",
                subscriber: [62, 111, 110, 150, 52, 220, 120, 130, 250, 245, 62, 111],
                revenue: [30, 55, 60, 80, 20, 101, 53, 60, 130, 142, 30, 55],
            },
            {
                packageId: "PKG_5",
                packageName: "Test 5",
                description: "Test 5",
                brand: "Advance Retail",
                subscriber: [220, 120, 130, 250, 245, 62, 111, 110, 150, 52, 13, 31],
                revenue: [101, 53, 60, 130, 142, 30, 55, 60, 80, 20, 40, 15],
            },
            {
                packageId: "PKG_6",
                packageName: "Test 6",
                description: "Test 6",
                brand: "Infinity",
                subscriber: [20, 10, 30, 50, 5, 10, 40, 33, 21, 50, 10, 30],
                revenue: [10, 5, 20, 30, 2, 2, 15, 20, 10, 23, 5, 20],
            },
            {
                packageId: "PKG_7",
                packageName: "Test 7",
                description: "Test 7",
                brand: "Advance Retail",
                subscriber: [10, 40, 33, 21, 50, 13, 31, 10, 22, 51, 40, 33],
                revenue: [2, 15, 20, 10, 23, 40, 15, 2, 3, 21, 15, 20],
            },
            {
                packageId: "PKG_8",
                packageName: "Test 8",
                description: "Test 8",
                brand: "Infinity family",
                subscriber: [20, 10, 30, 50, 10, 10, 40, 33, 21, 50, 10, 30],
                revenue: [3, 6, 6, 30, 4, 4, 15, 6, 6, 10, 7, 8],
            }
        ],
        piedata: {
            datasets: [
                {
                    label: [
                        "Infinity",
                        "Infinity family",
                        "Hotspot & Dongle",
                        "Advance Retail"
                    ],
                    data: [3, 2, 1, 2],
                    backgroundColor: ["#edc24c", "#fc944e", "#bbeb54", "#54ebaf"]
                }
            ],
            labels: [
                "Infinity",
                "Infinity family",
                "Hotspot & Dongle",
                "Advance Retail"
            ]
        },
        options: {}
    }
    componentDidMount() {
        let options = {
            maintainAspectRatio: false,
            onClick:  (evt, item) => {
                let subscriber = [];
                let revenue = [];
                let sumSubscriber = [];
                let sumRevenue = [];
                let obj = {};
                this.state.data.map(Package => {
                    if (Package.brand == item[0]._model.label) {
                        subscriber.push(Package.subscriber);
                        revenue.push(Package.revenue);
                    }
                });
                sumSubscriber = subscriber.reduce(
                    (r, a) => a.map((b, i) => (r[i] || 0) + b),
                    []
                );
                sumRevenue = revenue.reduce(
                    (r, a) => a.map((b, i) => (r[i] || 0) + b),
                    []
                );
                obj.subscriber = sumSubscriber;
                obj.revenue = sumRevenue;
                obj.brand = item[0]._model.label
                this.props.click(obj)
            }
        }
        this.setState({
            options: options
        })
    }
    render() {
        return <Pie
            data={{
                labels: this.state.piedata.labels,
                datasets: this.state.piedata.datasets
            }}
            options={this.state.options}
            height="70%" />
    }

}


export default Brands;