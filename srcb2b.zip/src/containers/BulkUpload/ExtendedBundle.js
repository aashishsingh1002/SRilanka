import React, { Component } from 'react';
import moment from 'moment';
import axios from 'axios';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import { connect } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';
import Button from '../../UI/Button/Button';
import { Multiselect } from 'multiselect-react-dropdown';
import { Picky } from 'react-picky';
import TextField from '@material-ui/core/TextField';
import Modal from '../../UI/Modal/Modal';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableBody from '@material-ui/core/TableBody';
import TableHead from '@material-ui/core/TableHead';
import Table from '@material-ui/core/Table';
import Input from '../../UI/Input/Input';
import Loader from '../../UI/Loader/Loader';
import MaterialTable from '@material-table/core';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import SaveAlt from '@material-ui/icons/SaveAlt';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import Search from '@material-ui/icons/Search';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { Link, Router, Route, hashHistory } from 'react-router';
import { withRouter } from 'react-router-dom';
import { fetchDealCaptureDD } from '../../store/actions/actionCreators';
import styled from 'styled-components';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import { Divider } from '@material-ui/core';

// const Select = styled(Picky)`
// .picky__input{
//   margin:1em 0 1em 0
// }

// `;
const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
  CheckBoxIcon: forwardRef((props, ref) => (
    <CheckBoxIcon {...props} ref={ref} />
  )),
};

const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4.5vh',
  },
  subheader: {
    color: 'white',
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
  table: {
    minWidth: 650,
  },
});
class ExtendedBundle extends Component {
  _isMounted = true;
  state = {
    dealData: '',
    modalOpen: false,
    profileName: [],
    promoPlanName: '',
    contractValue: [],
    loading: true,
    dealExtensionData: [],
    extendedDealData: [],
    version: '',
    schema: [],
    contract: [
      { contract: '4' },
      { contract: '5' },
      { contract: '6' },
      { contract: '8' },
      { contract: '12' },
    ],
    flag: null,
  };
  navigate = () => {
    this.props.history.push('/ilulaDeals');
  };
  navigateBack = () => {
    this.props.history.push('/bulkUploadDealCapture');
  };
  handleProfileName = (event) => {
    this.setState({
      profileName: event,
    });
  };
  handleFlag = (event) => {
    this.setState({
      flag: event,
      profileName: [],
    });
  };
  handleContract = (event) => {
    this.setState({ contractValue: event });
  };
  handlePromoPlanName = (event) => {
    console.log(event);
    this.setState({ promoPlanName: event.target.value });
  };

  handleOpen() {
    this.setState({ modalOpen: true });
  }
  handleClose = () => {
    this.setState({ modalOpen: false });
  };
  componentWillUnmount() {
    this._isMounted = false;
  }

  constructor(props) {
    super(props);
    this.selectTable = React.createRef();
  }
  async saveAsExcel() {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Deal Extension');
    let sheetColumns = [];
    this.state.schema.forEach((row) => {
      console.log('row', row);

      sheetColumns.push({
        header: row.uiName,
        key: row.refName,
        width: 25,
      });
    });

    worksheet.columns = sheetColumns;

    this.selectTable.current.state.data.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), 'Deal Extension.xlsx');
  }

  componentDidMount() {
    this.getDealData().then(() => {
      this.versions().then(() => {
        this.uiFields().then(() => {
          this.getProfileData().then(() => {
            {
              console.log(this.state.schema);
            }
            let columns = this.state.schema.map((row) => {
              return {
                title: row.uiName,
                field: row.refName,
                sorting: false,
                cellStyle: { width: '20%' },
                render: (rowData) => {
                  return (
                    row.refName &&
                    rowData[row.refName] && (
                      <span
                        style={{
                          display: 'block',
                          width: row.maxlength ? row.maxlength + 'vw' : '10vw',
                        }}
                      >
                        {' '}
                        {rowData[row.refName]}
                      </span>
                    )
                  );
                },
              };
            });
            console.log(columns);
            this.setState({ columns, loading: false });
          });
        });
      });
    });
  }
  getDealData() {
    return axios
      .get(
        process.env.REACT_APP_URL +
          `mtn/deal/basicInfo/LeadDealsOnly?releaseId=${this.props.releaseData.releaseId}`
      )
      .then((res) => {
        this.setState({ dealData: res.data.data });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  getUcIdLocalStorage() {
    let UcIdLc = localStorage.getItem('UcId');

    const lcProfileData = localStorage.getItem('edProfileData');
    const edProfileData = lcProfileData ? JSON.parse(lcProfileData) : {};

    if (UcIdLc === edProfileData.UcId) {
      const localData = {
        profileName: edProfileData.name || [],
        contractValue: edProfileData.contract || [],
        flag: edProfileData.flag || [],
      };

      this.setState({
        setUcId: localStorage.getItem('UcId'),
        ...localData,
      });
    } else {
      const localData = {
        profileName: [],
        contractValue: [],
        flag: [],
      };

      this.setState({
        setUcId: localStorage.getItem('UcId'),
        ...localData,
      });
    }
  }
  versions() {
    return axios
      .get(
        process.env.REACT_APP_URL + 'config/version?entityName=extendDeals',
        {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        }
      )

      .then((res) => {
        this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  saveProfileData = (event) => {
    event.preventDefault();
    let requestAdd = {};
    console.log(this.props.releaseData);
    console.log(this.props.releaseData.promoPlanName);
    console.log(this.state.contractValue);
    requestAdd.name = this.state.profileName;
    requestAdd.releaseId = this.props.releaseData.releaseId;
    requestAdd.promoPlanname = this.state.promoPlanName;
    requestAdd.contract = this.state.contractValue;
    requestAdd.type = 'Bundle';
    console.log(requestAdd);
    this.setState({ loadingTable: true });
    axios
      .post(process.env.REACT_APP_URL + 'mtn/edprofile', requestAdd)
      .then((response) => {
        console.log('response', JSON.stringify(response));
        axios //Ankit
          .post(
            'deploy/IlulaDeals?releaseId=' + this.props.releaseData.releaseId,
            {}
          )
          .then((response) => {
            console.log(response);
            this.setState({
              loadingTable: false,
            });
          })
          .catch((error) => {
            console.log(error);
            this.setState({
              loadingTable: false,
            });
          });
        console.log(response);
        this.setState({
          loadingTable: false,
        });
      })
      .catch((error) => {
        console.log(error);
        this.setState({
          loadingTable: false,
        });
      });
  };
  uiFields() {
    if (
      localStorage.getItem('extendDeals') &&
      localStorage.extendDeals_version &&
      localStorage.extendDeals_version == this.state.extendDeals
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem('extendDeals')),
        });
      } catch (e) {
        localStorage.removeItem('extendDeals');
      }
      return Promise.resolve();
    } else {
      return axios
        .get(process.env.REACT_APP_URL + 'config?entityName=extendDeals', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          let schema = [];
          schema = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted) this.setState({ schema: schema });
          localStorage.setItem('extendDeals', JSON.stringify(schema));
          localStorage.extendDeals_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  getExtendedDealData(dealId) {
    return axios
      .get(
        process.env.REACT_APP_URL +
          'mtn/edprofile/extenddeal?releaseId=' +
          this.props.releaseData.releaseId,
        {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            ucId: this.props.data,
          },
        }
      )
      .then((res) => {
        console.log(res);
        if (res) {
          this.setState({
            extendedDealData: res.data.data.map((row) => {
              return { ...row, tableData: '' };
            }),
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  getProfileData() {
    return axios
      .get(process.env.REACT_APP_URL + 'mtn/deal/basicInfo/basepkg')
      .then((res) => {
        console.log(res);
        if (res) {
          this.setState({
            dealExtensionData: res.data.data,
            // .map((row) => {
            //   return row.PACKAGE1;
            // }),
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  render() {
    console.log(this.props.data);
    console.log(this.state.dealExtensionData);
    //     let ratePlan = <Card style={{ overflow: 'visible' }}>
    //     <CardHeader
    //         className={classes.cardHeader}
    //         classes={{
    //             subheader: classes.subheader,
    //         }}
    //         action={
    //             this.props.releaseData.releaseId &&
    //             <React.Fragment>
    //                 <div>

    //                     <LightTooltip title='Back To Deal Capture' arrow>

    //                         <LastPageIcon onClick={this.backToDealCapture}
    //                             style={{ color: 'white', cursor: 'pointer' }} />
    //                     </LightTooltip>

    //                 </div>
    //             </React.Fragment>
    //         }
    //         subheader={this.props.releaseData.releaseId ? "Deal Extension You are inside release " + this.props.releaseData.releaseId : 'Rate Plan Configuration'} />

    //     <CardContent>
    //         <div>Type</div>
    //         <RadioGroup row aria-label="position" name="position"
    //             value={this.state.typeRatePlan}
    //             onChange={(event) => {
    //                 this.setState({
    //                     typeRatePlan: event.target.value
    //                 })
    //             }}
    //             style={{ marginBottom: '2%' }}
    //         >
    //             <FormControlLabel
    //                 value={'profile'} control={<Radio style={{ color: '#3f74c5' }} />} label="Profile"
    //             />
    //             <FormControlLabel
    //                 value="bundle" control={<Radio style={{ color: '#3f74c5' }} />} label="Bundle"
    //             />
    //         </RadioGroup>

    //         <Box mt={2} >
    //             {ratePlanComponent}

    //         </Box>
    //     </CardContent>
    // </Card>
    const { classes } = this.props;

    let filterFlag = null;
    if (this.state.flag) {
      if (this.state.flag === 'M2M Price Plan') {
        filterFlag = 'Y'; // only 1 selectable
      } else if (this.state.flag === 'Normal Price Plan') {
        filterFlag = 'N'; // disable 1
      }
    }

    let contractList = [];
    if (this.state.flag) {
      if (this.state.flag === 'M2M Price Plan') {
        contractList = ['1']; // only 1 selectable
      } else if (this.state.flag === 'Normal Price Plan') {
        contractList = ['3', '6', '12', '18', '24', '36']; // disable 1
      }
    }

    let extendedData = (
      <div>
        <form onSubmit={this.saveProfileData}>
          {/* <Input
                      
                       
                        size={6}
                        required={true}
                        value={this.state.profileName}
                        refType="SelectInput"

                        uiName="Profile Name"
                        refLovs={this.state.profileName}
                        changed={(event) => {
                                console.log(event)
                                this.setState({
                                    profileName:event
                                })
                            
                           
                            }
                        }
                    /> */}

          <div style={{ display: 'flex', marginBottom: '16px' }}>
            <div style={{ width: '240px' }}>
              <label style={{ display: 'block', marginBottom: '0.5em' }}>
                MTM Flag
              </label>
              <Picky
                disabled={this.state.dealData === 'N' ? true : false}
                id='picky'
                options={['M2M Price Plan', 'Normal Price Plan']}
                value={this.state.flag}
                onChange={this.handleFlag}
                dropdownHeight={400}
              />
            </div>
            <div style={{ width: '240px', marginLeft: '16px' }}>
              <label style={{ display: 'block', marginBottom: '0.5em' }}>
                Package Profile{' '}
              </label>
              {/*         
           <Select
                        onChange={(event) => {
                          this.props.onChange(event.target.value);
                        }}
                      >
                        {this.props.dropdowns.basepkg.map(({ PACKAGE1 }) => (
                          <MenuItem value={PACKAGE1}>{PACKAGE1}</MenuItem>
                        ))}
                      </Select> */}
              <Picky
                disabled={this.state.dealData === 'N' ? true : false}
                id='picky'
                options={this.state.dealExtensionData
                  .filter((pkg) => {
                    if (filterFlag) {
                      return filterFlag === pkg.MTM_FLAG;
                    }
                    return false;
                  })
                  .map(({ PACKAGE1 }) => PACKAGE1)}
                value={this.state.profileName}
                multiple={true}
                includeSelectAll={true}
                includeFilter={true}
                onChange={this.handleProfileName}
                dropdownHeight={400}
              />
            </div>
            <div style={{ width: '240px', marginLeft: '16px' }}>
              <label style={{ display: 'block', marginBottom: '0.5em' }}>
                Contract
              </label>

              <Picky
                id='picky'
                disabled={this.state.dealData === 'N' ? true : false}
                options={contractList}
                value={
                  this.state.flag === 'M2M Price Plan'
                    ? 1
                    : this.state.contractValue
                }
                multiple={true}
                includeSelectAll={true}
                includeFilter={true}
                onChange={this.handleContract}
                dropdownHeight={400}
              />
            </div>
          </div>

          {/* <div>Promo Plan Name</div>
        <TextField
          style={{ minWidth: "20%" }}
          placeholder=""
          type="text"
          value={this.state.promoPlanName}
          onChange={
          this.handlePromoPlanName}
          required={true}
        />  */}

          <div style={{ textAlign: 'right' }}>
            <Button
              style={{ padding: '6px 40px', marginLeft: '8px' }}
              type='submit'
              className={classes.btn}
              type='submit'
            >
              Save
            </Button>
            <Button
              style={{ padding: '6px 40px', marginLeft: '8px' }}
              onClick={() => {
                this.handleOpen();
                this.getExtendedDealData();
              }}
            >
              Extended Deals
            </Button>
          </div>
        </form>
        <Divider style={{ margin: '16px 0' }} />
        <div>
          <div style={{ textAlign: 'right' }}>
            {/* <Button
              variant="contained"
              style={{
                background: "#C46C08",
                marginTop: "3%",
                color: "#fff",
                marginRight: "3%",
              }}
              type="submit"
              className={classes.btn}
              onClick={() => {
                this.handleOpen();
                this.getExtendedDealData();
              }}
            >
              Extended Deals
            </Button> */}
            <Button
              style={{
                padding: '6px 40px',
                marginLeft: '8px',
                background: '#fff',
                border: '2px solid #ffcc00',
              }}
              type='submit'
              onClick={this.navigateBack.bind(this)}
            >
              Back
            </Button>
            <Button
              style={{
                padding: '6px 40px',
                marginLeft: '8px',
              }}
              type='submit'
              onClick={this.navigate.bind(this)}
            >
              Next
            </Button>
          </div>
          <div></div>
        </div>
        <div>
          <Modal
            show={this.state.modalOpen}
            modalClosed={this.handleClose}
            title={'Deal Extension Data'}
          >
            <MaterialTable
              tableRef={this.selectTable}
              isLoading={this.state.loadingTable}
              icons={tableIcons}
              title={'Deal Extension'}
              columns={this.state.columns}
              data={this.state.extendedDealData}
              actions={[
                {
                  icon: () => (
                    <Button
                      variant='contained'
                      style={{
                        marginLeft: '20px',
                        background: '#546D7A',
                        color: 'white',
                        textTransform: 'none',
                      }}
                      onClick={() => {
                        this.saveAsExcel();
                      }}
                    >
                      <SaveAlt style={{ marginRight: '10px' }} />
                      Export
                    </Button>
                  ),
                  isFreeAction: true,
                },
              ]}
              options={{
                search: false,
                paging: true,
                toolbar: true,
                rowStyle: {
                  fontSize: '15px',
                  padding: 8,
                },
                headerStyle: {
                  fontWeight: 'bold',
                },
              }}
            />

            {/* <TableContainer component={Paper}>
              {console.log(this.state.columns)}
              <Table
                className={classes.table}
                size="small"
                aria-label="a dense table"
              >
                 <TableHead>
                     
                  <TableRow>
                    {this.state.schema.map((x) => (
                      <TableCell align="right">{x.uiName}</TableCell>
                    ))}
                  </TableRow>
                </TableHead> 
                <TableBody>
                    {console.log(this.state.extendedDealData)}
                  {this.state.extendedDealData.map((row) => (
                    <TableRow key={row.name}>
                      {this.state.schema.map((x) => (
                        <TableCell align="right">{row[x.refName]}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>  */}
          </Modal>
        </div>
      </div>
    );
    if (this.state.loadingTable) extendedData = <Loader />;
    return extendedData;
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    fetchDealCaptureDD: (req) => dispatch(fetchDealCaptureDD(req)),
  };
};
const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
    data: state.dealCaptureData.ucIdData.toString(),
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(withRouter(ExtendedBundle), axios)));
