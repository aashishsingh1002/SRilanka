import React, { Component } from 'react';
import { Line } from "react-chartjs-2";
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { Fade } from "react-awesome-reveal";

class Brands extends Component {

    state = {
        linedata: {},
        options: {
            maintainAspectRatio: false,
            responsive: true,
            legend: {
                display: false
            },
            tooltips: {
                callbacks: {
                    label: function (tooltipItems, data) {
                        return (
                            "Subscriber " +
                            data.datasets[0].data[tooltipItems.index] +
                            ",Revenue " +
                            data.datasets[1].data[tooltipItems.index] +
                            ",Arpu " +
                            (
                                (data.datasets[1].data[tooltipItems.index] /
                                    data.datasets[0].data[tooltipItems.index]) *
                                100
                            ).toFixed(2)
                        );
                    }
                }
            },
            scales: {
                yAxes: [
                    {
                        type: "linear",
                        display: true,
                        position: "left",
                        id: "y-axis-1",
                        scaleLabel: {
                            display: true,
                            labelString: "Subscriber(In Thousands)",
                            fontColor: "blue"
                        },
                        ticks: {
                            fontColor: "blue",
                            fontSize: 14
                        }
                    },
                    {
                        type: "linear",
                        display: true,
                        position: "right",
                        id: "y-axis-2",
                        scaleLabel: {
                            display: true,
                            labelString: "Revenue(In Lakhs)",
                            fontColor: "green"
                        },
                        ticks: {
                            fontColor: "green",
                            fontSize: 14
                        }
                    }
                ],
                xAxes: [
                    {
                        scaleLabel: {
                            display: true,
                            labelString: "Year-2019"
                        }
                    }
                ]
            }
        }
    }
    componentDidMount() {

        let linedata = {
            labels: [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            ],
            datasets: [
                {
                    label: "North",
                    backgroundColor: "blue",
                    borderColor: "lightblue",
                    fill: false,
                    lineTension: 0,
                    radius: 5,
                    yAxisID: "y-axis-1",
                    data: this.props.data.subscriber
                },
                {
                    label: "East",
                    backgroundColor: "green",
                    borderColor: "lightgreen",
                    fill: false,
                    lineTension: 0,
                    radius: 5,
                    yAxisID: "y-axis-2",
                    data: this.props.data.revenue

                }
            ]
        }

        this.setState({
            linedata: linedata
        })

    }
    render() {
        return <React.Fragment>
            <Fade top>
                <Grid container alignContent="flex-end" spacing={2} style={{ marginBottom: '2vh' }}>
                    <Grid item xs={9} style={{
                        display: 'flex',
                        alignItems: 'center'
                    }}>
                        <div style={{ cursor: 'pointer' }} onClick={this.props.click} >

                            <ArrowBackIcon />
                        </div>
                    </Grid>
                    <Grid item xs={3} style={{
                        textAlign: 'right'
                    }}>
                        {this.props.data.packageId ? < Typography variant="subtitle1" >
                            {this.props.data.packageId + ' : ' + this.props.data.recommendation}
                        </Typography>
                            : < Typography variant="subtitle1" >
                                {this.props.data.brand}
                            </Typography>}
                    </Grid>
                </Grid>
                <Line
                    data={this.state.linedata}
                    options={this.state.options}
                    height="350%" />
            </Fade>
        </React.Fragment>
    }

}


export default Brands;