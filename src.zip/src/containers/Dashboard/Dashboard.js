import React, { Component } from 'react';
import Releases from './Releases';
import Attachment from './Attachment';
import AuditLogs from './AuditLogs';
import Workflow from './Workflow';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import { connect } from 'react-redux';
import Loader from '../../UI/Loader/Loader';
import axios from 'axios';
import Literature from './Literature';

class Dashboard extends Component {
    _isMounted = false;

    state = {
        literature: false,
        attachment: false,
        auditLogs: false,
        workflow: false,
        relData: {},
        approversVersion: '',
        approversData: {},
        loading: false,
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidMount() {
        console.log('dashboard mounted')
        this._isMounted = true;
        if (this._isMounted)
            this.setState({ loading: true })
        this.approversDataHandler().then(() => {
            if (this._isMounted)
                this.setState({ loading: false })
            console.log(this.state.approversData)
            let approversData = { ...this.state.approversData }
            let sortedApproverData = {}
            Object.keys(approversData).map(approver => {
                sortedApproverData[approver] = approversData[approver]
                    .sort((a, b) => (a.disabled < b.disabled) ? 1 : ((b.disabled < a.disabled) ? -1 : 0));
            })
            console.log(sortedApproverData)

            let order = Object.keys(sortedApproverData).sort(function (a, b) {
                console.log(sortedApproverData[a][0].order)
                console.log(sortedApproverData[b][0].order)
                console.log(sortedApproverData[a][0].order > sortedApproverData[b][0].order)
                return sortedApproverData[a][0].order < sortedApproverData[b][0].order ? -1 :
                    sortedApproverData[a][0].order > sortedApproverData[b][0].order ? 1 : 0;
            })


            console.log(order)

            let finalSortedApproverData = {}
            order.map(approver => {
                finalSortedApproverData[approver] = sortedApproverData[approver]
            })
            console.log(finalSortedApproverData)
            this.setState({
                approversData: finalSortedApproverData
            })

        })
    }

    approversDataHandler() {

        console.log("fetching from api");
        return axios
            .get(process.env.REACT_APP_URL + "SelectApprovers/approver", {
                headers: {
                    opId: this.props.userInfo.opId,
                    buId: this.props.userInfo.buId,
                    lob: "Postpaid",
                    authUserId: this.props.userInfo.id,
                    Authorization: 'Bearer ' + this.props.userInfo.jwt
                }
            })
            .then(res => {
                console.log(res)
                let approvalData = res.data.data;
                if (this._isMounted)
                    this.setState({ approversData: { ...approvalData } })
                localStorage.setItem(
                    "approversData",
                    JSON.stringify(approvalData)
                );
                localStorage.approversData_version = this.state.approversVersion;
            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });
    }
    attachmentHandler = (relData) => {
        this.setState({ relData: { ...relData } })
        this.setState({ attachment: true })
    }
    auditLogsHandler = (relData) => {
        this.setState({ relData: { ...relData } })
        this.setState({ auditLogs: true })
    }

    literatureHandler = (relData) => {
        this.setState({ relData: { ...relData } })
        this.setState({ literature: true })
    }
    workflowHandler = (relData) => {
        this.setState({ relData: { ...relData } })
        this.setState({ workflow: true })
    }
    showAttachmentHandler = () => {
        this.setState({ attachment: false })
    }

    showAuditLogsHandler = () => {
        this.setState({ auditLogs: false })
    }
    showLiteratureHandler = () => {
        this.setState({ literature: false })
    }
    showWorkflowHandler = () => {
        this.setState({ workflow: false })
    }

    render() {
        let dashboard = <React.Fragment>
            {this.state.literature ? <Literature
                userInfo={this.props.userInfo}
                showLiterature={this.showLiteratureHandler}
                releaseData={this.state.relData} /> : null}
            {this.state.attachment ? <Attachment userInfo={this.props.userInfo} showAttachment={this.showAttachmentHandler} releaseData={this.state.relData} /> : null}
            {this.state.auditLogs ? <AuditLogs
                showAuditLogs={this.showAuditLogsHandler} releaseData={this.state.relData} /> : null}
            {this.state.workflow ? <Workflow
                showWorkflow={this.showWorkflowHandler}
                userInfo={this.props.userInfo}
                releaseData={this.state.relData} approvers={this.state.approversData} /> : null}
            <Releases attachmentUpload={this.attachmentHandler}
                auditLogs={this.auditLogsHandler}
                literature={this.literatureHandler}
                workflow={this.workflowHandler} />
        </React.Fragment>
        if (this.state.loading)
            dashboard = <Loader />
        return dashboard

    }

}

const mapStateToProps = state => {
    return {
        userInfo: state.login.loggedInUserInfo,

    };
}

export default connect(mapStateToProps)(WithErrorHandler(Dashboard, axios));

