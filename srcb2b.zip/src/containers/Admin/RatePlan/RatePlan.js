import React, { Component } from 'react';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import LibraryBooksIcon from '@material-ui/icons/LibraryBooks';
import CardActions from '@material-ui/core/CardActions';
import KeyboardArrowRightIcon from '@material-ui/icons/KeyboardArrowRight';
import KeyboardArrowLeftIcon from '@material-ui/icons/KeyboardArrowLeft';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import ListSubheader from '@material-ui/core/ListSubheader';
import AppsIcon from '@material-ui/icons/Apps';
import { withRouter } from 'react-router-dom';
import MoneyIcon from '@material-ui/icons/Money';


class RatePlan extends Component {

    state = {
        ratePlan: true
    }
    render() {
        return <Grid item xs={12} sm={6} md={4}
            style={{ height: '30vh' }}>
            <Card key="b" style={{ background: '#FFB800', height: '100%' }}>

                <CardContent style={{ height: '75%' }}>
                    {this.state.ratePlan ? <span style={{ color: 'white' }}>
                        <MoneyIcon
                            style={{ marginRight: '20px', fontSize: '60px' }} />
                        <span style={{ marginRight: '10px', fontSize: '40px' }}>Rate Plan</span>
                    </span> :
                        <List component="div" disablePadding style={{ color: 'white' }}>
                            <ListSubheader style={{ color: 'white' }}>Rate Plan</ListSubheader>
                            <ListItem button
                                onClick={() => {
                                    this.props.history.push("/adminRatePlanConfiguration")
                                }}>
                                <ListItemIcon>
                                    <AppsIcon style={{ color: 'white' }} />
                                </ListItemIcon>
                                <ListItemText primary="Modify Fields" />
                            </ListItem>
                        </List>}
                </CardContent>
                <CardActions style={this.state.ratePlan ? {
                    height: '25%', display: 'flex', justifyContent: 'flex-end'
                } :
                    { height: '25%', display: 'flex' }}>
                    {this.state.ratePlan ? <KeyboardArrowRightIcon onClick={() => this.setState((prevState) => {
                        return { ratePlan: !prevState.ratePlan };
                    })}
                        style={{ color: 'white', cursor: 'pointer' }} /> :
                        <KeyboardArrowLeftIcon onClick={() => this.setState((prevState) => {
                            return { ratePlan: !prevState.ratePlan };
                        })}
                            style={{ color: 'white', cursor: 'pointer' }} />}
                </CardActions>
            </Card>
        </Grid>
    }
}

export default withRouter(RatePlan);