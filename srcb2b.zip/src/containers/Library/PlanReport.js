import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import IconButton from '@material-ui/core/IconButton';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../UI/Loader/Loader';
import { withStyles } from '@material-ui/core/styles';
import * as actionTypes from '../../store/actions/actionTypes';
import Box from '@material-ui/core/Box';
import MenuBookIcon from '@material-ui/icons/MenuBook';
import Chip from '@material-ui/core/Chip';
import ButtonGroup from '@material-ui/core/ButtonGroup';
// import Button from "@material-ui/core/Button";
import MaterialTable from 'material-table';
import Button from '../../UI/Button/Button';
//import MaterialTable from '../../UI/Table/Table';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import Title from '../../UI/Typography/Title';

const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const theme = createMuiTheme({
  overrides: {
    MuiTable: {
      root: {
        tableLayout: 'fixed',
      },
    },
    MuiTableCell: {
      root: {
        padding: '7px',
        paddingLeft: '10px',
      },
    },
    MuiPaper: {
      width: '100%',
    },
  },
});

const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4.5vh',
  },
  subheader: {
    color: 'white',
  },
});

const columns = {
  // epcPlanId: 'Package Id',
  // planName: 'Package Name',
  // rental: 'Rental',
  // billFrequncy: 'Bill Frequency',
  // advancedRental: 'Advanced Rental',
  // brandName: 'Brand Name',
  // crp: 'CRP',
  // planStartDate: 'Start Date',
  // planEndDate: 'End Date',
  // deployedDate: 'Deployed Date',

  attrName: 'Attribute',
  className: 'Attribute Group',
};

class Releases extends Component {
  _isMounted = false;
  state = {
    data: [],
    show: false,
    loading: false,
    actions: [
      {
        icon: () => (
          <Button
            // variant="contained"
            // style={{
            //   marginLeft: "20px",
            //   background: "#546D7A",
            //   color: "white",
            //   textTransform: "none",
            // }}
            onClick={() => {
              this.saveAsExcel();
            }}
          >
            <SaveAlt style={{ marginRight: '10px' }} />
            Export
          </Button>
        ),
        isFreeAction: true,
      },
    ],
    columns: [
      {
        title: 'Attribute',
        field: 'attrName',
      },
      {
        title: 'Attribute Group',
        field: 'className',
      },

      // {
      //   title: 'Package Id',
      //   field: 'epcPlanId',
      // },
      // {
      //   title: 'Package Name',
      //   field: 'planName',
      //   sorting: false,
      // },
      // {
      //   title: 'Rental',
      //   field: 'rental',
      //   sorting: false,
      // },
      // {
      //   title: 'Bill Frequency',
      //   field: 'billFrequncy',
      //   sorting: false,
      // },
      // {
      //   title: 'Advanced Rental',
      //   field: 'advancedRental',
      //   sorting: false,
      // },
      // {
      //   title: 'Brand Name',
      //   field: 'brandName',
      //   sorting: false,
      // },
      // {
      //   title: 'CRP',
      //   field: 'crp',
      //   sorting: false,
      // },
      // {
      //   title: 'Start Date',
      //   field: 'planStartDate',
      //   sorting: false,
      // },
      // {
      //   title: 'End Date',
      //   field: 'planEndDate',
      //   sorting: false,
      // },
      // {
      //   title: 'Deployed Date',
      //   field: 'deployedDate',
      //   sorting: false,
      // },
    ],
  };

  modalCloseHandler = () => {
    this.setState({ show: false });
  };

  async saveAsExcel() {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Attribute Report');
    let sheetColumns = [];
    Object.keys(columns).map((key) => {
      sheetColumns.push({
        header: columns[key],
        key: key,
        width: 25,
      });
    });

    worksheet.columns = sheetColumns;

    this.selectTable.current.state.data.map((row) => {
      worksheet.addRow(row);
    });

    // worksheet.getRow(1).fill = {
    //     type: 'pattern',
    //     pattern: 'solid',
    //     fgColor: { argb: 'cccccc' },
    //     font: { bold: true }
    // }

    worksheet.getRow(1).font = {
      bold: true,
    };

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), 'Attribute Report.xlsx');
  }

  planReportHandler = () => {
    
    return axios
      .get('package/rollback/attrLib', {
        //  "ratePlan/getEpcTelemediaPlanReport"
        headers: {
          opId: this.props.userInfo.opId,
        },
      })
      .then((res) => {
        console.log(res);
        if (this._isMounted) {
          this.setState({ data: res.data.data });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  constructor(props) {
    
    super(props);
    this.selectTable = React.createRef();
  }

  componentDidMount = () => {
    this._isMounted = true;
    this.props.onReleaseExit();
    this.setState({ loading: true });
    this.planReportHandler().then(() => {
      if (this._isMounted) {
        this.setState({ loading: false });
      }
    });
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  render() {
    const { classes } = this.props;

    let planReport = (
      <div style={{ marginTop: '1em' }}>
        <div
          style={
            this.state.loading ? { display: 'none' } : { display: 'block' }
          }
        >
          {/* <Title>Attribute Report</Title> */}
          <ThemeProvider theme={theme}>
            <MaterialTable
              tableRef={this.selectTable}
              actions={this.state.actions}
              icons={tableIcons}
              title={'Attribute Report'}
              columns={this.state.columns}
              data={this.state.data}
              options={{
                search: false,
                filtering: true,
                pageSize: 8,
                pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
                toolbar: true,
                paging: true,
                rowStyle: {
                  fontSize: '14px',
                  // fontWeight: "600"
                },
                headerStyle: {
                  fontWeight: 'bold',
                },
              }}
            />
          </ThemeProvider>
        </div>
        {this.state.loading && <Loader />}
      </div>
    );
    return planReport;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onReleaseExit: () =>
      dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(withRouter(Releases), axios)));
