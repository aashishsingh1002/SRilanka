export const ENTITY_NAME = 'setup';

export const SETUP_LISTS = [
  {
    id: 'fixedcost',
    name: 'Fixed Cost',
    entity: 'fixedCost',
    GET: '/mtn/deal/ref/channelFC',
    POST: '/mtn/deal/ref/storechannelFC',
    validations: [
      {
        name: 'channel',
        required: true,
      },
      {
        name: 'type',
        required: true,
      },
      {
        name: 'fixedCost',
        type: 'number',
        required: true,
        positiveVal: true,
      },
    ],
  },
  {
    id: 'variablecost',
    name: 'Variable Cost',
    entity: 'variableCost',
    GET: '/mtn/deal/ref/channelVC',
    POST: '/mtn/deal/ref/storechannelVC',
    validations: [
      {
        name: 'channel',
        required: true,
      },
      {
        name: 'type',
        required: true,
      },
      {
        name: 'variableCost',
        type: 'number',
        required: true,
        positiveVal: true,
      },
    ],
  },
  {
    id: 'commission',
    name: 'Commission',
    entity: 'commission',
    GET: '/mtn/deal/ref/commission',
    POST: '/mtn/deal/ref/storecommission',
    validations: [
      {
        name: 'channel',
        required: true,
      },
      {
        name: 'ongoingCommission',
        required: true,
        positiveVal: true,
      },
    ],
  },
  {
    id: 'interconnect',
    name: 'Interconnect',
    entity: 'interconnectCost',
    GET: '/mtn/deal/ref/interconnect',
    POST: '/mtn/deal/ref/storeinterconnect',
    validations: [
      {
        name: 'pkgType',
        required: true,
      },

      {
        name: 'interconnectCost',
        type: 'number',
        required: true,
        positiveVal: true,
      },
    ],
  },
  {
    id: 'arsetup',
    name: 'AR Setup',
    entity: 'arSetup',
    GET: '/mtn/deal/ref/arSetup',
    POST: '/mtn/deal/ref/storearSetup',
    validations: [
      {
        name: 'period1',
        required: true,
      },
      {
        name: 'arSetup',
        type: 'number',
        required: true,
        positiveVal: true,
      },
    ],
  },
  {
    id: 'targetreturn',
    name: 'Target Return',
    entity: 'targetReturn',
    GET: '/mtn/deal/ref/targetReturn',
    POST: '/mtn/deal/ref/storetargetReturn',
    validations: [
      {
        name: 'period',
        required: true,
      },
      {
        name: 'targitReturnVariable',
        type: 'number',
        required: true,
        positiveVal: true,
      },
    ],
  },
  {
    id: 'devicestatus',
    name: 'Device Status',
    entity: 'deviceStatus',
    GET: '/mtn/deal/ref/deviceStatus',
    POST: '/mtn/deal/ref/storedeviceStatus',
    validations: [
      {
        name: 'deviceStatusProvisions',
        required: true,
      },
      {
        name: 'ratePercentage',
        type: 'number',
        required: true,
        positiveVal: true,
      },
    ],
  },
  {
    id: 'accounting',
    name: 'Accounting',
    entity: 'accounting',
    GET: '/mtn/deal/ref/accounting',
    POST: '/mtn/deal/ref/storeaccounting',
    validations: [
      {
        name: 'periodUsedAccountingCals',
        type: 'number',
        required: true,
        positiveVal: true,
      },
      {
        name: 'period',
        required: true,
      },
    ],
  },

  {
    id: 'exchangeRate',
    name: 'Exchange Rate',
    entity: 'exchangeRate',
    GET: '/mtn/deal/exchangeRates',
    POST: 'mtn/deal/storeExchangeRates',
    UPDATE_URL: 'mtn/deal/editExchangeRates',
    validations: [
      {
        name: 'quarter',
        required: true,
      },
      {
        name: 'currency',
        required: true,
      },
      {
        name: 'rate',
        type: 'number',
        required: true,
        positiveVal: true,
      },
    ],
  },

  {
    id: 'latestCompetitor',
    name: 'Latest Competitor',
    entity: 'latestCompetitor',
    GET: '/mtn/deal/ref/latestCompetitor',
    POST: 'mtn/deal/ref/storeLatestCompetitor',
    UPLOAD_URL: '/mtn/deal/ref/uploadLatestCompetitors?createdBy=',
    VALIDATION_URL: '/mtn/deal/ref/GetlatestCompetitorlogs?createdBy=',
    excelTabName: 'XMtnLatestCompetitorTab',
    validations: [
      {
        name: 'year',
        type: 'number',
        required: true,
        positiveVal: true,
      },
      {
        name: 'month',
        required: true,
      },
      {
        name: 'network',
        required: true,
      },
      {
        name: 'oem',
        required: true,
      },
      {
        name: 'priceX36Month',
        type: 'number',
      },
      {
        name: 'priceX24Month',
        type: 'number',
      },
      {
        name: 'monthValue',
        type: 'number',
      },
      { name: 'comments', required: true },
    ],
  },
];
