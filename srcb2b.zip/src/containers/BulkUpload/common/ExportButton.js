import React from 'react';
import Button from '@material-ui/core/Button';
import { saveAsExcel } from './utils';

const btnStyle = {
  textTransform: 'capitalize',
  background: '#ffcc00',
  letterSpacing: '-1px',
  fontWeight: '600',
  color: '#000',
  fontSize: '16px',
  borderRadius: '50px',
  padding: '6px 32px',
  '&:hover': {
    opacity: 0.8,
    background: '#ffcc00',
  },
};
const hyperLinkStyle = {
  background: 'none',
  border: 'none',
  color: '#069',
  textDecoration: 'underline',
  cursor: 'pointer',
  fontSize: '16px',
  // textTransform: 'capitalize',
  // background: '#ffcc00',
  // letterSpacing: '-1px',
  // fontWeight: '600',
  // color: '#000',
  // fontSize: '16px',
  // borderRadius: '50px',
  // padding: '6px 32px',
  // '&:hover': {
  //   opacity: 0.8,
  //   background: '#ffcc00',
  // },
};

const ExportButton = ({ schema, name, data, derived }) => {
  const onClick = () => {
    saveAsExcel({ schema, name, data, derived });
  };

  return (
    <Button variant='contained' style={btnStyle} onClick={onClick}>
      Export
    </Button>
  );
};

export default ExportButton;

export const HyperLinkButton = ({ schema, name, data, derived }) => {
  const onClick = () => {
    saveAsExcel({ schema, name, data, derived });
  };

  return (
    <button variant='contained' style={hyperLinkStyle} onClick={onClick}>
      {name}
    </button>
  );
};

export const AuditLogsExport = ({ schema, name, data, derived }) => {
  const onClick = () => {
    saveAsExcel({ schema, name, data, derived });
  };

  return (
    <Button variant='contained' style={btnStyle} onClick={onClick}>
      Audit Version
    </Button>
  );
};
