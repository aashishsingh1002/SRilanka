import MuiAlert from '@material-ui/lab/Alert';
import React from 'react';
import Snackbar from '@material-ui/core/Snackbar';

export const objAppendOnUpdate = (
  obj = {},
  updatedBy,
  { oldArr = [], identifier, val }
) => {
  // Find reference from the list
  const { createdBy } = oldArr.find((i) => i[identifier] === val);

  return {
    ...obj,
    createdBy,
    updatedBy,
  };
};

export const alertUpload = () => {
  const Alert = (props) => {
    return <MuiAlert elevation={6} variant='filled' {...props} />;
  };
  const vertical = 'top';
  const horizontal = 'center';
  return (
    <Snackbar
      anchorOrigin={{ vertical, horizontal }}
      open={this.state.openSnack}
      autoHideDuration={4000}
      onClose={this.handleClose}
    >
      <Alert onClose={this.handleClose} severity='success'>
        Files Uploaded Successfully
      </Alert>
    </Snackbar>
  );
};

/**
Business-"Product Modelling in progress" Pending with Business && enableFederation=false && enableDeploy=false
Siebel- "Siebel configuration in progress" Pending with Siebel
SV- "Singleview configuration in progress" Pending with SV
Business Finance- "Finance approval in progress" Pending with Business Finance Team
Business-"Business review in progress" Pending with Business && enableFederation=true
Testing- "Testing approval in progress" Pending with Testing
Business-"Roll out in progress" Pending with Business && enableDeploy=true
Once Approved--status as "Journey Completed"(current)-->"Closed"


 */
export const transformPLMStatus = (
  pendingWith = '',
  releaseStatus = '',
  enableFederation = false,
  enableDeploy = false,
  pendingWithGroup = ''
) => {
  const status = (pendingWithGroup ? pendingWithGroup : '').toLowerCase();

  if (
    status === '' &&
    !enableFederation &&
    !enableDeploy &&
    releaseStatus !== 'Deployed' &&
    releaseStatus !== 'Cancelled'
  ) {
    return 'Product Modelling in progress';
  } else if (status === 'siebel') {
    return 'Siebel Configuration in progress';
  } else if (status === 'single view') {
    return 'Singleview configuration in progress';
  } else if (status === 'business finance team') {
    return 'Finance approval in progress';
  } else if (status === 'business' && enableFederation && !enableDeploy) {
    return 'Business review in progress';
  } else if (status === 'testing approval') {
    return 'Testing Approval in Progress';
  } else if (status === 'business release approval' && enableDeploy) {
    return 'Roll out in progress';
  } else if (status === 'journey completed') {
    return 'Deployed';
  } else if (releaseStatus === 'deployed') {
    return 'Deployed';
  } else if (releaseStatus === 'cancelled') {
    return 'Cancelled';
  }
  //  else if (releaseStatus === 'Journey Completed') {
  //   return 'Closed';
  // }

  return releaseStatus;
};
