import React, { Component } from "react";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import Drawer from "@material-ui/core/Drawer";
import AppBar from "@material-ui/core/AppBar";
import CssBaseline from "@material-ui/core/CssBaseline";
import Avatar from '@material-ui/core/Avatar';
import Toolbar from "@material-ui/core/Toolbar";
import List from "@material-ui/core/List";
import Typography from "@material-ui/core/Typography";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Divider from "@material-ui/core/Divider";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
import clsx from "clsx";
import * as actionTypes from "../../store/actions/actionTypes";
import { withRouter } from "react-router-dom";
import Collapse from "@material-ui/core/Collapse";
import PermDataSettingIcon from "@material-ui/icons/PermDataSetting";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import AppsIcon from "@material-ui/icons/Apps";
import { createMuiTheme } from "@material-ui/core/styles";
import { ThemeProvider } from "@material-ui/styles";
import BrightnessAutoIcon from "@material-ui/icons/BrightnessAuto";
import RedeemIcon from "@material-ui/icons/Redeem";
import LibraryBooksIcon from "@material-ui/icons/LibraryBooks";
import MoneyIcon from "@material-ui/icons/Money";
import StoreIcon from "@material-ui/icons/Store";
import LocalOfferIcon from "@material-ui/icons/LocalOffer";
import MenuBookIcon from "@material-ui/icons/MenuBook";
import LocalAtmIcon from "@material-ui/icons/LocalAtm";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import WorkIcon from "@material-ui/icons/Work";
import AllInboxIcon from "@material-ui/icons/AllInbox";
import { setLocale } from "react-redux-i18n";
import { Translate } from "react-redux-i18n";
import FindInPageIcon from "@material-ui/icons/FindInPage";
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import TurnedInNotIcon from "@material-ui/icons/TurnedInNot";
import TCSLogo from "../../assests/images/logo.png";
// import Logo from "../../assests/images/mtn-logo.svg";
// import LogoImage from "../../assests/images/mtnIlulaLogo.png";
import InsertDriveFileOutlinedIcon from "@material-ui/icons/InsertDriveFileOutlined";
import logo1 from "../../assests/images/logo1.jpg";

import CloseIcon from "@material-ui/icons/Close";
import { AccountCircle, HomeOutlined } from "@material-ui/icons";
import { BrighterSans } from "./fonts";
import { Menu, MenuItem } from "@material-ui/core";
import Grid from "@material-ui/core/Grid";
import Autocomplete from "@material-ui/lab/Autocomplete";
import { createTheme } from "@material-ui/core/styles";
import TimelineIcon from "@material-ui/icons/Timeline";
import { FaHandshake } from "@react-icons/all-files/fa/FaHandshake";
import CollectionsBookmarkIcon from "@material-ui/icons/CollectionsBookmark";
//import MoneyIcon from '@mui/icons-material/Money';
import EventNoteIcon from "@material-ui/icons/EventNote";
//import UploadFileIcon from '@material-ui/icons/UploadFileIcon';
import DriveFolderUploadIcon from "@mui/icons-material/DriveFolderUpload";
import UploadModal from "../../common/Upload/UploadModal";
import LayersIcon from "@material-ui/icons/Layers";
import axios from '../../axios-epc';
import IdleTimer from "react-idle-timer";
import ModalAction from "../../UI/ModalAction/ModalAction";
import PowerSettingsNewIcon from '@mui/icons-material/PowerSettingsNew';
const theme = createMuiTheme({
  typography: {
    fontFamily: "BrighterSans",
    body1: {
      fontSize: "14px",
    },
  },
  overrides: {
    MuiCssBaseline: {
      "@global": {
        "@font-face": [BrighterSans],
      },
    },
  },
});

const drawerWidth = 240;

const useStyles = (theme) => ({
  root: {
    display: "flex",
  },

  avatar: {
    width: theme.spacing(15),
    height: theme.spacing(15),
    backgroundColor: '#ff1921',
  },

  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    backgroundColor: "#ff1921",
    boxShadow: "none",
  },
  large: {
    width: theme.spacing(12),
    height: theme.spacing(12),
  },

  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: '25px',
    marginBottom: '25px',
  },
  menuButton: {
    marginRight: 36,
  },
  hide: {
    display: "none",
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    //whiteSpace: "nowrap",
  },
  drawerPaper: {
    background: "#dfe4ec",
    // background: "#272c2f",
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: "hidden",
    width: 0,
  },

  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: `0 ${theme.spacing(3)}px`,
    // background: "rgba(0, 0, 0, 0.04)",
  },
  content2: {
    flexGrow: 1,
    // background: "rgba(0, 0, 0, 0.04)",
  },
  selected: {
    background: "#ff1921",
    color: "#FFF",
  },
  nested: {
    color: "#000",
  },
  title: {
    flexGrow: 1,
  },
  listItem: {
    borderBottom: "1px solid #999",
    color: "#000",
    "&:hover": {
      // color: "#FFF",
      background: "#ff1921",
    },
  },

  // #ff1921
  listItemSelected: {
    color: "#FFF",
    background: "#ff1921",
    "&:hover": {
      color: "#FFF",
      background: "#ff1921",
    },
  },
});

class Layout extends Component {
  _isMounted = false;
  state = {
    open: true,
    planConfig: false,
    contractConfig: false,
    plan: false,
    product: false,
    offerability: false,
    contract: false,
    contractProfile: false,
    ratePlan: false,
    rental: false,
    discount: false,
    user: false,
    workflow: false,
    library: false,
    show: false,
    timerConfig: {},
    release: false,
    genericConfiguration: false,
    rateplanConfiguration: false,
    isOpen: false,
    reportlists:[]
  };
  constructor(props) {
    super(props);
    this.idleTimerRef = React.createRef();
    this.sessionTimerRef = React.createRef();
  }
  componentWillUnmount() {
    this._isMounted = false;
  }

componentDidMount=()=>{
  this._isMounted = true;
  console.log('UserI',this.props.userInfo)
  if(this.props.userInfo.group && this.props.userInfo.group.length>0)
  this.reportlist().then(()=>{})
  console.log("layout mounted");
    axios
      .get(process.env.REACT_APP_URL + "b2b-dashboard/popup/notification",{
        headers: {
          buId: this.props.userInfo.buId,
          opId: this.props.userInfo.opId,
          Authorization: 'Bearer ' + this.props.userInfo.jwt}})
      .then((res) => {
        console.log(res);
        this.setState({
          timerConfig: res.data.data,
        });
      })
      .catch((error) => {
        console.log(error);
      });
}
  logoutHandler = () => {
    sessionStorage.clear();
    localStorage.clear()
    this.setState({show:false});
    this.props.onLogout();
    //this.props.history.replace("/login");
    
    
    this.props.changeLocale('en')
    window.location.replace(process.env.REACT_APP_URL + "EPCLogin");
    // this.props.changeLocale('en')
  };

  drawerHandler = () => {
    this.props.setDrawer(!this.props.openDrawer);
  };

  handleClick = (item) => {
    this.setState((prevState) => {
      return { [item]: !prevState[item] };
    });
  };
  reportlist=()=>{
    console.log('UI',this.props.userInfo)
    return axios
      .get("/b2b-report/list", {
        headers: {
          buId: this.props.userInfo.buId,
          opId: this.props.userInfo.opId,
          authUserId:this.props.userInfo.id,
          authGroupId:this.props.userInfo.group[0],
          Authorization: 'Bearer ' + this.props.userInfo.jwt,
        },
      })
      .then((res) => {
    
        console.log(res);
        let reportlists = [];
        res.data.data.filter((element) => {
          reportlists.push(element);
        });
        if (this._isMounted) {
          console.log('REL',reportlists)
          this.setState({ reportlists:reportlists });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  showAttachmentHandler = () => {
    this.setState({ attachment: false });
  };

  render() {
    const { classes } = this.props;
    const { pathname } = this.props.history.location;

    if (!(Object.keys(this.props.userInfo).length > 0)) {
      return this.props.children;
    }

    return (
      <ThemeProvider theme={theme}>
        <div className={classes.root}>
        {Object.keys(this.props.userInfo).length > 0 &&
          Object.keys(this.state.timerConfig).length > 0 && (
            <IdleTimer
              ref={this.idleTimerRef}
              timeout={Number(this.state.timerConfig.inactiveTime)}
              // timeout={6000}
              onIdle={() => {
                console.log("idle timer log");
                this.setState({ show: true });
                this.sessionTimerRef.current = setTimeout(
                  this.logoutHandler,
                  Number(this.state.timerConfig.autoLogout)
                );
              }}
            ></IdleTimer>
          )}  
            

        <ModalAction
          show={this.state.show}
          modalClosed={() => {
            clearTimeout(this.sessionTimerRef.current);
            this.setState({ show: false });
          }}
          actionText={"Log me out"}
          closeText={"Keep me signed in"}
          title={"Timeout"}
          action={() => {
            clearTimeout(this.sessionTimerRef.current);
            this.logoutHandler();
          }}
        >
          <div style={{ padding: "20" }}>
            <h2>You've been idle for a while!</h2>
            <p>You will be logged out soon</p>
          </div>
        </ModalAction>
          <CssBaseline />
          <AppBar
            position="fixed"
            className={clsx(classes.appBar, {
              [classes.appBarShift]: this.props.openDrawer,
            })}
          // className={classes.appBar}
          >
            <Toolbar
            // style={{ height: "70px" }}
            >
              {/* <div>
              <ListItem
                    button
                    onClick={this.drawerHandler}
                    style={{marginLeft:'1em'}}
                  >
                    <ListItemIcon>
                      {this.props.openDrawer ? (
                        <CloseIcon style={{ color: "#000" }} />
                      ) : (
                        <MenuIcon style={{ color: "#000" }} />
                      )}
                    </ListItemIcon>
                    <ListItemText />
                  </ListItem>
              </div> */}

              <img
                src={logo1}
                style={{
                  cursor: "pointer",
                  height: "10vh",
                  // marginBottom: "2px",
                  // marginLeft: "1em",
                }}
                onClick={() => this.props.history.push("/")}
              />

              {(pathname == "/planConfiguration" ||
                pathname == "/productConfiguration") && (
                  <div style={{ marginLeft: "5%" }}>
                    <Grid container spacing={1} alignItems="flex-end">
                      <Grid item>
                        <Autocomplete
                          value={this.props.searchValue}
                          onChange={(event, value) => {
                            if (value) {
                              this.props.setSearchValue(value);
                              if (this.props.entity == "PACKAGE") {
                                this.props.changePackageActiveStep(0);
                                let pkgData = { ...this.props.packageData };
                                pkgData["packageId"] = value.split("/")[0];
                                this.props.onPackageEnter(pkgData);
                                this.props.changePackageKey(
                                  this.props.pkgKey + "1"
                                );
                                this.props.history.push("/planConfiguration");
                                this.props.history.go();
                              } else if (this.props.entity == "PRODUCT") {
                                this.props.changeProductActiveStep(0);
                                let proData = { ...this.props.productData };
                                proData["productId"] = value.split("/")[0];
                                this.props.onProductEnter(proData);
                                this.props.changeProductKey(
                                  this.props.productKey + "1"
                                );
                                this.props.history.push("/productConfiguration");
                                this.props.history.go();
                              }
                              this.props.setSearchValue(null);
                            }
                          }}
                          options={this.props.searchItems}
                          // getOptionLabel={(option) => ""}
                          renderOption={(option) => {
                            var matches = option.match(/\[(.*?)\]/);

                            if (matches) {
                              var submatch = matches[0];
                              var submatch0 = option.split(submatch)[0];
                            }

                            if (pathname == "/productConfiguration") {
                              var usedesc = submatch0 || option || "";
                              var submatch0arr = usedesc.split("/");
                              submatch0arr.shift();
                              var submatchdesc = submatch0arr.join("/");
                            }

                            return (
                              <>
                                {submatchdesc || option}{" "}
                                <span style={{ color: "#ff0000" }}>
                                  {submatch}
                                </span>
                              </>
                            );
                          }}
                          renderInput={(params) => (
                            <div ref={params.InputProps.ref}>
                              <input
                                style={{
                                  width: "30vw",
                                  height: "4vh",
                                  border: "none",
                                  borderRadius: "3px",
                                }}
                                type="text"
                                {...params.inputProps}
                              />
                            </div>
                          )}
                        />
                      </Grid>
                    </Grid>
                  </div>
                )}

              <Typography variant="h6" className={classes.title}>
                {/* Ilula */}
              </Typography>
              <div
                style={{
                  display: "flex",
                  textTransform: "capitalize",
                  color: "#FFF",
                  alignItems: "center",
                }}
              >
                <IconButton
                  aria-label="account of current user"
                  aria-controls="menu-appbar"
                  aria-haspopup="true"
                  // onClick={(event) => {
                  //   this.setState({
                  //     anchorEl: event.currentTarget,
                  //     //menuOpen: true,
                  //   });}}
                  onClick={this.logoutHandler}
                  
                  color="inherit"
                >
                  <PowerSettingsNewIcon />
                </IconButton>
                <Menu
                  id="menu-appbar"
                  anchorEl={this.state.anchorEl}
                  anchorOrigin={{
                    vertical: "top",
                    horizontal: "right",
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "right",
                  }}
                  open={this.state.menuOpen}
                  onClose={() => this.setState({ menuOpen: false })}
                >
                  {/* <MenuItem onClick={this.logoutHandler}>Logout</MenuItem> */}
                </Menu>






                {/* <div className={classes.logout} onClick={this.logoutHandler}>
								<IconButton
									style={{ color: 'white' }}
									disableRipple
									disableFocusRipple>
									<ExitToAppIcon />
									<span
										style={{
											marginLeft: '10px',
											fontSize: '16px',
											fontWeight: '600',
										}}>
										Logout
									</span>
								</IconButton>
							</div> */}












                <div style={{ display: "flex", flexDirection: "column",marginLeft:'5px' }}>
                  <span>
                    {`${this.props.userInfo.firstName.toLowerCase()} ${this.props.userInfo.lastName.toLowerCase()}`}
                  </span>

                  {this.props.userInfo.group &&
                    this.props.userInfo.group.map((grp) => {
                      return (
                        <span key={grp} style={{ fontSize: "11px" }}>
                          {grp}

                        </span>
                      );
                    })}
                </div>
              </div>
            </Toolbar>
          </AppBar>

          <Drawer
            variant="permanent"
            className={clsx(classes.drawer, {
              [classes.drawerOpen]: this.props.openDrawer,
              [classes.drawerClose]: !this.props.openDrawer,
            })}
            classes={{
              paper: clsx(classes.drawerPaper, {
                [classes.drawerOpen]: this.props.openDrawer,
                [classes.drawerClose]: !this.props.openDrawer,
              }),
            }}
          >
            <div className={classes.toolbar}>
              {/* <IconButton onClick={this.drawerHandler}>
                {theme.direction === "rtl" ? <CloseIcon /> : <CloseIcon />}
              </IconButton> */}
            </div>



            {/* <div className={classes.center}>
									<Avatar className={classes.avatar}>
										<AccountCircle className={classes.large} />
									</Avatar>
								</div> */}
            {/* <div style={{ marginLeft: '20px' }}>
									<Grid
										container
										alignContent="center"
										style={{ marginBottom: '5px' }}>
										<span
											style={{
												fontWeight: 'bold',
												width: drawerWidth,
												wordBreak: 'break-all',
												paddingLeft: '70px',
												paddingRight: '20px',
											}}>
											{' ' +
												this.props.userInfo.firstName +
												' ' +
												this.props.userInfo.lastName}
										</span>
                    <span
											style={{
												fontWeight: 'bold',
												width: drawerWidth,
												wordBreak: 'break-all',
												paddingLeft: '70px',
												paddingRight: '20px',
											}}>
									  {this.props.userInfo.group &&
                    this.props.userInfo.group.map((grp) => {
                      return (
                        <span key={grp} style={{ fontSize: "11px" }}>
                          {grp}
                        </span>
                      );
                    })}
										</span>
                       {this.props.userInfo.group &&
                    this.props.userInfo.group.map((grp) => {
                      return (
                        <span key={grp} style={{ fontSize: "11px" }}>
                          {grp}
                        </span>
                      );
                    })} 


									</Grid>
									<Grid alignContent="center">
										{this.props.approversData && this.props.userInfo.group && (
											<React.Fragment>
												{this.props.userInfo.group
													.filter(
														(value, index) =>
															this.props.userInfo.group.indexOf(value) === index
													)
													.filter((value, index, theArray) => {
														if (
															this.props.userInfo.group[index]
																.substring(
																	this.props.userInfo.group[index].length - 3,
																	this.props.userInfo.group[index].length
																)
																.toLowerCase() === 'b2b' &&
															theArray.includes(
																`${this.props.userInfo.group[index].substring(
																	0,
																	3
																)}B2c`
															)
														) {
															return;
														} else {
															return value;
														}
													})
													.map((grp) => {
														return (
															this.props.approversData[grp] && (
																<Grid
																	container
																	alignContent="center"
																	style={{ marginBottom: '5px' }}>
																	<span
																		style={{
																			fontWeight: 'bold',
																			width: drawerWidth,
																			wordBreak: 'break-all',
																			paddingLeft: '10px',
																			paddingRight: '10px',
																		}}>
																		{this.props.approversData[grp]}
																	</span>
																</Grid>
															)
														);
													})}
											</React.Fragment>
										)}
									</Grid>
								</div> */}






            <Divider />
            {this.props.userInfo.group &&
              this.props.userInfo.group.includes("b2bsales") &&

              <List>
                <ListItem
                  className={clsx(classes.nested, {
                    [classes.listItem]: pathname !== '/allReleases',
                    [classes.listItemSelected]:
                      pathname === '/allReleases',
                  })}
                  button
                  onClick={() => this.props.history.push('/allReleases')}
                >
                  <ListItemIcon className={classes.navIcon}>
                    <AllInboxIcon

                      style={{
                        color:
                          pathname === '/allReleases' ? '#FFF' : '#000',
                      }}
                    />
                  </ListItemIcon>
                  <ListItemText primary={'All Releases'} />
                </ListItem>
                <Divider />
                <ListItem
                  className={
                    pathname === "/"
                      ? classes.listItemSelected
                      : classes.listItem
                  }
                  button
                  onClick={() => this.props.history.push("/")}
                >
                  <ListItemIcon className={classes.navIcon}>
                    <HomeOutlined
                      style={{ color: pathname === "/" ? "#FFF" : "#000" }}
                    />
                  </ListItemIcon>
                  <ListItemText primary={`My Releases`} />
                </ListItem>
                
                    

                {/* {this.props.releaseData.releaseId && (
                    <>
                      <ListItem
                        className={
                          pathname === "/editRelease"
                            ? classes.listItemSelected
                            : classes.listItem
                        }
                        button
                        onClick={() => {
                          this.handleClick("release");
                          this.props.history.push("/editRelease");
                        }}
                      >
                        <ListItemIcon className={classes.navIcon}>
                          <InsertDriveFileOutlinedIcon
                            style={{
                              color:
                                pathname === "/editRelease" ? "#fff" : "#000",
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText
                          // primary={`Release ${this.props.releaseData.releaseId}`}
                          // primary={`Release ${this.props.releaseData.releaseNbr}`}
                          primary={`Release ${this.props.releaseData.externalReleaseId}`}
                        />
                      </ListItem>
                      <Collapse
                        in={this.state.release}
                        timeout="auto"
                        unmountOnExit
                      >
                        <Divider style={{ background: "#fff" }} />
                      </Collapse>
                    </>
                  )}

                  <React.Fragment>
                    <ListItem
                      style={{
                        borderBottom: "1px solid #999",
                        color: "#000",
                      }}
                      button
                      onClick={() => this.handleClick("planConfig")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <PermDataSettingIcon
                          style={{
                            color: "#000",
                          }}
                        />
                      </ListItemIcon>
                      <ListItemText
                        primary={<Translate value="dashboard.proConfig" />}
                      />
                      {this.state.planConfig ? (
                        <ExpandLess style={{ fontSize: "18px" }} />
                      ) : (
                        <ExpandMore style={{ fontSize: "18px" }} />
                      )}
                    </ListItem>
                    <Collapse
                      in={this.state.planConfig}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List component="div" disablePadding>
                        <ListItem
                          button
                          className={clsx(classes.nested, {
                            [classes.listItem]:
                              pathname !== "/planConfiguration",
                            [classes.listItemSelected]:
                              pathname === "/planConfiguration",
                          })}
                          onClick={() => {
                            console.log(this.props.pkgKey);
                            this.props.changePackageActiveStep(0);
                            this.props.onPackageEnter({});
                            this.props.changePackageKey(
                              this.props.pkgKey + "1"
                            );
                            this.props.history.push("/planConfiguration");
                          }}
                        >
                          <ListItemIcon>
                            <AppsIcon
                              className={classes.nested}
                              style={{
                                color:
                                  pathname === "/planConfiguration"
                                    ? "#FFF"
                                    : "#000",
                              }}
                            />
                          </ListItemIcon>
                          <ListItemText
                            primary={<Translate value="dashboard.bundles" />}
                          />
                        </ListItem>
                        <ListItem
                          button
                          className={clsx(classes.nested, {
                            [classes.listItem]:
                              pathname !== "/productConfiguration",
                            [classes.listItemSelected]:
                              pathname === "/productConfiguration",
                          })}
                          onClick={() => {
                            this.props.changeProductActiveStep(0);
                            this.props.onProductEnter({});
                            this.props.changeProductKey(
                              this.props.productKey + "1"
                            );
                            this.props.history.push("/productConfiguration");
                          }}
                        >
                          <ListItemIcon>
                            <AppsIcon
                              className={classes.nested}
                              style={{
                                color:
                                  pathname === "/productConfiguration"
                                    ? "#FFF"
                                    : "#000",
                              }}
                            />
                          </ListItemIcon>
                          <ListItemText
                            primary={<Translate value="dashboard.products" />}
                          />
                        </ListItem>
                        <ListItem
                          className={clsx(classes.nested, {
                            [classes.listItem]:
                              pathname !== "/ratePlanConfiguration",
                            [classes.listItemSelected]:
                              pathname === "/ratePlanConfiguration",
                          })}
                          button
                          onClick={() =>
                            this.props.history.push("/ratePlanConfiguration")
                          }
                        >
                          <ListItemIcon className={classes.navIcon}>
                            <AppsIcon
                              style={{
                                color:
                                  pathname === "/ratePlanConfiguration"
                                    ? "#FFF"
                                    : "#000",
                              }}
                            />
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              <Translate value="dashboard.Rate Plan Configuration" />
                            }
                          />
                        </ListItem>

                        <ListItem
                          className={clsx(classes.nested, {
                            [classes.listItem]: pathname !== "/events",
                            [classes.listItemSelected]: pathname === "/events",
                          })}
                          button
                          onClick={() => this.props.history.push("/events")}
                        >
                          <ListItemIcon className={classes.navIcon}>
                            <AppsIcon
                              style={{
                                color: pathname === "/events" ? "#FFF" : "#000",
                              }}
                            />
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              <Translate value="dashboard.Events Configuration" />
                            }
                          />
                        </ListItem>
                        <ListItem
                          className={clsx(classes.nested, {
                            [classes.listItem]:
                              pathname !== "/attributeConfiguration",
                            [classes.listItemSelected]:
                              pathname === "/attributeConfiguration",
                          })}
                          button
                          onClick={() =>
                            this.props.history.push("/attributeConfiguration")
                          }
                        >
                          <ListItemIcon>
                            <AppsIcon
                              className={classes.nested}
                              style={{
                                color:
                                  pathname === "/attributeConfiguration"
                                    ? "#FFF"
                                    : "#000",
                              }}
                            />
                          </ListItemIcon>
                          <ListItemText primary={"Attribute Configuration"} />
                        </ListItem>
                        {/* <ListItem
                          button
                          className={clsx(classes.nested, {
                            [classes.listItem]:
                              pathname !== "/contractsCreation",
                            [classes.listItemSelected]:
                              pathname === "/contractsCreation",
                          })}
                          onClick={() => {
                            this.props.history.push("/contractsCreation");
                          }}
                        >
                          <ListItemIcon>
                            <AppsIcon
                              className={classes.nested}
                              style={{
                                color:
                                  pathname === "/contractsCreation"
                                    ? "#FFF"
                                    : "#000",
                              }}
                            />
                          </ListItemIcon>
                          <ListItemText
                            primary={<Translate value="dashboard.contracts" />}
                          />
                        </ListItem> */}

                {/* <ListItem
                          button
                          className={clsx(classes.nested, {
                            [classes.listItem]:
                              pathname !== "/contractProfileCreation",
                            [classes.listItemSelected]:
                              pathname === "/contractProfileCreation",
                          })}
                          onClick={() => {
                            this.props.history.push("/contractProfileCreation");
                          }}
                        >
                          <ListItemIcon>
                            <AppsIcon
                              className={classes.nested}
                              style={{
                                color:
                                  pathname === "/contractProfileCreation"
                                    ? "#FFF"
                                    : "#000",
                              }}
                            />
                          </ListItemIcon>
                          <ListItemText
                            primary={
                              <Translate value="dashboard.contractsProfiles" />
                            }
                          />
                        </ListItem> 
                      </List>
                    </Collapse>
                  </React.Fragment> */}

                {/* 
                   <ListItem
                    style={{ borderBottom: '1px solid #999', color: '#000' }}
                    button
                    className={classes.nested}
                    onClick={() => this.handleClick('genericConfiguration')}
                  >
                    <ListItemIcon className={classes.navIcon}>
                     <LibraryBooksIcon style={{ color: "#C66B00" }} /> 
                      <BrightnessAutoIcon style={{ color: '#000' }} />
                    </ListItemIcon>
                    <ListItemText primary='Attribute Configuration' />
                    {this.state.genericConfiguration ? (
                      <ExpandLess style={{ fontSize: '18px' }} />
                    ) : (
                      <ExpandMore style={{ fontSize: '18px' }} />
                    )}
                  </ListItem>

                  <Collapse
                    in={this.state.genericConfiguration}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]:
                            pathname !== '/attributeConfiguration',
                          [classes.listItemSelected]:
                            pathname === '/attributeConfiguration',
                        })}
                        button
                        onClick={() =>
                          this.props.history.push('/attributeConfiguration')
                        }
                      >
                        <ListItemIcon>
                          <AppsIcon
                            className={classes.nested}
                            style={{
                              color:
                                pathname === '/attributeConfiguration'
                                  ? '#FFF'
                                  : '#000',
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText
                          primary={'Attribure & Attribute Groups'}
                        />
                      </ListItem>
                      
                    </List>
                  </Collapse> 
 */}
                {/* <Collapse
                    in={this.state.ratePlanConfiguration}
                    timeout='auto'
                    unmountOnExit
                  >
                    <List component='div' disablePadding>
                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]:
                            pathname !== '/ratePlanConfiguration',
                          [classes.listItemSelected]:
                            pathname === '/ratePlanConfiguration',
                        })}
                        button
                        onClick={() =>
                          this.props.history.push('/ratePlanConfiguration')
                        }
                      >
                        <ListItemIcon>
                          <AppsIcon
                            className={classes.nested}
                            style={{
                              color:
                                pathname === '/ratePlanConfiguration'
                                  ? '#FFF'
                                  : '#000',
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={'Rate Plan Configuration'} />
                      </ListItem>
                    </List>
                  </Collapse> */}
                {/* <ListItem
                  style={{ borderBottom: "1px solid #999", color: "#000" }}
                  button
                  className={classes.nested}
                  onClick={() => this.handleClick("release")}
                >
                  <ListItemIcon className={classes.navIcon}>
                    <WorkIcon style={{ color: "#000" }} />
                  </ListItemIcon>
                  <ListItemText primary="WorkQueue" />
                  {this.state.release ? (
                    <ExpandLess style={{ fontSize: "18px" }} />
                  ) : (
                    <ExpandMore style={{ fontSize: "18px" }} />
                  )}
                </ListItem> */}

                {/* <Collapse
                  in={this.state.release}
                  timeout="auto"
                  unmountOnExit
                > */}
                {/*<List component="div" disablePadding>*/}
                <Divider/>
                    <ListItem
                      className={clsx(classes.nested, {
                        [classes.listItem]: pathname !== "/worklist",
                        [classes.listItemSelected]: pathname === "/worklist",
                      })}
                      button
                      onClick={() => this.props.history.push("/worklist")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                    <WorkIcon style={{ color:
                          pathname === '/worklist' ? '#FFF' : '#000'}} />
                  </ListItemIcon>
                  <ListItemText primary="Work Queue" />
                    </ListItem>
                    {/* <ListItem
                      button
                      className={clsx(classes.nested, {
                        [classes.listItem]: pathname !== "/rfiWorklist",
                        [classes.listItemSelected]:
                          pathname === "/rfiWorklist",
                      })}
                      onClick={() => {
                        this.props.history.push("/rfiWorklist");
                      }}
                    >
                      <ListItemIcon>
                        <AppsIcon
                          className={classes.nested}
                          style={{
                            color:
                              pathname === "/rfiWorklist" ? "#fff" : "#000",
                          }}
                        />
                      </ListItemIcon>
                      <ListItemText
                        primary={<Translate value="dashboard.RFI/RFC" />}
                      />
                      {/* <span>
                          <FaBell
                            style={{
                              color:
                                pathname === '/rfiWorklist' ? '#000' : '#fff',
                            }}
                          />
                          <span>{this.state.resubmitCount}</span>
                        </span>}
                    </ListItem> */}
                 {/*</List>*/}
                {/*</Collapse>*/}
                {/* <ListItem button onClick={() => this.props.history.push('/')}>
                                    <ListItemIcon className={classes.navIcon}>
                                        <TurnedInNotIcon style={{ color: "green" }} />
                                    </ListItemIcon>
                                    <ListItemText primary="My Releases" />
                                </ListItem> */}









                {/* new code for Extenal Template */}

                {/* <ListItem
                    style={{ borderBottom: "1px solid #999", color: "#000" }}
                    button
                    className={classes.nested}
                     onClick={() => this.handleClick("attribute")}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <WorkIcon style={{ color: "#000" }} />
                    </ListItemIcon>
                    <ListItemText primary="Manage" />
                    {this.state.release ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>

                  <Collapse
                    in={this.state.attribute}
                    timeout="auto"
                    unmountOnExit
                  >
                    <List component="div" disablePadding>
                 
                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== "/ExternalTemplate",
                          [classes.listItemSelected]: pathname === "/ExternalTemplate",
                        })}
                        button
                        onClick={() => this.props.history.push("/ExternalTemplate")}
                      >
                        <ListItemIcon>
                          <AppsIcon
                            className={classes.nested}
                            style={{
                              color: pathname === "/ExternalTemplate" ? "#FFF" : "#000",
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={"External Sytem Templete"} />
                      </ListItem>
                      <ListItem
                        button
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== "/AssociateTemplate",
                          [classes.listItemSelected]:
                            pathname === "/AssociateTemplate",
                        })}
                        onClick={() => {
                          this.props.history.push("/AssociateTemplate");
                        }}
                      >
                        <ListItemIcon>
                          <AppsIcon
                            className={classes.nested}
                            style={{
                              color:
                                pathname === "/AssociateTemplate" ? "#fff" : "#000",
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText
                          primary={<Translate value="dashboard.AssociateExternalAttribute" />}
                        />
                       
                      </ListItem>
                    </List>
                  </Collapse> */}












                {/* <ListItem
                    className={clsx(classes.nested, {
                      [classes.listItem]: pathname !== "/productPerformance",
                      [classes.listItemSelected]:
                        pathname === "/productPerformance",
                    })}
                    button
                    onClick={() =>
                      this.props.history.push("/productPerformance")
                    }
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <TimelineIcon
                        style={{
                          color:
                            pathname === "/productPerformance"
                              ? "#FFF"
                              : "#000",
                        }}
                      />
                    </ListItemIcon>
                    <ListItemText
                      // primary={
                      //   <Translate value="dashboard.productPerformance" />
                      // }
                    />
                  </ListItem> */}

                {/* <ListItem
                    className={clsx(classes.nested, {
                      [classes.listItem]: pathname !== "/advanceSearch",
                      [classes.listItemSelected]: pathname === "/advanceSearch",
                    })}
                    button
                    onClick={() => this.props.history.push("/advanceSearch")}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <FindInPageIcon
                        style={{
                          color:
                            pathname === "/advanceSearch" ? "#FFF" : "#000",
                        }}
                      />
                    </ListItemIcon>
                    <ListItemText
                      primary={<Translate value="dashboard.advanceSearch" />}
                    />
                  </ListItem>



                  <ListItem
                    className={clsx(classes.nested, {
                      [classes.listItem]: pathname !== "/libraryReport",
                      [classes.listItemSelected]: pathname === "/libraryReport",
                    })}
                    button
                    onClick={() => this.props.history.push("/libraryReport")}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <FindInPageIcon
                        style={{
                          color:
                            pathname === "/libraryReport" ? "#FFF" : "#000",
                        }}
                      />
                    </ListItemIcon>
                    <ListItemText
                      primary={<Translate value="dashboard.LibraryReport" />}
                    />
                      </ListItem>*/}




                  <ListItem
                    style={{ borderBottom: "1px solid #999", color: "#000" }}
                    className={classes.nested}
                    button
                    onClick={() => this.handleClick("library")}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <LibraryBooksIcon className={classes.nested} />
                    </ListItemIcon>
                    <ListItemText primary="Reports" />

                    {this.state.library ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Divider />

                  <Collapse
                    in={this.state.library}
                    timeout="auto"
                    unmountOnExit
                  >
                    <List component="div" disablePadding>
                      {this.state.reportlists.map(element=>
                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== `/report?id=${element.reportId}&name=${element.reportName}`,
                          [classes.listItemSelected]:
                            pathname === `/report?id=${element.reportId}&name=${element.reportName}`,
                        })}
                        button
                        onClick={() => {
                          this.props.history.push(`/report?id=${element.reportId}&name=${element.reportName}`);
                        }}
                      >
                        <ListItemIcon className={classes.navIcon}>
                          <AppsIcon
                            style={{
                              color:
                                pathname === `/report?id=${element.reportId}&name=${element.reportName}`
                                  ? "#FFF"
                                  : "#000",
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={element.reportName} />
                      </ListItem>
)}
                      {/* <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== "/planReport",
                          [classes.listItemSelected]:
                            pathname === "/planReport",
                        })}
                        button
                        onClick={() => {
                          this.props.history.push("/planReport");
                        }}
                      >
                        <ListItemIcon>
                          <AppsIcon
                            style={{
                              color:
                                pathname === "/planReport" ? "#FFF" : "#000",
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={"Plan Report"} />
                      </ListItem>

                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== "/productReport",
                          [classes.listItemSelected]:
                            pathname === "/productReport",
                        })}
                        button
                        onClick={() => {
                          this.props.history.push("/productReport");
                        }}
                      >
                        <ListItemIcon>
                          <AppsIcon
                            style={{
                              color:
                                pathname === "/productReport" ? "#FFF" : "#000",
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={"Product Report"} />
                      </ListItem> */}


                    



                    </List>




                    
                  </Collapse>
                {/* {this.props.releaseData.releaseId && (
                    <ListItem
                      className={clsx(classes.nested, {
                        [classes.listItem]: pathname !== "/bulkEdit",
                        [classes.listItemSelected]: pathname === "/bulkEdit",
                      })}
                      button
                      onClick={() => this.props.history.push("/bulkEdit")}
                    >
                      <ListItemIcon className={classes.navIcon}>
                        <LayersIcon
                          style={{
                            color: pathname === "/bulkEdit" ? "#FFF" : "#000",
                          }}
                        />
                      </ListItemIcon>
                      <ListItemText
                        primary={<Translate value="dashboard.Bulk Edit" />}
                      />
                    </ListItem>
                  )} */}

              </List>
            }












            {this.props.userInfo.group &&
              this.props.userInfo.group.includes("Admin") && (
                <List>
                  <ListItem button onClick={() => this.handleClick("plan")}>
                    <ListItemIcon className={classes.navIcon}>
                      <LibraryBooksIcon style={{ color: "#8175CB" }} />
                    </ListItemIcon>
                    <ListItemText primary="Package" />
                    {this.state.plan ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Collapse in={this.state.plan} timeout="auto" unmountOnExit>
                    <List component="div" disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push("/adminPlanConfiguration")
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Modify Fields" />
                      </ListItem>
                    </List>
                  </Collapse>

                  <ListItem button onClick={() => this.handleClick("product")}>
                    <ListItemIcon className={classes.navIcon}>
                      <StoreIcon style={{ color: "#00ACC2" }} />
                    </ListItemIcon>
                    <ListItemText primary="Product" />
                    {this.state.product ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.product}
                    timeout="auto"
                    unmountOnExit
                  >
                    <List component="div" disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push("/adminProductConfiguration")
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Modify Fields" />
                      </ListItem>
                      <ListItem
                        button
                        onClick={() => {
                          this.props.history.push("/adminCtsConfiguration");
                        }}
                      >
                        <ListItemIcon>
                          <AppsIcon />
                        </ListItemIcon>
                        <ListItemText primary="Modify CTS" />
                      </ListItem>
                    </List>
                  </Collapse>

                  <ListItem
                    button
                    onClick={() => this.handleClick("offerability")}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <LocalOfferIcon style={{ color: "#EB646F" }} />
                    </ListItemIcon>
                    <ListItemText primary="Offerability" />
                    {this.state.offerability ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.offerability}
                    timeout="auto"
                    unmountOnExit
                  >
                    <List component="div" disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push(
                            "/adminOfferabilityConfiguration"
                          )
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Modify Offerability" />
                      </ListItem>
                    </List>
                  </Collapse>
                  <ListItem button onClick={() => this.handleClick("contract")}>
                    <ListItemIcon className={classes.navIcon}>
                      <MenuBookIcon style={{ color: "#008E7B" }} />
                    </ListItemIcon>
                    <ListItemText primary="Contract" />
                    {this.state.contract ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.contract}
                    timeout="auto"
                    unmountOnExit
                  >
                    <List component="div" disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push(
                            "/adminBundleContractConfiguration"
                          )
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Bundle Contract" />
                      </ListItem>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push(
                            "/adminContractCreationConfiguration"
                          )
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Contract Creation" />
                      </ListItem>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push(
                            "/adminContractProfileConfiguration"
                          )
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Contract Profile" />
                      </ListItem>
                    </List>
                  </Collapse>
                  {/* <ListItem button onClick={() => this.handleClick('contractProfile')}>
                                        <ListItemIcon className={classes.navIcon}>
                                            <LocalLibraryIcon style={{ color: "#D77CD8" }} />
                                        </ListItemIcon>
                                        <ListItemText primary="Contract Profile" />
                                        {this.state.contractProfile ? <ExpandLess style={{ fontSize: '18px' }} /> :
                                            <ExpandMore style={{ fontSize: "18px" }} />}
                                    </ListItem>
                                    <Collapse in={this.state.contractProfile} timeout="auto" unmountOnExit>
                                        <List component="div" disablePadding>
                                            <ListItem button className={classes.nested}
                                                onClick={() => this.props.history.push("/adminContractProfileConfiguration")} >
                                                <ListItemIcon> <AppsIcon />  </ListItemIcon>
                                                <ListItemText primary="Modify Fields" />
                                            </ListItem>
                                        </List>
                                    </Collapse> */}
                  <ListItem
                    button
                    onClick={() => this.handleClick("attribute")}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <BrightnessAutoIcon style={{ color: "#F60076" }} />
                    </ListItemIcon>
                    <ListItemText primary="Attribute" />
                    {this.state.attribute ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.attribute}
                    timeout="auto"
                    unmountOnExit
                  >
                    <List component="div" disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push("/adminAttrConfiguration")
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Attribute" />
                      </ListItem>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push("/adminAttrGrpConfiguration")
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Attribute Group" />
                      </ListItem>
                    </List>
                  </Collapse>
                  <ListItem button onClick={() => this.handleClick("ratePlan")}>
                    <ListItemIcon className={classes.navIcon}>
                      <MoneyIcon style={{ color: "#FFB800" }} />
                    </ListItemIcon>
                    <ListItemText primary="Rate Plan" />
                    {this.state.ratePlan ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.ratePlan}
                    timeout="auto"
                    unmountOnExit
                  >
                    <List component="div" disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push("/adminRatePlanConfiguration")
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Modify Fields" />
                      </ListItem>
                    </List>
                  </Collapse>
                  <ListItem button onClick={() => this.handleClick("rental")}>
                    <ListItemIcon className={classes.navIcon}>
                      <LocalAtmIcon style={{ color: "#8D6D62" }} />
                    </ListItemIcon>
                    <ListItemText primary="Pricing" />
                    {this.state.rental ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Collapse in={this.state.rental} timeout="auto" unmountOnExit>
                    <List component="div" disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push("/adminPriceConfiguration")
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Modify Price" />
                      </ListItem>

                    </List>
                  </Collapse>
                  <ListItem button onClick={() => this.handleClick("user")}>
                    <ListItemIcon className={classes.navIcon}>
                      <AccountCircleIcon style={{ color: "#FF6239" }} />
                    </ListItemIcon>
                    <ListItemText primary="User" />
                    {this.state.user ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Collapse in={this.state.user} timeout="auto" unmountOnExit>
                    <List component="div" disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push("/adminuserConfiguration")
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="User Creation" />
                      </ListItem>
                    </List>
                  </Collapse>
                  <ListItem button onClick={() => this.handleClick("workflow")}>
                    <ListItemIcon className={classes.navIcon}>
                      <WorkIcon style={{ color: "#1dad03" }} />
                    </ListItemIcon>
                    <ListItemText primary="Workflow" />
                    {this.state.workflow ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Collapse
                    in={this.state.workflow}
                    timeout="auto"
                    unmountOnExit
                  >
                    <List component="div" disablePadding>
                      <ListItem
                        button
                        className={classes.nested}
                        onClick={() =>
                          this.props.history.push("/adminWorklist")
                        }
                      >
                        <ListItemIcon>
                          {" "}
                          <AppsIcon />{" "}
                        </ListItemIcon>
                        <ListItemText primary="Worklist" />
                      </ListItem>
                    </List>
                  </Collapse>
                  {/* <ListItem button onClick={() => this.handleClick('discount')}>
                                        <ListItemIcon className={classes.navIcon}>
                                            <AddShoppingCartIcon style={{ color: "#FF6239" }} />
                                        </ListItemIcon>
                                        <ListItemText primary="Discount" />
                                        {this.state.discount ? <ExpandLess style={{ fontSize: '18px' }} /> :
                                            <ExpandMore style={{ fontSize: "18px" }} />}
                                    </ListItem>
                                    <Collapse in={this.state.discount} timeout="auto" unmountOnExit>
                                        <List component="div" disablePadding>
                                            <ListItem button className={classes.nested}
                                                onClick={() => this.props.history.push("/adminDiscountConfiguration")} >
                                                <ListItemIcon> <AppsIcon />  </ListItemIcon>
                                                <ListItemText primary="Modify Fields" />
                                            </ListItem>
                                        </List>
                                    </Collapse> */}
                </List>
              )}

            {this.props.userInfo.group &&
              !this.props.userInfo.group.includes("Admin") &&
              !this.props.userInfo.group.includes("b2bsales") &&(
                <List>
                  <ListItem
                    button
                    onClick={() => this.props.history.push("/allReleases")}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <AllInboxIcon style={{ color: "blue" }} />
                    </ListItemIcon>
                    <ListItemText primary="All Releases" />
                  </ListItem>
<Divider/>
                  <ListItem
                    button
                    onClick={() => this.props.history.push("/worklist")}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <WorkIcon style={{ color: "#a87f32" }} />
                    </ListItemIcon>
                    <ListItemText
                      primary={<Translate value="dashboard.workQueue" />}
                    />
                  </ListItem>
                  <Divider/>
                  {this.props.userInfo.group.includes("b2bpm")&&(
                    <>
                     <ListItem
                    style={{ borderBottom: "1px solid #999", color: "#000" }}
                    className={classes.nested}
                    button
                    onClick={() => this.handleClick("library")}
                  >
                    <ListItemIcon className={classes.navIcon}>
                      <LibraryBooksIcon className={classes.nested} />
                    </ListItemIcon>
                    <ListItemText primary="Reports" />

                    {this.state.library ? (
                      <ExpandLess style={{ fontSize: "18px" }} />
                    ) : (
                      <ExpandMore style={{ fontSize: "18px" }} />
                    )}
                  </ListItem>
                  <Divider />

                  <Collapse
                    in={this.state.library}
                    timeout="auto"
                    unmountOnExit
                  >
                    <List component="div" disablePadding>
                      {this.state.reportlists.map(element=>
                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== `/report?id=${element.reportId}&name=${element.reportName}`,
                          [classes.listItemSelected]:
                            pathname === `/report?id=${element.reportId}&name=${element.reportName}`,
                        })}
                        button
                        onClick={() => {
                          this.props.history.push(`/report?id=${element.reportId}&name=${element.reportName}`);
                        }}
                      >
                        <ListItemIcon>
                          <AppsIcon
                            style={{
                              color:
                                pathname === `/report?id=${element.reportId}&name=${element.reportName}`
                                  ? "#FFF"
                                  : "#000",
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={element.reportName} />
                      </ListItem>
)}
                      {/* <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== "/planReport",
                          [classes.listItemSelected]:
                            pathname === "/planReport",
                        })}
                        button
                        onClick={() => {
                          this.props.history.push("/planReport");
                        }}
                      >
                        <ListItemIcon>
                          <AppsIcon
                            style={{
                              color:
                                pathname === "/planReport" ? "#FFF" : "#000",
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={"Plan Report"} />
                      </ListItem>

                      <ListItem
                        className={clsx(classes.nested, {
                          [classes.listItem]: pathname !== "/productReport",
                          [classes.listItemSelected]:
                            pathname === "/productReport",
                        })}
                        button
                        onClick={() => {
                          this.props.history.push("/productReport");
                        }}
                      >
                        <ListItemIcon>
                          <AppsIcon
                            style={{
                              color:
                                pathname === "/productReport" ? "#FFF" : "#000",
                            }}
                          />
                        </ListItemIcon>
                        <ListItemText primary={"Product Report"} />
                      </ListItem> */}


                    



                    </List>




                    
                  </Collapse></>
                 
                  )}
                </List>
              )}
          </Drawer>


          <main
            className={
              pathname !== "/editRelease" &&
                pathname !== "/federate" &&
                pathname !== "/validateTransformRelease" &&
                pathname !== "/selectApprover"
                ? classes.content
                : classes.content2
            }
          >
            <div className={classes.toolbar} />
            {/* <Toolbar /> */}

            {this.props.children}
          </main>
        </div>
      </ThemeProvider>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    approversData: state.approverData.approversData,
    userInfo: state.login.loggedInUserInfo,
    pkgKey: state.packageData.pkgKey,
    productKey: state.productData.productKey,
    searchItems: state.searchData.searchItems,
    searchValue: state.searchData.searchValue,
    entity: state.searchData.entity,
    packageData: state.packageData.packageData,
    productData: state.productData.productData,
    openDrawer: state.drawerData.open,
    releaseData: state.releaseData.releaseData,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    setDrawer: (open) =>
      dispatch({ type: actionTypes.DRAWER_TOGGLE, open: open }),
    onLogout: () => dispatch({ type: actionTypes.LOG_OUT }),
    onPackageEnter: (packageData) =>
      dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
    changePackageKey: (pkgKey) =>
      dispatch({ type: actionTypes.CHANGE_PACKAGE_KEY, pkgKey: pkgKey }),
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    changeProductKey: (productKey) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_KEY,
        productKey: productKey,
      }),
    onProductEnter: (productData) =>
      dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
    changeProductActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    setSearchValue: (searchValue) =>
      dispatch({
        type: actionTypes.SET_SEARCH_VALUE,
        searchValue: searchValue,
      }),
    onSelectedRole: (roleSelected) =>
      dispatch({
        type: actionTypes.ROLE_SELECTED,
        roleSelected
      }),
    changeLocale: (locale) => dispatch(setLocale(locale)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(withRouter(Layout)));
