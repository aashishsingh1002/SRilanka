import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import Tooltip from "@material-ui/core/Tooltip";
import axios from 'axios';
import { connect } from "react-redux";
import * as actionTypes from '../../store/actions/actionTypes';
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import { withRouter } from "react-router-dom";
import Input from '../../UI/Input/Input';
import Grid from '@material-ui/core/Grid';
import Loader from '../../UI/Loader/Loader';
import StyledButton from '../../UI/Button/Button';
import moment from 'moment';
import MaterialTable from "material-table";
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { forwardRef } from 'react';
import EditIcon from '@material-ui/icons/Edit';
import DeleteIcon from '@material-ui/icons/Delete';
import IconButton from '@material-ui/core/IconButton';

const tableIcons = {
  // Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  // Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  // Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  // Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  // DetailPanel: forwardRef((props, ref) => (
  //   <ChevronRight {...props} ref={ref} />
  // )),
  // Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  // Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  // FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  // LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  // NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  // PreviousPage: forwardRef((props, ref) => (
  //   <ChevronLeft {...props} ref={ref} />
  // )),
  // ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  // Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  // SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  // ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  // ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};



const useStyles = (theme) => ({
  cardHeader: {
    paddingBottom: 0,
  },
  subheader: {
    color: "rgba(0, 0, 0, 0.87)",
    fontSize: "16px",
    fontWeight: "600",

  },
  boldText: {
  },
  center: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "96%",
    flexShrink: 0,
  },
});

const theme = createMuiTheme({
  overrides: {
    MuiTable: {
      root: {
        tableLayout: 'fixed',
      },
    },
    MuiTableCell: {
      root: {
        padding: '7px',
        paddingLeft: '10px',
      },
    },
    MuiPaper: {
      width: '100%',
    },
  },
});




class AssociateTemplate extends Component {
  _isMounted = false;


  state = {
    postRequest: true,
    dataMyItems: [],
    isEdit: false,

    columnsMyItems: [
      {
        title: 'External System',
        field: 'sysId',
      },
      {
        title: 'Attribute Id',
        field: 'attrId',

      },
      {
        title: 'Attribute Type',
        field: 'attrLabel'
      },
      {
        title: 'Display Order',
        field: 'dispalyOrder'
      },
      {
        title: 'Default Value',
        field: 'attrDefaultValue'
      },
      {
        title: 'Mandatory',
        field: 'attrMandatory'
      },
      {
        title: 'Edit',
        field: 'action',
        filtering: false,

        render: (rowData) => (
          <IconButton
            style={{ marginLeft: '10' }}
            onClick={(event) => {
              console.log(rowData)
              event.stopPropagation();
              this.setState({
                //colSize:rowData.colSize,
                isEdit :true,
                sysId: rowData.sysId,
                attrId: rowData.attrId,
                attrLabel: rowData.attrLabel,
                dispalyOrder: rowData.dispalyOrder,
                attrMandatory: rowData.attrMandatory,
                attrDefaultValue: rowData.attrDefaultValue,
                attrMaxLength: rowData.attrMaxLength,
                attrType: rowData.attrType,
                attrAllowedValues: rowData.attrAllowedValues,
                tempAssId: rowData.tempAssId,

              })

            }}
          >
            <EditIcon />
          </IconButton>
        ),
        sorting: false,
        cellStyle: { width: '7%' },
      },


      {
        title: 'delete',
        field: 'action',
        filtering: false,

        render: (rowData) => (
          <IconButton
            style={{ marginLeft: '10' }}
            onClick={(event) => {
              console.log(rowData)
              event.stopPropagation();
              this.setState({
                colSize:rowData.colSize,
                templateDesc: rowData.templateDesc,
                templateName: rowData.templateName,
                templateType: rowData.templateType

              })

            }}
          >
            <DeleteIcon />
          </IconButton>
        ),
        sorting: false,
        cellStyle: { width: '7%' },
      }
  

    ],
  }


  componentDidMount() {
    this._isMounted = true;
    this.teamItemsHandler().then(() => {
      //this.teamItemDataHandler().then(()=>{
      
      this.uiFields();
    //});
    });
  }

  uiFields() {

    console.log('fetching from api');
    console.log(this.props);
    return axios
      .get(
        process.env.REACT_APP_URL + 'config?entityName=external.templateAttribute',
        {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,

          },
        }
      )
      .then((res) => {
        let schema = res.data.data;
        schema = schema.filter((el) => {
          if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
            if (el.refLovs != null)
              el.refLovs = el.refLovs.split(',').map((item) => item.trim());
            else if (el.refLovs == null && el.refName == 'templateId') {

              el.refLovs = this.state.templateItems.map((template) => template.templateName)
            }
            else if (el.refLovs == null) el.refLovs = [];
          }
          return el;
        });
        localStorage.setItem('productBasic', JSON.stringify(schema));
        localStorage.productBasic_version = this.state.version;
        if (this._isMounted) this.setState({ schema: schema });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });

  }





  saveProDetailsHandler = (event) => {
    event.preventDefault();
    console.log(this.state);
    this.setState({ loading: true });
    let payload = {};
    let date = moment().format('DD-MMM-YY');
    let assExtSysAttrAud = {};

    this.state.schema.map((formElement) => {
      if (formElement.refType == 'Date'){
        assExtSysAttrAud[formElement.refName] = moment(
          this.state[formElement.refName]
        ).format('DD-MMM-YY');

      }
      else if (formElement.refType == 'SelectInput' && formElement.refName == 'templateId'){
         
        let tempId =null;
         this.state.templateItems.filter(
          (templ) => templ.templateName ==  this.state[formElement.refName]).map(tmplt =>
            { 
              tempId = tmplt.templateId;
             
            });
        assExtSysAttrAud[formElement.refName] =     tempId;
      }
      
      else if (formElement.refType == 'Checkbox') {
        assExtSysAttrAud[formElement.refName] =
        this.state[formElement.refName] === null ||
          this.state[formElement.refName] === undefined
          ? 'N'
          : this.state[formElement.refName];

      }
        
      else if (formElement.refType == 'TextInput' || 'TextArea') {
        assExtSysAttrAud[formElement.refName] =
        this.state[formElement.refName];

      }
        
      else {
        assExtSysAttrAud[formElement.refName] =
        this.state[formElement.refName];
      }
       
    });


    assExtSysAttrAud.buId = this.props.userInfo.buId;
    assExtSysAttrAud.opId = this.props.userInfo.opId;
    assExtSysAttrAud.startDate = date;
    assExtSysAttrAud.endDate = '30-DEC-2030'
    assExtSysAttrAud.createdBy = 'pmir';
    assExtSysAttrAud.createdDate = date;
    assExtSysAttrAud.catalogId = 'B2C'

    console.log(assExtSysAttrAud);
    if (!this.state.isEdit) {
      assExtSysAttrAud.version = '1.0';
      payload.assExtSysAttrAud = assExtSysAttrAud;
      // payload.releaseId = this.props.releaseData.releaseId;
      console.log('post');
      console.log(payload);
      axios
        .post(process.env.REACT_APP_URL + 'product/external/template/attribute', payload, {
          headers: {
            // authUserId: this.props.userInfo.id,
            // Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((response) => {
          console.log('new gen product');
          console.log(response);
          let proDetails = { ...response.data.data };
          this.props.onProductEnter(proDetails);

          let searchItems = [
            response.data.data.productId + '/' + response.data.data.productDesc,
          ].concat(this.props.searchItems);
          this.props.setSearchItems(searchItems);

          this.state.schema.map((formElement) => {
            this.setState({
              [formElement.refName]: formElement.refName === 'defaultState' ? response.data.data[formElement.refName].split(',') : response.data.data[formElement.refName],
            });
          });
          this.setState({ postRequest: false, loading: false });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }else{

      // payload.version = '1.0';
      // payload.tempId  = this.state.tempId;
      // payload.templateId = this.state.templateId;
      assExtSysAttrAud.updatedDate =date;
      assExtSysAttrAud.updatedBy = 'pmir';
      assExtSysAttrAud.tempAssId = this.state.tempAssId;
     //payload.templatetAud = templatetAud;
     // payload.releaseId = this.props.releaseData.releaseId;
     payload.assExtSysAttrAud = assExtSysAttrAud;
     console.log('put');
     console.log(payload);

    

     axios
       .post(
         process.env.REACT_APP_URL + 'product/external/update/attribute',
         payload,
         {
           headers: {
             //authUserId: this.props.userInfo.id,
             // Authorization: 'Bearer ' + this.props.userInfo.jwt
           },
         }
       )
       .then((response) => {
         console.log('new gen product');
         console.log(response);
         let proDetails = { ...response.data.data };
         this.props.onProductEnter(proDetails);

         let searchItems = [
           response.data.data.productId + '/' + response.data.data.productDesc,
         ].concat(this.props.searchItems);
         this.props.setSearchItems(searchItems);

         this.state.schema.map((formElement) => {
           this.setState({
             [formElement.refName]: formElement.refName === 'defaultState' ? response.data.data[formElement.refName].split(',') : response.data.data[formElement.refName],
           });
         });
         this.setState({ putRequest: false, loading: false ,    isEdit :false});
       })
       .catch((error) => {
         console.log(error);
         if (this._isMounted) this.setState({ loading: false });
       });


    }

  };

  teamItemDataHandler = (templateName) => {
    console.log(this.state);
    console.log(this.state.templateMap);
    console.log(templateName);
    return axios
      .get('product/external/getAll/attribute?templateId='+this.state.templateMap[templateName], {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {

        console.log(res);
        if (this._isMounted) {
          this.setState({ templateDataItems: res.data.data });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
    // } else return Promise.resolve();
  };


  
  teamItemsHandler = () => {
    return axios
      .get('product/external/getTemplates', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {

        console.log(res);
        if (this._isMounted) {
         
          this.setState({ templateItems: res.data.data });
          let templateMap = {}
          this.state.templateItems.map((template) => {
            templateMap[template.templateName] = template.templateId;
            
          });
          this.setState({ templateMap: templateMap });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
    // } else return Promise.resolve();
  };




  render() {
    const { classes } = this.props;
    let associateTemplate = (
      <div>
        <div
          style={{
            marginBottom: '1em',
            display: 'flex',
            justifyContent: 'flex-end',
          }}
        >

        </div>
        <div>
          <h3> Associate Template</h3>
        </div>

        <form
          onSubmit={this.saveProDetailsHandler}
          style={{ overflow: 'visible' }}
        >
          <Grid
            container
            alignItems='flex-start'
            spacing={5}
            style={{ overflow: 'visible' }}
          >
            {this.state.schema && this.state.schema.map((formElement) => {

              return (
                <Input
                  key={formElement.refName}
                  {...formElement}
                  value={this.state[formElement.refName]}
                  disabled={formElement.isDisabled == 'Y' ? true : false}
                  required={formElement.isMandatory == 'Y' ? true : false}
                  checkChanged={(event) => {
                    this.setState({
                      [formElement.refName]: event.target.checked ? 'Y' : 'N',
                    });
                  }}
                  changed={(event) => {
                    
                    if (formElement.refName == 'templateId') {
                      this.teamItemDataHandler(event);
                    }
                    if (!event.target) {
                      this.setState({
                        [formElement.refName]: event,
                      });
                    } else {

                      this.setState({
                        [formElement.refName]: event.target.value,
                      });

                    }
                  }}
                />
              )
            })}


          </Grid>

          <div
            style={{
              display: 'flex',
              justifyContent: 'flex-end',
              alignItems: 'center',
            }}
          >

            <StyledButton
              style={{
                marginLeft: '20px',
                marginTop: '3%',
                background: '#5dc17f',
              }}
              type='submit'
>
              Save
                    </StyledButton>
          </div>

        </form>

        <div>
          <h3> Configured External System Attributes</h3>
        </div>


        {<ThemeProvider theme={theme}>
          <MaterialTable

            title='My Items'
            data={this.state.templateDataItems}
            icons={tableIcons}
            columns={
              this.state.columnsMyItems}

            options={{
              search: false,
              filtering: true,
              pageSize: 8,
              pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
              toolbar: true,
              paging: true,
              rowStyle: {
                fontSize: '14px',
                // fontWeight: "600"
              },
              headerStyle: {
                fontWeight: 'bold',
              },
            }}
            // actions={[
            //   {
            //     icon: 'edit',
            //     tooltip: 'Edit User',
            //     //onClick: (event, rowData) => alert('You are editing ' + rowData.name)
            //   },
            //   {
            //     icon: 'delete',
            //     tooltip: 'Delete User',
            //     //onClick: (event, rowData) => confirm('You want to delete ' + rowData.name)
            //   }
            // ]}
          />
        </ThemeProvider>}

        {/* <Table
                title='My Items'
                data={this.state.dataMyItems}
                columns={
                  this.state.columnsMyItems
       
                }
                pageSize={5}
                fontSize={'14px'}
              /> */}


      </div>
    );
    if (this.state.loading) associateTemplate = <Loader />;
    return associateTemplate;
  }
}


const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
    searchItems: state.searchData.searchItems,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onReleaseExit: () =>
      dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
  };
};

//export default ExternalTemplate;
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(withRouter(AssociateTemplate), axios)));
