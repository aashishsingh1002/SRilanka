import React, { useState } from "react";
import Button from "@material-ui/core/Button";
import UploadModal from "./CustomizedUploadModal";
// import UploadModal from './UploadModal';

const btnStyle = {
  textTransform: "capitalize",
  background: "#fff",
  border: "2px solid #ffcc00",
  letterSpacing: "-1px",
  fontWeight: "600",
  color: "#000",
  fontSize: "16px",
  borderRadius: "50px",
  padding: "6px 32px",
  "&:hover": {
    opacity: 0.8,
    background: "#ffcc00",
  },
};

const UploadButton = (props) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <>
      {isOpen && <UploadModal {...props} setIsOpen={setIsOpen} />}
      <Button
        variant="contained"
        style={btnStyle}
        onClick={() => {
          setIsOpen(true);
        }}
      >
        Upload
      </Button>
    </>
  );
};

export default UploadButton;
