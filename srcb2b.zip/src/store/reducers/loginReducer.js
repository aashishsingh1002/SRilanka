import * as actionTypes from "../actions/actionTypes";

const initialState = {
  loggedInUserInfo: {},
};

const loginSuccess = (state, action) => {
  return {
    ...state,
    loggedInUserInfo: { ...action.loggedInUserInfo },
  };
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.LOGIN_SUCCESS:
      return loginSuccess(state, action);
    default:
      return state;
  }
};

export default reducer;
