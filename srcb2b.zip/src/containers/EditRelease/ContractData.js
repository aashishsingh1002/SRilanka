import React from 'react';
import ExpansionPanel from '../../UI/ExpansionPanel/ExpansionPanel';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';

const ContractData = (props) => {
    return (
        <ExpansionPanel heading='Contract'>
            {props.contract && Object.keys(props.contract).length > 0 ?
                < List
                    component="nav"
                    aria-labelledby="nested-list-subheader"
                    style={{ width: '100%', maxHeight: '30vh', overflow: 'auto' }}
                >
                    <React.Fragment>
                        <ListItem >
                            <ListItemText primary={'Contract' + Object.keys(props.contract)[0]}
                                secondary={'Contract Profile :- ' +
                                    props.contract[Object.keys(props.contract)[0]].contractProfile
                                    + ' Monthly Penalty Fee :- ' +
                                    props.contract[Object.keys(props.contract)[0]].monthlypenaltyFee
                                    + ' Penalty Fix Fee :- ' + 
                                    props.contract[Object.keys(props.contract)[0]].penaltyFixFee
                                    + ' Sign Up Fee :- ' + props.contract[Object.keys(props.contract)[0]].signUpFee} />
                        </ListItem>
                        <Divider />
                    </React.Fragment>

                </List>
                : null}
        </ExpansionPanel>


    );
}

export default ContractData;