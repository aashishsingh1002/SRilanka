export const ENTITY_NAME = 'tiers';

export const TIERS_LISTS = [
  {
    id: 'tiers1',
    name: 'Tiers 1',
    entity: 'bulkUploadTiers1',
    GET: 'mtn/deal/ref/tier1',
    POST: 'mtn/deal/ref/storetier1',
    PUT: '/mtn/deal/ref/editTier1',
    validations: [
      {
        name: 'minimum',
        type: 'number',
        required: true,
        positiveVal: true,
      },
      {
        name: 'maximum',
        type: 'number',
        required: true,
        positiveVal: true,
      },
      {
        name: 'ref',
        type: 'number',
      },
      {
        name: 'hhPriceTier',
        type: 'number',
        positiveVal: true,
      },
      {
        name: 'hhFrom',
        type: 'number',
        positiveVal: true,
      },
      {
        name: 'band',
        type: 'number',
        positiveVal: true,
      },
      {
        name: 'matrixHhTier',
        type: 'number',
        positiveVal: true,
      },
      {
        name: 'hhTo',
        type: 'number',
        positiveVal: true,
      },
    ],
  },
  {
    id: 'tiers2',
    name: 'Tiers 2',
    entity: 'bulkUploadTiers2',
    GET: 'mtn/deal/ref/tier2',
    POST: 'mtn/deal/ref/storetier2',
    PUT: 'mtn/deal/ref/editTier2',
    validations: [
      {
        name: 'ref1',
        type: 'number',
      },
      {
        name: 'subFrom',
        type: 'number',
        required: true,
        positiveVal: true,
      },
      {
        name: 'subTo',
        type: 'number',
        required: true,
        positiveVal: true,
      },
      {
        name: 'band',
        type: 'number',
        positiveVal: true,
      },
    ],
  },
  {
    id: 'subscriptionTiers',
    name: 'Subscription Tiers',
    entity: 'subscriptionTiers',
    GET: '/mtn/deal/ref/subsTier',
    POST: '/mtn/deal/ref/storesubsTier',
    PUT: 'mtn/deal/ref/editsubsTier',
    validations: [
      {
        name: 'from1',
        type: 'number',
        required: true,
        positiveVal: true,
      },
      {
        name: 'to1',
        type: 'number',
        required: true,
        positiveVal: true,
      },
      // {
      //   name: "range1",
      //   type: "number",
      // },
    ],
  },
];
