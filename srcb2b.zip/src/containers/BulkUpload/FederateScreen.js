import React from "react";
import { useSelector } from "react-redux";
import BasicDetails from "./BasicDetails";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import { useState } from "react";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Divider from "@material-ui/core/Divider";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import AppsIcon from "@material-ui/icons/Apps";
import axios from "../../axios-epc";
import ExcelJS from "exceljs/dist/es5/exceljs.browser.js";
import { saveAs } from "file-saver";
import GetAppIcon from "@material-ui/icons/GetApp";
import { Paper } from "@material-ui/core";
import Table from "../../UI/Table/Table";
import Button from "../../UI/Button/Button";
import Checkbox from "@material-ui/core/Checkbox";
import genAxios from "axios";

const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Paper p={3}>
          <Typography>{children}</Typography>
        </Paper>
      )}
    </div>
  );
};

const FederateScreen = () => {
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const openDrawer = useSelector((state) => state.drawerData.open);
  const releaseData = useSelector((state) => state.releaseData.releaseData);

  const [activeTab, setActiveTab] = useState(0);
  const [selValidationLog, setSelValidationLog] = useState(null);
  const [loading, setLoading] = useState(false);
  const [federate, setFederate] = useState([]);
  const [fedResponse, setFedResponse] = useState([]);
  const [columns] = useState([
    { title: "Deal Id", field: "dealId", sorting: false },
    { title: "Status", field: "status", sorting: false },
    { title: "Overall Status", field: "overallStatus", sorting: false },
    { title: "Message", field: "errorMessage", sorting: false },
  ]);

  const handleChangeTab = (newValue) => {
    setActiveTab(newValue ? newValue : 0);
  };

  const handleToggle = (value) => () => {
    const currentIndex = federate.indexOf(value);
    const newFederate = [...federate];

    if (currentIndex === -1) {
      newFederate.push(value);
    } else {
      newFederate.splice(currentIndex, 1);
    }

    setFederate(newFederate);
  };

  const fedStatusHandler = () => {
    setLoading(true);
    return genAxios
      .post(
        process.env.REACT_APP_URL +
          "mtn/ilula/siebelstatus?releaseId=" +
          releaseData.releaseId,
        {}
      )
      .then((res) => {
        console.log(res);
        if (res) {
          setFedResponse(res.data.data);
        }
        setActiveTab(1);
      })
      .catch((error) => {
        setLoading(false);
      });
  };

  const siebelFederation = () => {
    if (federate.includes("Siebel")) {
      return genAxios
        .post(
          process.env.REACT_APP_URL +
            "mtn/ilula/siebel?releaseId=" +
            releaseData.releaseId,
          {}
        )
        .then((res) => {
          setActiveTab(1);
        })
        .catch((error) => {
          console.log(error);
          setActiveTab(1);
        });
    } else return Promise.resolve();
  };

  const federationHandler = () => {
    if (federate.length > 0) {
      setLoading(true);
      siebelFederation().then(() => {
        setLoading(false);
      });
    }
  };

  return (
    <>
      <BasicDetails releaseData={releaseData} userInfo={userInfo} />
      <div style={{ padding: "0 24px 24px" }}>
        <div style={{ padding: "20px 0", fontSize: "18px", fontWeight: "600" }}>
          Federate
        </div>
        <div>
          <div
            style={{
              background: "#fff",
              marginBottom: "24px",
              maxWidth: "600px",
              borderRadius: "50px",
              padding: "4px",
            }}
          >
            {/* <AppBar position="static"> */}
            <div
              style={{
                display: "flex",
                textAlign: "center",
                fontWeight: "600",
              }}
            >
              <div
                style={{
                  flexBasis: "50%",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
                onClick={() => handleChangeTab(0)}
              >
                <div
                  style={
                    activeTab === 0
                      ? {
                          background: "#ffc800",
                          padding: "8px",
                          borderRadius: "50px",
                          width: "100%",
                        }
                      : {}
                  }
                >
                  Federation
                </div>
              </div>
              <div
                style={{
                  flexBasis: "50%",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
                onClick={() => {
                  fedStatusHandler();
                  handleChangeTab(1);
                }}
              >
                <div
                  style={
                    activeTab === 1
                      ? {
                          background: "#ffc800",
                          padding: "8px",
                          borderRadius: "50px",
                          width: "100%",
                        }
                      : {}
                  }
                >
                  Status
                </div>
              </div>
            </div>
          </div>
        </div>
        <TabPanel value={activeTab} index={0}>
          <List>
            <ListItem dense button onClick={handleToggle("Siebel")}>
              {/* <ListItemIcon>
                <Checkbox
                  edge='start'
                  checked={federate.indexOf('Siebel') !== -1}
                  tabIndex={-1}
                  disableRipple
                  style={{ color: '#ffc800' }}
                />
              </ListItemIcon>
              <ListItemText primary={'iLula Product Catalog(Siebel)'} /> */}
            </ListItem>
          </List>
          <div style={{ padding: "20px", textAlign: "right" }}>
            <Button
              style={{ padding: "6px 40px" }}
              onClick={() => federationHandler()}
              disabled={!federate.includes("Siebel")}
            >
              Federate
            </Button>
          </div>
        </TabPanel>

        <TabPanel value={activeTab} index={1}>
          <Table
            pageSize={5}
            title="Status"
            data={fedResponse}
            columns={columns}
          />
        </TabPanel>
      </div>
    </>
  );
};

export default FederateScreen;
