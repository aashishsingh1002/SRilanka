import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';

const WithErrorHandler = (WrappedComponent, axios) => {
    return class extends Component {
        state = {
            error: null
        }

        componentWillMount() {

            this.reqInterceptor = axios.interceptors.request.use(req => {
                console.log(req)

                this.setState({ error: null });
                return req;
            });
            this.resInterceptor = axios.interceptors.response.use(res => {
                console.log(res)
                if (res.data.statusMsg === "FAILURE") {
                    let error = <React.Fragment>
                        <p><span style={{ fontWeight: 'bold' }}> Error Description: </span> {res.data.statusDescription + '.'}</p>
                        <p><span style={{ fontWeight: 'bold' }}> Api Details: </span> {res.config.url}</p>
                    </React.Fragment>
                    let obj = {
                        message: error
                    }
                    this.setState({ error: obj });
                }
                else if (res.data.statusMsg === "SUCCESS")
                    return res
                else
                    return res
            }, error => {
                this.setState({ error: error });
            });
        }

        componentWillUnmount() {
            axios.interceptors.request.eject(this.reqInterceptor);
            axios.interceptors.response.eject(this.resInterceptor);
        }

        errorConfirmedHandler = () => {
            this.setState({ error: null });
        }

        render() {
            return (
                <React.Fragment>
                    <Modal
                        show={this.state.error != null}
                        modalClosed={this.errorConfirmedHandler}
                        title={'Something Went Wrong!'}
                    >
                        {this.state.error ?
                            < Typography variant="h6"> {this.state.error.message}</Typography >
                            : null}
                    </Modal>
                    <WrappedComponent {...this.props} />
                </React.Fragment>
            );
        }
    }
}

export default WithErrorHandler;