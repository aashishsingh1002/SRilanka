import React, { useState, useEffect } from "react";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Input from "../../../UI/Input/Input";
import axios from "../../../axios-epc";
import Button from "@material-ui/core/Button";
import moment from "moment";

const DiscountPricingMatrix = (props) => {
  //const abc = props.discountData;
  console.log(props);
  const { data, schema } = props;

  const [loading, setLoading] = useState(false);
  const [values, setValues] = useState({});
  const UOM = schema.find(({ refName }) => refName === "uom");
  const PostUOM = schema.find(({ refName }) => refName === "userField5");
  const UNITS = schema.find(({ refName }) => refName === "effectiveStartUnits");

  const updateValues = (refName, key, value) => {
    console.log(refName);
    setValues({
      ...values,
      [refName]: {
        ...values[refName],
        [key]: value,
      },
    });
  };


  useEffect(() => {
    console.log("..............Using effect..");
    if (props.discountData != null) {
      console.log("&&&&&&&&&&&" );
      showValues();
    }
  }, []);

 
  const showValues = () => {
    let formValues = {};

    console.log(props.discountData);
    if (props.discountData && props.discountData.length > 0) {
      props.discountData.map((val, i) => {
        val['discountValue'] = val['discountMatrixValue'];
        formValues[val.usageGrp] = val;
          
      })
      console.log('-------------------*****----------');
      setValues(formValues);
    }

  }

  // showValues();

  const renderValue = (usgGroup, key) => {
    return values && values[usgGroup] && values[usgGroup][key];
  };

  const saveMatrix = (event) => {
    event.preventDefault()
    event.stopPropagation();
    setLoading(true);
    //13-JAN-22
    const date = moment().format("DD-MMM-YY");

    //console.log(this.props);
    const discountMatrixWrapperList = Object.keys(values).map((v) => {
      return {
        usageGroup: v,
        ugcType: props.ugcType,
        ugcSubType1: props.ugcSubType1,
        ugcSubType2: props.ugcSubType2,
        ugcSubType3: props.ugcSubType3,
        classifier1: props.classifier1,
        classifier3: props.classifier3,
        componentLevel: props.componentLevel || "/service",
        discountAppliedOn: "USAGE",
        timeBand: "24_hr",
        priceType: "RC",
        startDate: date,
        endDate: null,
        createdDate: date,
        updatedDate: date,
        updatedBy: props.userInfo.id,
        ...values[v],
        discountValue: values[v].discountValue || "100",
        discountFrom: values[v].discountFrom || "0",
      };
    });

    const payload = {
      id: props.id,
      releaseId: props.releaseData.releaseId,
      discountMatrixWrapperlist: discountMatrixWrapperList,
    };


    if (props.discountData && Object.keys(props.discountData).length === 0) {

      console.log("post request");
      console.log(payload);

      axios
        .post("irdiscount/matrix", payload, {
          headers: {
            opId: props.userInfo.opId,
            buId: props.userInfo.buId,
            createdBy: props.userInfo.id
        
          },
        })
        .then((response) => {
          setLoading(true);
          //--- new code--

          var discountIds = response.data.data;

          for (var i = 0; i < discountIds.length; i++) {
            let objDiscount = {};
            objDiscount.discountId = discountIds[i].discountId;
            for (var j = 0; j < payload.discountMatrixWrapperlist.length; j++) {

              if (discountIds[i].usageGrp === payload.discountMatrixWrapperlist[j].usageGroup) {
                objDiscount.discountAppliedOn = payload.discountMatrixWrapperlist[j].usageGroup;
                objDiscount.discountValue = payload.discountMatrixWrapperlist[j].discountTo + " " + payload.discountMatrixWrapperlist[j].uom;
                console.log(objDiscount);
                props.addComponent(objDiscount);
                break;
              }
            }
          }

          window.location.reload();
          this.setState({
            componentIdDiscount: response.data.data,
            loading: false,
          });
        })
        .catch((error) => {
          setLoading(false);
          console.log(error);
        });
    } else {

      const discountMatrixWrapperList = Object.keys(values).map((v) => {
        return {
          usageGroup: v,
          ugcType: props.ugcType,
          ugcSubType1: props.ugcSubType1,
          ugcSubType2: props.ugcSubType2,
          ugcSubType3: props.ugcSubType3,
          classifier1: props.classifier1,
          classifier3: props.classifier3,
          componentLevel: props.componentLevel || "/service",
          discountAppliedOn: "USAGE",
          timeBand: "24_hr",
          priceType: "RC",
          startDate: date,
          endDate: null,
          createdDate: date,
          updatedDate: date,
          updatedBy: props.userInfo.id,
          // ...values[v],
          componentId: values[v].discountId,
          usageGroup: values[v].usageGrp,
          discountTo: values[v].discountTo,
          uom: values[v].uom,
          postusageRate: values[v].postusageRate,
          postusageUom: values[v].postusageUom,
          immediateTerm: values[v].immediateTerm,
          immediateUnits: values[v].immediateUnits,
          discountValue: values[v].discountValue || "100",
          discountFrom: values[v].discountFrom || "0",
        };
      });
  
      const payload1 = {
        id: props.id,
        releaseId: props.releaseData.releaseId,
        discountMatrixWrapperlist: discountMatrixWrapperList,
      };



      console.log("put request");

      payload['componentId'] = payload.discountMatrixWrapperlist[0].discountId;
      console.log(payload1);
      axios
        .post("irdiscount/matrix", payload1, {
          headers: {
            opId: props.userInfo.opId,
            buId: props.userInfo.buId,
            createdBy: props.userInfo.id,
          },
        })
        .then((response) => {
          setLoading(true);
          //--- new code--

          var discountIds = response.data.data;
          console.log(payload);

          console.log(response.data.data);
          //window.location.reload();
          let objDiscount = {};
          objDiscount.discountId = payload1.componentId;
          objDiscount.discountAppliedOn = payload1.discountMatrixWrapperlist[0].discountAppliedOn;
          objDiscount.discountValue = payload1.discountMatrixWrapperlist[0].discountTo + " " + payload.discountMatrixWrapperlist[0].uom;

          //objDiscount.discountValue = discountIds[i].discountId;
          //this.state.componentIdDiscount = payload.componentId;

          
          props.updateComponentDiscount(
            objDiscount,
            payload.componentId
          );

          window.location.reload();
          this.setState({
            componentIdDiscount: payload.componentId,
            loading: false,
          });
        })
        .catch((error) => {
          setLoading(false);
          console.log(error);
        });

    }

  };

  return (
    <div>
      <form onSubmit={(e) => saveMatrix(e)}>

        <TableContainer component={Paper} style={{ marginTop: "10px" }}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>USG Group</TableCell>
                <TableCell>Discount Value</TableCell>
                <TableCell>Discount From</TableCell>
                <TableCell>Discount To</TableCell>
                <TableCell>UOM</TableCell>
                <TableCell>Postusage Rate</TableCell>
                <TableCell>Postusage UOM</TableCell>
                <TableCell>Immediate Term</TableCell>
                <TableCell>Immediate Unit</TableCell>
                {/* <TableCell>Price Type</TableCell>
              <TableCell>Discount Applied On</TableCell>
              <TableCell>Discount Level</TableCell>
              <TableCell>Time Band</TableCell> */}
              </TableRow>
            </TableHead>
            <TableBody>
              {data.map((usgGroup) => (
                <TableRow>
                  <TableCell style={{ minWidth: "320px" }}>
                    {usgGroup}
                  </TableCell>
                  <TableCell>
                    <Input
                      table
                      required
                      refType="NumberInput"
                      value={renderValue(usgGroup, "discountValue") || "100"}
                      changed={(el) =>
                        updateValues(usgGroup, "discountValue", el.target.value)
                      }
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      table
                      required
                      refType="NumberInput"
                      value={renderValue(usgGroup, "discountFrom") || "0"}
                      changed={(el) =>
                        updateValues(usgGroup, "discountFrom", el.target.value)
                      }
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      table
                      required
                      refType="NumberInput"
                      value={renderValue(usgGroup, "discountTo")}
                      changed={(el) =>
                        updateValues(usgGroup, "discountTo", el.target.value)
                      }
                    />
                  </TableCell>
                  <TableCell style={{ minWidth: "160px" }}>
                    <Input
                      table
                      required
                      refType="SelectInput"
                      refLovs={UOM.refLovs}
                      value={renderValue(usgGroup, "uom")}
                      changed={(el) => updateValues(usgGroup, "uom", el)}
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      table
                      required
                      refType="NumberInput"
                      value={renderValue(usgGroup, "postusageRate")}
                      changed={(el) =>
                        updateValues(usgGroup, "postusageRate", el.target.value)
                      }
                    />
                  </TableCell>
                  <TableCell style={{ minWidth: "160px" }}>
                    <Input
                      table
                      required
                      refType="SelectInput"
                      refLovs={PostUOM.refLovs}
                      value={renderValue(usgGroup, "postusageUom")}
                      changed={(el) =>
                        updateValues(usgGroup, "postusageUom", el)
                      }
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      table
                      required
                      refType="NumberInput"
                      value={renderValue(usgGroup, "immediateTerm")}
                      changed={(el) =>
                        updateValues(usgGroup, "immediateTerm", el.target.value)
                      }
                    />
                  </TableCell>
                  <TableCell style={{ minWidth: "160px" }}>
                    <Input
                      table
                      required
                      refType="SelectInput"
                      refLovs={UNITS.refLovs}
                      value={renderValue(usgGroup, "immediateUnits")}
                      changed={(el) => updateValues(usgGroup, "immediateUnits", el)}
                    />
                  </TableCell>
                  {/* <TableCell style={{ minWidth: "160px" }}>
                  <Input
                    table
                    refType="SelectInput"
                    refLovs={["Recurring", "Non Recurring"]}
                    value={renderValue(usgGroup, "priceType")}
                    changed={(el) => updateValues(usgGroup, "priceType", el)}
                  />
                </TableCell>
                <TableCell>USAGE</TableCell>
                <TableCell style={{ minWidth: "160px" }}>
                  <Input
                    table
                    refType="SelectInput"
                    refLovs={["SERVICE", "ACCOUNT"]}
                    value={renderValue(usgGroup, "componentLevel")}
                    changed={(el) =>
                      updateValues(usgGroup, "componentLevel", el)
                    }
                  />
                </TableCell>
                <TableCell>24_Hr</TableCell> */}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Button
            type="submit"
            // onClick={() => saveMatrix()}
            style={{
              background: "#02bfa0",
              textTransform: "none",
              marginTop: "1%",
            }}
          >
            {loading ? "Saving..." : "Save"}
          </Button>
        </div>
      </form>
    </div>
  );

};

export default DiscountPricingMatrix;
