/** @format */

import React, { Component } from 'react';
import { Route, Switch, Redirect, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Login from './containers/Login/Login';
import Dashboard from './containers/Dashboard/Dashboard';
import Layout from './HOC/Layout/Layout';
import Worklist from './containers/Worklist/Worklist';
import EditRelease from './containers/EditRelease/EditRelease';
import PlanConfiguration from './containers/Entities/Package/PlanConfiguration';
import * as actionTypes from './store/actions/actionTypes';
import ProductConfiguration from './containers/Entities/Product/ProductConfiguration';
import Contract from './containers/EntityCreation/Contract';
import ContractProfile from './containers/EntityCreation/ContractProfile';
import Attribute from './containers/EntityCreation/Attribute';
import RatePlan from './containers/EntityCreation/RatePlan/RatePlan';
import WorkflowAdmin from './containers/WorkflowAdmin/WorkflowAdmin';
import AllReleases from './containers/AllReleases/AllReleases';
import axios from 'axios';
import ReleaseReport from './containers/Library/ReleaseReport';

class App extends Component {
	componentDidMount() {
		console.log('enviroment variable');
		console.log(process.env.REACT_APP_URL);
		// console.log('reading cookies')

		// let readCookie = setInterval(() => {
		//     let obj = {
		//         "firstName": this.getCookie('firstName'),
		//         "lastName": this.getCookie('lastName'),
		//         "opId": this.getCookie('opid'),
		//         "email": this.getCookie('email'),
		//         "buId": this.getCookie('buid'),
		//         "id": this.getCookie('username1'),
		//         "group": this.getCookie('group')
		//             ? this.getCookie('group').split(",") : ['ProductManager'],
		//         'jwt': this.getCookie('token')
		//     }
		//     this.props.onLogin(obj)
		//     if (Object.keys(this.props.userInfo).length > 0 && this.props.userInfo.firstName) {
		//         console.log('read cookies')
		//         clearInterval(readCookie)
		//         if (this.props.userInfo.group.includes("ProductManager"))
		//             this.props.history.push('/dashboard')
		//         else if (this.props.userInfo.group.includes("WorkflowAdmin"))
		//             this.props.history.push('/WorkflowAdminDashboard')
		//         else
		//             this.props.history.push('/worklist')

		//     }
		// }, 1000)
	}

	getCookie(cname) {
		var name = cname + '=';
		var decodedCookie = decodeURIComponent(document.cookie);
		var ca = decodedCookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') {
				c = c.substring(1);
			}
			if (c.indexOf(name) == 0) {
				return c.substring(name.length, c.length);
			}
		}
		return '';
	}

	render() {
		let routes = (
			<Switch>
				<Route
					path='/login'
					exact
					render={() => {
						console.log('object');
						let obj = {
							firstName: this.getCookie('firstName'),
							lastName: this.getCookie('lastName'),
							opId: this.getCookie('opid'),
							email: this.getCookie('email'),
							buId: this.getCookie('buid'),
							id: this.getCookie('username1'),
							group: this.getCookie('group')
								? this.getCookie('group').split(',')
								: ['ProductManager'],
							jwt: this.getCookie('token'),
							// "group": [
							//     this.getCookie('group') ? this.getCookie('group') : 'ProductManager'
							// ]
						};
						console.log('name');
						console.log(this.getCookie('firstName'));
						console.log(obj);
						if (!this.getCookie('firstName')) {
							window.location.replace(
								'https://ace.pre.airtelworld.in/EPCLogin'
							);
						}
						this.props.onLogin(obj);

						axios
							.get(
								process.env.REACT_APP_URL + 'SelectApprovers/roleuimapping',
								{
									headers: {
										opId: obj.opId,
										buId: obj.buId,
										lob: 'Postpaid',
										Authorization: 'Bearer ' + obj.jwt,
									},
								}
							)
							.then((res) => {
								console.log(res);
								let approverData = res.data.data;
								approverData = {
									...approverData,
									['ProductManager']: 'Product Manager',
								};
								console.log(approverData);

								this.props.onApproversData(approverData);

								// if (obj.group.includes("ProductManager"))
								//     this.props.history.push('/dashboard')
								// else if (obj.group.includes("WorkflowAdmin"))
								//     this.props.history.push('/WorkflowAdminDashboard')
								// else
								//     this.props.history.push('/worklist')
							})
							.catch((error) => {
								console.log(error);
								// this.props.onLogin(obj)
								// if (obj.group.includes("ProductManager"))
								//     this.props.history.push('/dashboard')
								// else if (obj.group.includes("WorkflowAdmin"))
								//     this.props.history.push('/WorkflowAdminDashboard')
								// else
								//     this.props.history.push('/worklist')
							});
					}}
				/>
				<Route path='/dashboard' exact component={Dashboard} />
				<Route path='/worklist' exact component={Worklist} />
				<Route path='/WorkflowAdminDashboard' exact component={WorkflowAdmin} />
				<Redirect to='/login' />
			</Switch>
		);

		if (
			Object.keys(this.props.userInfo).length > 0 &&
			this.props.userInfo.firstName
		) {
			if (this.props.userInfo.group.includes('ProductManager')) {
				routes = (
					<Switch>
						<Route
							path='/'
							exact
							render={() => {
								this.props.onReleaseExit();
								return <Dashboard />;
							}}
						/>
						<Route path='/worklist' exact component={Worklist} />
						<Route path='/editRelease' exact component={EditRelease} />
						<Route
							path='/planConfiguration'
							exact
							component={PlanConfiguration}
						/>
						<Route
							path='/productConfiguration'
							exact
							component={ProductConfiguration}
						/>
						<Route path='/contractsCreation' exact component={Contract} />
						<Route
							path='/contractProfileCreation'
							exact
							component={ContractProfile}
						/>
						<Route path='/attributeConfiguration' exact component={Attribute} />
						<Route path='/ratePlanConfiguration' exact component={RatePlan} />
						<Route path='/allReleases' exact component={AllReleases} />
						<Route path='/releaseReport' exact component={ReleaseReport} />

						<Redirect to='/' />
					</Switch>
				);
			} else if (this.props.userInfo.group.includes('WorkflowAdmin')) {
				routes = (
					<Switch>
						<Route
							path='/WorkflowAdminDashboard'
							exact
							component={WorkflowAdmin}
						/>
						<Route path='/allReleases' exact component={AllReleases} />
						<Redirect to='/WorkflowAdminDashboard' />
					</Switch>
				);
			} else {
				routes = (
					<Switch>
						<Route path='/worklist' exact component={Worklist} />
						<Route path='/allReleases' exact component={AllReleases} />
						<Redirect to='/worklist' />
					</Switch>
				);
			}
		}

		return (
			<div
				style={
					this.props.location.pathname != '/login'
						? {
								transform: 'scale(.8)',
								width: '125vw',
								height: '100vh',
								marginLeft: '-12.7vw',
								marginTop: '-10vh',
						  }
						: null
				}>
				<Layout>{routes}</Layout>
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	return {
		userInfo: state.login.loggedInUserInfo,
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		onReleaseExit: () =>
			dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
		onLogin: (loggedInUserInfo) =>
			dispatch({
				type: actionTypes.LOGIN_SUCCESS,
				loggedInUserInfo: loggedInUserInfo,
			}),
		onApproversData: (approversData) =>
			dispatch({
				type: actionTypes.APPROVER_MAP,
				approversData: approversData,
			}),
	};
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(App));
