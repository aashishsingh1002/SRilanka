import React, { useState, useEffect, useRef } from 'react';
import { TextField, ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';
import moment from 'moment';
import { SETUP_LISTS } from './setup-constants';
import axios from '../../../axios-epc';
import MaterialTable, { MTableToolbar } from '@material-table/core';
import { TABLE_CONFIG, THEME_OVERRIDE, TABLE_ICONS } from './setup-config';
import { useSelector } from 'react-redux';
import Button from '@material-ui/core/Button';
import SaveAlt from '@material-ui/icons/SaveAlt';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import { CustomPaginationComponent } from '../common/table-config';
import GetAppIcon from '@material-ui/icons/GetApp';
import { saveAsExcel } from '../common/utils';
import { Autocomplete } from '@material-ui/lab';
import { fetchDealCaptureDD } from '../../../store/actions/actionCreators';
import { useDispatch } from 'react-redux';
import { connect } from 'react-redux';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import UploadButton from '../common/Upload/UploadButton';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import YearPicker from '../../../UI/YearPicker/YearPicker';
import { objAppendOnUpdate } from '../../../helpers/functions';
import Snackbar from '../../../UI/Snackbar/Snackbar';

const theme = createMuiTheme({
  overrides: THEME_OVERRIDE,
});

const useStyles = (theme) => ({});

const TiersTable = ({ setLoading, schema, id }) => {
  const dispatch = useDispatch();
  // selectors
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const dropdowns = useSelector((state) => state.dropdownData);
  // States

  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loadingTable, setLoadingTable] = useState(true);
  const [selected, setSelected] = useState();
  const [selectedRows, setSelectedRows] = useState([]);
  const [openSnack, setOpenSnack] = useState(false);
  const [messageSnack, setMessagesnack] = useState('');
  const selectTable = useRef();
  const [quarter, setQuarter] = useState([]);
  const [quarterLoaded, setQuarterLoaded] = useState(false);

  // Functions

  const valueCheck = (val) => {
    if (val < 0) {
      return 0;
    }
    return val;
  };

  const noneditable = (rowData) => {
    if (rowData.refName === 'type' && rowData.entityName === 'fixedCost') {
      return 'onAdd';
    }
    if (rowData.refName === 'type' && rowData.entityName === 'variableCost') {
      return 'onAdd';
    }
    if (
      rowData.refName === 'quarter' &&
      rowData.entityName === 'Exchange Rate'
    ) {
      return 'onAdd';
    }

    return 'always';
  };
  const getData = () => {
    if (!selected) {
      return;
    }
    setLoadingTable(true);

    return axios
      .get(selected.GET)
      .then((res) => {
        if (res) {
          const { data } = res.data;
          const mapData = data.map((row) => ({ ...row, tableData: '' }));
          setData(mapData);
        }
        setLoadingTable(false);
      })
      .catch((error) => {
        setLoading(false);
        setLoadingTable(false);
      });
  };
  const tableValidations = (rowData) => {
    if (!selected) return;
    let shouldReturn = true;
    selected.validations.forEach((row) => {
      if (row.required) {
        if (!rowData[row.name]) {
          shouldReturn = false;
        }
      }
    });
    return shouldReturn;
  };
  // const validation = (rowData) => {
  //   console.log('rowData', rowData);
  //   return !!rowData;
  // };

  const getQuarters = () => {
    setLoadingTable(true);
    axios
      .get('/mtn/deal/basicInfo/Exchangequarters')
      .then((res) => {
        if (res) {
          setQuarter(res.data.data);
          setQuarterLoaded(true);
          setLoadingTable(false);
        }
      })
      .catch((error) => {});
  };

  const mapColumns = () => {
    let tmpColumns = schema.map((row) => {
      return {
        title: row.uiName,
        field: row.refName,
        sorting: false,
        editable: noneditable(row),
        // cellStyle: { width: "30%" },

        validate: tableValidations,

        render: (rowData) => {
          return (
            row.refName &&
            rowData[row.refName] && (
              <span
                style={{
                  display: 'block',
                  width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                }}
              >
                {' '}
                {rowData[row.refName]}
              </span>
            )
          );
        },
        editComponent: (props) => {
          console.log(selected.name);
          if (row.refName === 'currency' && selected.name === 'Exchange Rate') {
            console.log(row.refLovs);
            if (!row.refLovs) return '';
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '10vw' }}
                  options={row.refLovs}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          // if (row.refName === 'year') {
          //   return <YearPicker value={props.value} onChange={props.onChange} />;
          // }

          if (row.refType === 'SelectInput') {
            if (!row.refLovs) return '';
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '10vw' }}
                  options={row.refLovs}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }

          if (row.refName === 'quarter' && selected.name === 'Exchange Rate') {
            console.log(dropdowns.quarter);
            console.log(quarter);
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '15vw' }}
                  options={
                    quarter &&
                    quarter.map((q) => {
                      return q.quarter;
                    })
                  }
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          if (
            props.columnDef.tableData.columnOrder === 0 &&
            props.rowData.tableData
          ) {
            return <span>{props.value}</span>;
          }

          // let type = 'text';
          // if (selected.validations) {
          //   const validation = selected.validations.find(
          //     (t) => t.name === props.columnDef.field
          //   );

          //   if (validation && validation.type) {
          //     type = validation.type;
          //   }
          // }
          let checkOnkeydown = '';
          let type = 'text';
          let isRequired = false;
          if (selected.validations) {
            const validation = selected.validations.find(
              (t) => t.name === props.columnDef.field
            );
            if (validation) {
              if (validation.type) {
                type = validation.type;
              }
              checkOnkeydown = !!validation.positiveVal;
              isRequired = !!validation.required;
            }
          }
          return (
            <TextField
              onKeyDown={(e) =>
                checkOnkeydown === true
                  ? ['+', '-'].includes(e.key) && e.preventDefault()
                  : ''
              }
              error={isRequired && !props.value}
              helperText={isRequired && !props.value && 'Required'}
              type={type}
              style={{
                width: '20vw',
                margin: 10,
                fontSize: 12,
              }}
              fullWidth
              value={valueCheck(props.value)}
              onChange={(event) => {
                props.onChange(event.target.value);
              }}
            />
          );
        },
      };
    });

    setColumns(tmpColumns);
  };

  const saveAsExcel = async (derived = false) => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(selected.name || 'Setup');
    let sheetColumns = schema.map((row) => ({
      header: row.uiName,
      key: row.refName,
      width: 25,
    }));

    worksheet.columns = sheetColumns;

    selectedRows.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    setLoading(true);
    const buf = await workbook.xlsx.writeBuffer();
    setLoading(false);

    const appendName = derived ? 'Derived_Export' : 'UI_Export';
    saveAs(new Blob([buf]), `${selected.name || 'Setup'}_${appendName}.xlsx`);
  };

  const saveAsExcelSetUp = async (derived = false) => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(selected.name || 'Setup');
    let sheetColumns = schema.map((row) => ({
      header: row.uiName,
      key: row.refName,
      width: 25,
    }));

    worksheet.columns = sheetColumns;

    selectTable.current.state.data.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    setLoading(true);
    const buf = await workbook.xlsx.writeBuffer();
    setLoading(false);

    const appendName = derived ? 'Derived_Export' : 'UI_Export';
    saveAs(new Blob([buf]), `${selected.name || 'Setup'}_${appendName}.xlsx`);
  };

  // Did Mount
  useEffect(() => {
    dispatch(fetchDealCaptureDD('quarter'));
    dispatch(fetchDealCaptureDD('Exchangequarters'));
  }, []);

  useEffect(() => {
    getQuarters();
  }, []);

  useEffect(() => {
    if (id) {
      const select = SETUP_LISTS.find((list) => list.id === id);
      setSelected(select);
    }
  }, [id]);

  useEffect(() => {
    if (selected && dropdowns.ExchangequartersLoaded && quarterLoaded) {
      getData().then(() => mapColumns());
    }
  }, [selected, dropdowns, quarterLoaded]);

  const uploadBtn = () => {
    if (selected && selected.id === 'latestCompetitor') {
      return {
        tooltip: 'Upload',
        icon: () => (
          <UploadButton
            uploadUrl={selected && selected.UPLOAD_URL + userInfo.id}
            valiationUrl={selected && selected.VALIDATION_URL + userInfo.id}
            excelTabName={selected && selected.excelTabName}
            schema={schema.filter((row) => row.groupName === 'UI Input')}
            uploadName={`${selected && selected.name}`}
            title='Latest Competitor'
            autoCloseOnSuccess={false}
            snackMessageOnSuccess={
              'Data being Uploaded, Please Check the Validation Logs for Completion and Errors.'
            }
            onClose={() => getData().then(() => setLoadingTable(false))}
            onSuccess={() => null}
            // onSuccess={() =>
            //   getData().then(() => {
            //     setLoadingTable(false);
            //     setOpenSnack(true);
            //     setMessagesnack(
            //       'Data being Uploaded, Please Check the Validation Logs for Completion and Errors.'
            //     );
            //   })
            // }
          />
        ),
        isFreeAction: true,
      };
    }
  };
  // Render
  return (
    <ThemeProvider theme={theme}>
      {console.log(selectedRows)}
      <Snackbar
        open={openSnack}
        message={messageSnack}
        onClose={(event, reason) => {
          if (reason === 'clickaway') {
            return;
          }
          setOpenSnack(false);
        }}
      />
      <MaterialTable
        style={{ padding: '20px' }}
        components={{
          Toolbar: (props) => (
            <div>
              <div
                style={{
                  fontSize: '18px',
                  fontWeight: '600',
                  marginLeft: '24px',
                }}
              >
                {props.title}
              </div>
              <div>
                <MTableToolbar {...props} />
              </div>
            </div>
          ),
          Pagination: (props) => {
            return <CustomPaginationComponent {...props} />;
          },
        }}
        tableRef={selectTable}
        isLoading={loadingTable}
        icons={TABLE_ICONS}
        title={`${selected && selected.name}`}
        columns={columns}
        data={data}
        options={TABLE_CONFIG}
        actions={[
          {
            tooltip: 'Export',
            icon: GetAppIcon,
            onClick: () => {
              saveAsExcel(false);
            },
          },
          uploadBtn(),
          {
            icon: () => (
              <Button
                variant='contained'
                style={{
                  textTransform: 'capitalize',
                  background: '#ffcc00',
                  letterSpacing: '-1px',
                  fontWeight: '600',
                  color: '#000',
                  fontSize: '16px',
                  borderRadius: '50px',
                  padding: '6px 32px',
                  '&:hover': {
                    opacity: 0.8,
                    background: '#ffcc00',
                  },
                }}
                onClick={() => {
                  saveAsExcelSetUp();
                }}
              >
                Export
              </Button>
            ),
            isFreeAction: true,
          },
        ]}
        onSelectionChange={(rowSelection) => {
          console.log(rowSelection);
          setSelectedRows(rowSelection);
        }}
        editable={{
          onBulkUpdate: (changes) =>
            new Promise((resolve, reject) => {
              setTimeout(() => {
                console.log(changes);
                if (Object.keys(changes).length > 0) {
                  let payload = [];
                  setLoadingTable(true);
                  Object.keys(changes).map((row) => {
                    let payloadData = { ...changes[row].newData };
                    payloadData.createdBy = userInfo.id;
                    payloadData.createdDate = moment().format('DD-MM-YYYY');
                    payload.push(payloadData);
                  });
                  axios
                    .post(
                      ['Exchange Rate'].includes(selected.name)
                        ? selected.UPDATE_URL
                        : selected.POST,
                      payload
                    )
                    .then((response) => {
                      getData().then(() => {
                        setLoadingTable(false);
                        setOpenSnack(true);
                        setMessagesnack('Saved Successfully!');
                        resolve();
                      });
                    })
                    .catch((error) => {
                      setLoadingTable(false);
                      resolve();
                    });
                } else resolve();
              }, 1000);
            }),
          onRowAdd: (newData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              payload.createdBy = userInfo.id;
              payload.createdDate = moment().format('DD-MM-YYYY');
              setLoadingTable(true);
              axios
                .post(selected.POST, [payload])
                .then((response) => {
                  if (response) {
                    let pkgData = [...data, newData];
                    setData(pkgData);

                    getData().then(() => {
                      setLoadingTable(false);
                      setOpenSnack(true);
                      setMessagesnack('Saved Successfully!');
                      resolve();
                    });
                  }
                  setLoadingTable(false);
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
          onRowUpdate: (newData, oldData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              console.log(newData);
              payload.createdBy = userInfo.id;
              payload.createdDate = moment().format('DD-MM-YYYY');
              const modPayloadData = objAppendOnUpdate(payload, userInfo.id, {
                oldArr: data,
                identifier: 'refId',
                val: payload['refId'],
              });

              setLoadingTable(true);
              axios
                .post(
                  ['Exchange Rate'].includes(selected.name)
                    ? selected.UPDATE_URL
                    : selected.POST,
                  [modPayloadData]
                )
                .then((response) => {
                  const dataUpdate = [...data];
                  const index = oldData.tableData.id;
                  dataUpdate[index] = newData;
                  setData(dataUpdate);
                  getData().then(() => {
                    setLoadingTable(false);
                    setOpenSnack(true);
                    setMessagesnack('Saved Successfully!');
                    resolve();
                  });
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
        }}
        localization={{
          body: {
            emptyDataSourceMessage: '',
          },
        }}
      />
    </ThemeProvider>
  );
};

export default withStyles(useStyles)(TiersTable);
