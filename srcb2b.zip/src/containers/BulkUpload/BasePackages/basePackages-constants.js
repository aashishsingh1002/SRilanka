export const ENTITY_NAME = 'basePackages';
export const DERIVED_URL = 'mtn/deal/basepkgder';

export const BASEPACKAGES_LISTS = [
  {
    id: 'basepackages',
    name: 'Base Packages',
    derivedExcelName: 'Basepackages',
    entity: 'bulkUploadBasePackages',
    GET: 'mtn/deal/basepkgui',
    POST: 'mtn/deal/storebasepkgui',
    VALIDATION_URL: 'mtn/deal/GetBasePackageslog?createdBy=',
    DERIVED_URL: 'mtn/deal/basepkgder',
    UPLOAD_URL: 'mtn/deal/uploadbasepkgs?createdBy=',
    excelTabName: 'XMtnBasePackagesUiTab',
    identifier: 'package1',
    identifierPayload: 'basepkg',
    validations: [
      {
        name: 'package1',
        required: true,
      },
      {
        name: 'class1',
        required: true,
      },
      {
        name: 'subscription',
        type: 'number',
      },
      {
        name: 'balancingValues',
        type: 'number',
      },
      {
        name: 'oneCi',
        type: 'number',
      },
      {
        name: 'sixCi',
        type: 'number',
      },
      {
        name: 'twelveCi',
        type: 'number',
      },
      {
        name: 'eighteenCi',
        type: 'number',
      },
      {
        name: 'thirtySixCi',
        type: 'number',
      },
      {
        name: 'twentyFourCi',
        type: 'number',
      },
      {
        name: 'oneComm',
        type: 'number',
      },
      {
        name: 'last6MonthVolume',
        type: 'number',
      },
      {
        name: 'uyo',
        type: 'number',
      },
      {
        name: 'stdUyo',
        type: 'number',
      },

      {
        name: 'data1',
        required: true,
      },
      {
        name: 'sms',
        required: true,
      },

      {
        name: 'other1',
        required: true,
      },
      {
        name: 'onnetMinutesBundle',
        required: true,
      },
      {
        name: 'anytimeMinutesBundle',
        required: true,
      },
      {
        name: 'vas',
        required: true,
      },
      {
        name: 'basePackage',
        required: true,
      },
      {
        name: 'last6MonthPercentContr',
        type: 'number',
      },
    ],
  },
  {
    id: 'packageRange',
    name: 'Package Range',
    entity: 'packageRange',
    GET: 'mtn/deal/ref/pkgRange',
    POST: 'mtn/deal/ref/storePkgRange',
    UPLOAD_URL: 'mtn/deal/ref/uploadpkgRanges?createdBy=',
    VALIDATION_URL: 'mtn/deal/ref/Getpackagerangelogs?createdBy=',
    excelTabName: 'XMtnPackageRangeTab',
    validations: [
      {
        name: 'package1',
        required: true,
      },
      // {
      //   name: 'stdSub',
      //   type: 'number',
      // },
      // {
      //   name: 'twentyfourMLineCommission',
      //   type: 'number',
      //   required: true,
      // },
    ],
  },
  // {
  //   id: 'linecommission',
  //   name: 'Line Commission',
  //   entity: 'lineComm',
  //   GET: 'mtn/deal/linecomm',
  //   POST: 'mtn/deal/storelinecomm',
  //   UPLOAD_URL: 'mtn/deal/uploadlinecomm',
  //   excelTabName: 'XMtnLineCommsUiTab',
  //   validations: [
  //     // {
  //     //   name: "package",
  //     //   required: true,
  //     // },
  //     {
  //       name: 'stdSub',
  //       type: 'number',
  //     },
  //     {
  //       name: 'twentyfourMLineCommission',
  //       type: 'number',
  //       required: true,
  //     },
  //   ],
  // },
  // {
  //   id: 'cisub',
  //   name: 'CI Sub',
  //   entity: 'ciSubs',
  //   GET: 'mtn/deal/cisubui',
  //   POST: 'mtn/deal/storecisubui',
  //   DERIVED_URL: 'mtn/deal/cisubder',
  //   UPLOAD_URL: 'mtn/deal/uploadcisubui',
  //   excelTabName: 'XMtnCiAndSubsUiTab',
  //   identifier: 'refId',
  //   identifierPayload: 'refId',
  //   validations: [
  //     // {
  //     //   name: "packageCode",
  //     //   required: true,
  //     // },
  //     {
  //       name: 'packag',
  //       required: true,
  //     },
  //     // {
  //     //   name: "thirtysixCi",
  //     //   type: "number",

  //     // },
  //     {
  //       name: 'twentyfourCi',
  //       type: 'number',
  //       required: true,
  //     },
  //     // {
  //     //   name: "subscriptionIncl",
  //     //   type: "number",
  //     //   required: true,
  //     // },
  //     // {
  //     //   name: "linecommPackage",
  //     //   required: true,
  //     // },
  //   ],
  // },
];
