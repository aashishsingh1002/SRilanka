import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import moment from 'moment';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { Picky } from 'react-picky';
import 'react-picky/dist/picky.css';
import './input.css';
// import classes from './Input.css';

const Input = (props) => {
	let inputElement = null;
	// const inputClasses = [classes.InputElement];

	// if (props.invalid && props.shouldValidate && props.touched) {
	//     inputClasses.push(classes.Invalid);
	// }

	switch (props.refType) {
		case 'NumberInput':
			let nbrValue = props.value ? props.value : '';
			inputElement = (
				<TextField
					type="number"
					fullWidth
					value={nbrValue}
					onChange={props.changed}
					disabled={props.disabled}
					required={props.required}
				/>
			);
			break;
		case 'TextInput':
			let txtValue = props.value ? props.value : '';
			inputElement = (
				<TextField
					fullWidth
					value={txtValue}
					onChange={props.changed}
					disabled={props.disabled}
					required={props.required}
				/>
			);

			break;
		case 'Checkbox':
			let chckValue = false;
			if (props.value == 'Y' || props.value == true) chckValue = true;
			inputElement = (
				<FormControlLabel
					control={
						<Checkbox
							checked={chckValue}
							onChange={props.changed}
							color="primary"
							disabled={props.disabled}
						/>
					}
				/>
			);
			break;
		case 'TextArea':
			let txtAreaValue = props.value ? props.value : '';
			inputElement = (
				<TextField
					fullWidth
					value={txtAreaValue}
					onChange={props.changed}
					disabled={props.disabled}
					required={props.required}
				/>
			);

			break;
		case 'Date':
			let value = props.value
				? moment(props.value).format('YYYY-MM-DD')
				: moment().format('YYYY-MM-DD');
			inputElement = (
				<TextField
					fullWidth
					type="date"
					disabled={props.disabled}
					value={value}
					onChange={props.changed}
					InputLabelProps={{
						shrink: true,
					}}
				/>
			);
			break;

		case 'SelectInput':
			let selValue = props.value ? props.value : '';
			inputElement = (
				<React.Fragment>
					<Picky
						clearFilterOnClose={true}
						id="picky"
						keepOpen={false}
						disabled={props.disabled}
						required={props.required}
						options={props.refLovs}
						value={selValue}
						multiple={false}
						includeFilter={true}
						onChange={props.changed}
						dropdownHeight={300}
						render={({ style, isSelected, item, selectValue }) => {
							return (
								<li
									style={style}
									className={isSelected ? 'selected' : ''}
									key={item}
									onClick={() => selectValue(item)}>
									<span
										style={{
											display: 'block',
											width: '100%',
											wordWrap: 'break-word',
										}}>
										{item}
									</span>
								</li>
							);
						}}
					/>
					{props.required && (
						<input
							required
							value={selValue}
							style={{
								opacity: 0,
								position: 'absolute',
								zIndex: -1,
							}}
						/>
					)}
				</React.Fragment>
			);

			// <FormControl style={{ minWidth: '100%' }}>
			//     <Select
			//         value={selValue}
			//         onChange={props.changed}
			//         disabled={props.disabled}
			//         required={props.required}
			//     >
			//         {
			//             props.refLovs.map(lov => {
			//                 return <MenuItem key={lov} value={lov}>{lov}</MenuItem>
			//             })
			//         }
			//     </Select>
			// </FormControl>

			break;

		default:
			inputElement = (
				<TextField
					{...props}
					fullWidth
					value={props.value}
					onChange={props.changed}
					disabled={props.disabled}
					required={props.required}
				/>
			);
	}

	let input = (
		<Grid item xs={12} sm={4} md={2}>
			<Box>
				<span>
					{props.uiName}
					{props.required && (
						<span
							style={{
								color: 'red',
								marginLeft: '5px',
								fontWeight: 'bold',
							}}>
							*
						</span>
					)}
				</span>
			</Box>
			<Box mt={2}>{inputElement}</Box>
		</Grid>
	);
	if (props.table) return inputElement;
	if (props.resize)
		input = (
			<Grid item xs={12} sm={5}>
				<Box>
					<span>
						{props.uiName}
						{props.required && (
							<span
								style={{
									color: 'red',
									marginLeft: '5px',
									fontWeight: 'bold',
								}}>
								*
							</span>
						)}
					</span>
				</Box>
				<Box mt={2}>{inputElement}</Box>
			</Grid>
		);

	return input;
};

export default Input;
