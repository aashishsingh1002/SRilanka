import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import Tooltip from "@material-ui/core/Tooltip";
import axios from 'axios';
import moment from 'moment';
import CopyCloneButton from '../../common/CopyCloneButton';
import Input from '../../UI/Input/Input';
import Grid from '@material-ui/core/Grid';
import * as actionTypes from '../../store/actions/actionTypes';
import Loader from '../../UI/Loader/Loader';
import StyledButton from '../../UI/Button/Button';
import Button from '../../UI/Button/Button';
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Table from '../../UI/Table/Table1';
import IconButton from '@material-ui/core/IconButton';
import AttachmentIcon from '@material-ui/icons/Attachment';
import LibraryBooksOutlinedIcon from '@material-ui/icons/LibraryBooksOutlined';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import SaveIcon from '@material-ui/icons/Save';
import EditIcon from '@material-ui/icons/Edit';
import TextField from '@material-ui/core/TextField';
import MaterialTable from "material-table";
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { forwardRef } from 'react';
import DeleteIcon from '@material-ui/icons/Delete';

const tableIcons = {
  // Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  // Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  // Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  // Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  // DetailPanel: forwardRef((props, ref) => (
  //   <ChevronRight {...props} ref={ref} />
  // )),
  // Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  // Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  // FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  // LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  // NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  // PreviousPage: forwardRef((props, ref) => (
  //   <ChevronLeft {...props} ref={ref} />
  // )),
  // ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  // Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  // SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  // ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  // ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};


const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: "#525354",
    color: "white",
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const theme = createMuiTheme({
  overrides: {
    MuiTable: {
      root: {
        tableLayout: 'fixed',
      },
    },
    MuiTableCell: {
      root: {
        padding: '7px',
        paddingLeft: '10px',
      },
    },
    MuiPaper: {
      width: '100%',
    },
  },
});

const useStyles = (theme) => ({
  cardHeader: {
    paddingBottom: 0,
  },
  subheader: {
    color: "rgba(0, 0, 0, 0.87)",
    fontSize: "16px",
    fontWeight: "600",

  },
  boldText: {
  },
  center: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "96%",
    flexShrink: 0,
  },
});

class ExternalTemplate extends Component {
  _isMounted = false;


  state = {
    postRequest: true,
    dataMyItems: [],
    isEdit: false,


    columnsMyItems: [
      {
        title: 'Template Name',
        field: 'templateName',
      },
      {
        title: 'Template Description',
        field: 'templateDesc',
    
      },
      {
        title: 'Template Column Size',
        field: 'colSize'
      }, {
        title: 'Edit',
        field: 'action',
        filtering: false,

        render: (rowData) => (
          <IconButton
            style={{ marginLeft: '10' }}
            onClick={(event) => {
              console.log(rowData)
              event.stopPropagation();
              this.setState({
                isEdit :true,
                colSize:rowData.colSize,
                templateDesc: rowData.templateDesc,
                templateName: rowData.templateName,
                templateType: rowData.templateType,
                tempId: rowData.tempId,
                templateId: rowData.templateId,


              })

            }}
          >
            <EditIcon />
          </IconButton>
        ),
        sorting: false,
        cellStyle: { width: '7%' },
      },


      {
        title: 'delete',
        field: 'action',
        filtering: false,

        render: (rowData) => (
          <IconButton
            style={{ marginLeft: '10' }}
            onClick={(event) => {
              console.log(rowData)
              event.stopPropagation();
             // templateId: rowData.templateId,
              this.deleteItemsHandler(rowData.templateId);

              // this.setState({
              //   colSize:rowData.colSize,
              //   templateDesc: rowData.templateDesc,
              //   templateName: rowData.templateName,
              //   templateType: rowData.templateType,
              //   tempId: rowData.tempId,
              //   templateId: rowData.templateId,

              // })

            }}
          >
            <DeleteIcon />
          </IconButton>
        ),
        sorting: false,
        cellStyle: { width: '7%' },
      }

    ],
  }



  constructor(props) {
    super(props);

    this.selectTable = React.createRef();
  }
  componentDidMount() {
    this._isMounted = true;

    this.uiFields().then(() => {
      this.teamItemsHandler().then(() => {

      });
    });
  }


  deleteItemsHandler = (templateId) => {
    return axios
      .delete('product/external/delete/template?templateId='+templateId, {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {




        console.log(res);
        // if (this._isMounted) {
        //   this.setState({ dataMyItems: res.data.data });
        // }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
    // } else return Promise.resolve();
  };


  uiFields() {

    console.log('fetching from api');
    console.log(this.props);
    return axios
      .get(
        process.env.REACT_APP_URL + 'config?entityName=external.systemTemplate',
        {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,

          },
        }
      )
      .then((res) => {
        let schema = res.data.data;
        schema = schema.filter((el) => {
          if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
            if (el.refLovs != null)
              el.refLovs = el.refLovs.split(',').map((item) => item.trim());
            else if (el.refLovs == null) el.refLovs = [];
          }
          return el;
        });
        localStorage.setItem('productBasic', JSON.stringify(schema));
        localStorage.productBasic_version = this.state.version;
        if (this._isMounted) this.setState({ schema: schema });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });

  }





  saveProDetailsHandler = (event) => {
    event.preventDefault();
    this.setState({ loading: true });
    let payload = {};
    let date = moment().format('DD-MMM-YY');
    //let templatetAud = {};

    this.state.schema.map((formElement) => {
      if (formElement.refType == 'Date')
        payload[formElement.refName] = moment(
          this.state[formElement.refName]
        ).format('DD-MMM-YY');
      else if (formElement.refType == 'Checkbox')
        payload[formElement.refName] =
          this.state[formElement.refName] === null ||
            this.state[formElement.refName] === undefined
            ? 'N'
            : this.state[formElement.refName];
      else if (formElement.refType == 'TextInput' || 'TextArea')
        payload[formElement.refName] =
          this.state[formElement.refName];
      else
        payload[formElement.refName] =
          this.state[formElement.refName];
    });

    payload.endDate = '30-DEC-31'
    payload.buId = this.props.userInfo.buId;
    payload.opId = this.props.userInfo.opId;
    payload.createdBy = 'pmir';
    payload.createdDate = date;
    payload.catalogId = 'B2C'


    if (!this.state.isEdit) {
      payload.version = '1.0';
      // payload.templatetAud = templatetAud;
      // payload.releaseId = this.props.releaseData.releaseId;
      console.log('post');
      console.log(payload);
      axios
        .post(process.env.REACT_APP_URL + 'product/external/template', payload, {
          headers: {
            // authUserId: this.props.userInfo.id,
            // Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((response) => {
          console.log('new gen product');
          console.log(response);
          let proDetails = { ...response.data.data };
          this.props.onProductEnter(proDetails);

          let searchItems = [
            response.data.data.productId + '/' + response.data.data.productDesc,
          ].concat(this.props.searchItems);
          this.props.setSearchItems(searchItems);

          this.state.schema.map((formElement) => {
            this.setState({
              [formElement.refName]: formElement.refName === 'defaultState' ? response.data.data[formElement.refName].split(',') : response.data.data[formElement.refName],
            });
          });
          this.setState({ postRequest: false, loading: false });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }else{



      // payload.version = '1.0';
       payload.tempId  = this.state.tempId;
       payload.templateId = this.state.templateId;
      payload.updatedDate =date;
      payload.updatedBy = 'pmir';
      //payload.templatetAud = templatetAud;
      // payload.releaseId = this.props.releaseData.releaseId;
      console.log('put');
      console.log(payload);

     

      axios
        .post(
          process.env.REACT_APP_URL + 'product/external/update/template',
          payload,
          {
            headers: {
              //authUserId: this.props.userInfo.id,
              // Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        )
        .then((response) => {
          console.log('new gen product');
          console.log(response);
          let proDetails = { ...response.data.data };
          this.props.onProductEnter(proDetails);

          let searchItems = [
            response.data.data.productId + '/' + response.data.data.productDesc,
          ].concat(this.props.searchItems);
          this.props.setSearchItems(searchItems);

          this.state.schema.map((formElement) => {
            this.setState({
              [formElement.refName]: formElement.refName === 'defaultState' ? response.data.data[formElement.refName].split(',') : response.data.data[formElement.refName],
            });
          });
          this.setState({ putRequest: false, loading: false ,    isEdit :false});
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });


      
    }

  };

  teamItemsHandler = () => {
    return axios
      .get('product/external/getTemplates', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {

        console.log(res);
        if (this._isMounted) {
          this.setState({ dataMyItems: res.data.data });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
    // } else return Promise.resolve();
  };

  render() {
    const { classes } = this.props;

    let externalTemplate = (
      <div>
        <div
          style={{
            marginBottom: '1em',
            display: 'flex',
            justifyContent: 'flex-end',
          }}
        >

        </div>
        <div>
          <h3> External System Template Definition</h3>
        </div>

        <form
          onSubmit={this.saveProDetailsHandler}
          style={{ overflow: 'visible' }}
        >
          <Grid
            container
            alignItems='flex-start'
            spacing={5}
            style={{ overflow: 'visible' }}
          >
            {this.state.schema && this.state.schema.map((formElement) => {

              return (
                <Input
                  key={formElement.refName}
                  {...formElement}
                  value={this.state[formElement.refName]}
                  disabled={formElement.isDisabled == 'Y' ? true : false}
                  required={formElement.isMandatory == 'Y' ? true : false}
                  checkChanged={(event) => {
                    this.setState({
                      [formElement.refName]: event.target.checked ? 'Y' : 'N',
                    });
                  }}
                  changed={(event) => {
                    if (!event.target) {
                      this.setState({
                        [formElement.refName]: event,
                      });
                    } else {
                      // if (event.target.type !== 'checkbox')
                      this.setState({
                        [formElement.refName]: event.target.value,
                      });

                    }
                  }}
                />
              )
            })}
          </Grid>
          {/* {this.props.releaseData.releaseId && ( */}
          <div
            style={{
              display: 'flex',
              justifyContent: 'flex-end',
              alignItems: 'center',
            }}
          >

            <StyledButton
              style={{
                marginLeft: '20px',
                marginTop: '3%',
                background: '#5dc17f',
              }}
              type='submit'

            // className={classes.btn}
            >
              Save
              </StyledButton>
          </div>

        </form>
        <div>
          <h3> Configured System template</h3>
        </div>


        <ThemeProvider theme={theme}>
          <MaterialTable

            title='My Items'
            data={this.state.dataMyItems}
            icons={tableIcons}
            columns={
              this.state.columnsMyItems}



            options={{
              search: false,
              filtering: true,
              pageSize: 8,
              pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
              toolbar: true,
              paging: true,
              rowStyle: {
                fontSize: '14px',
                // fontWeight: "600"
              },
              headerStyle: {
                fontWeight: 'bold',
              },
            }}




          />
        </ThemeProvider>

        {/* <Table
          title='My Items'
          data={this.state.dataMyItems}
          columns={
            this.state.columnsMyItems
 
          }
          pageSize={5}
          fontSize={'14px'}
        /> */}








      </div>
    );

    if (this.state.loading) externalTemplate = <Loader />;
    return externalTemplate;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
    searchItems: state.searchData.searchItems,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onReleaseExit: () =>
      dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
  };
};

//export default ExternalTemplate;
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(withRouter(ExternalTemplate), axios)));