export const ENTITY_NAME = "device";

export const DEVICES_LISTS = [
  {
    id: "device",
    name: "Device",
    entity: "bulkUploadDevices",
    GET: "mtn/deal/deviceui",
    POST: "mtn/deal/storedeviceui",
    DERIVED_URL: "mtn/deal/deviceder",
    UPLOAD_URL: "mtn/deal/uploaddeviceui",
    identifier: "manufacturer",
    excelTabName: "XMtnDevicesUiTab",
  },
  {
    id: "devicePricing",
    name: "Device Pricing",
    entity: "bulkUploadDevicesPricing",
    GET: "mtn/deal/deviceprcui",
    POST: "mtn/deal/storedeviceprcui",
    DERIVED_URL: "mtn/deal/deviceprcder",
    UPLOAD_URL: "mtn/deal/uploaddeviceprcui",
    excelTabName: "XMtnDevicePricingUiTab",
    identifier: "deviceNumber",
    validations: [
      {
        name: "deviceNumber",
        type: "number",
      },
      {
        name: "purchasePrice",
        type: "number",
      },
      {
        name: "tnpRebate",
        type: "number",
      },
      {
        name: "exchangeRateApplied",
        type: "number",
      },
      {
        name: "column1",
        type: "number",
      },
      {
        name: "postpaidLeadSub",
        type: "number",
      },
      {
        name: "postpaidLeadSub",
        type: "number",
      },
      {
        name: "prepaidRrp",
        type: "number",
      },
    ],
  },
];
