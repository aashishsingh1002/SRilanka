import React, { useState, useEffect, useRef } from 'react';
import { TextField, ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';
import moment from 'moment';
import { TIERS_LISTS } from './tiers-constants';
import axios from '../../../axios-epc';
import MaterialTable, { MTableToolbar } from '@material-table/core';
import Button from '@material-ui/core/Button';
import { TABLE_CONFIG, THEME_OVERRIDE, TABLE_ICONS } from './tiers-config';
import { useSelector } from 'react-redux';
import SaveAlt from '@material-ui/icons/SaveAlt';
import GetAppIcon from '@material-ui/icons/GetApp';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import { CustomPaginationComponent } from '../common/table-config';
import { objAppendOnUpdate } from '../../../helpers/functions';
import Snackbar from '../../../UI/Snackbar/Snackbar';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';

const theme = createMuiTheme({
  overrides: THEME_OVERRIDE,
});

const useStyles = (theme) => ({});

const TiersTable = ({ setLoading, schema, id }) => {
  // selectors
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);

  // States
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loadingTable, setLoadingTable] = useState(true);
  const [selected, setSelected] = useState();
  const selectTable = useRef();
  const [selectedRows, setSelectedRows] = useState([]);
  const [openSnack, setOpenSnack] = useState(false);
  const [messageSnack, setMessagesnack] = useState('');
  // Functions
  const valueCheck = (val) => {
    if (val < 0) {
      return 0;
    }
    return val;
  };
  const noneditable = (rowData) => {
    if (rowData.refName === 'range1') {
      return 'never';
    }
    if (rowData.refName === 'from1') {
      return 'onAdd';
    }
    if (rowData.refName === 'minimum') {
      return 'onAdd';
    }
    if (rowData.refName === 'maximum') {
      return 'onAdd';
    }
    if (rowData.refName === 'ref1') {
      return 'onAdd';
    }
    if (rowData.refName === 'subFrom') {
      return 'onAdd';
    }
    if (rowData.refName === 'subTo') {
      return 'onAdd';
    }

    return 'always';
  };
  const tableValidations = (rowData) => {
    if (!selected) return;
    let shouldReturn = true;
    selected.validations.forEach((row) => {
      if (row.required) {
        if (!rowData[row.name]) {
          shouldReturn = false;
        }
      }
    });
    return shouldReturn;
  };
  const getData = () => {
    if (!selected) {
      return;
    }
    setLoadingTable(true);

    return axios
      .get(selected.GET)
      .then((res) => {
        if (res) {
          const { data } = res.data;
          const mapData = data.map((row) => ({ ...row, tableData: '' }));
          setData(mapData);
        }
        setLoadingTable(false);
      })
      .catch((error) => {
        setLoading(false);
        setLoadingTable(false);
      });
  };
  const validation = (rowData) => {
    console.log('rowData', rowData);
    return !!rowData;
  };
  const mapColumns = () => {
    let tmpColumns = schema
      .filter((x) => x.refName !== 'ref')
      .filter((x) => x.refName !== 'ref1')
      .map((row) => {
        return {
          title: row.uiName,
          field: row.refName,
          sorting: false,
          editable: noneditable(row), // row.refName === 'range1' ? 'never' : 'always',
          // cellStyle: { width: "30%" },
          validate: tableValidations,
          render: (rowData) => {
            return (
              row.refName &&
              rowData[row.refName] && (
                <span
                  style={{
                    display: 'block',
                    width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                  }}
                >
                  {' '}
                  {rowData[row.refName]}
                </span>
              )
            );
          },
          editComponent: (props) => {
            // let type = 'text';

            // if (row.refName === 'range1') {
            //   return console.log('yoyo');
            // }
            // if (selected.validations) {
            //   const validation = selected.validations.find(
            //     (t) => t.name === props.columnDef.field
            //   );

            //   if (validation && validation.type) {
            //     type = validation.type;
            //   }
            //}
            let checkOnkeydown = '';
            let type = 'text';
            let isRequired = false;
            if (selected.validations) {
              const validation = selected.validations.find(
                (t) => t.name === props.columnDef.field
              );
              if (validation) {
                if (validation.type) {
                  type = validation.type;
                }
                checkOnkeydown = !!validation.positiveVal;
                isRequired = !!validation.required;
              }
            }
            return (
              <TextField
                helperText={isRequired && !props.value && 'Required'}
                onKeyDown={(e) =>
                  checkOnkeydown === true
                    ? ['e', 'E', '+', '-'].includes(e.key) && e.preventDefault()
                    : ''
                }
                error={isRequired && !props.value}
                type={type}
                style={{
                  width: '20vw',
                  margin: 10,
                  fontSize: 12,
                }}
                fullWidth
                value={valueCheck(props.value)}
                onChange={(event) => {
                  props.onChange(event.target.value);
                }}
              />
            );
          },
        };
      });

    setColumns(tmpColumns);
  };
  const saveAsExcel = async (derived = false) => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(selected.name || 'Tiers');
    let sheetColumns = schema.map((row) => ({
      header: row.uiName,
      key: row.refName,
      width: 25,
    }));

    worksheet.columns = sheetColumns;

    selectedRows.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    setLoading(true);
    const buf = await workbook.xlsx.writeBuffer();
    setLoading(false);

    const appendName = derived ? 'Derived_Export' : 'UI_Export';
    saveAs(new Blob([buf]), `${selected.name || 'Tiers'}_${appendName}.xlsx`);
  };
  const saveAsExcelTiers = async (derived = false) => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(selected.name || 'Tiers');
    let sheetColumns = schema.map((row) => ({
      header: row.uiName,
      key: row.refName,
      width: 25,
    }));

    worksheet.columns = sheetColumns;

    selectTable.current.state.data.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    setLoading(true);
    const buf = await workbook.xlsx.writeBuffer();
    setLoading(false);

    const appendName = derived ? 'Derived_Export' : 'UI_Export';
    saveAs(new Blob([buf]), `${selected.name || 'Tiers'}_${appendName}.xlsx`);
  };

  // Did Mount
  useEffect(() => {
    if (id) {
      const select = TIERS_LISTS.find((list) => list.id === id);
      setSelected(select);
    }
  }, [id]);

  useEffect(() => {
    if (selected) {
      getData().then(() => mapColumns());
    }
  }, [selected]);

  // Render
  return (
    <ThemeProvider theme={theme}>
      <Snackbar
        open={openSnack}
        message={messageSnack}
        onClose={(event, reason) => {
          if (reason === 'clickaway') {
            return;
          }
          setOpenSnack(false);
        }}
      />

      <MaterialTable
        style={{ padding: '20px' }}
        localization={{
          body: {
            emptyDataSourceMessage: '',
          },
        }}
        components={{
          Toolbar: (props) => (
            <div>
              <div
                style={{
                  fontSize: '18px',
                  fontWeight: '600',
                  marginLeft: '24px',
                }}
              >
                {props.title}
              </div>
              <div>
                <MTableToolbar {...props} />
              </div>
            </div>
          ),
          Pagination: (props) => {
            return <CustomPaginationComponent {...props} />;
          },
        }}
        tableRef={selectTable}
        isLoading={loadingTable}
        icons={TABLE_ICONS}
        title={`${selected && selected.name}`}
        columns={columns}
        data={data}
        options={TABLE_CONFIG}
        actions={[
          {
            tooltip: 'Export',
            icon: GetAppIcon,
            onClick: () => {
              saveAsExcel(false);
            },
          },
          {
            icon: () => (
              <Button
                variant='contained'
                style={{
                  textTransform: 'capitalize',
                  background: '#ffcc00',
                  // letterSpacing: "-1px",
                  fontWeight: '600',
                  color: '#000',
                  fontSize: '14px',
                  borderRadius: '50px',
                  padding: '6px 32px',
                  '&:hover': {
                    opacity: 0.8,
                    background: '#ffcc00',
                  },
                }}
                onClick={() => {
                  saveAsExcelTiers();
                }}
              >
                Export
              </Button>
            ),
            isFreeAction: true,
          },
        ]}
        onSelectionChange={(rowSelection) => {
          console.log(rowSelection);
          setSelectedRows(rowSelection);
        }}
        editable={{
          onBulkUpdate: (changes) =>
            new Promise((resolve, reject) => {
              setTimeout(() => {
                console.log(changes);
                if (Object.keys(changes).length > 0) {
                  let payload = [];
                  setLoadingTable(true);
                  Object.keys(changes).map((row) => {
                    let payloadData = {
                      ...changes[row].newData,
                      range1:
                        changes[row].newData.from1 +
                        ' to ' +
                        changes[row].newData.to1,
                    };

                    payloadData.createdBy = userInfo.id;
                    payloadData.createdDate = moment().format('DD-MM-YYYY');
                    payload.push(payloadData);
                  });
                  axios
                    .post(selected.PUT, payload)
                    .then((response) => {
                      console.log(response);
                      getData().then(() => {
                        setLoadingTable(false);
                        setOpenSnack(true);
                        setMessagesnack('Saved Successfully!');
                        resolve();
                      });
                    })
                    .catch((error) => {
                      setLoadingTable(false);
                      resolve();
                    });
                } else resolve();
              }, 1000);
            }),
          onRowAdd: (newData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              payload.createdBy = userInfo.id;
              payload.createdDate = moment().format('DD-MM-YYYY');
              let range = [
                {
                  range1: newData.from1 + ' to ' + newData.to1,
                  ...newData,
                },
              ];
              console.log(newData.from1);
              setLoadingTable(true);
              axios
                .post(
                  selected.POST,
                  selected.name === 'Subscription Tiers' ? range : [payload]
                )
                .then((response) => {
                  console.log(response);
                  if (response) {
                    let pkgData = [...data, newData];
                    setData(pkgData);
                    getData().then(() => {
                      setLoadingTable(false);
                      setOpenSnack(true);
                      setMessagesnack('Saved Successfully!');
                      resolve();
                    });
                  }
                  setLoadingTable(false);
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
          onRowUpdate: (newData, oldData) =>
            new Promise((resolve, reject) => {
              let payload = {
                ...newData,
                range1: newData.from1 + ' to ' + newData.to1,
              };
              console.log(newData);
              payload.createdBy = userInfo.id;
              payload.createdDate = moment().format('DD-MM-YYYY');
              const modPayloadData = objAppendOnUpdate(payload, userInfo.id, {
                oldArr: data,
                identifier: 'refId',
                val: payload['refId'],
              });

              setLoadingTable(true);
              axios
                .post(selected.PUT, [modPayloadData])
                .then((response) => {
                  console.log(response);
                  const dataUpdate = [...data];
                  const index = oldData.tableData.id;
                  dataUpdate[index] = newData;

                  setData(dataUpdate);
                  getData().then(() => {
                    setLoadingTable(false);
                    setOpenSnack(true);
                    setMessagesnack('Saved Successfully!');
                    resolve();
                  });
                  setLoadingTable(false);
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
        }}
      />
    </ThemeProvider>
  );
};

export default withStyles(useStyles)(WithErrorHandler(TiersTable, axios));
