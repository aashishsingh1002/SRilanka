import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import Button from '@material-ui/core/Button';
import AttachmentIcon from '@material-ui/icons/Attachment';
import IconButton from '@material-ui/core/IconButton';
import Chip from '@material-ui/core/Chip';
import BookIcon from '@material-ui/icons/Book';
import GroupIcon from '@material-ui/icons/Group';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../UI/Loader/Loader';
import { withStyles } from '@material-ui/core/styles';
import ModalAction from '../../UI/ModalAction/ModalAction';
import moment from 'moment';
import CancelIcon from '@material-ui/icons/Cancel';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import Popover from '@material-ui/core/Popover';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';

import MaterialTable from 'material-table';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import MenuBookIcon from '@material-ui/icons/MenuBook';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Backdrop from '@material-ui/core/Backdrop';
import Drawer from '@material-ui/core/Drawer';
import Toolbar from '@material-ui/core/Toolbar';
import CloseIcon from '@material-ui/icons/Close';

const StyledMenu = withStyles({
	paper: {
		background: '#FFFFFF',
		border: '1px solid #EAEAEA',
		boxSizing: 'border-box',
		boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.08)',
		borderRadius: '8px',
	},
})((props) => <Menu elevation={0} getContentAnchorEl={null} {...props} />);

const StyledMenuItem = withStyles((theme) => ({
	root: {
		fontWeight: '600',
		fontSize: '12px',
		linHeight: '16px',
		color: '#0079FF',
	},
}))(MenuItem);

const tableIcons = {
	Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
	Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
	Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
	Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
	DetailPanel: forwardRef((props, ref) => (
		<ChevronRight {...props} ref={ref} />
	)),
	Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
	Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
	Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
	FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
	LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
	NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
	PreviousPage: forwardRef((props, ref) => (
		<ChevronLeft {...props} ref={ref} />
	)),
	ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
	Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
	SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
	ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
	ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const theme = createMuiTheme({
	overrides: {
		MuiTable: {
			root: {
				tableLayout: 'fixed',
			},
		},
		MuiTableCell: {
			root: {
				padding: '7px',
				paddingLeft: '10px',
			},
		},
		MuiPaper: {
			width: '100%',
		},
	},
});

const drawerWidth = '70vw';

const useStyles = (theme) => ({
	cardHeader: {
		background: '#546D7A',
		height: '4.5vh',
	},
	subheader: {
		color: 'white',
	},
	drawer: {
		width: drawerWidth,
		flexShrink: 0,
	},
	drawerPaper: {
		width: drawerWidth,
		// height: window.screen.height + .2 * window.screen.height,
		height: '100rem',
		zIndex: 1000000,
	},
	backdrop: {
		zIndex: theme.zIndex.drawer + 1,
		// height: window.screen.height + .2 * window.screen.height,
		height: '100rem',
		color: '#fff',
	},
});

const getColor = {
	Deployed: '#1565c0',
	InProgress: '#528548',
	Cancelled: '#fc0a5b',
	'Approval In Progress': '#ff9100',
	'Design InProgress': '#528548',
	Approved: '#1565c0',
	'PCN Approved': '#1565c0',
};

class Releases extends Component {
	_isMounted = false;
	state = {
		loadingEdit: false,
		editRelRemarks: '',
		editRelApproverNote: '',
		editRelease: false,
		releaseEditData: {},
		anchorEls: [],
		anchorEl: null,
		releaseData: {},
		approverNote: '',
		remarks: '',
		data: [],
		show: false,
		loading: false,
		openDrawer: false,
		actions: [
			{
				icon: () => (
					<Button
						onClick={this.newReleaseHandler}
						variant="contained"
						style={{
							marginLeft: '20px',
							background: '#546D7A',
							color: 'white',
							textTransform: 'none',
						}}>
						Create New ePCN
					</Button>
				),
				isFreeAction: true,
			},
		],
		columnsSriLanka: [
			{
				title: 'ePCN No.',
				field: 'externalReleaseId',
				cellStyle: { width: '10%' },
				editable: 'never',
			},
			{
				title: 'ePCN Objective',
				field: 'remarks',
				sorting: false,
				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: '12px',
									overflow: 'auto',
									maxHeight: '40vh',
									whiteSpace: 'pre-wrap',
								}}>
								{rowData.remarks}
							</pre>
						}>
						<span>
							{' '}
							{rowData.remarks
								? rowData.remarks.length > 25
									? rowData.remarks.substring(0, 25) + '...'
									: rowData.remarks
								: ''}
						</span>
					</Tooltip>
				),
				editComponent: (props) => (
					<TextField
						inputProps={{
							maxLength: 2000,
						}}
						fullWidth
						value={props.value}
						onChange={(e) => props.onChange(e.target.value)}
						required={true}
						placeholder="ePCN Objective"
						rowsMin={4}
						rowsMax={5}
						multiline
						variant="outlined"
					/>
				),
				// cellStyle: { width: '15%' }
			},
			{
				title: 'Launch Approver Note',
				field: 'launchApproverNote',
				sorting: false,
				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: '12px',
									overflow: 'auto',
									maxHeight: '40vh',
									whiteSpace: 'pre-wrap',
								}}>
								{rowData.launchApproverNote}
							</pre>
						}>
						<span>
							{' '}
							{rowData.launchApproverNote
								? rowData.launchApproverNote.length > 25
									? rowData.launchApproverNote.substring(0, 25) + '...'
									: rowData.launchApproverNote
								: ''}
						</span>
					</Tooltip>
				),

				editComponent: (props) => (
					<TextField
						inputProps={{
							maxLength: 2000,
						}}
						fullWidth
						value={props.value}
						onChange={(e) => props.onChange(e.target.value)}
						required={true}
						placeholder="Launch Approver Note"
						rowsMin={4}
						rowsMax={5}
						multiline
						variant="outlined"
					/>
				),
				// cellStyle: { width: '15%' }
			},
			{
				title: 'Creation Date',
				field: 'createdOn',
				sorting: false,
				editable: 'never',
				cellStyle: { width: '10%' },
			},
			{
				title: 'Status',
				field: 'releaseStatus',
				editable: 'never',
				render: (rowData) => (
					<Chip
						label={rowData.releaseStatus}
						style={{
							background: getColor[rowData.releaseStatus],
							color: 'white',
						}}
					/>
				),
				sorting: false,
				// , cellStyle: { width: '10%' }
			},
			{
				title: 'Pending With',
				field: 'pendingWith',
				sorting: false,
				editable: 'never',
				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: '12px',
									overflow: 'auto',
									maxHeight: '40vh',
									whiteSpace: 'pre-wrap',
								}}>
								{rowData.pendingWith}
							</pre>
						}>
						<span>
							{' '}
							{rowData.pendingWith
								? rowData.pendingWith.length > 25
									? rowData.pendingWith.substring(0, 25) + '...'
									: rowData.pendingWith
								: ''}
						</span>
					</Tooltip>
				),

				// cellStyle: { width: '10%' },
			},

			{
				title: 'Action',
				field: 'action',
				filtering: false,
				cellStyle: { width: '5%' },
				render: (rowData) => (
					<React.Fragment>
						<Typography
							aria-controls="simple-menu"
							aria-haspopup="true"
							onClick={(event) => {
								event.stopPropagation();
								let anchorEls = [...this.state.anchorEls];
								anchorEls[rowData.releaseId] = event.target;
								this.setState({ anchorEls });
							}}
							style={{
								color: '#0079FF',
								fontSize: '22px',
								fontWeight: '900',
								cursor: 'pointer',
							}}>
							...
						</Typography>
						<StyledMenu
							id="simple-menu"
							anchorEl={this.state.anchorEls[rowData.releaseId]}
							keepMounted
							open={Boolean(this.state.anchorEls[rowData.releaseId])}
							onClick={(event) => {
								event.stopPropagation();
								this.menuHandleClose(rowData.releaseId);
							}}>
							{rowData.releaseStatus !== 'Cancelled' && (
								<React.Fragment>
									<StyledMenuItem
										onClick={(event) => {
											event.stopPropagation();
											this.menuHandleClose(rowData.releaseId);
											this.props.attachmentUpload(rowData);
										}}>
										Attachment
									</StyledMenuItem>
									<Divider
										style={{ marginLeft: '10px', marginRight: '10px' }}
									/>
								</React.Fragment>
							)}

							<StyledMenuItem
								onClick={(event) => {
									event.stopPropagation();
									this.menuHandleClose(rowData.releaseId);
									this.setState({ loading: true });
									axios
										.get('custom/pdf?releaseId=' + rowData.releaseId, {
											responseType: 'blob',
										})
										.then((res) => {
											console.log(res);
											console.log(res.data);

											this.setState({ loading: false });
											var headers = res.headers;
											var blob = new Blob([res.data], {
												type: headers['content-type'],
											});

											var link = document.createElement('a');
											link.href = window.URL.createObjectURL(blob);
											link.download = 'Literature_' + rowData.externalReleaseId;
											link.click();
										})
										.catch((error) => {
											console.log(error);
											if (this._isMounted) this.setState({ loading: false });
										});
								}}>
								Literature
							</StyledMenuItem>
							<Divider style={{ marginLeft: '10px', marginRight: '10px' }} />

							<StyledMenuItem
								onClick={(event) => {
									event.stopPropagation();
									this.menuHandleClose(rowData.releaseId);
									this.props.auditLogs(rowData);
								}}>
								Audit Logs
							</StyledMenuItem>
							<Divider style={{ marginLeft: '10px', marginRight: '10px' }} />

							{rowData.releaseStatus == 'InProgress' && (
								<React.Fragment>
									<StyledMenuItem
										onClick={(event) => {
											event.stopPropagation();
											this.menuHandleClose(rowData.releaseId);
											this.props.workflow(rowData);
										}}>
										Select Approver
									</StyledMenuItem>
									<Divider
										style={{ marginLeft: '10px', marginRight: '10px' }}
									/>
								</React.Fragment>
							)}

							{rowData.releaseStatus !== 'PCN Approved' &&
								rowData.releaseStatus !== 'Cancelled' && (
									<React.Fragment>
										<StyledMenuItem
											onClick={(event) => {
												event.stopPropagation();
												this.menuHandleClose(rowData.releaseId);
												this.setState({
													releaseData: { ...rowData },
													anchorEl: this.state.anchorEls[rowData.releaseId],
												});
											}}>
											Cancel
										</StyledMenuItem>
										<Divider
											style={{ marginLeft: '10px', marginRight: '10px' }}
										/>
									</React.Fragment>
								)}
						</StyledMenu>
					</React.Fragment>
				),
				sorting: false,
			},
		],
	};

	menuHandleClose = (releaseId) => {
		let anchorEls = [...this.state.anchorEls];
		anchorEls[releaseId] = null;
		this.setState({ anchorEls });
	};

	cancelRelease = () => {
		console.log(this.state.data);
		this.setState({ loading: true, anchorEl: null });
		console.log('cancel1');
		axios
			.post('cancel/release?releaseId=' + this.state.releaseData.releaseId, {
				updatedBy: this.props.userInfo.id,
				updatedDate: moment().format('DD-MMM-YY'),
			})
			.then((res) => {
				console.log(res);
				if (res) {
					if (this.state.releaseData.pendingWith != 'WorkFlow Not Initiated') {
						console.log('cancel2');

						axios
							.post(
								'custom/cancelTask?releaseId=' +
									this.state.releaseData.releaseId,
								{}
							)
							.then((res) => {
								console.log(res);
								this.setState({
									data: this.state.data.map((el) =>
										el.releaseId === this.state.releaseData.releaseId
											? {
													...el,
													releaseStatus: 'Cancelled',
													pendingWith: '',
											  }
											: el
									),
								});
								this.setState({ loading: false });
							})
							.catch((error) => {
								console.log(error);
								if (this._isMounted) this.setState({ loading: false });
							});
					} else {
						this.setState({
							data: this.state.data.map((el) =>
								el.releaseId === this.state.releaseData.releaseId
									? {
											...el,
											releaseStatus: 'Cancelled',
											pendingWith: '',
									  }
									: el
							),
						});
						this.setState({ loading: false });
					}
				} else {
					this.setState({ loading: false });
				}
			})

			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	};

	modalCloseHandler = () => {
		this.setState({ show: false, remarks: '' });
	};

	actionHandler = () => {
		console.log('called');
		document.getElementById('saveForm').click();
	};

	saveHelper = (event) => {
		event.preventDefault();
		let date = moment().format('YYYY-MM-DD');
		let payload = {
			buId: this.props.userInfo.buId,
			createdBy: this.props.userInfo.id,
			createdOn: date,
			remarks: this.state.remarks,
			launchApproverNote: this.state.approverNote,
			catalogId: 'DEF_CATALOG',
			opId: this.props.userInfo.opId,
			releaseDate: date,
		};
		console.log(payload);
		this.setState({ loading: true, show: false });

		axios
			.post('dashboard/myReleases/create', payload, {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,
				},
			})
			.then((response) => {
				console.log(response);
				console.log(response.data.data);

				let obj = {};
				obj = { ...response.data.data.ppmReleaseMaster };
				obj.pendingWith = response.data.data.pendingWith;
				let data = [...this.state.data];
				data.unshift(obj);
				console.log(data);
				this.setState({
					data: data,
					loading: false,
					show: false,
					remarks: '',
					approverNote: '',
				});

				// window.location.reload();
			})
			.catch((error) => {
				console.log(error);
				this.setState({
					show: false,
					remarks: '',
					loading: false,
					approverNote: '',
				});
			});
	};

	newReleaseHandler = () => {
		this.setState({ show: true });
	};
	valueChangeHandler = (event) => {
		this.setState({ [event.target.name]: event.target.value });
	};

	allReleasesHandler = () => {
		console.log('printing paramter username parmas');
		return axios
			.get('dashboard/myReleases?createdBy=' + this.props.userInfo.id, {
				params: {
					username: this.props.userInfo.id,
				},
				headers: {
					Accept: 'application/json,text/plan,*/*',
					buId: this.props.userInfo.buId,
					channelId: 'CSA',
					language: 'ENG',
					opId: this.props.userInfo.opId,
				},
			})
			.then((res) => {
				console.log(res);
				let data = [];
				res.data.data.filter((element) => {
					var obj = {};
					obj = { ...element.myReleases };
					obj.pendingWith = element.pendingWith;
					data.push(obj);
				});
				console.log(data);
				if (this._isMounted) {
					this.setState({ data: data });
				}
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	};
	componentDidMount = () => {
		this._isMounted = true;
		this.setState({ loading: true });
		this.allReleasesHandler().then(() => {
			if (this._isMounted) {
				this.setState({ loading: false });
			}
		});
	};

	componentWillUnmount() {
		this._isMounted = false;
	}

	editReleaseHandler = (event) => {
		event.preventDefault();
		console.log(this.state.releaseEditData);
		this.setState({
			loadingEdit: true,
		});
		axios
			.post('dashboard/myReleases/update', {
				releaseNbr: this.state.releaseEditData.releaseNbr,
				remarks: this.state.editRelRemarks,
				launchApproverNote: this.state.editRelApproverNote,
				updatedBy: this.props.userInfo.id,
			})
			.then((response) => {
				console.log(response);
				if (response) {
					let releaseEditData = { ...this.state.releaseEditData };
					releaseEditData.remarks = this.state.editRelRemarks;
					releaseEditData.launchApproverNote = this.state.editRelApproverNote;
					let data = this.state.data.map((row) =>
						row.releaseId == this.state.releaseEditData.releaseId
							? {
									...row,
									remarks: this.state.editRelRemarks,
									launchApproverNote: this.state.editRelApproverNote,
							  }
							: row
					);
					this.setState({
						editRelease: false,
						loadingEdit: false,
						releaseEditData,
						data,
					});
				} else {
					this.setState({
						loadingEdit: false,
					});
				}
			})
			.catch((error) => {
				console.log(error);
				this.setState({
					loadingEdit: false,
				});
			});
	};
	render() {
		const open = Boolean(this.state.anchorEl);
		const id = open ? 'simple-popover' : undefined;
		const { classes } = this.props;

		let myReleases = (
			<div>
				<div
					style={
						this.state.loading ? { display: 'none' } : { display: 'block' }
					}>
					<Backdrop className={classes.backdrop} open={this.state.openDrawer}>
						<Drawer
							className={classes.drawer}
							variant="persistent"
							anchor="right"
							open={this.state.openDrawer}
							classes={{
								paper: classes.drawerPaper,
							}}>
							{!this.state.loadingEdit && (
								<Toolbar>
									<div
										style={{
											display: 'flex',
											margin: '0px 20px 0px 20px;',
											justifyContent: 'space-between',
											width: '100%',
										}}>
										{this.state.editRelease ? (
											<Button
												onClick={() => {
													this.setState({
														editRelease: false,
													});
												}}
												variant="contained"
												style={{
													background: '#546D7A',
													color: 'white',
												}}>
												View
											</Button>
										) : (
											<Button
												onClick={() => {
													this.setState({
														editRelease: true,
													});
													this.setState((prevState) => {
														return {
															editRelease: true,
															editRelRemarks: prevState.releaseEditData.remarks,
															editRelApproverNote:
																prevState.releaseEditData.launchApproverNote,
														};
													});
												}}
												variant="contained"
												style={{
													background: 'green',
													color: 'white',
												}}>
												Edit
											</Button>
										)}

										<IconButton
											edge="start"
											onClick={() => {
												this.setState({
													editRelease: false,
													openDrawer: false,
													editRelRemarks: '',
													editRelApproverNote: '',
												});
											}}>
											<CloseIcon />
										</IconButton>
									</div>
								</Toolbar>
							)}
							{this.state.loadingEdit ? (
								<Loader relative />
							) : (
								<div
									style={{
										marginLeft: '15px',
										marginRight: '2vw',
										overflow: 'auto',
									}}>
									<div
										style={{
											width: '100%',
										}}>
										<Typography
											style={{
												marginTop: '10px',
												fontWeight: '600',
												fontSize: '18px',
												color: '#393939',
											}}>
											{this.state.releaseEditData.externalReleaseId}
										</Typography>
										<Typography
											style={{
												fontWeight: '600',
												fontSize: '12px',
												color: '#696969',
											}}>
											created on:{this.state.releaseEditData.createdOn}
										</Typography>

										<React.Fragment>
											{this.state.editRelease ? (
												<form onSubmit={this.editReleaseHandler}>
													<Grid item xs={12}>
														<Box mt={2}>
															<span
																style={{
																	fontWeight: 'bold',
																}}>
																ePCN Objective
																<span
																	style={{
																		color: 'red',
																		marginLeft: '5px',
																	}}>
																	*
																</span>
															</span>
															<span
																style={{
																	marginLeft: '5px',
																}}>
																(Max Length 2000)
															</span>
														</Box>
														<Box mt={2}>
															<TextField
																inputProps={{
																	maxLength: 2000,
																}}
																name="editRelRemarks"
																fullWidth
																value={this.state.editRelRemarks}
																onChange={this.valueChangeHandler}
																required={true}
																placeholder="ePCN Objective"
																rowsMin={4}
																rowsMax={17}
																multiline
																variant="outlined"
															/>
														</Box>
														<span>
															Max Remaining:{' '}
															{2000 - this.state.editRelRemarks.length}
														</span>
													</Grid>

													<Grid item xs={12}>
														<Box mt={2}>
															<span
																style={{
																	fontWeight: 'bold',
																}}>
																Launch Approver Note
																<span
																	style={{
																		color: 'red',
																		marginLeft: '5px',
																	}}>
																	*
																</span>
															</span>
															<span
																style={{
																	marginLeft: '5px',
																}}>
																(Max Length 2000)
															</span>
														</Box>
														<Box mt={2}>
															<TextField
																inputProps={{
																	maxLength: 2000,
																}}
																name="editRelApproverNote"
																fullWidth
																required={true}
																value={this.state.editRelApproverNote}
																onChange={this.valueChangeHandler}
																placeholder="Launch Approver Note"
																rowsMin={4}
																rowsMax={17}
																multiline
																variant="outlined"
															/>
														</Box>
														<span>
															Max Remaining:{' '}
															{2000 - this.state.editRelApproverNote.length}
														</span>
													</Grid>
													<div
														style={{
															width: '100%',
															textAlign: 'center',
														}}>
														<Button
															type="submit"
															style={{
																color: '#0079FF',
																border: '1px solid #0079FF',
																marginTop: '3vh',
															}}
															color="info"
															variant="outlined">
															Submit
														</Button>
													</div>
												</form>
											) : (
												<React.Fragment>
													<Typography
														style={{
															fontWeight: '550',
															fontSize: '18px',
															color: '#393939',
															marginTop: '15px',
														}}>
														ePCN Objective
													</Typography>
													<pre
														style={{
															fontSize: '17px',
															overflow: 'auto',
															maxHeight: '45vh',
															whiteSpace: 'pre-wrap',
														}}>
														{this.state.releaseEditData.remarks}
													</pre>

													<Typography
														style={{
															fontWeight: '550',
															fontSize: '18px',
															color: '#393939',
															marginTop: '15px',
														}}>
														Launch Approver Note
													</Typography>

													<pre
														style={{
															fontSize: '17px',
															overflow: 'auto',
															maxHeight: '45vh',
															whiteSpace: 'pre-wrap',
														}}>
														{this.state.releaseEditData.launchApproverNote}
													</pre>
												</React.Fragment>
											)}{' '}
										</React.Fragment>
									</div>
								</div>
							)}
						</Drawer>
					</Backdrop>
					<Popover
						id={id}
						open={open}
						anchorEl={this.state.anchorEl}
						onClose={() => {
							this.setState({
								anchorEl: null,
							});
						}}
						anchorOrigin={{
							vertical: 'bottom',
							horizontal: 'left',
						}}
						transformOrigin={{
							vertical: 'top',
							horizontal: 'right',
						}}>
						<Card>
							<CardHeader
								className={classes.cardHeader}
								classes={{
									subheader: classes.subheader,
								}}
								subheader={
									'Do you want to cancel ePCN ' +
									(this.state.releaseData
										? this.state.releaseData.externalReleaseId
										: '') +
									' ?'
								}
							/>
							<CardContent style={{ padding: '4px' }}>
								<div
									style={{
										marginTop: '10px',
										display: 'flex',
										justifyContent: 'flex-end',
									}}>
									<Button
										size="small"
										color="primary"
										style={{
											textTransform: 'none',
										}}
										onClick={() => {
											this.setState({
												anchorEl: null,
											});
										}}>
										Close
									</Button>
									<Button
										size="small"
										color="primary"
										style={{
											textTransform: 'none',
										}}
										onClick={this.cancelRelease}>
										Ok
									</Button>
								</div>
							</CardContent>
						</Card>
					</Popover>

					<ThemeProvider theme={theme}>
						<MaterialTable
							isLoading={this.state.loadingTable}
							icons={tableIcons}
							title={'My ePCN'}
							columns={this.state.columnsSriLanka}
							data={this.state.data}
							actions={this.state.actions}
							onRowClick={(event, rowData) => {
								if (rowData.releaseStatus == 'InProgress') {
									console.log(rowData);
									window.scrollTo(0, 0);
									this.setState({
										openDrawer: true,
										releaseEditData: rowData,
									});
								}
							}}
							// editable={{
							//     isEditable: rowData => rowData.releaseStatus == 'InProgress',
							//     onRowUpdate: (newData, oldData) =>
							//         new Promise((resolve, reject) => {
							//             console.log(newData)
							//             if (newData.remarks && newData.launchApproverNote) {
							//                 axios
							//                     .post("dashboard/myReleases/update", {
							//                         releaseNbr: newData.releaseNbr,
							//                         remarks: newData.remarks,
							//                         launchApproverNote: newData.launchApproverNote,
							//                         updatedBy: this.props.userInfo.id
							//                     })
							//                     .then(response => {
							//                         console.log(response);
							//                         const dataUpdate = [...this.state.data];
							//                         const index = oldData.tableData.id;
							//                         dataUpdate[index] = newData;
							//                         this.setState({
							//                             data: dataUpdate
							//                         })
							//                         resolve();
							//                     })
							//                     .catch(error => {
							//                         console.log(error);
							//                         resolve();
							//                     });
							//             }
							//             else
							//                 reject()
							//         }),
							// }}
							options={{
								filtering: true,
								pageSize: 30,
								pageSizeOptions: [20, 30, 50, 75, 100],
								toolbar: true,
								paging: true,
								rowStyle: {
									fontSize: '14px',
									// fontWeight: "600"
								},
								headerStyle: {
									fontWeight: 'bold',
								},
							}}
						/>
					</ThemeProvider>

					<ModalAction
						show={this.state.show}
						modalClosed={this.modalCloseHandler}
						actionText={'Create'}
						title={'Create New ePCN'}
						action={this.actionHandler}
						// disableButton={
						// 	this.state.remarks.length === 0 ||
						// 	this.state.remarks.replace(
						// 		/[\s-!$%^&*()_+|~=`{}\[\]:";'<>?,.\/]/g,
						// 		''
						// 	).length === 0 ||
						// 	/[\-!$%^&*()_+|~=`{}\[\]:";'<>?,.\/]/g.test(this.state.remarks)
						// }
					>
						<form onSubmit={this.saveHelper}>
							<Grid item xs={12}>
								<Box mt={2}>
									<span
										style={{
											fontWeight: 'bold',
										}}>
										ePCN Objective
										<span
											style={{
												color: 'red',
												marginLeft: '5px',
											}}>
											*
										</span>
									</span>
									<span
										style={{
											marginLeft: '5px',
										}}>
										(Max Remaining: {2000 - this.state.remarks.length})
									</span>
								</Box>

								<Box mt={2}>
									<TextField
										focused
										autoFocus
										inputProps={{
											maxLength: 2000,
										}}
										name="remarks"
										fullWidth
										value={this.state.remarks}
										onChange={this.valueChangeHandler}
										required={true}
										placeholder="ePCN Objective"
										rowsMin={4}
										rowsMax={5}
										multiline
										variant="outlined"
										// error={
										// 	this.state.remarks.length === 0 ||
										// 	this.state.remarks.replace(
										// 		/[\s-!@#$%^&*()_+|~=`{}\[\]:";'<>?,.\/]/g,
										// 		''
										// 	).length === 0 ||
										// 	/[\-!@#$%^&*()_+|~=`{}\[\]:";'<>?,.\/]/g.test(
										// 		this.state.remarks
										// 	)
										// }
										// helperText={
										// 	this.state.remarks.length === 0 ||
										// 	this.state.remarks.replace(
										// 		/[\s-!@#$%^&*()_+|~=`{}\[\]:";'<>?,.\/]/g,
										// 		''
										// 	).length === 0 ||
										// 	/[\-!@#$%^&*()_+|~=`{}\[\]:";'<>?,.\/]/g.test(
										// 		this.state.remarks
										// 	)
										// 		? 'ePCN Objective is Mandatory'
										// 		: null
										// }
									/>
								</Box>
							</Grid>

							<Grid item xs={12}>
								<Box mt={2}>
									<span
										style={{
											fontWeight: 'bold',
										}}>
										Launch Approver Note
										<span
											style={{
												color: 'red',
												marginLeft: '5px',
											}}>
											*
										</span>
									</span>
									<span
										style={{
											marginLeft: '5px',
										}}>
										(Max Remaining: {2000 - this.state.approverNote.length})
									</span>
								</Box>
								<Box mt={2}>
									<TextField
										inputProps={{
											maxLength: 2000,
										}}
										name="approverNote"
										fullWidth
										required={true}
										value={this.state.approverNote}
										onChange={this.valueChangeHandler}
										placeholder="Launch Approver Note"
										rowsMin={4}
										rowsMax={5}
										multiline
										variant="outlined"
									/>
								</Box>
							</Grid>

							<button type="submit" id="saveForm" style={{ display: 'none' }}>
								button
							</button>
						</form>
					</ModalAction>
				</div>
				{this.state.loading && <Loader />}
			</div>
		);
		return myReleases;
	}
}

const mapStateToProps = (state) => {
	return {
		userInfo: state.login.loggedInUserInfo,
	};
};

export default connect(mapStateToProps)(
	withStyles(useStyles)(WithErrorHandler(withRouter(Releases), axios))
);
