import React from "react";

const SummaryEmpty = (props) => {
  return (
    <div
      style={{
        background: "#fff",
        borderRadius: "5px",
        padding: "20px",
        boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.08)",
      }}
    >
      {props.children}
    </div>
  );
};

export default SummaryEmpty;
