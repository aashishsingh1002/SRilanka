import React, { Component } from 'react';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import { connect } from 'react-redux';
import Loader from '../../UI/Loader/Loader';
import Table from '../../UI/Table/Table'
import Tooltip from '@material-ui/core/Tooltip';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import TextField from '@material-ui/core/TextField'
import IconButton from '@material-ui/core/IconButton';
import AttachmentIcon from '@material-ui/icons/Attachment'
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Modal from '../../UI/Modal/Modal';
import Attachment from '../Dashboard/Attachment';
import AuditLogs from '../Dashboard/AuditLogs';
import BookIcon from '@material-ui/icons/Book';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

import Backdrop from '@material-ui/core/Backdrop';

import MaterialTable from 'material-table';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core'
import { createMuiTheme } from '@material-ui/core/styles';

import Drawer from '@material-ui/core/Drawer';
import Toolbar from '@material-ui/core/Toolbar';
import CloseIcon from '@material-ui/icons/Close';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';


const tableIcons = {
    Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
    Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
    Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
    DetailPanel: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
    Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
    Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
    FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
    LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
    NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    PreviousPage: forwardRef((props, ref) => <ChevronLeft {...props} ref={ref} />),
    ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
    SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
    ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
    ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />)
};


const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
        },
    },
};

const LightTooltip = withStyles((theme) => ({
    tooltip: {
        backgroundColor: '#525354',
        color: 'white',
        boxShadow: theme.shadows[1],
        fontSize: 14,
    },
}))(Tooltip);

const drawerWidth = "35vw";

const useStyles = (theme) => ({

    drawer: {
        width: drawerWidth,
        flexShrink: 0,
    },
    drawerPaper: {
        width: drawerWidth,
        height: window.screen.height + .2 * window.screen.height,
        zIndex: 1000000
    },
    backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        height: window.screen.height + .2 * window.screen.height,
        color: '#fff',
    },
});
const theme = createMuiTheme({
    overrides: {
        MuiTable: {
            root: {
                tableLayout: 'fixed',
            },
        },
        MuiTableCell: {
            root: {
                padding: '0px',
                paddingLeft: '10px'
            },
        },
        MuiPaper: {
            width: '100%'
        }
    },
});

class WorkflowAdmin extends Component {

    _isMounted = false;

    state = {
        relWorkFlowAction: '',
        relWorkRemarks: '',
        releaseEditData: {},
        loadingEdit: false,
        openDrawer: false,
        auditLogs: false,
        relData: {},
        attachment: false,
        show: false,
        modalContent: null,
        dataMyItems: [],
        dataTeamItems: [],
        loading: true,
        columnsTeamItems: [
            {
                title: "Self Assign", field: 'selfAssign',
                cellStyle: { width: '5%' },
                filtering: false,
                render: rowData => <IconButton
                    onClick={() => {
                        console.log(rowData.userId)
                        if (rowData.userId == null)
                            this.selfAssignHandler(rowData)
                    }}>
                    <KeyboardArrowUpIcon />
                </IconButton>
            },
            { title: "ePCN No.", field: 'externalReleaseId' },
            {
                title: 'ePCN Objective', field: 'releaseObjective', sorting: false,
                render: rowData =>
                    <Tooltip
                        interactive
                        title={
                            <pre style={{
                                fontSize: '12px', overflow: 'auto',
                                maxHeight: "40vh",
                                whiteSpace: 'pre-wrap'
                            }}>
                                {rowData.releaseObjective}</pre>}>
                        <span> {rowData.releaseObjective ? rowData.releaseObjective.length > 25 ?
                            rowData.releaseObjective.substring(0, 25) + "..." : rowData.releaseObjective : ''}</span>

                    </Tooltip>
            },
            { title: 'Creation Date', field: 'releaseCreationDate' },
            { title: 'Created By', field: 'createdBy' },

            {
                title: 'Pending With',
                field: 'pendingWith',
            },

            {
                title: 'Attachment',
                field: 'attachment',
                filtering: false,
                render: rowData => <IconButton onClick={() => {
                    this.setState({ relData: { ...rowData } })
                    this.setState({ attachment: true })

                }} >
                    <AttachmentIcon />
                </IconButton>, sorting: false
            },
            {
                title: 'Audit Logs',
                field: 'auditLogs',
                filtering: false,
                render: rowData => <IconButton onClick={(event) => {
                    this.setState({ relData: { ...rowData } })
                    this.setState({ auditLogs: true })
                }} >
                    <BookIcon />
                </IconButton>, sorting: false
            },

        ],
        columnsMyItems: [
            {
                title: "Un Assign", field: 'unAssign',
                filtering: false, render:
                    rowData => <IconButton onClick={(event) => {
                        event.stopPropagation();
                        this.unAssignHandler(rowData)
                    }} >
                        <ExpandMoreIcon />
                    </IconButton>
            },
            {
                title: "ePCN No.", field: 'externalReleaseId'
            },
            {
                title: 'ePCN Objective', field: 'releaseObjective', sorting: false,
                render: rowData =>
                    <Tooltip
                        interactive
                        title={
                            <pre style={{
                                fontSize: '12px', overflow: 'auto',
                                maxHeight: "40vh",
                                whiteSpace: 'pre-wrap'
                            }}>
                                {rowData.releaseObjective}</pre>}>
                        <span> {rowData.releaseObjective ? rowData.releaseObjective.length > 25 ?
                            rowData.releaseObjective.substring(0, 25) + "..." : rowData.releaseObjective : ''}</span>

                    </Tooltip>
            },
            { title: 'Creation Date', field: 'releaseCreationDate' },
            {
                title: 'Attachment',
                field: 'attachment',
                filtering: false,
                render: rowData => <IconButton onClick={(event) => {
                    event.stopPropagation();
                    this.setState({ relData: { ...rowData } })
                    this.setState({ attachment: true })

                }} >
                    <AttachmentIcon />
                </IconButton>, sorting: false
            },
            {
                title: 'Audit Logs',
                field: 'auditLogs',
                filtering: false,
                render: rowData => <IconButton onClick={(event) => {
                    event.stopPropagation();
                    this.setState({ relData: { ...rowData } })
                    this.setState({ auditLogs: true })
                }} >
                    <BookIcon />
                </IconButton>, sorting: false
            },
        ]

    }

    unAssignHandler = (rowData) => {
        console.log(rowData)
        if (this._isMounted)
            this.setState({ loading: true })
        axios
            .post(
                "rest/task/" + rowData.taskId + "/unclaim",
                { userId: this.props.userInfo.id },
                {
                    headers: {
                        "Content-Type": "application/json"
                    }
                }
            )
            .then(response => {
                console.log(response);
                if (response) {
                    let myItems = [...this.state.dataMyItems]
                    var removeIndex = this.state.dataMyItems
                        .map(function (item) {
                            return item.releaseId;
                        })
                        .indexOf(rowData.releaseId);

                    myItems.splice(removeIndex, 1);
                    let newMyitem = {};
                    newMyitem = { ...rowData };
                    newMyitem.save = "";
                    newMyitem.action = "";
                    newMyitem.remarks = "";
                    this.setState((prevState) => {
                        return { loading: false, dataMyItems: myItems, dataTeamItems: [newMyitem].concat(prevState.dataTeamItems) };
                    });
                }
                else {
                    this.setState({ loading: false });
                }
            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false })
            });

    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidMount() {
        this._isMounted = true;
        this.adminTaskList().then(() => {
            this.myItemsHandler().then(() => {
                this.setState({
                    loading: false
                })
            })
        })
    }

    actionHandler = (event) => {
        event.preventDefault();
        console.log(this.state.relWorkFlowAction)
        console.log(this.state.relWorkRemarks)
        console.log(this.state.releaseEditData.releaseId)
        let variables = {};
        let payload = {};
        this.setState({ loadingEdit: true })
        if (this.state.relWorkFlowAction == "Approve") {

            variables.approve = { value: true };
            variables.remarks = { value: this.state.relWorkRemarks };
            payload.variables = variables;
            console.log("payload");

            console.log(payload);
            axios
                .post(
                    "rest/task/" + this.state.releaseEditData.taskId + "/complete",
                    payload,
                    {
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }
                )
                .then(response => {
                    console.log(response);

                    axios
                        .post(
                            "SmsNotificationService/approve?releaseId=" +
                            this.state.releaseEditData.releaseId,
                            {
                                "roles": []
                            },
                            {
                                headers: {
                                    opId: this.props.userInfo.opId,
                                    buId: this.props.userInfo.buId,
                                    lob: "Postpaid",
                                    initiateapproval: false
                                }
                            }
                        )
                        .then(response => {
                            console.log(response);
                            if (response) {
                                let myItems = [...this.state.dataMyItems]
                                let removeIndex = this.state.dataMyItems
                                    .map(function (item) {
                                        return item.releaseId;
                                    })
                                    .indexOf(this.state.releaseEditData.releaseId);

                                myItems.splice(removeIndex, 1);
                                this.setState({
                                    dataMyItems: myItems, loadingEdit: false,
                                    openDrawer: false, relWorkFlowAction: "",
                                    relWorkRemarks: '',
                                });
                            }
                            else {
                                this.setState({
                                    loadingEdit: false, openDrawer: false, relWorkFlowAction: "",
                                    relWorkRemarks: '',
                                });
                            }
                        })
                        .catch(error => {
                            console.log(error);
                            this.setState({
                                loadingEdit: false, openDrawer: false, relWorkFlowAction: "",
                                relWorkRemarks: '',
                            })
                        });

                })
                .catch(error => {
                    console.log(error);
                    this.setState({
                        loadingEdit: false, openDrawer: false, relWorkFlowAction: "",
                        relWorkRemarks: '',
                    })
                });

        }
        else {
            axios
                .post("SelectApprovers/" +
                    this.state.relWorkFlowAction.toLowerCase() + "/" + this.state.releaseEditData.releaseId + '/' +
                    this.props.userInfo.id, {
                        remarks: this.state.relWorkRemarks
                    })
                .then(response => {
                    console.log(response);
                    if (response) {
                        let myItems = [...this.state.dataMyItems]
                        let removeIndex = this.state.dataMyItems
                            .map(function (item) {
                                return item.releaseId;
                            })
                            .indexOf(this.state.releaseEditData.releaseId);

                        myItems.splice(removeIndex, 1);
                        this.setState({
                            dataMyItems: myItems, loadingEdit: false, openDrawer: false, relWorkFlowAction: "",
                            relWorkRemarks: '',
                        });
                    } else {
                        this.setState({
                            loadingEdit: false, openDrawer: false, relWorkFlowAction: "",
                            relWorkRemarks: '',
                        });
                    }
                })
                .catch(error => {
                    console.log(error);
                    this.setState({
                        loadingEdit: false, openDrawer: false, relWorkFlowAction: "",
                        relWorkRemarks: '',
                    })
                });

        }

    }

    myItemsHandler() {
        let url = "custom/userTaskList?groupId=" +
            this.props.userInfo.group[0] +
            "&userId=" +
            this.props.userInfo.id
        console.log(url)
        return axios
            .get(
                'custom/adminUserTaskList?workflowId=swf&userId=' + this.props.userInfo.id,
                {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId
                    }
                }
            )
            .then(res => {
                console.log("my items");
                console.log(res)
                console.log(res.data.data);
                let myItems = [];
                res.data.data.filter(el => {
                    if (el.releaseDetails.length > 0) {
                        let obj = {};
                        obj.taskId = el.taskId;
                        el.releaseDetails.filter(element => {
                            if (element.varName == "releaseCreationDate") {
                                obj.releaseCreationDate = element.releaseDetails;
                            } else if (element.varName == "releaseId") {
                                obj.releaseId = element.releaseDetails;
                            } else if (element.varName == "releaseStatus") {
                                obj.releaseStatus = element.releaseDetails;
                            } else if (element.varName == "releaseObjective") {
                                obj.releaseObjective = element.releaseDetails;
                            } else if (element.varName == "releaseCreatedBy") {
                                obj.createdBy = element.releaseDetails;
                            } else if (element.varName == "releaseExternalId") {
                                obj.externalReleaseId = element.releaseDetails;
                            }
                        });
                        obj.action = "";
                        obj.remarks = "";
                        obj.save = "";

                        myItems.push(obj);
                    }
                });
                if (this._isMounted)
                    this.setState({ dataMyItems: myItems })

            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false })
            });
    }


    selfAssignHandler = (rowData) => {
        console.log(rowData)
        if (this._isMounted)
            this.setState({ loading: true })
        axios
            .post(
                "rest/task/" + rowData.taskId + "/claim",
                { userId: this.props.userInfo.id },
                {
                    headers: {
                        "Content-Type": "application/json"
                    }
                }
            )
            .then(response => {
                console.log(response);
                if (response) {
                    let teamItems = [...this.state.dataTeamItems]
                    var removeIndex = this.state.dataTeamItems
                        .map(function (item) {
                            return item.releaseId;
                        })
                        .indexOf(rowData.releaseId);

                    teamItems.splice(removeIndex, 1);
                    let newMyitem = {};
                    newMyitem = { ...rowData };
                    newMyitem.save = "";
                    newMyitem.action = "";
                    newMyitem.remarks = "";
                    if (this._isMounted)
                        this.setState((prevState) => {
                            return { loading: false, dataTeamItems: teamItems, dataMyItems: [newMyitem].concat(prevState.dataMyItems) };
                        });

                }
                else {
                    this.setState((prevState) => {
                        return { loading: false };
                    });
                }
            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false })
            });

    }

    adminTaskList() {
        return axios
            .get(
                "custom/adminTaskList?workflowId=swf"
            )
            .then(res => {
                console.log(res)
                console.log("team ");
                console.log(res.data.data);
                let teamItems = []
                res.data.data.filter((el, i) => {
                    let obj = {};
                    obj.taskId = el.taskId;
                    el.releaseDetails.map((element) => {
                        if (element.varName == "releaseCreationDate") {
                            obj.releaseCreationDate = element.releaseDetails;
                        } else if (element.varName == "releaseId") {
                            obj.releaseId = element.releaseDetails;
                        } else if (element.varName == "releaseStatus") {
                            obj.releaseStatus = element.releaseDetails;
                        } else if (element.varName == "releaseObjective") {
                            obj.releaseObjective = element.releaseDetails;
                        } else if (element.varName == "releaseCreatedBy") {
                            obj.createdBy = element.releaseDetails;
                        }
                        else if (element.varName == "releaseExternalId") {
                            obj.externalReleaseId = element.releaseDetails;
                        }

                    });
                    obj.selfAssign = ''
                    obj.pendingWith = el.pendingWith
                    obj.userId = el.userId
                    if (obj.releaseId) {
                        teamItems.push(obj);
                    }
                });
                console.log(teamItems)
                if (this._isMounted)
                    this.setState({ dataTeamItems: teamItems })

            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });
    }

    errorConfirmedHandler = () => {
        this.setState({ show: false });
    }

    showAttachmentHandler = () => {
        this.setState({ attachment: false })
    }

    showAuditLogsHandler = () => {
        this.setState({ auditLogs: false })
    }


    render() {
        const { classes } = this.props;

        let workflowAdmin = <React.Fragment>

            <Modal
                show={this.state.show}
                modalClosed={this.errorConfirmedHandler}
                title={'Something Went Wrong!'}
            >
                {this.state.modalContent}
            </Modal>

            <Backdrop className={classes.backdrop} open={this.state.openDrawer} >

                <Drawer
                    className={classes.drawer}
                    variant="persistent"
                    anchor="right"
                    open={this.state.openDrawer}
                    classes={{
                        paper: classes.drawerPaper,
                    }}
                >
                    <Toolbar>

                        <IconButton edge="start" style={{ position: 'absolute', right: '0', marginRight: '2vw' }} onClick={() => {
                            this.setState({
                                openDrawer: false
                                , relWorkFlowAction: "",
                                relWorkRemarks: ''
                            })
                        }}>
                            <CloseIcon />
                        </IconButton>
                    </Toolbar>
                    {this.state.loadingEdit ? <Loader /> :

                        <div style={{ marginLeft: '15px', marginRight: '2vw' }}>
                            <div style={{
                                width: '100%',
                                height: '103vh',
                                overflowY: 'auto',
                                overflowX: 'hidden'
                            }}>
                                < Typography style={{ marginTop: '10px', fontWeight: '600', fontSize: '18px', color: '#393939' }}>
                                    {this.state.releaseEditData.externalReleaseId}</Typography >
                                < Typography style={{ fontWeight: '600', fontSize: '12px', color: '#696969' }}>
                                    created on:{this.state.releaseEditData.releaseCreationDate}</Typography >

                                < Typography style={{ fontWeight: '550', fontSize: '16px', color: '#393939', marginTop: '15px' }}>
                                    ePCN Objective</Typography >
                                <div style={{
                                    fontWeight: '600', fontSize: '14px',
                                    color: '#696969', marginTop: '5px', maxHeight: '15vh', overflow: 'auto'
                                }}>
                                    {this.state.releaseEditData.releaseObjective}
                                </div>

                                < Typography style={{ fontWeight: '550', fontSize: '16px', color: '#393939', marginTop: '15px' }}>
                                    Launch Approver Note</Typography >
                                <div style={{
                                    fontWeight: '600', fontSize: '14px',
                                    color: '#696969', marginTop: '5px', maxHeight: '15vh', overflow: 'auto'
                                }}>
                                    {this.state.releaseEditData.approverNote}
                                </div>
                                <form onSubmit={this.actionHandler} id="workFlowForm">

                                    <Grid container spacing={3} style={{ marginTop: '20px', display: 'inline-flex' }}>

                                        <Grid item xs={12} >
                                            <Box>
                                                <span style={{ fontWeight: '600', fontSize: '14px', color: '#696969' }}>Action</span>
                                                <span style={{
                                                    color: 'red',
                                                    marginLeft: '5px',

                                                }}>*</span>
                                            </Box>
                                            <Box mt={2} >

                                                <FormControl style={{ minWidth: '100%', }}>
                                                    <Select
                                                        name='action'
                                                        MenuProps={MenuProps}
                                                        displayEmpty
                                                        value={this.state.relWorkFlowAction}
                                                        onChange={(event) => this.setState({ relWorkFlowAction: event.target.value })}
                                                        input={<Input required={true} />}
                                                        renderValue={(selected) => {
                                                            if (selected) {
                                                                if (selected.length === 0) {
                                                                    return <em>Action</em>;
                                                                }
                                                                return selected
                                                            }
                                                        }}
                                                        inputProps={{ 'aria-label': 'Without label' }}
                                                    >
                                                        <MenuItem disabled value="">
                                                            <em>Action</em>
                                                        </MenuItem>

                                                        {['Approve', 'RFI'].map((name) => (
                                                            <MenuItem key={name} value={name} >
                                                                {name}
                                                            </MenuItem>
                                                        ))
                                                        }
                                                    </Select>
                                                </FormControl>
                                            </Box>
                                        </Grid>

                                        <Grid item xs={12} >
                                            <Box>
                                                <span style={{ fontWeight: '600', fontSize: '14px', color: '#696969' }}>Remarks</span>
                                                <span style={{
                                                    color: 'red',
                                                    marginLeft: '5px',

                                                }}>*</span>
                                            </Box>
                                            <Box mt={2} >

                                                <TextField
                                                    inputProps={{
                                                        maxLength: 255,
                                                    }}
                                                    placeholder="Remarks"
                                                    onChange={(event) => {
                                                        this.setState({
                                                            relWorkRemarks: event.target.value
                                                        })
                                                    }}
                                                    fullWidth
                                                    value={this.state.relWorkRemarks}
                                                    rows={2}
                                                    rowsMax={5}
                                                    multiline
                                                    required={true}
                                                    variant='outlined'
                                                />
                                            </Box>
                                        </Grid>

                                    </Grid>
                                </form>

                            </div>

                        </div>

                    }
                    {!this.state.loadingEdit && <div style={{
                        height: '17vh',
                        width: '100%',
                        background: '#FFFFFF',
                        boxShadow: '0px 0px 4px rgba(0, 0, 0, 0.137156)', textAlign: 'center'

                    }}>

                        <Button
                            form="workFlowForm"
                            type="submit"
                            style={{
                                color: '#0079FF', border: '1px solid #0079FF',
                                marginTop: '3vh'
                            }}
                            color="info"
                            variant="outlined"
                        >
                            Submit
                           </Button>


                    </div>}

                </Drawer>

            </Backdrop>
            <ThemeProvider theme={theme}>
                <MaterialTable
                    icons={tableIcons}
                    title={'My Items'}
                    columns={this.state.columnsMyItems}
                    data={this.state.dataMyItems}
                    onRowClick={(event, rowData) => {
                        console.log(rowData)
                        this.setState({
                            openDrawer: true,
                            releaseEditData: rowData
                        })
                    }}
                    options={{
                        filtering: true,
                        pageSize: 5,
                        pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
                        toolbar: true,
                        paging: true,
                        rowStyle: {
                            fontSize: '14px',
                            // fontWeight: "600"
                        },
                        headerStyle: {
                            fontWeight: 'bold',
                        }

                    }}
                />
            </ThemeProvider>
            <div style={{ marginTop: '30px' }}>
                <Table title='Team Items' data={this.state.dataTeamItems}
                    columns={this.state.columnsTeamItems} pageSize={5} fontSize={'14px'} />
            </div>

            {this.state.attachment ? <Attachment userInfo={this.props.userInfo}
                showAttachment={this.showAttachmentHandler}
                releaseData={this.state.relData} /> : null
            }
            {this.state.auditLogs ?
                <AuditLogs showAuditLogs={this.showAuditLogsHandler}
                    releaseData={this.state.relData} /> : null}

        </React.Fragment>


        if (this.state.loading)
            workflowAdmin = <Loader />

        return workflowAdmin
    }

}



const mapStateToProps = state => {
    return {
        userInfo: state.login.loggedInUserInfo,
    };
}




export default connect(mapStateToProps)(WithErrorHandler(withStyles(useStyles)(WorkflowAdmin), axios));
