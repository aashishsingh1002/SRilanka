import React, { Component } from 'react';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import Loader from '../../UI/Loader/Loader';
import MaterialTable from '@material-table/core';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import moment from 'moment';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';

const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const theme = createMuiTheme({
  overrides: {
    MuiTableCell: {
      root: {
        padding: '0px',
        paddingLeft: '10px',
      },
    },
    MuiPaper: {
      width: '100%',
    },
    MuiInputBase: {
      input: {
        fontSize: 14,
      },
    },
  },
});

const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4.5vh',
  },
  subheader: {
    color: 'white',
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
});

class DevMarket extends Component {
  _isMounted = false;

  state = {
    loading: true,
    devMarketData: [],
    version: '',
    schema: [],
    columns: [],
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    this.versions().then(() => {
      this.uiFields().then(() => {
        this.getDevMarketData().then(() => {
          let columns = this.state.schema.map((row) => {
            return {
              title: row.uiName,
              field: row.refName,
              sorting: false,
              cellStyle: { width: '20%' },
              render: (rowData) => {
                return (
                  row.refName &&
                  rowData[row.refName] && (
                    <span
                      style={{
                        display: 'block',
                        width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                      }}
                    >
                      {' '}
                      {rowData[row.refName]}
                    </span>
                  )
                );
              },
              editComponent: (props) => (
                <TextField
                  style={{
                    width: '20vw',
                    margin: 10,
                    fontSize: 12,
                  }}
                  fullWidth
                  value={props.value}
                  onChange={(event) => {
                    props.onChange(event.target.value);
                  }}
                />
              ),
            };
          });
          console.log(columns);
          this.setState({ columns, loading: false });
        });
      });
    });
  }

  versions() {
    return axios
      .get('config/version?entityName=bulkUploadDevMarket', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields() {
    if (
      localStorage.getItem('bulkUploadDevMarket') &&
      localStorage.bulkUploadDevMarket_version &&
      localStorage.bulkUploadDevMarket_version == this.state.version
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem('bulkUploadDevMarket')),
        });
      } catch (e) {
        localStorage.removeItem('bulkUploadDevMarket');
      }
      return Promise.resolve();
    } else {
      console.log('fetching from api');
      return axios
        .get('config?entityName=bulkUploadDevMarket', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          let schema = [];
          schema = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted) this.setState({ schema: schema });
          localStorage.setItem('bulkUploadDevMarket', JSON.stringify(schema));
          localStorage.bulkUploadDevMarket_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  getDevMarketData() {
    return axios
      .get('mtn/deal/ref/devmarket')
      .then((res) => {
        console.log(res);
        if (res) {
          this.setState({
            devMarketData: res.data.data.map((row) => {
              return { ...row, tableData: '' };
            }),
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  render() {
    const { classes } = this.props;

    let devMarket = (
      <div
        style={this.props.openDrawer ? { width: '97vw' } : { width: '117vw' }}
      >
        {/* <Grid container spacing={10} style={{ marginBottom: '1px' }}>

                <Grid item md={3}>
                    < FormControl style={{ minWidth: '100%', float: 'right' }}>
                        <InputLabel >No of Rows</InputLabel>
                        <Select
                            labelId='No of Rows'
                            name='No of Rows'
                            value={this.state.noOfRows}
                            onChange={(event) => {
                                this.setState({
                                    noOfRows: event.target.value
                                })
                            }}
                            input={<Input />}
                            renderValue={(selected) => {
                                if (selected) {
                                    if (selected.length === 0) {
                                        return <em>No of Rows</em>;
                                    }

                                    return selected

                                }
                            }}
                            inputProps={{ 'aria-label': 'Without label' }}
                        >
                            <MenuItem disabled value="">
                                <em>No of Rows</em>
                            </MenuItem>
                            {[1, 2, 3, 4].map((name) => (
                                <MenuItem key={name} value={name} >
                                    {name}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item md={3}>
                    <Button
                        variant="contained"
                        style={{ background: '#02bfa0', color: 'white', marginTop: '10px' }}
                        className={classes.btn}
                        onClick={() => {
                            if (this.state.noOfRows) {
                                let devMarketData = [...this.state.devMarketData]
                                for (let cnt = 0; cnt < Number(this.state.noOfRows); cnt++) {
                                    devMarketData.unshift({})
                                }
                                this.setState({
                                    devMarketData,
                                    noOfRows: null
                                })
                            }
                        }}>
                        Add
                        </Button>
                </Grid>
            </Grid> */}
        {this.state.devMarketData.length > 0 && (
          <ThemeProvider theme={theme}>
            <MaterialTable
              isLoading={this.state.loadingTable}
              icons={tableIcons}
              title={'Dev Market'}
              columns={this.state.columns}
              data={this.state.devMarketData}
              editable={{
                onBulkUpdate: (changes) =>
                  new Promise((resolve, reject) => {
                    setTimeout(() => {
                      console.log(changes);
                      if (Object.keys(changes).length > 0) {
                        let payload = [];
                        this.setState({ loadingTable: true });
                        Object.keys(changes).map((row) => {
                          let payloadData = { ...changes[row].newData };
                          payloadData.createdBy = this.props.userInfo.id;
                          payloadData.createdDate =
                            moment().format('DD-MM-YYYY');
                          payload.push(payloadData);
                        });
                        console.log(payload);
                        axios
                          .post('mtn/deal/ref/storedevmarket', payload)
                          .then((response) => {
                            console.log(response);
                            this.getDevMarketData().then(() => {
                              this.setState({
                                loadingTable: false,
                              });
                              resolve();
                            });
                          })
                          .catch((error) => {
                            console.log(error);
                            this.setState({
                              loadingTable: false,
                            });
                            resolve();
                          });
                      } else resolve();
                    }, 1000);
                  }),
                onRowAdd: (newData) =>
                  new Promise((resolve, reject) => {
                    let payload = { ...newData };
                    console.log(newData);
                    payload.createdBy = this.props.userInfo.id;
                    payload.createdDate = moment().format('DD-MM-YYYY');
                    this.setState({ loadingTable: true });
                    console.log(payload);
                    axios
                      .post('mtn/deal/ref/storedevmarket', [payload])
                      .then((response) => {
                        console.log(response);
                        if (response) {
                          let devMarketData = [
                            ...this.state.devMarketData,
                            newData,
                          ];
                          this.setState({
                            devMarketData,
                          });
                        }
                        this.setState({
                          loadingTable: false,
                        });
                        resolve();
                      })
                      .catch((error) => {
                        console.log(error);
                        this.setState({
                          loadingTable: false,
                        });
                        resolve();
                      });
                  }),
                onRowUpdate: (newData, oldData) =>
                  new Promise((resolve, reject) => {
                    let payload = { ...newData };
                    console.log(newData);
                    payload.createdBy = this.props.userInfo.id;
                    payload.createdDate = moment().format('DD-MM-YYYY');
                    this.setState({ loadingTable: true });
                    console.log(payload);
                    axios
                      .post('mtn/deal/ref/storedevmarket', [payload])
                      .then((response) => {
                        console.log(response);
                        const dataUpdate = [...this.state.devMarketData];
                        const index = oldData.tableData.id;
                        dataUpdate[index] = newData;
                        this.setState({
                          devMarketData: dataUpdate,
                          loadingTable: false,
                        });
                        resolve();
                      })
                      .catch((error) => {
                        console.log(error);
                        this.setState({
                          loadingTable: false,
                        });
                        resolve();
                      });
                  }),
              }}
              options={{
                pageSize: 10,
                pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
                toolbar: true,
                paging: true,
                rowStyle: {
                  fontSize: '15px',
                  padding: 10,
                },
                headerStyle: {
                  fontWeight: 'bold',
                },
              }}
            />
          </ThemeProvider>
        )}
      </div>
    );

    if (this.state.loading) devMarket = <Loader />;

    return devMarket;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
    openDrawer: state.drawerData.open,
  };
};

export default connect(mapStateToProps)(
  withStyles(useStyles)(WithErrorHandler(DevMarket, axios))
);
