import React, { useState, useEffect, useRef } from 'react';
import { TextField, ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';
import moment from 'moment';
import { BASEPACKAGES_LISTS } from './basePackages-constants';
import axios from '../../../axios-epc';
import MaterialTable, { MTableToolbar } from '@material-table/core';
import {
  TABLE_CONFIG,
  THEME_OVERRIDE,
  TABLE_ICONS,
} from './basePackages-config';
import { useSelector, useDispatch } from 'react-redux';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import Modal from '../../../UI/Modal/Modal';
import DerivedData from '../common/Derived';
import UploadButton from '../common/Upload/UploadButton';
import ExportButton from '../common/ExportButton';
import { CustomPaginationComponent } from '../common/table-config';
import { saveAsExcel } from '../common/utils';
import GetAppIcon from '@material-ui/icons/GetApp';
import { Autocomplete } from '@material-ui/lab';
import { fetchDealCaptureDD } from '../../../store/actions/actionCreators';
import Select from 'react-select';
import Snackbar from '../../../UI/Snackbar/Snackbar';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import useAPI from '../../../hooks/useAPI';

const theme = createMuiTheme({
  overrides: THEME_OVERRIDE,
});

const useStyles = (theme) => ({});

const BasePackagesTable = ({ setLoading, schema, id }) => {
  // selectors
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const dropdowns = useSelector((state) => state.dropdownData);
  const dispatch = useDispatch();
  // States
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loadingTable, setLoadingTable] = useState(true);
  const [selected, setSelected] = useState();
  const [modalOpen, setModalOpen] = useState(false);
  const [selection, setSelection] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [openSnack, setOpenSnack] = useState(false);
  const [messageSnack, setMessagesnack] = useState('');
  const [allDDLoaded, setAllDDLoaded] = useState(false);

  const selectTable = useRef();

  const [bundlesData, bundlesDataLoaded] = useAPI('/mtn/bundle/BundlesData');
  const [pricePlanData, pPlanDataLoaded] = useAPI('/mtn/siebel/PricePlan');
  const [packages, packagesLoaded] = useAPI('/mtn/deal/ref/pkgDropDown');

  // Functions
  const noneditable = (rowData) => {
    if (
      rowData.refName === 'package1' &&
      rowData.entityName === 'packageRange'
    ) {
      return 'onAdd';
    }
    return 'always';
  };

  const tableValidations = (rowData) => {
    if (!selected) return;
    let shouldReturn = true;
    selected.validations.forEach((row) => {
      if (row.required) {
        if (!rowData[row.name]) {
          shouldReturn = false;
        }
      }
    });
    return shouldReturn;
  };

  const getData = () => {
    if (!selected) {
      return;
    }
    setLoadingTable(true);

    return axios
      .get(selected.GET)
      .then((res) => {
        if (res) {
          const { data } = res.data;
          const mapData = data.map((row) => ({ ...row, tableData: '' }));
          setData(mapData);
        }
        setLoadingTable(false);
      })
      .catch((error) => {
        setLoading(false);
        setLoadingTable(false);
      });
  };

  const mapColumns = () => {
    let tmpColumns = schema.map((row) => {
      return {
        groupName: row.groupName,
        title: row.uiName,
        field: row.refName,
        validate: tableValidations,
        editable: noneditable(row),
        sorting: false,
        // cellStyle: { width: "30%" },
        render: (rowData) => {
          return (
            row.refName &&
            rowData[row.refName] && (
              <span
                style={{
                  display: 'block',
                  wordBreak: 'break-word',
                  width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                }}
              >
                {' '}
                {rowData[row.refName]}
              </span>
            )
          );
        },
        editComponent: (props) => {
          console.log(props);
          let type = 'text';
          let isRequired = false;

          if (selected.validations) {
            const validation = selected.validations.find(
              (t) => t.name === props.columnDef.field
            );

            if (validation) {
              if (validation.type) {
                type = validation.type;
              }
              isRequired = !!validation.required;
            }
          }

          const convertDD = (arr) => arr.map((d) => ({ value: d, label: d }));
          if (row.refName === 'packag') {
            const basepkgList = dropdowns.basepkg.map(({ PACKAGE1 }) => ({
              value: PACKAGE1,
              label: PACKAGE1,
            }));

            let basepkgDefVal = [];

            if (props.value) {
              basepkgDefVal = Array.isArray(props.value)
                ? convertDD(props.value)
                : convertDD([props.value]);
            }

            return (
              <Select
                menuPortalTarget={document.body}
                defaultValue={basepkgDefVal}
                onChange={(event) => {
                  props.onChange(event.value);

                  // console.log(event)
                  // const onChangeVal =
                  //   event && event.length ? event.map((e) => e.value) :'';
                  // props.onChange(onChangeVal);
                }}
                options={basepkgList}
              />
            );
          }
          if (
            row.refName === 'data1' ||
            row.refName === 'sms' ||
            row.refName === 'other1' ||
            row.refName === 'onnetMinutesBundle' ||
            row.refName === 'anytimeMinutesBundle' ||
            row.refName === 'vas'
          ) {
            console.log(bundlesData);
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '30vw', fontSize: '10px' }}
                  options={bundlesData}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }

          if (row.refName === 'basePackage') {
            console.log(bundlesData);
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '30vw', fontSize: '10px' }}
                  options={pricePlanData}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }

          if (row.refName === 'package1' && selected.name === 'Package Range') {
            const isSelectRequired = !props.value;
            return (
              <FormControl error={isSelectRequired}>
                <Autocomplete
                  defaultValue={props.value}
                  style={{ width: '30vw', fontSize: '10px' }}
                  options={packages}
                  renderInput={(params) => <TextField {...params} />}
                  onChange={(event, value) => {
                    props.onChange(value);
                  }}
                />
                {isSelectRequired && <FormHelperText>Required</FormHelperText>}
              </FormControl>
            );
          }
          // if (row.refName === "packageCode") {
          //   console.log(packageCodeData)
          //   return (
          //     <Autocomplete
          //       defaultValue={props.value}
          //       style={{ width: "30vw", fontSize: "10px" }}
          //       options={packageCodeData}
          //       renderInput={(params) => <TextField {...params} />}
          //       onChange={(event, value) => {
          //         props.onChange(value);
          //       }}
          //     />

          //   );
          // }

          if (props.columnDef.title === 'PACKAGE1' && props.rowData.tableData) {
            return <span>{props.value}</span>;
          }
          //let type = 'text';
          if (selected.validations) {
            const validation = selected.validations.find(
              (t) => t.name === props.columnDef.field
            );

            if (validation && validation.type) {
              type = validation.type;
            }
          }
          return (
            <TextField
              type={type}
              error={isRequired && !props.value}
              helperText={isRequired && !props.value && 'Required'}
              style={{
                width: '20vw',
                margin: 10,
                fontSize: 12,
              }}
              fullWidth
              value={props.value}
              onChange={(event) => {
                props.onChange(event.target.value);
              }}
            />
            // <TextField
            //   type={type}
            //   style={{
            //     width: '20vw',
            //     margin: 10,
            //     fontSize: 12,
            //   }}
            //   fullWidth
            //   value={props.value}
            //   onChange={(event) => {
            //     props.onChange(event.target.value);
            //   }}
            // />
          );
        },
      };
    });

    setColumns(tmpColumns);
  };

  useEffect(() => {
    dispatch(fetchDealCaptureDD('basepkg'));
  }, []);

  useEffect(() => {
    if (id) {
      const select = BASEPACKAGES_LISTS.find((list) => list.id === id);
      setSelected(select);
    }
  }, [id]);

  useEffect(() => {
    if (
      bundlesDataLoaded &&
      pPlanDataLoaded &&
      packagesLoaded &&
      dropdowns.basepkgLoaded
    ) {
      setAllDDLoaded(true);
    }
  }, [
    bundlesDataLoaded,
    pPlanDataLoaded,
    packagesLoaded,
    dropdowns.basepkgLoaded,
  ]);

  useEffect(() => {
    if (selected && allDDLoaded) {
      getData().then(() => mapColumns());
    }
  }, [selected, allDDLoaded]);

  const derivedAction = () => {
    if (
      selected &&
      selected.name !== 'Package Range' &&
      selected.name !== 'CI Sub'
    ) {
      return {
        tooltip: 'Show Derived Data',
        icon: CheckBoxIcon,
        onClick: (evt, data) => {
          setModalOpen(true);
        },
      };
    }
  };

  // Render
  return (
    <ThemeProvider theme={theme}>
      <Modal
        show={modalOpen}
        modalClosed={() => {
          setModalOpen(false);
        }}
        title={'Derived Data'}
      >
        <DerivedData
          selected={selected}
          columns={columns}
          schema={schema}
          selection={selection}
          identifierPayload={selected && selected.identifierPayload}
          derived={true}
        />
      </Modal>
      <Snackbar
        open={openSnack}
        message={messageSnack}
        onClose={(event, reason) => {
          if (reason === 'clickaway') {
            return;
          }
          setOpenSnack(false);
        }}
      />
      <MaterialTable
        style={{ padding: '20px' }}
        components={{
          Toolbar: (props) => (
            <div>
              <div
                style={{
                  fontSize: '18px',
                  fontWeight: '600',
                  marginLeft: '24px',
                }}
              >
                {props.title}
              </div>
              <div>
                <MTableToolbar {...props} />
              </div>
            </div>
          ),
          Pagination: (props) => {
            return <CustomPaginationComponent {...props} />;
          },
        }}
        tableRef={selectTable}
        isLoading={loadingTable}
        icons={TABLE_ICONS}
        title={`${selected && selected.name}`}
        columns={columns.filter(
          (row) =>
            selected.name === 'Line Commission' || row.groupName === 'UI Input'
        )}
        data={data}
        options={{
          ...TABLE_CONFIG,
          // selection: selected && selected.name !== "Line Commission",//Ankit
        }}
        actions={[
          // {
          //   icon: () => deriveButton(),
          //   isFreeAction: true,
          // },
          derivedAction,
          {
            tooltip: 'Export',
            icon: GetAppIcon,
            onClick: () => {
              saveAsExcel({
                schema: schema.filter(
                  (row) =>
                    (selected && selected.name === 'Line Commission') ||
                    row.groupName === 'UI Input'
                ),
                name: selected && selected.name,
                data: selectedRows,
              });
            },
          },
          {
            icon: () => (
              <UploadButton
                uploadUrl={selected && selected.UPLOAD_URL + userInfo.id}
                valiationUrl={selected && selected.VALIDATION_URL + userInfo.id}
                excelTabName={selected && selected.excelTabName}
                schema={schema.filter(
                  (row) =>
                    (selected && selected.name === 'Line Commission') ||
                    row.groupName === 'UI Input'
                )}
                uploadName={`${selected && selected.name}`}
                title={`${selected && selected.name}`}
                autoCloseOnSuccess={false} // QUICK FIX FOR NOW
                snackMessageOnSuccess={
                  'Data being Uploaded, Please Check the Validation Logs for Completion and Errors.'
                }
                onClose={() => getData().then(() => setLoadingTable(false))} // only called when data uploaded
                onSuccess={() => null} // END QUICK FIX
                // onSuccess={() =>
                //   getData().then(() => {
                //     setLoadingTable(false);
                //     setOpenSnack(true);
                //     setMessagesnack(
                //       "Data being Uploaded, Please Check the Validation Logs for Completion and Errors."
                //     );
                //   })
                // }
              />
            ),
            isFreeAction: true,
          },
          {
            icon: () => (
              <ExportButton
                schema={schema.filter(
                  (row) =>
                    (selected && selected.name === 'Line Commission') ||
                    row.groupName === 'UI Input'
                )}
                name={selected && selected.name}
                data={selectTable.current && selectTable.current.state.data}
              />
            ),
            isFreeAction: true,
          },
        ]}
        onSelectionChange={(rowSelection) => {
          const { identifier } = selected;
          setSelection(rowSelection.map((r) => r[identifier]));
          setSelectedRows(rowSelection);
        }}
        editable={{
          onBulkUpdate: (changes) =>
            new Promise((resolve, reject) => {
              setTimeout(() => {
                console.log(changes);
                if (Object.keys(changes).length > 0) {
                  let payload = [];
                  setLoadingTable(true);

                  Object.keys(changes).map((row) => {
                    let payloadData = { ...changes[row].newData };
                    let oldCreatedBy = data.find(
                      (item) => item.package1 === row.package1
                    );
                    console.log('oldCreatedBy', oldCreatedBy);
                    payload.createdBy = oldCreatedBy.createdBy;

                    //  payloadData.createdBy = userInfo.id;
                    // payloadData.createdDate = moment().format('DD-MM-YYYY');
                    payload.recordEndDate = '';
                    payload.updatedBy = userInfo.id;

                    payload.push(payloadData);
                  });
                  axios
                    .post(selected.POST, payload)
                    .then((response) => {
                      getData().then(() => {
                        setLoadingTable(false);
                        setOpenSnack(true);
                        setMessagesnack('Saved Successfully!');
                        resolve();
                      });
                    })
                    .catch((error) => {
                      setLoadingTable(false);
                      resolve();
                    });
                } else resolve();
              }, 1000);
            }),
          onRowAdd: (newData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              payload.createdBy = userInfo.id;
              payload.recordEndDate = '';
              payload.updatedBy = null;
              setLoadingTable(true);
              axios
                .post(selected.POST, [payload])
                .then((response) => {
                  if (response) {
                    let pkgData = [...data, newData];
                    setData(pkgData);
                  }
                  getData().then(() => {
                    setLoadingTable(false);
                    setOpenSnack(true);
                    setMessagesnack('Saved Successfully!');
                    resolve();
                  });
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
          onRowUpdate: (newData, oldData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              console.log('oldData', oldData);
              console.log('newData', newData);
              console.log('data', data);
              let oldCreatedBy = data.find(
                (item) => item.package1 === newData.package1
              );
              console.log('oldCreatedBy', oldCreatedBy);
              payload.createdBy = oldCreatedBy.createdBy;
              payload.recordEndDate = '';
              payload.updatedBy = userInfo.id;

              setLoadingTable(true);
              axios
                .post(selected.POST, [payload])
                .then((response) => {
                  const dataUpdate = [...data];
                  const index = oldData.tableData.id;
                  dataUpdate[index] = newData;
                  setData(dataUpdate);
                  getData().then(() => {
                    setLoadingTable(false);
                    setOpenSnack(true);
                    setMessagesnack('Saved Successfully!');
                    resolve();
                  });

                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
        }}
        localization={{
          body: {
            emptyDataSourceMessage: '',
          },
        }}
      />
    </ThemeProvider>
  );
};

export default withStyles(useStyles)(BasePackagesTable);
