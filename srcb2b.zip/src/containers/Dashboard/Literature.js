import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js'
import { saveAs } from 'file-saver'
import Button from '@material-ui/core/Button';
import AttachmentIcon from '@material-ui/icons/Attachment';
import { connect } from 'react-redux';


class Literature extends Component {
    _isMounted = false;

    state = {
        show: true,
        loading: true,
        download: false,
        literatureData: {}
    }

    async saveAsExcel() {
        this.setState({ loading: true })

        const workbook = new ExcelJS.Workbook();
        if (this.state.literatureData && this.state.literatureData['Plan Details']
            && this.state.literatureData['Plan Details'].length > 0) {
            const planDetailsWorksheet = workbook.addWorksheet("Plan Details");
            let planDetailsCols = []
            Object.keys(this.state.literatureData['Plan Details'][0]).map(key => {
                if (key !== 'seqId') {
                    let val = key.replace(/([A-Z])/g, " $1");
                    val = val.charAt(0).toUpperCase() + val.slice(1);
                    planDetailsCols.push({ header: val, key: key, width: 25, bold: true })
                }
            })
            planDetailsWorksheet.columns = planDetailsCols

            this.state.literatureData['Plan Details'].map(row => {
                planDetailsWorksheet.addRow(row);
            })

            planDetailsWorksheet.getRow(1).font = {
                bold: true
            }
        }


        if (this.state.literatureData && this.state.literatureData['Product Details']
            && this.state.literatureData['Product Details'].length > 0) {
            const productDetailsWorksheet = workbook.addWorksheet("Product Details");
            let productDetailsCols = []
            Object.keys(this.state.literatureData['Product Details'][0]).map(key => {
                if (key !== 'seqId') {
                    let val = key.replace(/([A-Z])/g, " $1");
                    val = val.charAt(0).toUpperCase() + val.slice(1);
                    productDetailsCols.push({ header: val, key: key, width: 25, bold: true })
                }
            })
            productDetailsWorksheet.columns = productDetailsCols

            this.state.literatureData['Product Details'].map(row => {
                productDetailsWorksheet.addRow(row);
            })

            productDetailsWorksheet.getRow(1).font = {
                bold: true
            }
        }

        if (this.state.literatureData && this.state.literatureData['Plan Offerability']
            && this.state.literatureData['Plan Offerability'].length > 0) {
            const offerabilityWorksheet = workbook.addWorksheet("Offerability");
            let offerabilityCols = []
            Object.keys(this.state.literatureData['Plan Offerability'][0]).map(key => {
                if (key !== 'seqId') {
                    let val = key.replace(/([A-Z])/g, " $1");
                    val = val.charAt(0).toUpperCase() + val.slice(1);
                    offerabilityCols.push({ header: val, key: key, width: 25, bold: true })
                }
            })
            offerabilityWorksheet.columns = offerabilityCols

            this.state.literatureData['Plan Offerability'].map(row => {
                offerabilityWorksheet.addRow(row);
            })

            offerabilityWorksheet.getRow(1).font = {
                bold: true
            }
        }

        if (this.state.literatureData && this.state.literatureData['Tariff']
            && this.state.literatureData['Tariff'].length > 0) {
            const tarrifWorksheet = workbook.addWorksheet("Tariff Details");
            let tarrifCols = []
            Object.keys(this.state.literatureData['Tariff'][0]).map(key => {
                if (key !== 'seqId') {
                    let val = key.replace(/([A-Z])/g, " $1");
                    val = val.charAt(0).toUpperCase() + val.slice(1);
                    tarrifCols.push({ header: val, key: key, width: 25, bold: true })
                }
            })
            tarrifWorksheet.columns = tarrifCols

            this.state.literatureData['Tariff'].map(row => {
                tarrifWorksheet.addRow(row);
            })

            tarrifWorksheet.getRow(1).font = {
                bold: true
            }
        }

        if (this.state.literatureData && this.state.literatureData['Product Service Detail']
            && this.state.literatureData['Product Service Detail'].length > 0) {
            const productServiceDetailsWorksheet = workbook.addWorksheet("Product Service Detail");
            let productServiceDetailsCols = []
            Object.keys(this.state.literatureData['Product Service Detail'][0]).map(key => {
                if (key !== 'seqId') {
                    let val = key.replace(/([A-Z])/g, " $1");
                    val = val.charAt(0).toUpperCase() + val.slice(1);
                    productServiceDetailsCols.push({ header: val, key: key, width: 25, bold: true })
                }
            })
            productServiceDetailsWorksheet.columns = productServiceDetailsCols

            this.state.literatureData['Product Service Detail'].map(row => {
                productServiceDetailsWorksheet.addRow(row);
            })

            productServiceDetailsWorksheet.getRow(1).font = {
                bold: true
            }
        }


        const buf = await workbook.xlsx.writeBuffer()
        this.setState({ loading: false })
        saveAs(new Blob([buf]), 'Literature_' +
            this.props.releaseData.externalReleaseId + '.xlsx')
    }


    getLiteratureData = () => {
        return axios
            .get(
                "customAttach/literature?releaseId=" +
                this.props.releaseData.externalReleaseId, {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId,
                    }
                }
            )
            .then(res => {
                console.log(res);
                if (res && res.data.data && Object.keys(res.data.data).length > 0) {
                    this.setState({ download: true, literatureData: res.data.data })
                }
            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false })

            });

    }

    modalCloseHandler = () => {
        this.setState({ show: false })
        this.props.showLiterature()
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidMount() {
        this._isMounted = true;

        this.getLiteratureData().then(() => {
            this.setState({ loading: false })
        })
    }

    downloadFile = (url) => {
		this.setState({ loading: true });

		return axios
			.get(url, {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,
				},
				responseType: 'blob',
			})
			.then((res) => {
				console.log(res);
				console.log(res.data);

				this.setState({ loading: false });
				var headers = res.headers;
				var blob = new Blob([res.data], {
					type: headers['content-type'],
				});

				var link = document.createElement('a');
				link.href = window.URL.createObjectURL(blob);
				link.download =
					'Literature_' + this.props.releaseData.externalReleaseId;
				link.click();
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	};

    render() {
        let literature = <Modal
            show={this.state.show}
            size={'sm'}
            modalClosed={this.modalCloseHandler}
            title={"Release Id " + this.props.releaseData.externalReleaseId}
        >
            {this.state.loading ? <div style={{ minHeight: '20vh' }}> <Loader /> </div> :
                // this.state.download ?
                <React.Fragment>
                    <div style={{
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        minHeight: '20vh'
                    }} >

                        {/* <Button variant="outlined" color="primary"
                            onClick={() => {
                                this.saveAsExcel()
                            }}
                            style={{
                                textTransform: 'none',
                                marginRight: 20
                            }}>
                            <AttachmentIcon style={{
                                marginRight: '10px'
                            }} /> Download as Excel
                                </Button> */}


<Button
									variant="outlined"
									color="primary"
									onClick={() => {
										const url =
											'customAttach/literature/excel/download?releaseId=' +
											this.props.releaseData.externalReleaseId;
										this.downloadFile(url);
									}}
									style={{
										textTransform: 'none',
										marginRight: 20,
									}}>
									<AttachmentIcon
										style={{
											marginRight: '10px',
										}}
									/>{' '}
									Download as Excel
								</Button>




                        <Button variant="outlined" color="primary"
                            onClick={() => {
                                this.setState({ loading: true });

                                axios
                                    .get("customAttach/pdf?releaseId=" +
                                        this.props.releaseData.externalReleaseId, {
                                            responseType: "blob",
                                            headers: {
                                                opId: this.props.userInfo.opId,
                                                buId: this.props.userInfo.buId,
                                            }
                                        })
                                    .then(res => {
                                        console.log(res);
                                        console.log(res.data);

                                        this.setState({ loading: false });
                                        var headers = res.headers;
                                        var blob = new Blob([res.data], {
                                            type: headers["content-type"]
                                        });

                                        var link = document.createElement("a");
                                        link.href = window.URL.createObjectURL(blob);
                                        link.download = 'Literature_' + this.props.releaseData.externalReleaseId;
                                        link.click();
                                    })
                                    .catch(error => {
                                        console.log(error);
                                        if (this._isMounted)
                                            this.setState({ loading: false });
                                    });
                            }}
                            style={{
                                textTransform: 'none'
                            }}>
                            <AttachmentIcon style={{
                                marginRight: '10px'
                            }} /> Download as Pdf
                                </Button>
                    </div>

                </React.Fragment>
                // : < Typography variant="h5" style={{
                //     textAlign: 'center'
                // }} > No Data Found </Typography >
            }

        </Modal>


        return literature

    }

}

const mapStateToProps = state => {
    return {
        userInfo: state.login.loggedInUserInfo,
    };
}


export default connect(mapStateToProps)(WithErrorHandler(Literature, axios))