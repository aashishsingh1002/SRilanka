export const ENTITY_NAME = 'device';

export const DEVICES_LISTS = [
  {
    id: 'device',
    name: 'Device',
    derivedExcelName: 'Device',
    entity: 'bulkUploadDevices',
    GET: 'mtn/deal/deviceui',
    POST: 'mtn/deal/storedeviceui',
    DERIVED_URL: 'mtn/deal/deviceder',
    UPLOAD_URL: 'mtn/deal/uploaddevicesui?createdBy=',
    VALIDATION_URL: 'mtn/deal/GetDeviceslog?createdBy=',
    PKG_UPDATE_URL: 'mtn/deal/updatedeviceui',
    identifier: 'uniqueNumber',
    identifierPayload: 'uniqueNumber',
    excelTabName: 'XMtnDevicesUiTab',

    validations: [
      {
        name: 'manufacturer',
        required: true,
      },
      {
        name: 'marketingName',
        required: true,
      },

      {
        name: 'deviceType',
        required: true,
      },
      {
        name: 'live',
        required: true,
      },
      {
        name: 'technology',
        required: true,
      },
    ],
  },
  {
    id: 'devicePricing',
    name: 'Device Pricing',
    derivedExcelName: 'DevicePrc',
    entity: 'bulkUploadDevicesPricing',
    GET: 'mtn/deal/deviceprcui',
    POST: 'mtn/deal/storedeviceprcui',
    DERIVED_URL: 'mtn/deal/deviceprcder',
    UPLOAD_URL: 'mtn/deal/uploaddevicesprcui?createdBy=',
    VALIDATION_URL: 'mtn/deal/GetDevicePricinglog?createdBy=',
    PKG_UPDATE_URL: 'mtn/deal/updatedeviceprcui',
    excelTabName: 'XMtnDevicePricingUiTab',
    identifier: 'refId',
    identifierPayload: 'refId',
    validations: [
      {
        name: 'deviceNumber',
        type: 'number',
        required: true,
      },
      {
        name: 'quarter',
        required: true,
      },
      {
        name: 'currency',
        required: true,
      },
      {
        name: 'sim',
        required: true,
      },
      {
        name: 'purchacePrice',
        type: 'number',
        required: true,
      },
      {
        name: 'pcrCost',
        required: true,
      },
      {
        name: 'tnpRebate',
        type: 'number',
      },
      {
        name: 'exchangeRateApplied',
        type: 'number',
      },
      {
        name: 'status',
        required: true,
      },
      {
        name: 'ddpCip',
        required: true,
      },
      {
        name: 'pricingSource',
        required: true,
      },

      {
        name: 'column1',
        type: 'number',
      },
      {
        name: 'postpaidLeadSub',
        type: 'number',
      },
      {
        name: 'prepaidRrp',
        type: 'number',
      },
    ],
  },
  {
    id: 'manufacturer',
    name: 'Manufacturer',

    entity: 'manufacturerTable',
    GET: 'mtn/modification/manudata',
    POST: 'mtn/modification/storemanufacturer',
    // DERIVED_URL: "mtn/deal/deviceprcder",
    VALIDATION_URL: 'mtn/modification/GetManufacturerlog?createdBy=',
    PKG_UPDATE_URL: 'mtn/modification/editmanufacturer',
    UPLOAD_URL: 'mtn/modification/uploadmanufacturers?createdBy=',
    excelTabName: 'xmtnmanufacturertab',
    identifier: 'refId',
    identifierPayload: 'refId',
    validations: [
      {
        name: 'manufacturer',
        required: true,
      },
      {
        name: 'ecoTerms',
        required: true,
      },
      {
        name: 'standardCurrency',
        required: true,
      },
    ],
  },

  {
    id: 'aspu',
    name: 'ASPU',
    derivedExcelName: 'ASPU',
    entity: 'aspu',
    GET: 'mtn/aspu/Data',
    POST: 'mtn/aspu/storeaspudata',
    DERIVED_URL: 'mtn/aspu/aspuder',
    PKG_UPDATE_URL: 'mtn/aspu/storeaspudata',
    UPLOAD_URL: 'mtn/aspu/uploadaspulog?createdBy=',
    VALIDATION_URL: 'mtn/aspu/GetAspuLog?createdBy=',
    excelTabName: 'XMtnAspuUiTab',
    identifier: 'refId',
    identifierPayload: 'refId',
    validations: [
      {
        name: 'manufacturerWithTechnology',
        required: true,
      },
      {
        name: 'manufacturerRequired',
        required: true,
      },
      {
        name: 'deviceManufacturer',
        required: true,
      },
      {
        name: 'hsModel',
        required: true,
      },
      {
        name: 'deviceRequired',
        required: true,
      },
      {
        name: 'packageTier',
        required: true,
        type: 'number',
      },
      {
        name: 'deviceTier',
        required: true,
        type: 'number',
      },
      {
        name: 'deviceCost',
        required: true,
        type: 'number',
      },
      {
        name: 'revenueBySubscriber',
        required: true,
        type: 'number',
      },
      {
        name: 'commonPackageName',
        required: true,
      },

      {
        name: 'quarterDevicePackageKey',
        required: true,
      },
      {
        name: 'commonDeviceName',
        required: true,
      },
      {
        name: 'deviceKey',
        required: true,
      },
      {
        name: 'totalRevenueLc',
        required: true,
        type: 'number',
      },
      {
        name: 'dataRevenue',
        required: true,
        type: 'number',
      },
      {
        name: 'smsRevenue',
        required: true,
        type: 'number',
      },
      {
        name: 'internationVoiceRevenue',
        required: true,
        type: 'number',
      },
      {
        name: 'localVoiceRevenue',
        required: true,
        type: 'number',
      },
      {
        name: 'totalRechargeValue',
        required: true,
        type: 'number',
      },
      {
        name: 'totalNumberOfRecharges',
        required: true,
        type: 'number',
      },

      {
        name: 'dataMbUsed2g',
        required: true,
      },
      {
        name: 'dataMbUsed3g',
        required: true,
      },
      {
        name: 'dataMbUsed4g',
        required: true,
      },
      {
        name: 'dataMbUsed',
        required: true,
      },

      {
        name: 'smsSent',
        required: true,
        type: 'number',
      },

      {
        name: 'intOutVoiceMinutesUsed',
        required: true,
        type: 'number',
      },

      {
        name: 'lclOutVoiceMinutesUsed',
        required: true,
        type: 'number',
      },
      {
        name: 'numberOfSubscribers',
        required: true,
        type: 'number',
      },
      {
        name: 'tariffType',
        required: true,
      },

      {
        name: 'hsModel',
        required: true,
      },
      {
        name: 'packageRequired',
        required: true,
      },
    ],
  },
];
