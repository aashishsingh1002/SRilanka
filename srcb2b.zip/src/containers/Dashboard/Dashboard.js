import React, { Component } from "react";
import Releases from "./Releases";
import Attachment from "./Attachment";
import AuditLogs from "./AuditLogs";
import Literature from "./Literature";
import Workflow from "./Workflow";
import TreeView from "./TreeView";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import { connect } from "react-redux";
import Loader from "../../UI/Loader/Loader";
import Button from "@material-ui/core/Button";
import axios from "axios";
import UploadModal from "./UploadModal";
import { Grid } from "@material-ui/core";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import * as actionTypes from '../../store/actions/actionTypes';

class Dashboard extends Component {
  _isMounted = false;

  state = {
    literature: false,
    attachment: false,
    treeView: false,
    auditLogs: false,
    workflow: false,
    uploadModal: false,
    relData: {},
    approversVersion: "",
    approversData: {},
    loading: false,
    serviceSelected: false,
    rolegroup: null,
    RadioBtn: null,
    productlists:[]
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount() {
    this._isMounted = true;
    if (this._isMounted) this.setState({ loading: true });
    //this.approversDataHandler().then(() => {
      if (this._isMounted) this.setState({ loading: false });
  //});
  }

  approversDataHandler(productid) {
    console.log("fetching from api");
    console.log('userInfo',this.props.userInfo)
    return (
      axios
        .get("/b2b-workflow/approvers/v2?replicationStatus="+productid, {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
            
            authUserId: this.props.userInfo.id,
            authGroupId: this.props.userInfo.group[0],
            Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((res) => {
          let approvalData = res.data.data;
          console.log(approvalData);
          if (this._isMounted)
            this.setState({ approversData: { ...approvalData } });
            console.log('app',this.state.approversData);
          localStorage.setItem("approversData", JSON.stringify(approvalData));
          localStorage.approversData_version = this.state.approversVersion;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        })
    );
    // }
  }
  attachmentHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ attachment: true });
  };
  auditLogsHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ auditLogs: true });
  };

  literatureHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ literature: true });
  };

  workflowHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ workflow: true });
  };

  treeViewHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ treeView: true });
  };
  uploadModalHandler = (relData) => {
    this.setState({ relData: { ...relData } });
    this.setState({ uploadModal: true });
  };
  showAttachmentHandler = () => {
    this.setState({ attachment: false });
  };

  showTreeViewHandler = () => {
    this.setState({ treeView: false });
  };

  showUploadModalHandler = () => {
    this.setState({ uploadModal: false });
  };

  showLiteratureHandler = () => {
    this.setState({ literature: false });
  };

  showAuditLogsHandler = () => {
    this.setState({ auditLogs: false });
  };
  showWorkflowHandler = () => {
    this.setState({ workflow: false });
  };

  render() {
    let dashboard = (
      <React.Fragment>
        {this.state.literature ? (
          <Literature
            userInfo={this.props.userInfo}
            showLiterature={this.showLiteratureHandler}
            releaseData={this.state.relData}
          />
        ) : null}
        {this.state.treeView ? (
          <TreeView
            userInfo={this.props.userInfo}
            showTreeView={this.showTreeViewHandler}
            releaseData={this.state.relData}
          />
        ) : null}
        {this.state.attachment ? (
          <Attachment
            userInfo={this.props.userInfo}
            showAttachment={this.showAttachmentHandler}
            releaseData={this.state.relData}
            
          />
        ) : null}
        {this.state.auditLogs ? (
          <AuditLogs
            showAuditLogs={this.showAuditLogsHandler}
            releaseData={this.state.relData}
          />
        ) : null}
        {this.state.uploadModal ? (
          <UploadModal
            uploadModal={this.showUploadModalHandler}
            releaseData={this.state.relData}
          />
        ) : null}

        {this.state.workflow ? (
          <Workflow
            showWorkflow={this.showWorkflowHandler}
            userInfo={this.props.userInfo}
            releaseData={this.state.relData}
            approvers={{}}
            selectedType={this.state.selectedType}
            //approversDataHandler={(id)=>this.approversDataHandler(id)}
          />
        ) : null}
        <Releases
  attachmentUpload={this.attachmentHandler}
  auditLogs={this.auditLogsHandler}
  literature={this.literatureHandler}
  workflow={this.workflowHandler}
  treeView={this.treeViewHandler}
  uploadModal={this.uploadModalHandler}
 // approverHandler={(id)=>this.approversDataHandler(id)}
  />
      </React.Fragment>
    );
    if (this.state.loading) dashboard = <Loader />;
    return dashboard;
  }
}

const mapStateToProps = (state) => {
  return {
	userInfo: state.login.loggedInUserInfo,
  };
};

export default connect(mapStateToProps)(WithErrorHandler(Dashboard, axios));
