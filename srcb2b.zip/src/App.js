import React, { Component } from 'react';
import { Route, Switch, Redirect, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Login from './containers/Login/Login';
import Dashboard from './containers/Dashboard/Dashboard';
import Layout from './HOC/Layout/Layout';
import Worklist from './containers/Worklist/Worklist';
import EditRelease from './containers/EditRelease/EditRelease';
import PlanConfiguration from './containers/Entities/Package/PlanConfiguration';
import * as actionTypes from './store/actions/actionTypes';
import ProductConfiguration from './containers/Entities/Product/ProductConfiguration';
import Contract from './containers/EntityCreation/Contract';
import ExternalTemplate from './containers/Entities/ExternalTemplate';
import AssociateTemplate from './containers/Entities/AssociateTemplate';
import LibraryReport from './containers/Entities/LibraryReport';
import ContractProfile from './containers/EntityCreation/ContractProfile';
import Attribute from './containers/EntityCreation/Attribute';
import RatePlan from './containers/EntityCreation/RatePlan/RatePlan';
import WorkflowAdmin from './containers/WorkflowAdmin/WorkflowAdmin';
import Admin from './containers/Admin/Admin';
import ProductPerformance from './containers/ProductPerformance/ProductPerformance';
import Events from './containers/EntityCreation/Events';
import AdminPlanConfiguration from './containers/Admin/Plan/PlanConfiguration';
import AdminProductConfiguration from './containers/Admin/Product/ProductConfiguration';
import AdminOfferabilityConfiguration from './containers/Admin/Offerability/OfferabilityConfiguration';
import BundleContractConfiguration from './containers/Admin/Contract/BundleContractConfiguration';
import ContractCreationConfiguration from './containers/Admin/Contract/ContractCreationConfiguration';
import ContractProfileConfiguration from './containers/Admin/ContractProfile/ContractProfileConfiguration';
import AttributeConfiguration from './containers/Admin/Attribute/AttributeConfiguration';
import AttributeGroupConfiguration from './containers/Admin/Attribute/AttributeGroupConfiguration';
import RatePlanConfiguration from './containers/Admin/RatePlan/RatePlanConfiguration';
import RentalConfiguration from './containers/Admin/Rental/RentalConfiguration';
import DiscountConfiguration from './containers/Admin/Discount/DiscountConfiguration';
import CtsConfiguration from './containers/Admin/Product/CtsConfiguration';
import UserConfiguration from './containers/Admin/User/UserConfiguration';
import AdvanceSearch from './containers/AdvanceSearch/AdvanceSearch';
import AllReleases from './containers/AllReleases/AllReleases';
import PlanReport from './containers/Library/PlanReport';
import PackageReport from './containers/Library/PackageReport';
import ProductReport from './containers/Library/ProductReport';
import SelectApprover from './containers/EditRelease/SelectApprover';
import customWorklist from './containers/Worklist/customWorklist';
import AdminPlanConfigurationNew from './containers/Admin/Plan/PlanConfigurationNew';
import BulkEdit from './containers/BulkEdit';
import Reports from './containers/Library/Reports'
class App extends Component {
  componentDidMount() {
    console.log('enviroment variable');
    console.log(process.env.REACT_APP_URL);
  }

  render() {
    let routes = (
      <Switch>
        <Route path='/login' component={Login} />
        <Redirect to='/login' />
      </Switch>
    );
    console.log('this.props.userInfo', this.props.userInfo);
    //"Admin"
    if (Object.keys(this.props.userInfo).length > 0) {
      if (this.props.userInfo.group.includes('b2bsales')) {
        routes = (
          <Switch>
            <Route
              path='/'
              exact
              render={() => {
                this.props.onReleaseExit();
                return <Dashboard />;
              }}
            />
            <Route
              path='/login'
              render={() => {
                console.log('logout');
                console.log(Object.keys(this.props.userInfo).length);

                if (Object.keys(this.props.userInfo).length > 0)
                  return <Dashboard />;
                else return <Login />;
              }}
            />
            <Route path='/worklist' exact component={Worklist} />
            <Route path='/rfiWorklist' exact component={customWorklist} />
            <Route path='/selectApprover' exact component={SelectApprover} />
            <Route path='/editRelease' exact component={EditRelease} />
            {/* <Route path='/ExternalTemplate' exact   render={(props) => <ExternalTemplate  {...props}/>} /> */}
            <Route path='/ExternalTemplate' exact component={ExternalTemplate}/>
            <Route path='/AssociateTemplate' exact component={AssociateTemplate}/>

            <Route
              path='/planConfiguration'
              exact
              component={PlanConfiguration}
            />
            <Route
              path='/productConfiguration'
              exact
              component={ProductConfiguration}
            />
            <Route path='/contractsCreation' exact component={Contract} />
            <Route
              path='/contractProfileCreation'
              exact
              component={ContractProfile}
            />
            <Route path='/attributeConfiguration' exact component={Attribute} />
            <Route path='/ratePlanConfiguration' exact component={RatePlan} />
            <Route
              path='/productPerformance'
              exact
              component={ProductPerformance}
            />
            <Route path='/events' exact component={Events} />
            <Route path='/advanceSearch' exact component={AdvanceSearch} />
            <Route path='/libraryReport' exact component={LibraryReport} />
            <Route path='/attributeReport' exact component={PlanReport} />
            <Route path='/planReport' exact component={PackageReport} />
            <Route path='/productReport' exact component={ProductReport} />
            <Route path='/allReleases' exact component={AllReleases} />
            <Route path='/bulkEdit' exact component={BulkEdit} />
            <Route path='/report' exact component={Reports} />
            <Redirect to='/' />
          </Switch>
        );
      } else if (this.props.userInfo.group.includes('Admin')) {
        routes = (
          <Switch>
            <Route
              path='/login'
              render={() => {
                console.log('logout');
                console.log(Object.keys(this.props.userInfo).length);

                if (Object.keys(this.props.userInfo).length > 0)
                  return <Admin />;
                else return <Login />;
              }}
            />
            <Route path='/adminDashboard' exact component={Admin} />
            <Route
              path='/adminPlanConfiguration'
              exact
              component={AdminPlanConfiguration}
            />
            <Route
              path='/adminPackageConfiguration'
              exact
              component={AdminPlanConfigurationNew}
            />
            <Route
              path='/adminProductConfiguration'
              exact
              component={AdminProductConfiguration}
            />
            <Route
              path='/adminOfferabilityConfiguration'
              exact
              component={AdminOfferabilityConfiguration}
            />
            <Route
              path='/adminBundleContractConfiguration'
              exact
              component={BundleContractConfiguration}
            />
            <Route
              path='/adminContractCreationConfiguration'
              exact
              component={ContractCreationConfiguration}
            />
            <Route
              path='/adminContractProfileConfiguration'
              exact
              component={ContractProfileConfiguration}
            />
            <Route
              path='/adminAttrConfiguration'
              exact
              component={AttributeConfiguration}
            />
            <Route
              path='/adminAttrGrpConfiguration'
              exact
              component={AttributeGroupConfiguration}
            />
            <Route
              path='/adminRatePlanConfiguration'
              exact
              component={RatePlanConfiguration}
            />
            <Route
              path='/adminPriceConfiguration'
              exact
              component={RentalConfiguration}
            />
            <Route
              path='/adminDiscountConfiguration'
              exact
              component={DiscountConfiguration}
            />

            <Route
              path='/adminCtsConfiguration'
              exact
              component={CtsConfiguration}
            />
            <Route
              path='/adminuserConfiguration'
              exact
              component={UserConfiguration}
            />
            <Route path='/adminWorklist' exact component={WorkflowAdmin} />

            <Redirect to='/adminDashboard' />
          </Switch>
        );
      } else {
        routes = (
          <Switch>
            <Route path='/worklist' exact component={Worklist} />
            <Route path='/allReleases' exact component={AllReleases} />
            <Route path='/report' exact component={Reports} />
            <Route
              path='/login'
              render={() => {
                console.log('logout');
                console.log(Object.keys(this.props.userInfo).length);

                if (Object.keys(this.props.userInfo).length > 0)
                  return <Worklist />;
                else return <Login />;
              }}
            />
            <Redirect to='/worklist' />
          </Switch>
        );
      }
    }
    if(this.props.userInfo.group && this.props.userInfo.group.length>0){
      console.log('null', this.props.userInfo);
    return (
    <div>
    <Layout>{routes}</Layout>
  </div>
  )}
  return <div>{routes}</div>
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onReleaseExit: () =>
      dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(App));
