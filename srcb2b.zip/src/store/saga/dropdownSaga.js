import axios from "axios";
import { call, put, takeEvery, takeLatest } from "redux-saga/effects";
import {
  FETCH_DEAL_CAPTURE_DD_REQUEST,
  FETCH_DEAL_CAPTURE_DD_SUCCESS,
} from "../actions/actionTypes";

function getAPI(payload) {
  return axios.request({
    method: "get",
    url: `${process.env.REACT_APP_URL}/mtn/deal/basicInfo/${payload}`,
    //   data: authParams
  });
}

function* fetchDealCaptureDD(action) {
  try {
    const payload = yield call(getAPI, action.payload);
    const { data } = payload.data;
    yield put({
      type: FETCH_DEAL_CAPTURE_DD_SUCCESS,
      payload: {
        key: action.payload,
        data: data,
      },
    });
  } catch (e) {
    yield put({ type: "DEAL_CAPTURE_DD_FAILED", message: e.message });
  }
}

export function* dealCaptureSagaWatcher() {
  yield takeEvery(FETCH_DEAL_CAPTURE_DD_REQUEST, fetchDealCaptureDD);
}
