import React, { Component } from 'react';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import CustomInput from '../../../UI/Input/Input';
import TextField from '@material-ui/core/TextField';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import IconButton from '@material-ui/core/IconButton';
import SearchIcon from '@material-ui/icons/Search';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from 'axios';
import Loader from '../../../UI/Loader/Loader';
import Button from '@material-ui/core/Button';
import Modal from '../../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import DeleteIcon from '@material-ui/icons/Delete';
import Paper from '@material-ui/core/Paper';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import moment from "moment";
import { connect } from 'react-redux';
import * as actionTypes from '../../../store/actions/actionTypes';
import { withRouter } from 'react-router-dom';
import MultiSelect from '../../../UI/Input/MultiSelect'



const useStyles = (theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '96%',
        flexShrink: 0,
    },
    table: {
        minWidth: 650,
    },

});


class BundleItems extends Component {
    _isMounted = false;

    state = {
        loading: true,
        version: '',
        categories: [],
        categoryOptions: [],
        types: [],
        typesOptions: [],
        subTypes: [],
        subTypesOptions: [],
        selCategories: [],
        selTypes: [],
        selSubtypes: [],
        products: [],
        show: false,
        modalContent: null,
        selProduct: '',
        bundleItemsProducts: {},
        bundleType: 'Product',
        bundleItems: [],
        selbundleItem: null
    }
    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidMount() {
        this._isMounted = true;
        this.versionsHandler().then(() => {
            this.fieldsLov().then(() => {
                let categoryOptions = [];
                let typesOptions = [];
                let subTypesOptions = [];

                this.state.categories.map(category => {
                    categoryOptions.push(
                        category.uiName
                    );
                });
                this.state.types.map(type => {
                    typesOptions.push(type.uiName);
                });
                this.state.subTypes.map(subType => {
                    subTypesOptions.push(subType.uiName);
                });

                this.setState({
                    categoryOptions: Array.from(new Set(categoryOptions)),
                    typesOptions: Array.from(new Set(typesOptions)),
                    subTypesOptions: Array.from(new Set(subTypesOptions))
                })
                this.packageBundleItemsData().then(() => {
                    this.setState({ loading: false })
                })
            })
        })
    }

    fieldsLov() {
        if (
            localStorage.getItem("productCategories") &&
            localStorage.getItem("productSubTypes") &&
            localStorage.getItem("productTypes") &&
            localStorage.productCts_version &&
            localStorage.productCts_version == this.state.version
        ) {
            console.log("fetching cts from local storage");
            try {
                this.setState({
                    categories: JSON.parse(
                        localStorage.getItem("productCategories")
                    ),
                    subTypes: JSON.parse(localStorage.getItem("productSubTypes")),
                    types: JSON.parse(localStorage.getItem("productTypes"))
                })
            } catch (e) {
                localStorage.removeItem("productCategories");
                localStorage.removeItem("productSubTypes");
                localStorage.removeItem("productTypes");
            }
            return Promise.resolve();
        } else {
            console.log("fetching cst from api");
            return axios
                .all([
                    axios.get(
                        process.env.REACT_APP_URL +
                        "config?entityName=product.categoryList",
                        {
                            headers: {
                                opId: this.props.userInfo.opId,
                                buId: this.props.userInfo.buId
                            }
                        }
                    ),
                    axios.get(
                        process.env.REACT_APP_URL +
                        "config?entityName=product.subTypeList",
                        {
                            headers: {
                                opId: this.props.userInfo.opId,
                                buId: this.props.userInfo.buId
                            }
                        }
                    ),
                    axios.get(
                        process.env.REACT_APP_URL +
                        "config?entityName=product.typeList",
                        {
                            headers: {
                                opId: this.props.userInfo.opId,
                                buId: this.props.userInfo.buId
                            }
                        }
                    )
                ])
                .then(
                    axios.spread((resCategories, resSubTypes, resTypes) => {

                        let types = resTypes.data.data;
                        localStorage.setItem("productTypes", JSON.stringify(types));
                        let subTypes = resSubTypes.data.data;
                        localStorage.setItem(
                            "productSubTypes",
                            JSON.stringify(subTypes)
                        );
                        let categories = resCategories.data.data;
                        localStorage.setItem(
                            "productCategories",
                            JSON.stringify(categories)
                        );
                        if (this._isMounted)
                            this.setState({
                                categories: categories,
                                subTypes: subTypes,
                                types: types
                            })
                        localStorage.productCts_version = this.state.version;
                    })
                )
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });
        }
    }

    versionsHandler() {
        return axios.get(
            process.env.REACT_APP_URL +
            "config/version?entityName=product.cts",
            {
                headers: {
                    opId: this.props.userInfo.opId,
                    buId: this.props.userInfo.buId
                }
            }
        )
            .then(res => {
                if (this._isMounted)
                    this.setState({ version: res.data.data.version })
            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });
    }

    searchProducts = () => {
        this.setState({
            loading: false,
            selProduct: null
        })
        let payload = {};
        payload.releaseId = this.props.releaseData.releaseId;
        payload.categoryList = this.state.selCategories;
        payload.typeList = this.state.selTypes;
        payload.subTypeList = this.state.selSubtypes;
        console.log(payload);
        axios
            .post(
                process.env.REACT_APP_URL +
                "package/bundle/ctsProducts",
                payload,
                {
                    headers: {
                        opId: this.props.userInfo.opId,
                    }
                }
            )
            .then(res => {
                console.log(res.data.data);
                let products = []
                if (res.data.data.length > 0) {
                    res.data.data.map(product => {
                        products.push(product.productId + "/" + product.productDesc);
                    });
                    if (this._isMounted)
                        this.setState({ loading: false, products: products })
                } else {
                    let modalContent = < Typography variant="h6">No Products Found.
                 </ Typography>
                    if (this._isMounted)
                        this.setState({
                            modalContent: modalContent, show: true,
                            loading: false,
                            products: []
                        })

                }
            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });
    }
    errorConfirmedHandler = () => {
        this.setState({ show: false });
    }

    saveBundleItem = () => {
        if (this.props.packageData.packageId) {
            if (this._isMounted)
                this.setState({ loading: true })
            let payload = {};
            let date = moment().format("DD-MMM-YY");
            let listOfPpmPackageProdMapAud = [];
            payload.packageId = this.props.packageData.packageId;
            payload.releaseId = this.props.releaseData.releaseId;
            Object.keys(this.state.bundleItemsProducts).forEach(key => {
                let bundleItem = {};
                bundleItem.buId = this.props.userInfo.buId;
                bundleItem.createdBy = this.props.userInfo.id;
                bundleItem.createdDate = date;
                bundleItem.opId = this.props.userInfo.opId;
                bundleItem.startDate = date;
                bundleItem.endDate = "31-DEC-31";
                bundleItem.version = "1.0";
                bundleItem.packageId = this.props.packageData.packageId;
                bundleItem.packageProductId = key;
                bundleItem.productId = key;
                bundleItem.defaultState = this.state.bundleItemsProducts[key].formData.defaultState;
                if (this.state.bundleItemsProducts[key].formData.defaultState == "Mandatory")
                    bundleItem.mandatory = "Y";
                else bundleItem.mandatory = "N";

                bundleItem.maximum = this.state.bundleItemsProducts[key].formData.maximum;
                bundleItem.minimum = this.state.bundleItemsProducts[key].formData.minimum;
                bundleItem.datasetId = this.state.bundleItemsProducts[key].formData.datasetId;
                listOfPpmPackageProdMapAud.push(bundleItem);
            });
            payload.listOfPpmPackageProdMapAud = listOfPpmPackageProdMapAud;
            console.log(payload);
            axios
                .post(process.env.REACT_APP_URL +
                    "package/bundle/", payload)
                .then(response => {
                    console.log(response);
                    if (this._isMounted)
                        this.setState({ loading: false })
                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });
        } else {
            let modalContent = < Typography variant="h6">Submit Basic Package Details first.
                                                                     </ Typography>
            this.setState({
                modalContent: modalContent, show: true,

            })
        }
    }

    packageBundleItemsData() {
        if (this.props.releaseData.releaseId) {
            if (this.props.packageData.packageId) {
                return axios
                    .get(
                        process.env.REACT_APP_URL +
                        "package/bundle?id=" + this.props.packageData.packageId +
                        '&releaseId=' + this.props.releaseData.releaseId, {
                            headers: {
                                opId: this.props.userInfo.opId,
                            }
                        }
                    )
                    .then(res => {
                        console.log(res.data.data);
                        if (res.data.data.length > 0) {
                            let bundleItems = {};
                            res.data.data.map(product => {
                                let proDetails = {};
                                let formData = {};
                                formData.defaultState = product.defaultState;
                                formData.minimum = product.minimum;
                                formData.maximum = product.maximum;
                                formData.datasetId = product.datasetId
                                proDetails.productDesc = product.description;
                                let productId = product.productId;
                                proDetails.formData = formData;
                                bundleItems[productId] = proDetails;
                            });
                            if (this._isMounted)
                                this.setState({ bundleItemsProducts: bundleItems })
                        }
                    })
                    .catch(error => {
                        console.log(error)
                        if (this._isMounted)
                            this.setState({ loading: false })
                    });
            } else {
                return Promise.resolve();
            }
        } else {
            return Promise.resolve();
        }
    }
    render() {
        const { classes } = this.props;

        let bundleItems = <React.Fragment
        >
            <Modal
                show={this.state.show}
                modalClosed={this.errorConfirmedHandler}
                title={'Something Went Wrong!'}
            >
                {this.state.modalContent}
            </Modal>
            <Grid container spacing={2}
                style={{ display: !this.state.loading ? 'block' : 'none' }}
            >
                <Grid item xs={12} sm={6} >
                    <Box >
                        <span style={{}}>Select the Type of Item to Bundle</span>
                    </Box>
                    <Box my={2} >

                        <CustomInput
                            resize
                            refType='SelectInput'
                            value={this.state.bundleType}
                            changed={
                                (value) => {
                                    this.setState({
                                        bundleType: value
                                    })
                                    let url = ''
                                    if (value == 'Package')
                                        url = "package/basicDetails/searchPackages?releaseID="
                                    else if (value == 'Bundle')
                                        url = "package/basicDetails/searchBundles?releaseID="
                                    else if (value == 'Promotion')
                                        url = "package/basicDetails/searchPromotions?releaseID="

                                    if (value != 'Product') {
                                        this.setState({ loading: true })
                                        axios
                                            .get(
                                                process.env.REACT_APP_URL +
                                                url +
                                                this.props.releaseData.releaseId,
                                                {
                                                    headers: {
                                                        opId: this.props.userInfo.opId
                                                    }
                                                }
                                            )

                                            .then(res => {
                                                console.log(res);
                                                let bundleItems = []
                                                Object.keys(res.data.data).map(item => {
                                                    bundleItems.push(item + "/" + res.data.data[item]);
                                                });
                                                if (this._isMounted)
                                                    this.setState({ loading: false, bundleItems: bundleItems })
                                            })
                                            .catch(error => {
                                                console.log(error)
                                                if (this._isMounted)
                                                    this.setState({ loading: false })
                                            });
                                    }
                                }
                            }

                            refLovs={['Product', 'Bundle', 'Package', 'Promotion']} />


                    </Box>
                </Grid>
                <Grid item xs={12}>

                    <Card style={{ overflow: 'visible' }}>
                        <CardHeader
                            className={classes.cardHeader}
                            classes={{
                                subheader: classes.subheader,
                            }}
                            subheader={'Filter ' + this.state.bundleType} />

                        <CardContent >
                            {this.state.bundleType == 'Product' && <div>
                                <Grid container alignContent="flex-start" spacing={2} >
                                    <Grid item xs={12} sm={6} md={3}>
                                        <Box >
                                            <span style={{}}>Category</span>
                                        </Box>

                                        <Box mt={2} >
                                            <MultiSelect
                                                refLovs={this.state.categoryOptions}
                                                value={this.state.selCategories}
                                                changed={(selected) => {
                                                    this.setState({ selCategories: selected })
                                                }
                                                }
                                                placeholder={'Categories'}
                                            />

                                        </Box>

                                    </Grid>

                                    <Grid item xs={12} sm={6} md={3}>
                                        <Box >
                                            <span style={{}}>Type</span>
                                        </Box>
                                        <Box mt={2} >
                                            <MultiSelect
                                                refLovs={this.state.typesOptions}
                                                value={this.state.selTypes}
                                                changed={(selected) => {
                                                    this.setState({ selTypes: selected })
                                                }
                                                }
                                                placeholder={'Types'}
                                            />
                                        </Box>
                                    </Grid>

                                    <Grid item xs={10} sm={6} md={3}>
                                        <Box >
                                            <span style={{}}>Sub Type</span>
                                        </Box>
                                        <Box mt={2} >
                                            <MultiSelect
                                                refLovs={this.state.subTypesOptions}
                                                value={this.state.selSubtypes}
                                                changed={(selected) => {
                                                    this.setState({ selSubtypes: selected })
                                                }
                                                }
                                                placeholder={'Sub Types'}
                                            />
                                        </Box>
                                    </Grid>
                                    {this.props.releaseData.releaseId && <Grid item xs={2} sm={6} md={3}>

                                        <Box mt={1} >
                                            <IconButton
                                                onClick={this.searchProducts}
                                            >
                                                <SearchIcon />
                                            </IconButton>
                                        </Box>
                                    </Grid>}


                                </Grid>
                                {this.state.products.length > 0 && <Grid container alignItems="flex-end" spacing={2} style={{ marginTop: '2vh' }}>
                                    <Grid item xs={12} sm={6} >
                                        <Box >
                                            <span style={{}}>Products</span>
                                        </Box>
                                        <Box mt={1} >
                                            <CustomInput
                                                resize
                                                refType='SelectInput'
                                                value={this.state.selProduct}
                                                changed={(value) => {
                                                    if (value) {
                                                        if (value.split("/")[0] in this.state.bundleItemsProducts) {
                                                            let modalContent = < Typography variant="h6">Product Already Selected.
                                                                     </ Typography>
                                                            this.setState({
                                                                modalContent: modalContent, show: true,

                                                            })
                                                        } else {
                                                            let proDetails = {};
                                                            let formData = {};
                                                            formData.defaultState = "Mandatory";
                                                            formData.minimum = "1";
                                                            formData.maximum = "1";
                                                            formData.datasetId = 'Product'
                                                            proDetails.productDesc = value.split("/")[1];
                                                            var productId = value.split("/")[0];
                                                            proDetails.formData = formData;
                                                            this.setState((prevState) => {
                                                                return {
                                                                    bundleItemsProducts: {
                                                                        ...prevState.bundleItemsProducts,
                                                                        [productId]: proDetails
                                                                    }
                                                                };
                                                            });
                                                        }
                                                        this.setState({ selProduct: null })

                                                    }
                                                }
                                                }
                                                refLovs={this.state.products} />

                                        </Box>
                                    </Grid>


                                </Grid>}
                            </div>}
                            {this.state.bundleType != 'Product' && <div>
                                <Grid container alignContent="flex-start" spacing={2}>
                                    <Grid item xs={12} sm={6}>
                                        <Box >
                                            <span style={{}}>{this.state.bundleType}</span>
                                        </Box>
                                        <Box mt={1} >
                                            <CustomInput
                                                resize
                                                refType='SelectInput'
                                                value={this.state.selbundleItem}
                                                changed={(value) => {
                                                    if (value) {
                                                        if (value.split("/")[0] in this.state.bundleItemsProducts) {
                                                            let modalContent = < Typography variant="h6">{this.state.bundleType} Already Selected.
                                                                     </ Typography>
                                                            this.setState({
                                                                modalContent: modalContent, show: true,

                                                            })
                                                        } else {
                                                            let proDetails = {};
                                                            let formData = {};
                                                            formData.defaultState = "Mandatory";
                                                            formData.minimum = "1";
                                                            formData.maximum = "1";
                                                            formData.datasetId = this.state.bundleType

                                                            proDetails.productDesc = value.split("/")[1];
                                                            var productId = value.split("/")[0];
                                                            proDetails.formData = formData;
                                                            this.setState((prevState) => {
                                                                return {
                                                                    bundleItemsProducts: {
                                                                        ...prevState.bundleItemsProducts,
                                                                        [productId]: proDetails
                                                                    }
                                                                };
                                                            });
                                                        }

                                                    }
                                                }
                                                }

                                                refLovs={this.state.bundleItems} />

                                        </Box>
                                    </Grid>
                                </Grid>
                            </div>}
                        </CardContent>

                    </Card>
                    <Grid item xs={12} style={{ marginTop: '2vh' }} >

                        <Card >
                            <CardHeader
                                className={classes.cardHeader}
                                classes={{
                                    subheader: classes.subheader,
                                }}
                                subheader={'Bundle Items'} />

                            <CardContent >
                                <TableContainer component={Paper}
                                    style={{ height: '30vh' }}>
                                    <Table className={classes.table} size="small" >
                                        <TableHead>
                                            <TableRow>
                                                <TableCell >Item Id</TableCell>
                                                <TableCell >Item Description</TableCell>
                                                <TableCell >Default State</TableCell>
                                                <TableCell >Min</TableCell>
                                                <TableCell >Max</TableCell>
                                                <TableCell >Delete</TableCell>

                                            </TableRow>
                                        </TableHead>
                                        <TableBody
                                        >
                                            {
                                                Object.keys(this.state.bundleItemsProducts).map(key => {
                                                    return <TableRow key={key}>

                                                        <TableCell
                                                            style={{
                                                                width: '25%',
                                                                cursor: 'pointer',
                                                                textDecoration: 'underline',
                                                                color: '#ff1921'
                                                            }}
                                                            onClick={
                                                                () => {
                                                                    this.props.changeProductActiveStep(0)
                                                                    let proData = { ...this.props.productData }
                                                                    proData['productId'] = key
                                                                    this.props.onProductEnter(proData)
                                                                    this.props.changeProductKey(this.props.productKey + '1')
                                                                    this.props.history.push('/productConfiguration')

                                                                }
                                                            }
                                                        >{key}</TableCell>
                                                        <TableCell
                                                            style={{ width: '25%' }}
                                                        >{this.state.bundleItemsProducts[key].productDesc}</TableCell>
                                                        <TableCell
                                                            style={{ width: '20%' }} >
                                                            <FormControl style={{ minWidth: '100%'}}>
                                                                <Select
                                                                    defaultValue='Mandatory'
                                                                    value={this.state.bundleItemsProducts[key].formData['defaultState']}
                                                                    onChange={(event) => {
                                                                        let changedData = { ...this.state.bundleItemsProducts[key] }
                                                                        changedData.formData['defaultState'] = event.target.value
                                                                        this.setState((prevState) => {
                                                                            return {
                                                                                bundleItemsProducts: {
                                                                                    ...prevState.bundleItemsProducts,
                                                                                    [key]: changedData
                                                                                }
                                                                            };
                                                                        });
                                                                    }}
                                                                >
                                                                    {
                                                                        ["Optional", "Mandatory"].map(lov => {
                                                                            return <MenuItem key={lov} value={lov}>{lov}</MenuItem>
                                                                        })
                                                                    }
                                                                </Select>
                                                            </FormControl>
                                                        </TableCell>
                                                        <TableCell
                                                            style={{ width: '10%' }}>
                                                            <TextField
                                                                value={this.state.bundleItemsProducts[key].formData['minimum']}
                                                                type="number"
                                                                onChange={(event) => {
                                                                    let changedData = { ...this.state.bundleItemsProducts[key] }
                                                                    changedData.formData['minimum'] = event.target.value
                                                                    this.setState((prevState) => {
                                                                        return {
                                                                            bundleItemsProducts: {
                                                                                ...prevState.bundleItemsProducts,
                                                                                [key]: changedData
                                                                            }
                                                                        };
                                                                    });
                                                                }}
                                                            />
                                                        </TableCell>
                                                        <TableCell
                                                            style={{ width: '10%' }}>
                                                            <TextField
                                                                type="number"
                                                                value={this.state.bundleItemsProducts[key].formData['maximum']}
                                                                onChange={(event) => {
                                                                    let changedData = { ...this.state.bundleItemsProducts[key] }
                                                                    changedData.formData['maximum'] = event.target.value
                                                                    this.setState((prevState) => {
                                                                        return {
                                                                            bundleItemsProducts: {
                                                                                ...prevState.bundleItemsProducts,
                                                                                [key]: changedData
                                                                            }
                                                                        };
                                                                    });
                                                                }}
                                                            />
                                                        </TableCell>
                                                        <TableCell
                                                            style={{ width: '5%' }} >
                                                            <DeleteIcon onClick={(event) => {
                                                                event.stopPropagation()
                                                                let bundleItemsProducts = { ...this.state.bundleItemsProducts }
                                                                delete bundleItemsProducts[key]
                                                                this.setState({
                                                                    bundleItemsProducts: bundleItemsProducts
                                                                })
                                                            }} style={{ color: 'red', cursor: 'pointer' }} />
                                                        </TableCell>

                                                    </TableRow>

                                                })
                                            }

                                        </TableBody>
                                    </Table>
                                </TableContainer>

                            </CardContent>
                            {this.props.releaseData.releaseId && <div style={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center'
                            }}>
                                <Button variant="outlined"
                                    onClick={this.saveBundleItem}
                                    style={{
                                        color: 'green', border: '1px solid green'
                                        , marginTop: '1%',
                                        marginBottom: '1%'

                                    }}
                                >
                                    Save
                        </Button>
                            </div>}
                        </Card>
                    </Grid>

                </Grid>

            </Grid>

        </React.Fragment>
        if (this.state.loading)
            bundleItems = <Loader />
        return bundleItems
    }

}

const mapStateToProps = state => {
    return {
        productKey: state.productData.productKey,
        productData: state.productData.productData,
    };
}
const mapDispatchToProps = dispatch => {
    return {
        changeProductKey: (productKey) => dispatch({ type: actionTypes.CHANGE_PRODUCT_KEY, productKey: productKey }),
        onProductEnter: (productData) => dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
        changeProductActiveStep: (activeStep) => dispatch({ type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP, activeStep: activeStep }),

    };
};


export default connect(mapStateToProps, mapDispatchToProps)(withStyles(useStyles)(WithErrorHandler(withRouter(BundleItems), axios)));