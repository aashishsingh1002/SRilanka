import React, { useEffect,useState } from 'react';

import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Typography from '@material-ui/core/Typography';
import SummaryGeneral from './summaryGeneral';
import SummaryBundle from './summaryBundle';
import SummarySV2 from './summarySV2';
import SummaryOfferability2 from './summaryOfferability2';
import SummaryPricing from './summaryPricing';
import SummarySiebel1 from './summarySiebel1';
import SummarySiebel2 from './summarySiebel2';
import SummaryProduct from './summaryProduct';
import SummaryProductBundle from './summaryProductBundle';
import StyledButton from '../../../UI/Button/Button';

import axios from '../../../axios-epc';
import { useSelector } from 'react-redux';
import Paper from '@material-ui/core/Paper';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import Button from '../../../UI/Button/Button'; //
import InputLabel from '@material-ui/core/InputLabel';
import SelectApprover from '../../EditRelease/SelectApprover';
import SelectApproverSummery from '../../EditRelease/SelectApproverSummery';
import { transformPLMStatus } from '../../../helpers/functions'; //helpers/functions
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';

function Alert(props) {
  return <MuiAlert elevation={6} variant='filled' {...props} />;
}



// validation = () => {
//   console.log("Click Function")

// }

const lists = [
  {
    title: 'General',
    content: <SummaryGeneral />,
  },
  {
    title: 'Bundle Items',
    content: <SummaryBundle />,
  },
  {
    title: 'Pricing',
    content: <></>,
  },
  {
    title: 'Offerability',
    content: <></>,
  },
  {
    title: 'Siebel Configuration 1/2',
    content: <></>,
  },
  {
    title: 'Siebel Configuration 2/2',
    content: <></>,
  },
  {
    title: 'SV Configuration',
    content: <SummarySV2 />,
  },
];

const ListItem = ({ title, children }) => {
  return (
    <Accordion
      elevation={0}
      square
      defaultExpanded
      style={{
        borderBottom: '1px solid #eee',
        padding: '0 20px',
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        aria-controls='panel1a-content'
        id='panel1a-header'
      >
        <Typography style={{ fontSize: '22px', fontWeight: 'bold' }}>
          {/* {list.title} */}
          {title}
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        {children}
        {/* {list.title === "Offerability" ? (
            <SummaryOfferability2 {...props} />
          ) : (
            list.content
          )} */}
        {/* {list.content} */}
        {/* <Typography>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Suspendisse malesuada lacus ex, sit amet blandit leo lobortis
            eget.
          </Typography> */}
      </AccordionDetails>
    </Accordion>
  );
};


// const validation = () => {
//   console.log("Click Function")

// } 




const Summary = (props) => {
  const { releaseId } = useSelector((state) => state.releaseData.releaseData);
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const [loading, setLoading] = useState(false);
  const [openSnack, setopenSnack] = useState(false);
  const [popupMsg, setpopupMsg] = useState(false);

  const vertical = 'top';
  const horizontal = 'center';


 // _isMounted = false;

 const handleClose=() =>{
  setopenSnack(false);
 }

  const validation = () => {
    setLoading(true);
    // alert('Hello!')


    // const res ={
    //   data: {
    //     "ERR_MSG" : "Alert! Incorrect Modeling.DATA POOLING PARENT CHILD",
    //     "ERR_CODE": "ERROR-0001"
    //     }
    // };

    const res ={
      data: {
        "statusMsg" : "success",
        "statuscode": "success"
        }
    };

    if(res.data.ERR_CODE ==='ERROR-0001'){
      setopenSnack(true);
      setpopupMsg(res.data.ERR_MSG);
      console.log(res.data.ERR_MSG)
    }


    if(res.data.statuscode ==='success'){
      setopenSnack(true);
      setpopupMsg(res.data.statusMsg);
      console.log(res.data.statusMsg)
    }
      
        return false;

    return axios.get(
      process.env.REACT_APP_URL + 
      'validation/bundle?releaseID=' +
      props.releaseData.releaseId +
      '&version=1.0_Release&packageId=' +
      props.id,
    {
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        opId: props.userInfo.opId,
        buId: props.userInfo.buId,
    }})
    .then((res) => {
      setLoading(false);
      console.log(res);
      if(res.statuscode){
        console.log(res.statusMsg);
      }
     
    }) .catch((error) => {
      setLoading(false);
      console.log(error);
    });
  } 


  const status = transformPLMStatus(
    props.releaseData.pendingWith,
    props.releaseData.releaseStatus,
    props.releaseData.enableFederation,
    props.releaseData.enableDeploy,
    props.releaseData.pendingWithGroup
  );
  return (
    <div style={{ margin: '-20px -40px' }}>

          <Snackbar
          anchorOrigin={{ vertical, horizontal }}
          open={openSnack}
          autoHideDuration={4000}
          onClose={handleClose}
          >
          <Alert onClose={handleClose} severity='success'>
           {popupMsg}
          </Alert>
        </Snackbar>


      {/* {lists.map((list) => ( */}
      <ListItem title='General'>
        {props.entity !== 'PRODUCT' ? (
          <SummaryGeneral {...props} />
        ) : (
          <SummaryProduct {...props} />
        )}
      </ListItem>
      <ListItem title='Bundle Items'>
        {props.entity !== 'PRODUCT' ? (
          <SummaryBundle {...props} />
        ) : (
          <SummaryProductBundle {...props} />
        )}
      </ListItem>
      <ListItem title='Pricing'>
        <SummaryPricing {...props} />
      </ListItem>
      <ListItem title='Offerability'>
        <SummaryOfferability2 {...props} />
      </ListItem>
      {/* <ListItem title='Siebel Configuration 1/2'>
        <SummarySiebel1 {...props} />
      </ListItem> */}
      {/* <ListItem title='Siebel Configuration 2/2'>
        <SummarySiebel2 {...props} />
      </ListItem> */}
      {/* {props.entity !== 'PRODUCT' && (
        <ListItem title='SV Configuration'>
          <SummarySV2 {...props} />
        </ListItem> */}
      {/* )} */}
      {releaseId &&
        userInfo.id === 'BU1' &&
        status === 'Product Modelling in progress' && (
          <SelectApproverSummery status={status} />
        )}
        <StyledButton
         onClick={validation}
            style={{
                  marginLeft: '20px',
                  marginTop: '3%',
                  background: '#5dc17f',
                  }}
                
            type='submit'
        >
                Validate
          </StyledButton>
    </div>






  );
};

export default Summary;
