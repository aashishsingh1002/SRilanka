import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import React, { useState } from 'react';
import StyledButton from '../../../UI/Button/Button';

export const TABLE_ICONS = {
  Add: (props) => <StyledButton {...props}>Add</StyledButton>,
  Check: Check,
  Clear: Clear,
  Delete: DeleteOutline,
  DetailPanel: ChevronRight,
  Edit: Edit,
  Export: SaveAlt,
  Filter: FilterList,
  FirstPage: FirstPage,
  LastPage: LastPage,
  NextPage: ChevronRight,
  PreviousPage: ChevronLeft,
  ResetSearch: Clear,
  Search: Search,
  SortArrow: ArrowDownward,
  ThirdStateCheck: Remove,
  ViewColumn: ViewColumn,
};

export const TABLE_CONFIG = {
  selection: true,
  pageSize: 5,
  pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
  toolbar: true,
  paging: true,
  rowStyle: {
    fontSize: '14px',
    padding: 10,
    background: 'rgba(0,0,0,0.04)',
  },
  headerStyle: {
    fontSize: '13px',
    fontWeight: 'bold',
    textTransform: 'capitalize',
    lineHeight: '1.2em',
  },
  // search: false,
  searchFieldAlignment: 'left',
  searchFieldVariant: 'outlined',
  showTitle: false,
  searchFieldStyle: {
    borderRadius: 50,
    border: '1px solid rgba(0, 0, 0, 0.04)',
    background: 'rgba(0, 0, 0, 0.04)',
    height: 40,
    width: 320,
  },
};

export const THEME_OVERRIDE = {
  MuiTableCell: {
    root: {
      padding: '0px',
      paddingLeft: '10px',
    },
  },
  MuiPaper: {
    width: '100%',
  },
  MuiInputBase: {
    input: {
      fontSize: 14,
    },
  },
};
