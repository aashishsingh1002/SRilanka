import React from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';

const useStyles = makeStyles((theme) => ({
    btn: {
        textTransform: 'unset !important'
    }
}));

const styles = (theme) => ({
    root: {
        margin: 0,
        padding: theme.spacing(2),
    },
    closeButton: {
        position: 'absolute',
        right: theme.spacing(1),
        top: theme.spacing(1),
        color: 'white',
        marginLeft: '200'
    },
    dialogPaper: {
        minHeight: '30vh',
    },
});

const DialogTitle = withStyles(styles)((props) => {
    const { children, classes, onClose, ...other } = props;
    return (
        <MuiDialogTitle disableTypography className={classes.root} {...other}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
                <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                    <CloseIcon />
                </IconButton>
            ) : null}

        </MuiDialogTitle>
    );
});

const DialogContent = withStyles((theme) => ({
    root: {
        padding: theme.spacing(2),
    },
}))(MuiDialogContent);

const DialogActions = withStyles((theme) => ({
    root: {
        margin: 0,
        padding: theme.spacing(1),
    },
}))(MuiDialogActions);

const Modal = withStyles(styles)((props) => {
    const classes = useStyles();

    return (
        <div>

            <Dialog disableBackdropClick={true}
                style={{
                    transform: 'scale(.8)',
                }}
                BackdropProps={{ style: { backgroundColor: "transparent" } }}
                classes={{ paper: props.classes.dialogPaper }} fullWidth
                maxWidth={props.size ? props.size : 'md'} onClose={props.modalClosed} aria-labelledby="customized-dialog-title" open={props.show}>
                <DialogTitle id="customized-dialog-title" onClose={props.modalClosed} style={{ background: '#546D7A', color: 'white' }}>
                    {props.title}
                </DialogTitle>
                <DialogContent dividers>
                    {props.children}
                </DialogContent>
                <DialogActions>
                    <Button autoFocus onClick={props.modalClosed}
                        color="primary" className={classes.btn}>
                        Ok
          </Button>
                </DialogActions>
            </Dialog>
        </div>
    );
})

export default Modal;