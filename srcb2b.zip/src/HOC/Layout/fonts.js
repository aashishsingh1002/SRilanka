import MTNBrighterSans from '../../assests/fonts/MTNBrighterSans-Regular.woff2'; //../../assests/fonts/MTNBrighterSans-Regular.woff2'

export const BrighterSans = {
  fontFamily: 'BrighterSans',
  fontStyle: 'normal',
  fontDisplay: 'swap',
  fontWeight: 400,
  src: `url(${MTNBrighterSans}) format('woff2')`,
};
