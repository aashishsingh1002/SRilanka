import * as actionTypes from "../actions/actionTypes";

const initialState = {
  generalLoaded: false,
  generalData: null,
  bundleData: [],
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.FETCH_GENERAL_SUCCESS:
      return {
        ...state,
        generalData: action.payload,
      };
    case actionTypes.FETCH_BUNDLE_SUCCESS:
      return {
        ...state,
        bundleData: action.payload,
      };

    default:
      return state;
  }
};

export default reducer;
