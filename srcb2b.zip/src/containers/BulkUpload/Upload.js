import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import { DropzoneArea } from 'material-ui-dropzone';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import DeleteIcon from '@material-ui/icons/Delete';
import GetAppIcon from '@material-ui/icons/GetApp';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';

const theme = createMuiTheme({
  overrides: {
    MuiDropzoneArea: {
      root: {
        minHeight: '20px',
      },
      text: {
        display: 'none',
      },
    },
  },
});

class Upload extends Component {
  _isMounted = false;

  state = {
    show: true,
    loading: false,
    files: [],
    dataUpload: {},
  };

  constructor(props) {
    super(props);
    this.dropzoneRef = React.createRef();
  }

  modalCloseHandler = () => {
    this.setState({ show: false });
    this.props.showUpload();
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount() {
    this._isMounted = true;
  }

  handleChange(file) {
    let dataUpload = {};
    dataUpload[file.name] = false;
    this.setState({
      files: file,
      dataUpload: dataUpload,
    });
  }

  saveDataHandler = () => {
    if (
      this.state.files.length > 0 &&
      !this.state.dataUpload[this.state.files[0].name]
    ) {
      this.setState({
        loading: true,
      });
      let formData = new FormData();
      this.state.files.map((file) => {
        formData.append('file', file);
      });
      console.log('formData');
      for (var pair of formData.entries()) {
        console.log(pair[0]);
        console.log(pair[1]);
      }

      const { uploadUrl } = this.props;
      axios
        .post(uploadUrl, formData)
        .then((res) => {
          if (res) {
            let dataUpload = {};
            dataUpload[this.state.files[0].name] = true;
            this.setState({
              dataUpload: dataUpload,
            });
            this.props.loadData();
          }

          this.setState({
            loading: false,
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  };

  async saveAsExcel() {
    const { worksheetName = '', fileName = '' } = this.props;
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(worksheetName);
    let sheetColumns = [];
    this.props.schema.forEach((row) => {
      sheetColumns.push({
        header: row.uiName,
        key: row.refName,
        width: 25,
      });
    });

    worksheet.columns = sheetColumns;
    worksheet.getRow(1).font = {
      bold: true,
    };

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), `${fileName}_Template.xlsx`);
  }

  render() {
    return (
      <Modal
        show={this.state.show}
        modalClosed={this.modalCloseHandler}
        size='md'
        title={this.props.title}
      >
        <div style={{ minHeight: '25vh' }}>
          <div
            style={
              this.state.loading ? { display: 'none' } : { display: 'block' }
            }
          >
            <TableContainer component={Paper} style={{ marginTop: '2vh' }}>
              <Table size='small'>
                <TableHead>
                  <TableRow>
                    <TableCell align='center' style={{ width: '10%' }}>
                      Template
                    </TableCell>
                    <TableCell align='left' style={{ width: '15%' }}>
                      Select File{' '}
                    </TableCell>
                    <TableCell align='left' style={{ width: '35%' }}>
                      File Name
                    </TableCell>
                    <TableCell align='left' style={{ width: '20%' }}>
                      Status
                    </TableCell>
                    <TableCell align='left' style={{ width: '10%' }}>
                      Delete
                    </TableCell>
                    <TableCell align='left' style={{ width: '10%' }}>
                      Upload
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell align='center'>
                      {' '}
                      <GetAppIcon
                        onClick={(event) => {
                          this.saveAsExcel();
                        }}
                        style={{ cursor: 'pointer' }}
                      />{' '}
                    </TableCell>
                    <TableCell align='left'>
                      <ThemeProvider theme={theme}>
                        <DropzoneArea
                          ref={this.dropzoneRef}
                          onChange={this.handleChange.bind(this)}
                          maxFileSize={10000000}
                          dropzoneText=''
                          showPreviewsInDropzone={false}
                          filesLimit={1}
                          acceptedFiles={[
                            'application/vnd.ms-excel',
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                          ]}
                        />
                      </ThemeProvider>
                    </TableCell>

                    {this.state.files.length > 0 && (
                      <React.Fragment>
                        <TableCell align='left'>
                          {' '}
                          {this.state.files[0].name}
                        </TableCell>
                        <TableCell align='left'>
                          {!this.state.dataUpload[this.state.files[0].name]
                            ? 'Not Uploaded'
                            : 'Uploaded'}
                        </TableCell>
                        <TableCell align='left'>
                          {!this.state.dataUpload[this.state.files[0].name] ? (
                            <DeleteIcon
                              onClick={(event) => {
                                this.dropzoneRef.current.deleteFile(
                                  this.state.files[0],
                                  0
                                );
                              }}
                              style={{ color: 'red', cursor: 'pointer' }}
                            />
                          ) : null}
                        </TableCell>
                        <TableCell align='left' style={{ width: '15%' }}>
                          {!this.state.dataUpload[this.state.files[0].name] ? (
                            <Button
                              variant='contained'
                              size='medium'
                              style={{
                                background: '#02bfa0',
                                textTransform: 'none',
                                float: 'right',
                              }}
                              onClick={this.saveDataHandler}
                            >
                              Upload
                            </Button>
                          ) : null}
                        </TableCell>
                      </React.Fragment>
                    )}
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </div>
        {this.state.loading && <Loader />}
      </Modal>
    );
  }
}

export default WithErrorHandler(Upload, axios);
