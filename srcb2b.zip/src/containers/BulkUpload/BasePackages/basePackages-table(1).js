import React, { useState, useEffect, useRef } from 'react';
import { TextField, ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import { withStyles } from '@material-ui/core/styles';
import moment from 'moment';
import { BASEPACKAGES_LISTS } from './basePackages-constants';
import axios from '../../../axios-epc';
import MaterialTable from 'material-table';
import {
  TABLE_CONFIG,
  THEME_OVERRIDE,
  TABLE_ICONS,
} from './basePackages-config';
import { useSelector } from 'react-redux';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import Modal from '../../../UI/Modal/Modal';
import DerivedData from '../common/Derived';
import UploadButton from '../common/Upload/UploadButton';
import ExportButton from '../common/ExportButton';

const theme = createMuiTheme({
  overrides: THEME_OVERRIDE,
});

const useStyles = (theme) => ({});

const BasePackagesTable = ({ setLoading, schema, id }) => {
  // selectors
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);

  // States
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loadingTable, setLoadingTable] = useState(true);
  const [selected, setSelected] = useState();
  const [modalOpen, setModalOpen] = useState(false);
  const [selection, setSelection] = useState([]);
  const selectTable = useRef();

  // Functions

  const tableValidations = (rowData) => {
    if (!selected) return;

    let shouldReturn = true;
    selected.validations.forEach((row) => {
      if (row.required) {
        if (!rowData[row.name]) {
          shouldReturn = false;
        }
      }
    });

    return shouldReturn;
  };

  const getData = () => {
    if (!selected) {
      return;
    }
    setLoadingTable(true);

    return axios
      .get(selected.GET)
      .then((res) => {
        if (res) {
          const { data } = res.data;
          const mapData = data.map((row) => ({ ...row, tableData: '' }));
          setData(mapData);
        }
        setLoadingTable(false);
      })
      .catch((error) => {
        setLoading(false);
        setLoadingTable(false);
      });
  };

  const mapColumns = () => {
    let tmpColumns = schema.map((row) => {
      return {
        groupName: row.groupName,
        title: row.uiName,
        field: row.refName,
        validate: tableValidations,
        sorting: false,
        // cellStyle: { width: "30%" },
        render: (rowData) => {
          return (
            row.refName &&
            rowData[row.refName] && (
              <span
                style={{
                  display: 'block',
                  wordBreak: 'break-word',
                  width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                }}
              >
                {' '}
                {rowData[row.refName]}
              </span>
            )
          );
        },
        editComponent: (props) => {
          let type = 'text';
          let isRequired = false;

          if (selected.validations) {
            const validation = selected.validations.find(
              (t) => t.name === props.columnDef.field
            );

            if (validation) {
              if (validation.type) {
                type = validation.type;
              }
              isRequired = !!validation.required;
            }
          }

          return (
            <TextField
              type={type}
              error={isRequired && !props.value}
              helperText={isRequired && !props.value && 'Required'}
              style={{
                width: '20vw',
                margin: 10,
                fontSize: 12,
              }}
              fullWidth
              value={props.value}
              onChange={(event) => {
                props.onChange(event.target.value);
              }}
            />
          );
        },
      };
    });

    setColumns(tmpColumns);
  };

  // Did Mount
  useEffect(() => {
    if (id) {
      const select = BASEPACKAGES_LISTS.find((list) => list.id === id);
      setSelected(select);
    }
  }, [id]);

  useEffect(() => {
    if (selected) {
      getData().then(() => mapColumns());
    }
  }, [selected]);

  const derivedAction = () => {
    if (selected && selected.name !== 'Line Commission') {
      return {
        tooltip: 'Show Derived Data',
        icon: CheckBoxIcon,
        onClick: (evt, data) => {
          setModalOpen(true);
        },
      };
    }
  };

  // Render
  return (
    <ThemeProvider theme={theme}>
      <Modal
        show={modalOpen}
        modalClosed={() => {
          setModalOpen(false);
        }}
        title={'Derived Data'}
      >
        <DerivedData
          selected={selected}
          columns={columns}
          schema={schema}
          selection={selection}
          identifierPayload={selected && selected.identifierPayload}
        />
      </Modal>
      <MaterialTable
        tableRef={selectTable}
        isLoading={loadingTable}
        icons={TABLE_ICONS}
        title={`${selected && selected.name}`}
        columns={columns.filter(
          (row) =>
            selected.name === 'Line Commission' || row.groupName === 'UI Input'
        )}
        data={data}
        options={TABLE_CONFIG}
        actions={[
          // {
          //   icon: () => deriveButton(),
          //   isFreeAction: true,
          // },
          derivedAction,
          {
            icon: () => (
              <UploadButton
                uploadUrl={selected && selected.UPLOAD_URL}
                excelTabName={selected && selected.excelTabName}
                schema={schema.filter(
                  (row) =>
                    (selected && selected.name === 'Line Commission') ||
                    row.groupName === 'UI Input'
                )}
                uploadName={`${selected && selected.name}`} //"Base Packages"//need to change
                title='Base Packages'
                onSuccess={() => getData()}
              />
            ),
            isFreeAction: true,
          },
          {
            icon: () => (
              <ExportButton
                schema={schema.filter(
                  (row) =>
                    (selected && selected.name === 'Line Commission') ||
                    row.groupName === 'UI Input'
                )}
                name={selected && selected.name}
                data={selectTable.current && selectTable.current.state.data}
              />
            ),
            isFreeAction: true,
          },
        ]}
        onSelectionChange={(rowSelection) => {
          const { identifier } = selected;
          setSelection(rowSelection.map((r) => r[identifier]));
        }}
        editable={{
          onBulkUpdate: (changes) =>
            new Promise((resolve, reject) => {
              setTimeout(() => {
                console.log(changes);
                if (Object.keys(changes).length > 0) {
                  let payload = [];
                  setLoadingTable(true);
                  Object.keys(changes).map((row) => {
                    let payloadData = { ...changes[row].newData };
                    payloadData.createdBy = userInfo.id;
                    payloadData.createdDate = moment().format('DD-MM-YYYY');
                    payload.push(payloadData);
                  });
                  axios
                    .post(selected.POST, payload)
                    .then((response) => {
                      getData().then(() => {
                        setLoadingTable(false);
                        resolve();
                      });
                    })
                    .catch((error) => {
                      setLoadingTable(false);
                      resolve();
                    });
                } else resolve();
              }, 1000);
            }),
          onRowAdd: (newData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              payload.createdBy = userInfo.id;
              payload.createdDate = moment().format('DD-MM-YYYY');
              setLoadingTable(true);
              axios
                .post(selected.POST, [payload])
                .then((response) => {
                  if (response) {
                    let pkgData = [...data, newData];
                    setData(pkgData);
                  }
                  setLoadingTable(false);
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
          onRowUpdate: (newData, oldData) =>
            new Promise((resolve, reject) => {
              let payload = { ...newData };
              console.log(newData);
              payload.createdBy = userInfo.id;
              payload.createdDate = moment().format('DD-MM-YYYY');
              setLoadingTable(true);
              axios
                .post(selected.POST, [payload])
                .then((response) => {
                  const dataUpdate = [...data];
                  const index = oldData.tableData.id;
                  dataUpdate[index] = newData;
                  setData(dataUpdate);
                  setLoadingTable(false);
                  resolve();
                })
                .catch((error) => {
                  setLoadingTable(false);
                  resolve();
                });
            }),
        }}
      />
    </ThemeProvider>
  );
};

export default withStyles(useStyles)(BasePackagesTable);
