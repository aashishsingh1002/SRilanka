import React, { useState, useEffect } from 'react';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../../axios-epc';
import Loader from '../../../UI/Loader/Loader';
import { ENTITY_NAME, BASEPACKAGES_LISTS } from './basePackages-constants';
import { useSelector } from 'react-redux';
import BasePackagesTable from './basePackages-table';
// import PkgTable from "./pkg-table";

const BasePackages = () => {
  // selectors
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const openDrawer = useSelector((state) => state.drawerData.open);

  // states
  const [version, setVersion] = useState('');
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState('');
  const [schema, setSchema] = useState([]);

  const getVersions = () => {
    return axios
      .get(`config/version?entityName=${ENTITY_NAME}`, {
        headers: {
          opId: userInfo.opId,
          buId: userInfo.buId,
        },
      })
      .then((res) => {
        setVersion(res.data.data.version);
      })
      .catch((error) => setLoading(false));
  };

  const uiFields = (id) => {
    const { entity } = BASEPACKAGES_LISTS.find((list) => list.id === id);

    if (
      localStorage.getItem(entity) &&
      localStorage[`${entity}_version`] &&
      localStorage[`${entity}_version`] == version
    ) {
      console.log('fetching from local storage');
      try {
        setSchema(JSON.parse(localStorage.getItem(entity)));
      } catch (e) {
        localStorage.removeItem(entity);
      }
      return Promise.resolve();
    } else {
      console.log('fetching from api');
      return axios
        .get(`config?entityName=${entity}`, {
          headers: {
            opId: userInfo.opId,
            buId: userInfo.buId,
          },
        })
        .then((res) => {
          let tmpSchema = [];
          tmpSchema = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });

          setSchema(tmpSchema);
          localStorage.setItem(entity, JSON.stringify(tmpSchema));
          localStorage[`${entity}_version`] = version;
          setLoading(false);
        })
        .catch((error) => {
          console.log(error);
          setLoading(false);
        });
    }
  };

  const onSelect = (e) => {
    const { value } = e.target;
    setSchema([]);
    setSelected(value);
    setLoading(true);
    uiFields(value);
  };

  // componentDidMount
  useEffect(() => {
    getVersions();
  }, []);

  return (
    <div
      style={{
        margin: '0 auto',
        width: openDrawer ? `calc(100vw - 343px)` : 'calc(100vw - 141px)',
      }}
    >
      <div style={{ padding: '20px 0', fontSize: '24px', fontWeight: '600' }}>
        <Select displayEmpty value={selected} onChange={onSelect}>
          <MenuItem value='' disabled>
            Select Base Package
          </MenuItem>
          {BASEPACKAGES_LISTS.map((list) => (
            <MenuItem key={list.id} value={list.id}>
              {list.name}
            </MenuItem>
          ))}
        </Select>
      </div>
      {loading && <Loader />}
      {!loading && selected && schema.length > 0 && (
        <BasePackagesTable
          setLoading={setLoading}
          schema={schema}
          id={selected}
        />
      )}
    </div>
  );
};

export default BasePackages;
