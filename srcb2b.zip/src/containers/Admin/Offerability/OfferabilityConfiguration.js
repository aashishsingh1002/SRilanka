import React, { Component } from 'react';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../../axios-epc';
import { connect } from 'react-redux';
import TextField from '@material-ui/core/TextField';
import CustomTable from '../../../UI/Table/Table';
import Loader from '../../../UI/Loader/Loader';
import Select from 'react-select';
import { withStyles } from '@material-ui/core/styles';
import SaveIcon from '@material-ui/icons/Save';
import Tooltip from '@material-ui/core/Tooltip';
const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4vh',
  },
  subheader: {
    color: 'white',
  },
  heading: {
    flexBasis: '80%',
    flexShrink: 0,
  },
  selectMenuOuter: { top: 'auto', bottom: '100%' },
});
const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

class OfferabilityConfiguration extends Component {
  _isMounted = false;

  state = {
    resLovs: [],
    lobReq: {},
    loading: true,
    columns: [
      {
        title: '',
        field: '',
        filtering: false,
        search: false,
        render: (rowData) => (
          <LightTooltip title='Save'>
            <SaveIcon
              style={{ color: 'green', cursor: 'pointer' }}
              onClick={() => {
                let payload = { ...rowData };
                payload.contextCd = 'pc.pkg.defn';
                payload.opId = this.props.userInfo.opId;
                this.setState({ loading: true });
                axios
                  .post('mtn/ppms/offer/data', payload)
                  .then((response) => {
                    console.log(response);
                    let req = this.state.resLovs;

                    axios
                      .post('mtn/ppms/lob', req)
                      .then((response) => {
                        console.log(response);

                        let modifiedPkgflagLovs = this.state.flagLovs;
                        axios
                          .post('mtn/ppms/pkgFlag', modifiedPkgflagLovs)
                          .then((response) => {
                            console.log(response);
                            this.setState({ loading: false, flagLovs: {} });
                            this.getLovs().then(() => {
                              this.uiFields().then(() => {
                                this.setState({ loading: false });
                              });
                            });
                          })
                          .catch((error) => {
                            console.log(error);
                            if (this._isMounted)
                              this.setState({ loading: false });
                          });
                      })
                      .catch((error) => {
                        console.log(error);
                        if (this._isMounted) this.setState({ loading: false });
                      });
                  })
                  .catch((error) => {
                    console.log(error);
                    if (this._isMounted) this.setState({ loading: false });
                  });
              }}
            ></SaveIcon>
          </LightTooltip>
        ),
        sorting: false,
        cellStyle: { width: '5%' },
      },
      {
        title: 'DisplayMessageCode',
        field: 'dispMsgCode',
        sorting: false,
        editable: 'never',
        render: (rowData) => (
          <div style={{ fontSize: '14px', color: 'gray' }}>
            {rowData.dispMsgCode}
         
          </div>
        ),

        cellStyle: { width: '20%' },
      },
      {
        title: 'Display Text',
        field: 'displayText',
        sorting: false,
        render: (rowData, req) => {
          return (
            <TextField
              style={{
                width: '8vw',
                fontSize: 14,
              }}
              value={rowData.displayText}
              onChange={(event) => {
                this.setState({
                  schema: this.state.schema.map((el) =>
                    el.displayText === rowData.displayText
                      ? {
                          ...el,
                          displayText: event.target.value,
                        }
                      : el
                  ),
                });
              }}
            />
          );
        },
        cellStyle: { width: '5%' },
      },
      {
        title: 'Language',
        field: 'language',
        sorting: false,
        render: (rowData) => (
          <TextField
            style={{
              width: '8vw',
              fontSize: 14,
            }}
            value={rowData.language}
            onChange={(event) => {
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.dispMsgCode === rowData.dispMsgCode
                    ? {
                        ...el,
                        language: event.target.value,
                      }
                    : el
                ),
              });
            }}
          />
        ),
        cellStyle: { width: '5%' },
      },
      {
        title: 'Tool Tip',
        field: 'toolTip',
        sorting: false,
        render: (rowData) => (
          <TextField
            style={{
              width: '8vw',

              fontSize: 14,
            }}
            value={rowData.toolTip}
            onChange={(event) => {
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.dispMsgCode === rowData.dispMsgCode
                    ? {
                        ...el,
                        toolTip: event.target.value,
                      }
                    : el
                ),
              });
            }}
          />
        ),
        cellStyle: { width: '5%' },
      },
      {
        title: 'Display Flag',
        field: 'displayFlagYn',
        sorting: false,
        render: (rowData) => (
          <div style={{ width: '5vw' }}>
            <Select
              menuPortalTarget={document.body}
              styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
              onChange={(selectedOption) => {
                console.log(selectedOption);
                this.setState({
                  schema: this.state.schema.map((el) =>
                    el.dispMsgCode === rowData.dispMsgCode
                      ? {
                          ...el,
                          displayFlagYn: selectedOption.value,
                        }
                      : el
                  ),
                });
              }}
              options={[
                {
                  value: 'Y',
                  label: 'Y',
                },
                {
                  value: 'N',
                  label: 'N',
                },
              ]}
              value={{
                value: rowData.displayFlagYn,
                label: rowData.displayFlagYn,
              }}
            />
          </div>
        ),
        cellStyle: { width: '5%' },
      },
      {
        title: 'Mandatory',
        field: 'mandatory',
        sorting: false,
        render: (rowData) => (
          <div style={{ width: '5vw' }}>
            <Select
              menuPortalTarget={document.body}
              styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
              onChange={(selectedOption) => {
                console.log(selectedOption);
                this.setState({
                  schema: this.state.schema.map((el) =>
                    el.dispMsgCode === rowData.dispMsgCode
                      ? {
                          ...el,
                          mandatory: selectedOption.value,
                        }
                      : el
                  ),
                });
              }}
              options={[
                {
                  value: 'Y',
                  label: 'Y',
                },
                {
                  value: 'N',
                  label: 'N',
                },
              ]}
              value={{
                value: rowData.mandatory,
                label: rowData.mandatory,
              }}
            />
          </div>
        ),
        cellStyle: { width: '5%' },
      },

      {
        title: 'Editable',
        field: 'editable',
        sorting: false,
        render: (rowData) => (
          <div style={{ width: '5vw' }}>
            <Select
              menuPortalTarget={document.body}
              styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
              onChange={(selectedOption) => {
                console.log(selectedOption);
                this.setState({
                  schema: this.state.schema.map((el) =>
                    el.dispMsgCode === rowData.dispMsgCode
                      ? {
                          ...el,
                          editable: selectedOption.value,
                        }
                      : el
                  ),
                });
              }}
              options={[
                {
                  value: 'Y',
                  label: 'Y',
                },
                {
                  value: 'N',
                  label: 'N',
                },
              ]}
              value={{
                value: rowData.editable,
                label: rowData.editable,
              }}
            />
          </div>
        ),
        cellStyle: { width: '5%' },
      },

      {
        title: 'Validation Type',
        field: 'validationType',
        render: (rowData) => (
          <div style={{ width: '160px' }}>
            <Select
              isClearable={rowData.validationType ? true : false}
              menuPortalTarget={document.body}
              styles={{
                menuPortal: (base) => ({
                  ...base,
                  zIndex: 9999,
                }),
              }}
              onChange={(selectedOption) => {
                console.log(selectedOption);
                this.setState({
                  schema: this.state.schema.map((el) =>
                    el.dispMsgCode === rowData.dispMsgCode
                      ? {
                          ...el,
                          validationType:
                            selectedOption === null
                              ? null
                              : selectedOption.value,
                        }
                      : el
                  ),
                });
              }}
              options={[
                {
                  value: 'regexValidator',
                  label: 'regexValidator',
                },
              ]}
              value={{
                value: rowData.validationType,
                label: rowData.validationType,
              }}
            />
          </div>
        ),
        sorting: false,
        cellStyle: { width: '30%' },
      },

      {
        title: 'Validation Text',
        field: 'validationText',
        render: (rowData) => (
          <TextField
            style={{
              width: '8vw',
              fontSize: 14,
            }}
            value={rowData.validationText}
            onChange={(event) => {
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.dispMsgCode === rowData.dispMsgCode
                    ? {
                        ...el,
                        validationText: event.target.value,
                      }
                    : el
                ),
              });
            }}
          />
        ),
        sorting: false,
        cellStyle: { width: '5%' },
      },
      {
        title: 'Validation Command',
        field: 'validationCommand',
        render: (rowData) => (
          <TextField
            style={{
              width: '8vw',
              fontSize: 14,
            }}
            value={rowData.validationCommand}
            onChange={(event) => {
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.dispMsgCode === rowData.dispMsgCode
                    ? {
                        ...el,
                        validationCommand: event.target.value,
                      }
                    : el
                ),
              });
            }}
          />
        ),
        sorting: false,
        cellStyle: { width: '5%' },
      },
    ],
    schema: [],
  };
  removeValue(rowData) {
    console.log(rowData);
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    console.log('mounted');
    console.log(this.state.schema);
    this.getLovs().then(() => {
      this.uiFields().then(() => {
        this.setState({ loading: false });
      });
    });
  }
  getLovs() {
    return axios
      .get('mtn/ppms/lob', {
        headers: {
          opId: this.props.userInfo.opId,
        },
      })
      .then((res) => {
        console.log(res.data.data);
        if (this._isMounted) this.setState({ schemaLovs: res.data.data });

        axios
          .get('mtn/ppms/pkgFlag')
          .then((res) => {
            console.log(res.data.data);
            if (this._isMounted) this.setState({ flagLovs: res.data.data });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  uiFields() {
    return axios
      .get('mtn/ppms/offer/data', {
        headers: {
          opId: this.props.userInfo.opId,
          contextCd: 'pc.pkg.offers',
        },
      })
      .then((res) => {
        console.log(res.data.data);
        if (this._isMounted) this.setState({ schema: res.data.data });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  render() {
    const { classes } = this.props;

    let OfferabilityConfiguration = (
      <div style={{ padding: '0' }}>
        <div
          style={
            this.state.loading ? { display: 'none' } : { display: 'block' }
          }
        >
          <div
            style={{
              margin: '10px auto',
              width: `calc(100vw - 343px)`,
            }}
          >
            <CustomTable
              pageSize={8}
              title='Offerability Configuration'
              data={this.state.schema}
              columns={this.state.columns}
            />
          </div>
        </div>
        {this.state.loading && <Loader />}
      </div>
    );
    return OfferabilityConfiguration;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
  };
};

export default connect(mapStateToProps)(
  withStyles(useStyles)(WithErrorHandler(OfferabilityConfiguration, axios))
);
