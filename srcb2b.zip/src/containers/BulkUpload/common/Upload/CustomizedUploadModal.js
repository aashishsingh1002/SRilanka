import React, { Component } from 'react';
import Modal from '../../../../UI/Modal/Modal';
import Loader from '../../../../UI/Loader/Loader';
import axios from '../../../../axios-epc';
import WithErrorHandler from '../../../../HOC/WithErrorHandler/WithErrorHandler';
import { DropzoneArea } from 'material-ui-dropzone';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import DeleteIcon from '@material-ui/icons/Delete';
import GetAppIcon from '@material-ui/icons/GetApp';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import Snackbar from '@material-ui/core/Snackbar';
import Grid from '@material-ui/core/Grid';
import MuiAlert from '@material-ui/lab/Alert';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import Box from '@material-ui/core/Box';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import AppsIcon from '@material-ui/icons/Apps';
import Divider from '@material-ui/core/Divider';
import ListItemText from '@material-ui/core/ListItemText';

function Alert(props) {
  return <MuiAlert elevation={6} variant='filled' {...props} />;
}

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

// const theme = createMuiTheme({
//   overrides: {
//     MuiDropzoneArea: {
//       root: {
//         minHeight: '20px',
//       },
//       text: {
//         display: 'none',
//       },
//     },
//   },
// });

const theme = createMuiTheme({
  overrides: {
    MuiDropzoneArea: {
      root: {
        height: '100%',
      },
    },
  },
});

class DeviceUpload extends Component {
  _isMounted = false;

  state = {
    show: true,
    loading: false,
    activeTab: 0,
    files: [],
    deviceUpload: {},
    key: 'app',
    openSnack: false,
    selValidationLog: null,
    dataUpload: {},
    openSnackSuccess: false,
    hasUpload: false,
  };

  constructor(props) {
    super(props);
    this.dropzoneRef = React.createRef();
  }

  modalCloseHandler = () => {
    const { onClose = () => null } = this.props;
    this.state.hasUpload && onClose();
    this.setState({ show: false });
    this.props.setIsOpen(false);
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount() {
    this._isMounted = true;
  }
  handleChange(file) {
    let dataUpload = {};
    dataUpload[file.name] = false;
    this.setState({
      files: file,
      dataUpload: dataUpload,
    });
  }
  handleChangeTab = (event, newValue) => {
    console.log(newValue);
    this.setState({ activeTab: newValue ? newValue : 0 });
  };

  handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    this.setState({ openSnack: false });
  };

  handleCloseSnackSuccess = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    this.setState({ openSnackSuccess: false });
  };

  saveDeviceHandler = () => {
    if (
      this.state.files.length > 0 &&
      !this.state.deviceUpload[this.state.files[0].name]
    ) {
      this.setState({
        loading: true,
      });
      let formData = new FormData();
      this.state.files.map((file) => {
        formData.append('file', file);
      });
      for (var pair of formData.entries()) {
        console.log(pair[0]);
        console.log(pair[1]);
      }

      axios
        .post(this.props.uploadUrl, formData)
        .then((res) => {
          if (res) {
            let deviceUpload = {};
            deviceUpload[this.state.files[0].name] = true;
            this.setState({
              deviceUpload: deviceUpload,
            });
            this.props.onSuccess();
          }

          this.setState({
            openSnackSuccess: true,
            hasUpload: true,
            loading: false,
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  };
  numberToLetters(num) {
    let letters = '';
    while (num >= 0) {
      letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[num % 26] + letters;
      num = Math.floor(num / 26) - 1;
    }
    return letters;
  }

  downloadValidationLogs = (event, index) => {
    this.setState({
      loading: true,
      selValidationLog: index,
    });
    this.callValidationLog();
  };

  async callValidationLog() {
    await axios
      .get(this.props.valiationUrl)
      .then((response) => {
        console.log(response);

        if (response) this.saveAsValidationLogExcel(response);
        else this.setState({ loading: false });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  async saveAsValidationLogExcel(response) {
    //const { worksheetName = '', fileName = '' } = this.props;
    const tabName = this.props.excelTabName || 'XMtnTab';
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(tabName);
    let sheetColumns = [];
    if (this.props.excelTabName === 'XMtnDevicesUiTab') {
      this.props.schema
        .filter((x) => x.refName != 'uniqueNumber')
        .forEach((row) => {
          sheetColumns.push({
            header: row.uiName,
            key: row.refName,
            width: 25,
          });
        });
    } else {
      this.props.schema.forEach((row) => {
        sheetColumns.push({
          header: row.uiName,
          key: row.refName,
          width: 25,
        });
      });
    }
    sheetColumns.push({
      header: 'Has Error',
      key: 'isError',
      width: 25,
    });
    sheetColumns.push({
      header: 'Change',
      key: 'change',
      width: 25,
    });

    sheetColumns.push({
      header: 'Validation Complete',
      key: 'valComplete',
      width: 25,
    });
    sheetColumns.push({
      header: 'Created By',
      key: 'createdBy',
      width: 25,
    });
    worksheet.columns = sheetColumns;

    worksheet.getRow(1).font = {
      bold: true,
    };
    response.data.data.map((row) => {
      worksheet.addRow(row);
    });

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), `${this.props.uploadName}_ValidationLog.xlsx`);
  }

  async saveAsExcelDevice() {
    const tabName = this.props.excelTabName || 'XMtnTab';
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(tabName);
    let sheetColumns = [];
    console.log(this.props.excelTabName);
    console.log(this.props.schema);
    if (this.props.excelTabName === 'XMtnDevicesUiTab') {
      this.props.schema
        .filter((x) => x.refName != 'uniqueNumber')
        .forEach((row) => {
          sheetColumns.push({
            header: row.uiName,
            key: row.refName,
            width: 25,
          });
        });
    } else {
      this.props.schema.forEach((row) => {
        sheetColumns.push({
          header: row.uiName,
          key: row.refName,
          width: 25,
        });
      });
    }

    worksheet.columns = sheetColumns;
    worksheet.getRow(1).font = {
      bold: true,
    };

    this.props.schema
      .filter(
        (x) =>
          !(
            this.props.excelTabName === 'XMtnDevicesUiTab' &&
            x.refName === 'uniqueNumber'
          )
      )
      .forEach((row, i) => {
        const letter = this.numberToLetters(i);
        const pos = `${letter}2:${letter}9999`;
        if (row.refLovs) {
          const refLovs = `"${row.refLovs.toString()}"`;
          worksheet.dataValidations.add(pos, {
            type: 'list',
            allowBlank: !!(row.isMandatory === 'Y'),
            formulae: [`${refLovs}`],
          });
        } else {
          worksheet.dataValidations.add(pos, {
            type: 'textLength',
            operator: 'greaterThan',
            showErrorMessage: true,
            allowBlank: !!(row.isMandatory === 'Y'),
            formulae: [0],
          });
        }
      });

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), `${this.props.uploadName}_Template.xlsx`);
  }
  render() {
    const vertical = 'top';
    const horizontal = 'center';
    const titleUpperCase = this.props.title;
    let dealData = (
      <Modal
        show={this.state.show}
        modalClosed={this.modalCloseHandler}
        title={this.props.title}
      >
        <Snackbar
          anchorOrigin={{ vertical, horizontal }}
          open={this.state.openSnack}
          autoHideDuration={4000}
          onClose={this.handleClose}
        >
          <Alert onClose={this.handleClose} severity='success'>
            Files Uploaded Successfully
          </Alert>
        </Snackbar>
        {this.props.snackMessageOnSuccess && (
          <Snackbar
            anchorOrigin={{ vertical, horizontal }}
            open={this.state.openSnackSuccess}
            autoHideDuration={4000}
            onClose={this.handleCloseSnackSuccess}
          >
            <Alert onClose={this.handleCloseSnackSuccess} severity='success'>
              {this.props.snackMessageOnSuccess}
            </Alert>
          </Snackbar>
        )}
        {this.state.loading ? (
          <div style={{ minHeight: '35vh' }}>
            <Loader />{' '}
          </div>
        ) : (
          <div style={{ minHeight: '35vh' }}>
            <AppBar position='static'>
              <Tabs
                value={this.state.activeTab}
                indicatorColor='white'
                variant='fullWidth'
                onChange={this.handleChangeTab}
              >
                <Tab
                  label={`${titleUpperCase.toUpperCase()} SHEET`}
                  style={{
                    background: '#ffc800',
                    color: '#10628F',
                    fontWeight: 'bold',
                  }}
                />
                <Tab
                  label='Validation Logs'
                  style={{
                    background: '#ffc800',
                    color: '#10628F',
                    fontWeight: 'bold',
                  }}
                />
              </Tabs>
            </AppBar>
            <TabPanel value={this.state.activeTab} index={0}>
              <div style={{ minHeight: '35vh' }}>
                <div
                  style={
                    this.state.loading
                      ? { display: 'none' }
                      : { display: 'block' }
                  }
                >
                  <Grid container spacing={2}>
                    <Grid item xs={3}>
                      <ThemeProvider theme={theme}>
                        <DropzoneArea
                          ref={this.dropzoneRef}
                          key={this.state.key}
                          onChange={this.handleChange.bind(this)}
                          maxFileSize={52428800}
                          dropzoneText='Upload Files'
                          showPreviewsInDropzone={false}
                          filesLimit={20}
                          style={{ minHeight: '150px' }}
                          acceptedFiles={[
                            'file/xls',
                            'file/xlsx',
                            '.xlsx',
                            'application/vnd.ms-excel',
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            'application/msword',
                          ]}
                          // acceptedFiles={['application/vnd.ms-excel'
                          //     , 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',]}
                        />
                      </ThemeProvider>
                    </Grid>

                    <Grid item xs={9}>
                      <TableContainer component={Paper}>
                        <Table size='small'>
                          <TableHead>
                            <TableRow>
                              <TableCell align='left' style={{ width: '90%' }}>
                                File Name
                              </TableCell>
                              <TableCell align='left' style={{ width: '10%' }}>
                                Delete
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {this.state.files.map((file, index) => (
                              <TableRow key={file.name}>
                                <TableCell align='left'> {file.name}</TableCell>

                                <TableCell align='left'>
                                  <DeleteIcon
                                    onClick={(event) => {
                                      this.dropzoneRef.current.deleteFile(
                                        this.state.files[index],
                                        index
                                      );
                                    }}
                                    style={{ color: 'red', cursor: 'pointer' }}
                                  />
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                      {this.state.files.length > 0 && (
                        <div
                          style={{
                            display: 'flex',
                            flex: '1',
                            justifyContent: 'space-around',
                            marginTop: '30px',
                          }}
                        >
                          <Button
                            variant='contained'
                            size='medium'
                            style={{
                              background: 'pink',
                              textTransform: 'none',
                              float: 'right',
                            }}
                            onClick={() => {
                              let key =
                                this.state.key.length > 10
                                  ? 'app'
                                  : this.state.key + '1';
                              this.setState({ key: key });
                            }}
                          >
                            Clear
                          </Button>
                          <Button
                            variant='contained'
                            size='medium'
                            style={{
                              background: '#02bfa0',
                              textTransform: 'none',
                              float: 'right',
                            }}
                            onClick={this.saveDeviceHandler}
                          >
                            Upload
                          </Button>
                        </div>
                      )}
                    </Grid>
                  </Grid>
                  <Grid container spacing={2}>
                    <Grid item xs={3}>
                      <Button
                        variant='contained'
                        style={{
                          textTransform: 'capitalize',
                          background: '#ffcc00',
                          letterSpacing: '-1px',
                          fontWeight: '600',
                          color: '#000',
                          fontSize: '16px',
                          borderRadius: '50px',
                          padding: '6px 32px',
                          '&:hover': {
                            opacity: 0.8,
                            background: '#ffcc00',
                          },
                        }}
                        onClick={(event) => {
                          this.saveAsExcelDevice();
                        }}
                      >
                        <GetAppIcon style={{ cursor: 'pointer' }} />
                        Template
                      </Button>
                    </Grid>
                  </Grid>
                  <p
                    style={{
                      fontSize: '16px',
                      marginTop: '0px',
                      marginBottom: '0px',
                      marginLeft: '5px',
                      marginRight: '5px',
                      color: '#FF0000',
                    }}
                  >
                    *Maximum Upload File Size: 50MB
                  </p>
                  <p
                    style={{
                      fontSize: '16px',
                      marginTop: '0px',
                      marginBottom: '0px',
                      marginLeft: '5px',
                      marginRight: '5px',
                      color: '#FF0000',
                    }}
                  >
                    *File Format Allowed: xlsx
                  </p>
                </div>
              </div>
            </TabPanel>
            <TabPanel value={this.state.activeTab} index={1}>
              <List component='nav'>
                <ListItem
                  style={{ cursor: 'pointer' }}
                  selected={this.state.selValidationLog === 0}
                  onClick={(event) => this.downloadValidationLogs(event, 0)}
                >
                  <ListItemIcon>
                    <AppsIcon />
                  </ListItemIcon>
                  <ListItemText primary={'Validation Logs'} />
                </ListItem>

                <Divider />
              </List>
            </TabPanel>
          </div>
        )}
      </Modal>
    );

    return dealData;
  }
  // render() {
  //   let deviceUpload = (
  //     <Modal
  //       show={this.state.show}
  //       modalClosed={this.modalCloseHandler}
  //       size='md'
  //       title={this.props.title}
  //     >
  //       <div style={{ minHeight: '25vh' }}>
  //         <div
  //           style={
  //             this.state.loading ? { display: 'none' } : { display: 'block' }
  //           }
  //         >
  //           <TableContainer component={Paper} style={{ marginTop: '2vh' }}>
  //             <Table size='small'>
  //               <TableHead>
  //                 <TableRow>
  //                   <TableCell align='center' style={{ width: '10%' }}>
  //                     Template
  //                   </TableCell>
  //                   <TableCell align='left' style={{ width: '15%' }}>
  //                     Select File{' '}
  //                   </TableCell>
  //                   <TableCell align='left' style={{ width: '35%' }}>
  //                     File Name
  //                   </TableCell>
  //                   <TableCell align='left' style={{ width: '20%' }}>
  //                     Status
  //                   </TableCell>
  //                   <TableCell align='left' style={{ width: '10%' }}>
  //                     Delete
  //                   </TableCell>
  //                   <TableCell align='left' style={{ width: '10%' }}>
  //                     Upload
  //                   </TableCell>
  //                 </TableRow>
  //               </TableHead>
  //               <TableBody>
  //                 <TableRow>
  //                   <TableCell align='center'>
  //                     {' '}
  //                     <GetAppIcon
  //                       onClick={(event) => {
  //                         this.saveAsExcelDevice();
  //                       }}
  //                       style={{ cursor: 'pointer' }}
  //                     />{' '}
  //                   </TableCell>
  //                   <TableCell align='left'>
  //                     <ThemeProvider theme={theme}>
  //                       <DropzoneArea
  //                         ref={this.dropzoneRef}
  //                         onChange={this.handleChange.bind(this)}
  //                         maxFileSize={10000000}
  //                         dropzoneText=''
  //                         showPreviewsInDropzone={false}
  //                         filesLimit={1}
  //                         acceptedFiles={[
  //                           'application/vnd.ms-excel',
  //                           'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  //                         ]}
  //                       />
  //                     </ThemeProvider>
  //                   </TableCell>

  //                   {this.state.files.length > 0 && (
  //                     <React.Fragment>
  //                       <TableCell align='left'>
  //                         {' '}
  //                         {this.state.files[0].name}
  //                       </TableCell>
  //                       <TableCell align='left'>
  //                         {!this.state.deviceUpload[this.state.files[0].name]
  //                           ? 'Not Uploaded'
  //                           : 'Uploaded'}
  //                       </TableCell>
  //                       <TableCell align='left'>
  //                         {!this.state.deviceUpload[
  //                           this.state.files[0].name
  //                         ] ? (
  //                           <DeleteIcon
  //                             onClick={(event) => {
  //                               this.dropzoneRef.current.deleteFile(
  //                                 this.state.files[0],
  //                                 0
  //                               );
  //                             }}
  //                             style={{ color: 'red', cursor: 'pointer' }}
  //                           />
  //                         ) : null}
  //                       </TableCell>
  //                       <TableCell align='left' style={{ width: '15%' }}>
  //                         {!this.state.deviceUpload[
  //                           this.state.files[0].name
  //                         ] ? (
  //                           <Button
  //                             variant='contained'
  //                             size='medium'
  //                             style={{
  //                               background: '#02bfa0',
  //                               textTransform: 'none',
  //                               float: 'right',
  //                             }}
  //                             onClick={this.saveDeviceHandler}
  //                           >
  //                             Upload
  //                           </Button>
  //                         ) : null}
  //                       </TableCell>
  //                     </React.Fragment>
  //                   )}
  //                 </TableRow>
  //               </TableBody>
  //             </Table>
  //           </TableContainer>
  //         </div>
  //       </div>
  //       {this.state.loading && <Loader />}
  //     </Modal>
  //   );

  //   return deviceUpload;
  // }
}

export default WithErrorHandler(DeviceUpload, axios);
