import React from "react";
import { useState } from "react";
import Modal from "../../../../UI/Modal/BulkEditModal";
import { useSelector } from "react-redux";
import { Checkbox } from "@material-ui/core";
import FormControlLabel from "@mui/material/FormControlLabel";

const Index = ({ show, modalClosed }) => {
  const searchItems = useSelector((state) => state.searchData.searchItems);
  const [bulkEdit, setBulkEdit] = useState(false);
  const setBulkValue = (e) => {
    setBulkEdit(e);
  };
  return (
    <div>
      {console.log(searchItems)}
      <Modal
        show={show}
        title={"Bulk Edit"}
        modalClosed={modalClosed}
        bulkEdit={(e) => setBulkValue(e)}
      >
        {bulkEdit
          ? searchItems.map((x, key) => (
              <FormControlLabel label={x} control={<Checkbox />} />
            ))
          : "Do you want to do bulk edit ?"}
      </Modal>
    </div>
  );
};

export default Index;
