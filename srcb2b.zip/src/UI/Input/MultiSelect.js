import React from 'react';
import { Picky } from 'react-picky';
import 'react-picky/dist/picky.css';
import Checkbox from '@material-ui/core/Checkbox';
import Switch from '@material-ui/core/Switch';

const MultiSelect = (props) => {
  return (
    <Picky
      clearFilterOnClose={true}
      placeholder={props.placeholder}
      options={props.refLovs}
      multiple={true}
      includeFilter
      includeSelectAll
      value={props.value}
      onChange={props.changed}
      style={{
        fontFamily: 'BrighterSans',
      }}
      renderSelectAll={({
        style,
        filtered,
        tabIndex,
        allSelected,
        toggleSelectAll,
        multiple,
      }) => {
        if (multiple && !filtered) {
          return (
            <div
              tabIndex={tabIndex}
              role='option'
              className={allSelected ? 'option selected' : 'option'}
              onClick={toggleSelectAll}
              onKeyPress={toggleSelectAll}
            >
              <span>
                <Switch
                  color='primary'
                  checked={allSelected == 'all' ? true : false}
                />
                Select All
              </span>
            </div>
          );
        }
      }}
      render={({ style, isSelected, item, selectValue, multiple }) => {
        return (
          <li
            style={style}
            className={isSelected ? 'selected' : ''}
            key={item}
            onClick={() => selectValue(item)}
          >
            <Checkbox
              checked={isSelected}
              style={{ color: '#ff1921', padding: 0, marginRight: '10px' }}
            />
            <span>{item}</span>
          </li>
        );
      }}
    />
  );
};

export default MultiSelect;
