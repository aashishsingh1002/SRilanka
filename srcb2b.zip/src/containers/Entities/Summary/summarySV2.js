// import React, { Component } from 'react';
// import { withRouter } from 'react-router-dom';
// import axios from '../../../axios-epc';
// // import Button from "@material-ui/core/Button";
// import Loader from '../../../UI/Loader/Loader';
// import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
// import TextField from '@material-ui/core/TextField';
// import { withStyles } from '@material-ui/core/styles';
// import moment from 'moment';
// import MaterialTable from '@material-table/core';
// import { TABLE_ICONS } from '../../BulkUpload/common/table-config';
// import { connect } from 'react-redux';
// import CustomInput from '../../../UI/Input/Input';
// import Grid from '@material-ui/core/Grid';
// import Card from '@material-ui/core/Card';
// import CardHeader from '@material-ui/core/CardHeader';
// import CardContent from '@material-ui/core/CardContent';
// import Button from '../../../UI/Button/Button';

// const ITEM_HEIGHT = 48;
// const ITEM_PADDING_TOP = 8;
// const MenuProps = {
//   PaperProps: {
//     style: {
//       maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
//       width: 250,
//     },
//   },
// };
// const useStyles = (theme) => ({
//   cardContent: {
//     // height: "70vh",
//   },
//   cardHeader: {
//     // background: "#546D7A",
//     // height: "4.5vh",
//   },
//   subheader: {
//     color: 'rgba(0, 0, 0, 0.87)',
//     fontSize: '18px',
//     fontWeight: '600',

//     // color: "white",
//     // fontWeight: 'bold'
//   },
//   heading: {
//     fontSize: theme.typography.pxToRem(15),
//     flexBasis: '96%',
//     flexShrink: 0,
//   },
//   btn: {
//     textTransform: 'unset !important',
//   },
// });

// const typeCheck = (refName) => {
//   if (refName === 'purchaseCost') {
//     return 'number';
//   }

//   if (refName === 'daId') {
//     return 'number';
//   }
//   if (refName === 'serviceOptionId') {
//     return 'number';
//   }
//   if (refName === 'adhocDaId') {
//     return 'number';
//   }
//   if (refName === 'dataShareDaId') {
//     return 'number';
//   }
//   return 'text';
// };

// class DAConfiguration extends Component {
//   constructor(props) {
//     super(props);
//     this.selectTable = React.createRef();
//   }

//   _isMounted = false;

//   state = {
//     attrGrps: {},
//     loading: true,
//     selAttrGrp: null,
//     selAttrGrps: {},
//     errors: [],
//     show: false,
//     modalContent: null,
//     openSnack: false,
//     messageSnack: '',
//     showTable: false,
//     columns: [],
//     configFields: {},
//     configFieldsLoading: true,
//     configUI: [],
//     data: [
//       {
//         localId: 0,
//       },
//     ],
//     // dataUpdate: [
//     //   {
//     //     localId: 0,
//     //   },
//     // ],
//     // serviceOptionId: null,
//   };

//   componentWillUnmount() {
//     this._isMounted = false;
//   }
//   componentDidMount() {
//     this._isMounted = true;
//     this.getAutoPopulateSVFields();
//     this.getUI();
//     // this.getList();
//   }

//   componentDidUpdate(prevProps, prevState) {
//     if (
//       !this.state.configFieldsLoading &&
//       this.state.configFieldsLoading !== prevState.configFieldsLoading
//     ) {
//       this.getList();
//     }
//   }

//   getList() {
//     if (this.props.releaseData.releaseId) {
//       return axios
//         .get('mtn/DA?releaseId=' + this.props.releaseData.releaseId, {
//           headers: {
//             productId: this.props.id,
//           },
//         })
//         .then((res) => {
//           if (res) {
//             const { data = [] } = res.data;
//             if (data.length) {
//               this.props.setServiceOptionId(data[0].serviceOptionId);
//               this.setState({
//                 data: data.map((item, i) => ({ ...item, localId: i })),
//                 showTable: true,
//                 configFields: {
//                   svProductOffering: data[0].svProductOffering,
//                   referenceCode: data[0].referenceCode,
//                   proRateIn: data[0].proRateIn,
//                   subscriberType: data[0].subscriberType,
//                   svProductDefinition: data[0].svProductDefinition,
//                   svPackageDefinition: data[0].svPackageDefinition,
//                   svProduct: data[0].svProduct,
//                   recurringFlag: data[0].recurringFlag,
//                   invoiceSectionNr: data[0].invoiceSectionNr,
//                   proRateRefund: data[0].proRateRefund,
//                   chargeGlGuidanceId: data[0].chargeGlGuidanceId,
//                   discountGlGuidanceId: data[0].discountGlGuidanceId,
//                 },
//               });
//             }
//           }
//         })
//         .catch(() => {});
//     }
//   }

//   getAutoPopulateSVFields() {
//     this.setState({ configFieldsLoading: true });
//     if (this.props.releaseData.releaseId) {
//       return axios
//         .get('mtn/DA/sv', {
//           headers: {
//             id: this.props.id,
//             identifier:
//               this.props.history.location.pathname === '/productConfiguration'
//                 ? 'AdhocBundles'
//                 : 'PricePlan',
//           },
//         })
//         .then((res) => {
//           // if (res) {
//           const { data = {} } = res.data;
//           this.setState({ configFields: data, configFieldsLoading: false });
//           // }
//         })
//         .catch(() => {});
//     }
//   }
//   getUI() {
//     // if (this.props.releaseData.releaseId) {
//     return axios
//       .get('config/entity?entityName=daConfiguration', {
//         headers: {
//           opId: this.props.userInfo.opId,
//           buId: this.props.userInfo.buId,
//         },
//       })
//       .then((res) => {
//         console.log(res);
//         if (res) {
//           const { data = [] } = res.data;
//           this.setState({
//             loading: false,
//             configUI: [...data]
//               .filter((d) => d.groupName !== 'UI Input')
//               .filter((d) => {
//                 console.log(d);
//                 if (
//                   d.refType === 'SelectInput' ||
//                   d.refType === 'MultiSelect'
//                 ) {
//                   if (d.refLovs != null) d.refLovs = d.refLovs.split(',');
//                   else if (d.refLovs == null) d.refLovs = [];
//                 }
//                 if (
//                   this.props.history.location.pathname ===
//                   '/productConfiguration'
//                 ) {
//                   return d.refName !== 'svPackageDefinition';
//                 } else if (
//                   this.props.history.location.pathname === '/planConfiguration'
//                 ) {
//                   return d.refName !== 'svProductDefinition';
//                 }
//                 return d;
//               }),
//             columns: [
//               ...data
//                 .filter(
//                   (d) =>
//                     d.refName !== 'productId' && d.refName !== 'serviceOptionId'
//                 )
//                 .filter((d) => d.groupName === 'UI Input')
//                 .map((d) => ({
//                   title: d.uiName,
//                   field: d.refName,

//                   render: (rowData) => {
//                     if (d.refName === 'productId') {
//                       return <span>{this.props.id}</span>;
//                     }

//                     // let type = 'text';
//                     // let isRequired = false;
//                     // if (validations) {
//                     //   const validation = validations.find(
//                     //     (t) => t.name === props.columnDef.field
//                     //   );
//                     //   if (validation) {
//                     //     if (validation.type) {
//                     //       type = validation.type;
//                     //     }
//                     //     isRequired = !!validation.required;
//                     //   }
//                     // }
//                     return (
//                       <TextField
//                         type={typeCheck(d.refName)}
//                         onChange={(props) => {
//                           // const tmpData = [...this.state.dataUpdate];
//                           const tmpData = [...this.state.data];
//                           this.setState({
//                             data: tmpData.map((item) => {
//                               if (item.localId === rowData.localId) {
//                                 return {
//                                   ...item,
//                                   [d.refName]: props.target.value,
//                                 };
//                               }
//                               return item;
//                             }),
//                           });
//                         }}
//                       />
//                     );
//                   },
//                 })),
//             ],
//           });
//         }
//       })
//       .catch((e) => {});
//     // } else {
//     //   this.setState({ loading: false });
//     //   return Promise.resolve();
//     // }
//   }

//   addRow() {
//     const rows = this.state.data;
//     const { localId } = rows.length ? rows[rows.length - 1] : { localId: 0 };
//     this.setState({
//       data: [
//         ...this.state.data,
//         {
//           localId: localId + 1,
//         },
//       ],
//       // dataUpdate: [
//       //   ...this.state.dataUpdate,
//       //   {
//       //     localId: localId + 1,
//       //   },
//       // ],
//     });
//   }

//   deleteRow(row) {
//     const updatedData2 = [
//       ...this.state.data.filter((d) => d.localId !== row.localId),
//     ];
//     const updatedData = [
//       ...this.state.data.map((d) => {
//         if (d.localId === row.localId) {
//           return {
//             ...d,
//             endDate: moment().format('DD-MM-YYYY'),
//           };
//         }
//         return d;
//       }),
//     ];
//     this.setState({
//       data: updatedData2,
//       // dataUpdate: updatedData,
//     });

//     this.onSaveHandler(updatedData);
//   }

//   errorConfirmedHandler = () => {
//     this.setState({ show: false });
//   };

//   onSaveHandler = (arr) => {
//     this.setState({ loading: true });
//     // const payload = this.state.dataUpdate
//     console.log('arr', arr);
//     const useData = arr ? arr : this.state.data;
//     console.log(useData);
//     const payload = useData
//       .map(({ localId, tableData, ...rest }) => {
//         if (Object.keys(rest).length !== 0) {
//           return {
//             ...rest,
//             productId: this.props.id,
//             serviceOptionId: this.props.serviceOptionId,
//             opId: this.props.userInfo.opId,
//             buId: this.props.userInfo.buId,
//             createdBy: this.props.userInfo.id,
//             createdDate: moment().format('DD-MM-YYYY'),
//             ...this.state.configFields,
//           };
//         } else {
//           return {
//             productId: this.props.id,
//             serviceOptionId: this.props.serviceOptionId,
//             opId: this.props.userInfo.opId,
//             buId: this.props.userInfo.buId,
//             createdBy: this.props.userInfo.id,
//             createdDate: moment().format('DD-MM-YYYY'),
//             ...this.state.configFields,
//           };
//         }
//       })
//       .filter((item) => !!item);

//     return axios
//       .post('mtn/DA?releaseId=' + this.props.releaseData.releaseId, payload, {})
//       .then((res) => {
//         console.log(res);
//         if (res) {
//           this.setState({
//             loading: false,
//           });
//         }
//       })
//       .catch(() => {
//         this.setState({ loading: false });
//       });
//   };
//   render() {
//     const { classes, access } = this.props;
//     const isDisabled =
//       (access && access === 'R') || !this.props.releaseData.releaseId;

//     let daConfiguration = (
//       <form
//         onSubmit={() => this.onSaveHandler()}
//         // style={{
//         //   margin: "0 auto",
//         //   width: this.props.openDrawer
//         //     ? `calc(100vw - 373px)`
//         //     : "calc(100vw - 161px)",
//         // }}
//       >
//         <Grid item xs={12}>
//           <Card>
//             <CardHeader
//               className={classes.cardHeader}
//               classes={{
//                 subheader: classes.subheader,
//               }}
//               subheader={'Basic Configuration'}
//             />

//             <CardContent className={classes.cardContent}>
//               <Grid container spacing={3}>
//                 {this.state.configUI.map((formElement) => {
//                   let override = {};
//                   return (
//                     <CustomInput
//                       key={formElement.refName}
//                       access={access}
//                       {...formElement}
//                       {...override}
//                       disabled
//                       //   disabled={formElement.isDisabled == "Y" ? true : false}
//                       //   required={formElement.isMandatory == "Y" ? true : false}
//                       value={this.state.configFields[formElement.refName]}
//                       changed={(event) => {
//                         if (!event.target) {
//                           this.setState({
//                             configFields: {
//                               ...this.state.configFields,
//                               [formElement.refName]: event,
//                             },
//                           });
//                         } else {
//                           if (event.target.type !== 'checkbox')
//                             this.setState({
//                               configFields: {
//                                 ...this.state.configFields,
//                                 [formElement.refName]: event.target.value,
//                               },
//                             });
//                           else
//                             this.setState({
//                               configFields: {
//                                 ...this.state.configFields,
//                                 [formElement.refName]: event.target.checked,
//                               },
//                             });
//                         }
//                       }}
//                     />
//                   );
//                 })}
//               </Grid>
//             </CardContent>
//           </Card>
//         </Grid>

//         <Card>
//           <CardHeader
//             className={classes.cardHeader}
//             classes={{
//               subheader: classes.subheader,
//             }}
//             subheader={'DA Configuration'}
//           />

//           <CardContent>
//             <div style={{ marginBottom: '10px', display: 'flex' }}>
//               <div
//                 style={{
//                   marginRight: '8px',
//                   display: 'flex',
//                   alignItems: 'center',
//                 }}
//               >
//                 Service Option Id:
//               </div>

//               <TextField
//                 disabled={isDisabled}
//                 style={{ fontsize: '20px' }}
//                 value={this.props.serviceOptionId}
//                 onChange={(e) => this.props.setServiceOptionId(e.target.value)}
//               />
//             </div>

//             {this.state.showTable && (
//               <>
//                 <MaterialTable
//                   icons={TABLE_ICONS}
//                   columns={this.state.columns}
//                   data={this.state.data}
//                   tableRef={this.selectTable}
//                   options={{
//                     showTitle: false,
//                     search: false,
//                   }}
//                 />
//               </>
//             )}
//           </CardContent>
//         </Card>
//       </form>
//     );

//     if (this.state.loading) {
//       daConfiguration = <Loader />;
//     }

//     return daConfiguration;
//   }
// }

// const mapStateToProps = (state) => {
//   return {
//     openDrawer: state.drawerData.open,
//   };
// };
// export default withRouter(
//   connect(mapStateToProps)(
//     withStyles(useStyles)(WithErrorHandler(DAConfiguration, axios))
//   )
// );
