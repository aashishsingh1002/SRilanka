import React from "react";
import { withStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
const StyledTextField = withStyles({
  root: {
    width: "100%",
    // "& label.Mui-focused": {
    "& .MuiInputLabel-shrink": {
      // color: 'green',
      fontWeight: "600",
      fontSize: "14px",
      transform: "scale(1)",
      color: "rgba(0, 0, 0, 0.87)",
    },
    "& .MuiInput-underline:after": {
      borderBottomColor: "#ff1921",
    },
  },
})(TextField);

const CustomTextField = ({
  label,
  placeholder = "Input text here",
  value,
  onChange = () => {},
  params,
}) => (
  <StyledTextField
    {...params}
    label={label}
    placeholder={placeholder}
    InputLabelProps={{
      shrink: true,
    }}
    // value={value || ""}
    onChange={onChange}
  />
);

export default CustomTextField;
