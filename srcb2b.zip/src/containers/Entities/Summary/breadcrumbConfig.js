export const BC_CONFIG = [
  {
    id: 'Business',
    key: 'B',
    control: [
      {
        key: 'General',
        access: 'RW',
      },
      {
        key: 'Bundle Items',
        access: 'RW',
      },
      {
        key: 'Pricing',
        access: 'RW',
      },
      {
        key: 'Offerability',
        access: 'RW',
      },
      {
        key: 'Product Class Selection',
        access: 'R',
      },
      {
        key: 'Inclusion/Exclusion Rules',
        access: 'R',
      },
      {
        key: 'Siebel Configuration 1/2',
        access: 'R',
      },
      {
        key: 'Siebel Configuration 2/2',
        access: 'R',
      },
      {
        key: 'SV Configuration',
        access: 'R',
      },
    ],
  },
  {
    id: 'Sv',
    key: 'Sv',
    control: [
      {
        key: 'General',
        access: 'R',
      },
      {
        key: 'Bundle Items',
        access: 'R',
      },
      {
        key: 'Pricing',
        access: 'R',
      },
      {
        key: 'Offerability',
        access: 'R',
      },
      {
        key: 'Product Class Selection',
        access: 'R',
      },
      {
        key: 'Inclusion/Exclusion Rules',
        access: 'R',
      },
      {
        key: 'Siebel Configuration 1/2',
        access: 'R',
      },
      {
        key: 'Siebel Configuration 2/2',
        access: 'R',
      },
      {
        key: 'SV Configuration',
        access: 'RW',
      },
    ],
  },
  {
    id: 'Siebel',
    key: 'Siebel',
    control: [
      {
        key: 'General',
        access: 'R',
      },
      {
        key: 'Bundle Items',
        access: 'R',
      },
      {
        key: 'Pricing',
        access: 'R',
      },
      {
        key: 'Offerability',
        access: 'R',
      },
      {
        key: 'Product Class Selection',
        access: 'RW',
      },
      {
        key: 'Inclusion/Exclusion Rules',
        access: 'R',
      },
      {
        key: 'SV Configuration',
        access: 'R',
      },
      {
        key: 'Siebel Configuration 1/2',
        access: 'RW',
      },
      {
        key: 'Siebel Configuration 2/2',
        access: 'RW',
      },
    ],
  },
  {
    id: 'BFT',
    key: 'BFT',
    control: [
      {
        key: 'General',
        access: 'R',
      },
      {
        key: 'Bundle Items',
        access: 'R',
      },
      {
        key: 'Pricing',
        access: 'R',
      },
      {
        key: 'Offerability',
        access: 'R',
      },
      {
        key: 'Product Class Selection',
        access: 'R',
      },
      {
        key: 'Inclusion/Exclusion Rules',
        access: 'R',
      },
      {
        key: 'SV Configuration',
        access: 'R',
      },
      {
        key: 'Siebel Configuration 1/2',
        access: 'R',
      },
      {
        key: 'Siebel Configuration 2/2',
        access: 'R',
      },
    ],
  },
  // {
  //   id: 'TESTING1',
  //   key: 'T',
  //   control: [
  //     {
  //       key: 'General',
  //       access: 'R',
  //     },
  //     {
  //       key: 'Bundle Items',
  //       access: 'R',
  //     },
  //     {
  //       key: 'Pricing',
  //       access: 'R',
  //     },
  //     {
  //       key: 'Offerability',
  //       access: 'R',
  //     },
  //     {
  //       key: 'Product Class Selection',
  //       access: 'R',
  //     },
  //     {
  //       key: 'Inclusion/Exclusion Rules',
  //       access: 'R',
  //     },
  //     {
  //       key: 'SV Configuration',
  //       access: 'R',
  //     },
  //     {
  //       key: 'Siebel Configuration 1/2',
  //       access: 'R',
  //     },
  //     {
  //       key: 'Siebel Configuration 2/2',
  //       access: 'R',
  //     },
  //   ],
  // },

  {
    id: 'NoGroup',
    key: 'N',
    control: [
      {
        key: 'General',
        access: 'RW',
      },
      {
        key: 'Bundle Items',
        access: 'RW',
      },
      {
        key: 'Pricing',
        access: 'RW',
      },
      {
        key: 'Offerability',
        access: 'RW',
      },
      {
        key: 'Product Class Selection',
        access: 'RW',
      },
      {
        key: 'Inclusion/Exclusion Rules',
        access: 'RW',
      },
      {
        key: 'Siebel Configuration',
        access: 'RW',
      },
      {
        key: 'SV Configuration',
        access: 'RW',
      },
    ],
  },
];
