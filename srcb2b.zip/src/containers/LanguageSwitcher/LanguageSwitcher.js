import React from "react";
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import LanguageIcon from '@material-ui/icons/Language';
import { connect } from 'react-redux';
import languages from "../../l10n/languages";
import languagesMap from '../../l10n/languagesMap'
import { setLocale } from "react-redux-i18n";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
        },
    },
};

const LanguageSwitcher = (props) => {
    console.log('language')
    console.log(props.locale)
    console.log(languagesMap[props.locale])
    return (<React.Fragment>

        < FormControl style={{ minWidth: 200, float: 'right' }}>

            <Select
                name='action'
                MenuProps={MenuProps}
                displayEmpty
                value={languagesMap[props.locale] ? languagesMap[props.locale] : languagesMap['en']}
                onChange={(event) => {
                    props.changeLocale(languages[event.target.value].value)
                }}
                input={<Input />}
                renderValue={(selected) => {
                    if (selected) {
                        if (selected.length === 0) {
                            return <em>Language</em>;
                        }

                        return selected

                    }
                }}
                inputProps={{ 'aria-label': 'Without label' }}
            >
                <MenuItem disabled value="">
                    <em>Language</em>
                </MenuItem>
                {Object.keys(languages).map((name) => (
                    <MenuItem key={name} value={name} >
                        {name}
                    </MenuItem>
                ))}
            </Select>
        </FormControl>
        <LanguageIcon style={{
            float: 'right',
            color: '#ff1921',
            // marginTop: '1vh',
            marginRight: '1vh'
        }} />
    </React.Fragment >

    );
}


const mapStateToProps = state => {
    return {
        locale: state.i18n.locale,
    };
}
const mapDispatchToProps = dispatch => {
    return {
        changeLocale: (locale) => dispatch(setLocale(locale)),
    };
};




export default connect(mapStateToProps, mapDispatchToProps)(LanguageSwitcher);