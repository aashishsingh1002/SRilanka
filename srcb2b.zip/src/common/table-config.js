import AddBox from "@material-ui/icons/AddBox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import Check from "@material-ui/icons/Check";
import ChevronLeft from "@material-ui/icons/ChevronLeft";
import ChevronRight from "@material-ui/icons/ChevronRight";
import Clear from "@material-ui/icons/Clear";
import DeleteOutline from "@material-ui/icons/DeleteOutline";
import Edit from "@material-ui/icons/Edit";
import FilterList from "@material-ui/icons/FilterList";
import FirstPage from "@material-ui/icons/FirstPage";
import LastPage from "@material-ui/icons/LastPage";
import Remove from "@material-ui/icons/Remove";
import SaveAlt from "@material-ui/icons/SaveAlt";
import Search from "@material-ui/icons/Search";
import ViewColumn from "@material-ui/icons/ViewColumn";

import React from "react";
import ArrowDropUpIcon from "@material-ui/icons/ArrowDropUp";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import { Grid, IconButton } from "@material-ui/core";

export const TABLE_ICONS = {
  Export: SaveAlt,
  Add: AddBox,
  Check: Check,
  Clear: Clear,
  Delete: DeleteOutline,
  DetailPanel: ChevronRight,
  Edit: Edit,
  Filter: FilterList,
  FirstPage: FirstPage,
  LastPage: LastPage,
  NextPage: ChevronRight,
  PreviousPage: ChevronLeft,
  ResetSearch: Clear,
  Search: Search,
  SortArrow: ArrowDownward,
  ThirdStateCheck: Remove,
  ViewColumn: ViewColumn,
};

export const CustomPaginationComponent = (props) => {
  const { page, rowsPerPage, count, onChangePage } = props;
  let from = rowsPerPage * page + 1;
  let to = rowsPerPage * (page + 1);
  if (to > count) {
    to = count;
  }
  return (
    <div>
      {" "}
      <Grid
        container
        alignItems="center"
        justify="center"
        // style={{ paddingTop: 8 }}
      >
        {" "}
        <Grid item>
          {" "}
          <IconButton
            disabled={page === 0}
            onClick={(e) => onChangePage(e, 0)}
            style={{
              fontFamily: "BrighterSans",
              color: page === 0 ? "rgba(0, 0, 0, 0.26)" : "#000",
              fontSize: "18px",
            }}
          >
            <FirstPage
              // fontSize="small"
              color={page === 0 ? "disabled" : "#000"}
              style={{ transform: "rotate(90deg)" }}
            />
          </IconButton>{" "}
          <IconButton
            disabled={page === 0}
            onClick={(e) => onChangePage(e, page - 1)}
            style={{
              fontFamily: "BrighterSans",
              color: page === 0 ? "rgba(0, 0, 0, 0.26)" : "#000",
              fontSize: "18px",
            }}
          >
            <ArrowDropUpIcon color={page === 0 ? "disabled" : "#000"} />{" "}
          </IconButton>{" "}
          <IconButton
            disabled={to >= count}
            onClick={(e) => onChangePage(e, page + 1)}
            style={{
              fontFamily: "BrighterSans",
              color: to < count ? "#000" : "rgba(0, 0, 0, 0.26)",
              fontSize: "18px",
            }}
          >
            <ArrowDropDownIcon color={to < count ? "#000" : "disabled"} />
          </IconButton>{" "}
          <IconButton
            disabled={to >= count}
            onClick={(e) => onChangePage(e, Math.ceil(count / rowsPerPage) - 1)}
            style={{
              fontFamily: "BrighterSans",
              color: to < count ? "#000" : "rgba(0, 0, 0, 0.26)",
              fontSize: "18px",
            }}
          >
            <LastPage
              color={to < count ? "#000" : "disabled"}
              style={{ transform: "rotate(90deg)" }}
            />
          </IconButton>{" "}
        </Grid>{" "}
      </Grid>{" "}
    </div>
  );
};
