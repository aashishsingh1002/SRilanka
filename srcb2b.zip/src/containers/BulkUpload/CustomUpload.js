import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import { DropzoneArea } from 'material-ui-dropzone';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import AppsIcon from '@material-ui/icons/Apps';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import DeleteIcon from '@material-ui/icons/Delete';
import GetAppIcon from '@material-ui/icons/GetApp';
import { connect } from 'react-redux';

function Alert(props) {
  return <MuiAlert elevation={6} variant='filled' {...props} />;
}

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}
const theme = createMuiTheme({
  overrides: {
    MuiDropzoneArea: {
      root: {
        height: '100%',
      },
    },
  },
});

class DealData extends Component {
  _isMounted = false;

  constructor(props) {
    super(props);
    this.dropzoneRef = React.createRef();
  }

  state = {
    show: true,
    loading: false,
    activeTab: 0,
    files: [],
    key: 'app',
    openSnack: false,
    selValidationLog: null,
    dataUpload: {},
  };

  handleChange(file) {
    let dataUpload = {};
    dataUpload[file.name] = false;
    this.setState({
      files: file,
      dataUpload: dataUpload,
    });
  }

  saveDataHandler = () => {
    if (
      this.state.files.length > 0 &&
      !this.state.dataUpload[this.state.files[0].name]
    ) {
      this.setState({
        loading: true,
      });
      let formData = new FormData();
      this.state.files.map((file) => {
        formData.append('file', file);
      });
      console.log('formData');
      for (var pair of formData.entries()) {
        console.log(pair[0]);
        console.log(pair[1]);
      }

      const { uploadUrl } = this.props;
      axios
        .post(uploadUrl, formData)
        .then((res) => {
          if (res) {
            let dataUpload = {};
            dataUpload[this.state.files[0].name] = true;
            this.setState({
              dataUpload: dataUpload,
            });
            this.props.loadData();
          }

          this.setState({
            loading: false,
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  };

  modalCloseHandler = () => {
    this.setState({ show: false });
    this.props.showUpload();
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  componentDidMount() {
    this._isMounted = true;
  }

  handleChangeTab = (event, newValue) => {
    console.log(newValue);
    this.setState({ activeTab: newValue ? newValue : 0 });
  };

  handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    this.setState({ openSnack: false });
  };

  downloadValidationLogs = (event, index) => {
    this.setState({
      loading: true,
      selValidationLog: index,
    });

    axios
      .get('/mtn/deal/ref/Getbundleslog?createdBy=' + this.props.userInfo.id)
      .then((response) => {
        console.log(response);

        if (response) this.saveAsValidationLogExcel(response);
        else this.setState({ loading: false });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  async saveAsValidationLogExcel(response) {
    const { worksheetName = '', fileName = '' } = this.props;
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(worksheetName);
    let sheetColumns = [];
    this.props.schema.forEach((row) => {
      sheetColumns.push({
        header: row.uiName,
        key: row.refName,
        width: 25,
      });
    });
    sheetColumns.push({
      header: 'Has Error',
      key: 'isError',
      width: 25,
    });
    sheetColumns.push({
      header: 'Change',
      key: 'change',
      width: 25,
    });

    sheetColumns.push({
      header: 'Validation Complete',
      key: 'valComplete',
      width: 25,
    });
    sheetColumns.push({
      header: 'Created By',
      key: 'createdBy',
      width: 25,
    });
    worksheet.columns = sheetColumns;

    worksheet.getRow(1).font = {
      bold: true,
    };
    response.data.data.map((row) => {
      worksheet.addRow(row);
    });

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), `${fileName}_ValidationLog.xlsx`);
  }

  async saveAsExcel() {
    const { worksheetName = '', fileName = '' } = this.props;
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(worksheetName);
    let sheetColumns = [];
    this.props.schema.forEach((row) => {
      sheetColumns.push({
        header: row.uiName,
        key: row.refName,
        width: 25,
      });
    });

    worksheet.columns = sheetColumns;
    worksheet.getRow(1).font = {
      bold: true,
    };

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), `${fileName}_Template.xlsx`);
  }

  // async saveAsExcel(response, valLog) {
  //   const workbook = new ExcelJS.Workbook();
  //   let worksheet = null;
  //   let columns = {};
  //   let fileName = null;
  //   Object.keys(response.data.data[0]).map((key) => {
  //     let val = key.replace(/([A-Z])/g, ' $1');
  //     val = val.charAt(0).toUpperCase() + val.slice(1);
  //     columns[key] = val;
  //   });

  //   console.log(columns);

  //   if (valLog === 'DEAL') {
  //     worksheet = workbook.addWorksheet('Bundles Validation Logs');
  //     fileName = 'Bundles Validation Logs';
  //   }
  //   let sheetColumns = [];

  //   Object.keys(columns).map((key) => {
  //     sheetColumns.push({
  //       header: columns[key],
  //       key: key,
  //       width: 25,
  //     });
  //   });
  //   worksheet.columns = sheetColumns;
  //   response.data.data.map((row) => {
  //     worksheet.addRow(row);
  //   });

  //   const options = {
  //     formatterOptions: {
  //       delimiter: '|',
  //       transform: (row) => {
  //         let newArray = [''];

  //         for (var i = 0; i < row.length; i++) {
  //           var arr = [];
  //           arr.push(row[i]);
  //           newArray.push(arr);
  //         }
  //         newArray.push(['']);
  //         console.log(newArray);

  //         return newArray;
  //       },
  //     },
  //   };
  //   this.setState({ loading: false });
  //   if (valLog === 'TRANSFORM') {
  //     worksheet.spliceRows(0, 1);
  //     workbook.csv.writeBuffer(options).then(function (buffer) {
  //       saveAs(
  //         new Blob([buffer], { type: 'application/octet-stream' }),
  //         fileName + '.csv'
  //       );
  //     });
  //   } else {
  //     worksheet.getRow(1).font = {
  //       bold: true,
  //     };
  //     const buf = await workbook.xlsx.writeBuffer();
  //     saveAs(new Blob([buf]), fileName + '.xlsx');
  //   }
  // }

  render() {
    const vertical = 'top';
    const horizontal = 'center';

    let dealData = (
      <Modal
        show={this.state.show}
        modalClosed={this.modalCloseHandler}
        title={'Bundles'}
      >
        <Snackbar
          anchorOrigin={{ vertical, horizontal }}
          open={this.state.openSnack}
          autoHideDuration={4000}
          onClose={this.handleClose}
        >
          <Alert onClose={this.handleClose} severity='success'>
            Files Uploaded Successfully
          </Alert>
        </Snackbar>
        {this.state.loading ? (
          <div style={{ minHeight: '35vh' }}>
            <Loader />{' '}
          </div>
        ) : (
          <div style={{ minHeight: '35vh' }}>
            <AppBar position='static'>
              <Tabs
                value={this.state.activeTab}
                indicatorColor='white'
                variant='fullWidth'
                onChange={this.handleChangeTab}
              >
                <Tab
                  label='Bundles Sheet'
                  style={{
                    background: '#ffc800',
                    color: '#10628F',
                    fontWeight: 'bold',
                  }}
                />
                <Tab
                  label='Validation Logs'
                  style={{
                    background: '#ffc800',
                    color: '#10628F',
                    fontWeight: 'bold',
                  }}
                />
              </Tabs>
            </AppBar>
            <TabPanel value={this.state.activeTab} index={0}>
              <div style={{ minHeight: '35vh' }}>
                <div
                  style={
                    this.state.loading
                      ? { display: 'none' }
                      : { display: 'block' }
                  }
                >
                  <Grid container spacing={2}>
                    <Grid item xs={3}>
                      <ThemeProvider theme={theme}>
                        <DropzoneArea
                          ref={this.dropzoneRef}
                          key={this.state.key}
                          onChange={this.handleChange.bind(this)}
                          maxFileSize={52428800}
                          dropzoneText='Upload Files'
                          showPreviewsInDropzone={false}
                          filesLimit={20}
                          style={{ minHeight: '150px' }}
                          acceptedFiles={[
                            'file/xls',
                            'file/xlsx',
                            '.xlsx',
                            'application/vnd.ms-excel',
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            'application/msword',
                          ]}
                          // acceptedFiles={['application/vnd.ms-excel'
                          //     , 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',]}
                        />
                      </ThemeProvider>
                    </Grid>

                    <Grid item xs={9}>
                      <TableContainer component={Paper}>
                        <Table size='small'>
                          <TableHead>
                            <TableRow>
                              <TableCell align='left' style={{ width: '90%' }}>
                                File Name
                              </TableCell>
                              <TableCell align='left' style={{ width: '10%' }}>
                                Delete
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {this.state.files.map((file, index) => (
                              <TableRow key={file.name}>
                                <TableCell align='left'> {file.name}</TableCell>

                                <TableCell align='left'>
                                  <DeleteIcon
                                    onClick={(event) => {
                                      this.dropzoneRef.current.deleteFile(
                                        this.state.files[index],
                                        index
                                      );
                                    }}
                                    style={{ color: 'red', cursor: 'pointer' }}
                                  />
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                      {this.state.files.length > 0 && (
                        <div
                          style={{
                            display: 'flex',
                            flex: '1',
                            justifyContent: 'space-around',
                            marginTop: '30px',
                          }}
                        >
                          <Button
                            variant='contained'
                            size='medium'
                            style={{
                              background: 'pink',
                              textTransform: 'none',
                              float: 'right',
                            }}
                            onClick={() => {
                              let key =
                                this.state.key.length > 10
                                  ? 'app'
                                  : this.state.key + '1';
                              this.setState({ key: key });
                            }}
                          >
                            Clear
                          </Button>
                          <Button
                            variant='contained'
                            size='medium'
                            style={{
                              background: '#02bfa0',
                              textTransform: 'none',
                              float: 'right',
                            }}
                            onClick={this.saveDataHandler}
                          >
                            Upload
                          </Button>
                        </div>
                      )}
                    </Grid>
                  </Grid>
                  <Grid container spacing={2}>
                    <Grid item xs={3}>
                      <Button
                        variant='contained'
                        style={{
                          textTransform: 'capitalize',
                          background: '#ffcc00',
                          letterSpacing: '-1px',
                          fontWeight: '600',
                          color: '#000',
                          fontSize: '16px',
                          borderRadius: '50px',
                          padding: '6px 32px',
                          '&:hover': {
                            opacity: 0.8,
                            background: '#ffcc00',
                          },
                        }}
                        onClick={(event) => {
                          this.saveAsExcel();
                        }}
                      >
                        <GetAppIcon style={{ cursor: 'pointer' }} />
                        Template
                      </Button>
                    </Grid>
                  </Grid>
                  <p
                    style={{
                      fontSize: '16px',
                      marginBottom: '0px',
                      marginTop: '0px',
                      marginLeft: '5px',
                      marginRight: '5px',
                      color: '#FF0000',
                    }}
                  >
                    *Maximum Upload File Size: 50MB
                  </p>
                  <p
                    style={{
                      fontSize: '16px',
                      marginBottom: '0px',
                      marginTop: '0px',
                      marginLeft: '5px',
                      marginRight: '5px',
                      color: '#FF0000',
                    }}
                  >
                    *File Format Allowed: xlsx
                  </p>
                </div>
              </div>
            </TabPanel>
            <TabPanel value={this.state.activeTab} index={1}>
              <List component='nav'>
                <ListItem
                  style={{ cursor: 'pointer' }}
                  selected={this.state.selValidationLog === 0}
                  onClick={(event) => this.downloadValidationLogs(event, 0)}
                >
                  <ListItemIcon>
                    <AppsIcon />
                  </ListItemIcon>
                  <ListItemText primary={'Validation Logs'} />
                </ListItem>

                <Divider />
              </List>
            </TabPanel>
          </div>
        )}
      </Modal>
    );

    return dealData;
  }
}
const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
  };
};
export default connect(mapStateToProps)(WithErrorHandler(DealData, axios));
