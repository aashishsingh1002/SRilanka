import React from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';


const Loader = (props) => {
    const style = {
        position: 'absolute',
        top: '40%',
        left: '45%',
        color: '#ff1921'
    }
    if (props.relative)
        style.position = 'relative'
    if (props.hide)
        return null
    else
        return (
            <CircularProgress size={100} style={style} />
        );
}

export default Loader;