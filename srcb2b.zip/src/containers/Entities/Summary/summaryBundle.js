import { Box, Grid, TextField } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

import { fetchSummaryBundle } from "../../../store/actions/actionCreators";
import { getUiFields, getVersions } from "../../BulkUpload/common/utils";

const SummaryBundle = () => {
  const dispatch = useDispatch();

  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  //const data = useSelector((state) => state.summary.bundleData);
  const { releaseId } = useSelector((state) => state.releaseData.releaseData);
  const { packageId } = useSelector((state) => state.packageData.packageData);

  const [loading, setLoading] = useState(true);
  const [columns, setColumns] = useState([
    {
      uiName: "Item Id",
      refName: "ruleCode",
    },
    {
      uiName: "Item Description",
      refName: "description",
    },
    // {
    //   uiName: "Unit",
    //   refName: "catalogId",
    // },
    // {
    //   uiName: "UOM",
    //   refName: "defaultState",
    // },
    {
      uiName: "Min",
      width: "10%",
      refName: "minimum",
    },
    {
      uiName: "Max",
      width: "10%",
      refName: "maximum",
    },
  ]);

  const init = async () => {
    const entity = "bundles.cts";
    // const version = await getVersions({ userInfo, entity });
    //const result = await getUiFields({ userInfo, entity, version });
    //console.log("result", result);
    // setColumns(result);
  };

  useEffect(() => {
    init();
    // getUiFields();
    if (packageId) {
      dispatch(
        fetchSummaryBundle({
          id: packageId,
          releaseId,
          userInfo,
        })
      );
    }
  }, []);
  console.log("Columns", columns);

  return (
    <TableContainer component={Paper}>
      <Table size="small">
        <TableHead>
          <TableRow>
            {columns.map((column) => (
              <TableCell style={{ fontWeight: 600 }}>{column.uiName}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {/* {data.map((item, i) => {
            return (
              <TableRow key={i}>
                {columns.map((column) => (
                  <TableCell>{item[column.refName]}</TableCell>
                ))}
              </TableRow>
            );
          })} */}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default SummaryBundle;
