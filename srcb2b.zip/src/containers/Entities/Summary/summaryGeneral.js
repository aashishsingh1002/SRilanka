import { Box, Grid, TextField } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchSummaryGeneral } from '../../../store/actions/actionCreators';
import { getUiFields, getVersions } from '../../BulkUpload/common/utils';

const SummaryGeneral = () => {
  const dispatch = useDispatch();

  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
 const data = useSelector((state) => state.summary.generalData);
  const { releaseId } = useSelector((state) => state.releaseData.releaseData);
  const { packageId } = useSelector((state) => state.packageData.packageData);

  const [loading, setLoading] = useState(true);
  const [columns, setColumns] = useState([]);

  const init = async () => {
    const entity = 'package.basicDetails';
    const version = await getVersions({ userInfo, entity });
    const result = await getUiFields({ userInfo, entity, version });
    console.log('result', result);
    setColumns(result);
  };

  useEffect(() => {
    init();
    // getUiFields();
    if (packageId) {
      dispatch(
        fetchSummaryGeneral({
          productId: packageId,
          releaseId,
          userInfo,
        })
      );
    }
  }, [packageId]);

  return (
    <Grid container spacing={3}>
      {' '}
      {columns &&
        columns.map(({ uiName, refName, refType }) => (
          <Grid item xs={3} style={{ display: 'flex' }}>
            <div
              style={{
                width: '100%',
                //   marginTop: "auto",
                marginBottom: '20px',
              }}
            >
              <Box>
                <span
                  style={{
                    fontWeight: '600',
                    fontSize: '14px',
                  }}
                >
                  {uiName}
                </span>
              </Box>
              <TextField
                disabled
                 value={data ? data[refName] : ''}
                multiline={refType === 'TextArea'}
              />
            </div>
          </Grid>
        ))}
    </Grid>
  );
};

export default SummaryGeneral;
