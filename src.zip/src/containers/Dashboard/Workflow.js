import React, { Component } from 'react';
import ModalAction from '../../UI/ModalAction/ModalAction';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import { withStyles } from '@material-ui/core/styles';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Autocomplete from '@material-ui/lab/Autocomplete';
import TextField from '@material-ui/core/TextField';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';

import Tooltip from '@material-ui/core/Tooltip';

const LightTooltip = withStyles((theme) => ({
	tooltip: {
		backgroundColor: '#525354',
		color: 'white',
		boxShadow: theme.shadows[1],
		fontSize: 14,
	},
}))(Tooltip);

const useStyles = (theme) => ({
	center: {
		textAlign: 'center',
	},
	root: {
		'& .MuiPaper-root': {
			width: '100%',
		},
	},
	heading: {
		fontSize: theme.typography.pxToRem(15),
		flexBasis: '33.33%',
		flexShrink: 0,
	},
});

class Workflow extends Component {
	_isMounted = false;

	constructor(props) {
		super(props);
		let workflow = {};
		let smsNotiData = {};
		Object.keys(props.approvers).forEach((key) => {
			props.approvers[key].filter((el) => {
				smsNotiData[el['grpName']] = {
					primarymail: el['primarysignatory'][0]
						? el['primarysignatory'][0]
						: null,
					secondarymail: el['primarysignatory'][1]
						? el['primarysignatory'][1]
						: null,
				};
				if (el['disabled'] == 'true') workflow[el['varName']] = 'Mandatory';
				else workflow[el['varName']] = 'NA';
			});
		});
		// cellStyle: { width: '20%' }
		this.state = {
			showModal: false,
			show: true,
			loading: true,
			expanded: false,
			worklowVariables: { ...workflow },
			smsNotiData: { ...smsNotiData },
			data: [],
		};
	}
	workflowVariableChangeHandler(event, varName) {
		let worklowVariables = {
			...this.state.worklowVariables,
		};
		worklowVariables[varName] = event.target.value;
		this.setState({ worklowVariables: worklowVariables });
	}

	modalCloseHandler = () => {
		this.setState({ show: false });
		this.props.showWorkflow();
	};

	componentWillUnmount() {
		this._isMounted = false;
	}
	componentDidMount = () => {
		this._isMounted = true;
		if (this._isMounted) this.setState({ loading: false });
		console.log('mounted' + this.props.releaseData.releaseId);
		console.log(this.props.approvers);
	};
	changeHandler = (panel) => (event, isExpanded) => {
		this.setState({ expanded: isExpanded ? panel : false });
	};
	initiateApprovalHandler = () => {
		console.log(this.props.releaseData.pendingWith);
		if (this.props.releaseData.pendingWith == 'WorkFlow Not Initiated') {
			this.setState({ loading: true });
			let variables = {};
			variables.releaseCreatedBy = {
				value: this.props.releaseData.createdBy,
				type: 'String',
			};
			variables.releaseId = {
				value: this.props.releaseData.releaseId,
				type: 'String',
			};
			variables.releaseObjective = {
				value: this.props.releaseData.remarks,
				type: 'String',
			};
			variables.releaseCreationDate = {
				value: this.props.releaseData.createdOn,
				type: 'String',
			};
			variables.releaseStatus = {
				value: this.props.releaseData.releaseStatus,
				type: 'String',
			};
			variables.releaseExternalId = {
				value: this.props.releaseData.externalReleaseId,
				type: 'String',
			};

			variables.releaseApproverNote = {
				value: this.props.releaseData.launchApproverNote,
				type: 'String',
			};
			let worklowVariables = {};
			Object.keys(this.state.worklowVariables).filter((key) => {
				if (this.state.worklowVariables[key] == 'Mandatory')
					worklowVariables[key] = {
						value: true,
					};
				else
					worklowVariables[key] = {
						value: false,
					};
			});
			let smsNotiPayload = {};
			let roles = [];
			Object.keys(this.props.approvers).map((role) => {
				this.props.approvers[role].map((approver) => {
					let obj = {};
					obj.taskname = approver.grpName;
					obj.primarymail =
						this.state.smsNotiData[approver.grpName].primarymail;
					obj.secondarymail =
						this.state.smsNotiData[approver.grpName].secondarymail;
					obj.varname = approver.varName;
					obj.value =
						this.state.worklowVariables[approver.varName].toLowerCase();
					roles.push(obj);
				});
			});
			smsNotiPayload.roles = roles;
			console.log(smsNotiPayload);
			let payloadVar = {};
			payloadVar.variables = worklowVariables;
			let payloadWorkflowStart = {};
			payloadWorkflowStart.variables = variables;
			payloadWorkflowStart.businessKey = 'myBusinessKey';
			payloadWorkflowStart.withVariablesInReturn = true;
			let url = 'rest/process-definition/key/swf/start';
			console.log(payloadVar);

			axios
				.post(url, payloadWorkflowStart)
				.then((response) => {
					axios
						.get('custom/taskId?executionId=' + response.data.id)
						.then((res) => {
							console.log(res);
							console.log(res.data.data.taskId);
							axios
								.post(
									'rest/task/' + res.data.data.taskId + '/complete',
									payloadVar,
									{
										headers: {
											'Content-Type': 'application/json',
										},
									}
								)
								.then((response) => {
									console.log(response);
									axios
										.post(
											'SmsNotificationService/sendsms?releaseId=' +
												this.props.releaseData.releaseId,
											smsNotiPayload,
											{
												headers: {
													opId: this.props.userInfo.opId,
													buId: this.props.userInfo.buId,
													lob: 'Postpaid',
													initiateapproval: true,
												},
											}
										)
										.then((response) => {
											console.log(response);
											this.modalCloseHandler();
											window.location.reload();
											this.setState({ loading: false });
										})
										.catch((error) => {
											console.log(error);
											this.setState({ loading: false });
										});
								})
								.catch((error) => {
									console.log(error);
									this.setState({ loading: false });
								});
						})
						.catch((error) => {
							console.log(error);
							this.setState({ loading: false });
						});
				})
				.catch((error) => {
					console.log(error);
					this.setState({ loading: false });
				});
		} else this.setState({ showModal: true });
	};
	render() {
		const { classes } = this.props;
		let panels = [];

		Object.keys(this.props.approvers).forEach((key) => {
			let panel = null;
			panel = (
				<Accordion
					key={key}
					expanded={this.state.expanded === key}
					onChange={this.changeHandler(key)}>
					<AccordionSummary
						expandIcon={<ExpandMoreIcon />}
						aria-controls="panel1bh-content"
						id="panel1bh-header">
						<Typography className={classes.heading}>{key}</Typography>
					</AccordionSummary>
					<AccordionDetails style={{ display: 'block' }}>
						<TableContainer component={Paper} style={{ overflow: 'visible' }}>
							<Table aria-label="collapsible table">
								<TableHead>
									<TableRow>
										<TableCell>Group</TableCell>
										<TableCell>Primary Signatory</TableCell>
										<TableCell>Secondary Signatory</TableCell>
										<TableCell>Mandatory/FYI/NA</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{this.props.approvers[key].map((row) => {
										return (
											<TableRow className={classes.root} key={row.grpName}>
												<TableCell style={{ width: '15%' }}>
													{row.grpName}
												</TableCell>

												<TableCell style={{ width: '25%' }}>
													<LightTooltip
														title={
															this.state.smsNotiData[row.grpName].primarymail
														}
														arrow>
														<Autocomplete
															disableClearable
															disabled={true}
															value={
																this.state.smsNotiData[row.grpName].primarymail
															}
															options={row.primarysignatory}
															onChange={(event, selected) => {
																let smsNotiData = {
																	...this.state.smsNotiData,
																};
																let approveData = {
																	...smsNotiData[[row.grpName]],
																};
																approveData.primarymail = selected;
																smsNotiData[row.grpName] = approveData;
																this.setState({ smsNotiData: smsNotiData });
															}}
															renderInput={(params) => (
																<TextField {...params} margin="normal" />
															)}
														/>
													</LightTooltip>
												</TableCell>

												<TableCell style={{ width: '25%' }}>
													<LightTooltip
														title={
															this.state.smsNotiData[row.grpName].secondarymail
														}
														arrow>
														<Autocomplete
															disableClearable
															disabled={true}
															onChange={(event, selected) => {
																let smsNotiData = {
																	...this.state.smsNotiData,
																};
																let approveData = {
																	...smsNotiData[[row.grpName]],
																};
																approveData.secondarymail = selected;
																smsNotiData[row.grpName] = approveData;
																this.setState({ smsNotiData: smsNotiData });
															}}
															value={
																this.state.smsNotiData[row.grpName]
																	.secondarymail
															}
															options={row.primarysignatory}
															renderInput={(params) => (
																<TextField {...params} margin="normal" />
															)}
														/>
													</LightTooltip>
												</TableCell>

												<TableCell style={{ width: '35%' }}>
													<RadioGroup
														row
														aria-label="position"
														name="position"
														onChange={(event) =>
															this.workflowVariableChangeHandler(
																event,
																row['varName']
															)
														}
														value={this.state.worklowVariables[row['varName']]}>
														<FormControlLabel
															value={'Mandatory'}
															control={<Radio style={{ color: '#ff1921' }} />}
															label="Mandatory"
															disabled={row.disabled == 'true' ? true : false}
														/>
														<FormControlLabel
															value="FYI"
															control={<Radio style={{ color: '#ff1921' }} />}
															label="FYI"
															disabled={row.disabled == 'true' ? true : false}
														/>
														<FormControlLabel
															disabled={row.disabled == 'true' ? true : false}
															value="NA"
															control={<Radio style={{ color: '#ff1921' }} />}
															label="NA"
														/>
													</RadioGroup>
												</TableCell>
											</TableRow>
										);
									})}
								</TableBody>
							</Table>
						</TableContainer>
					</AccordionDetails>
				</Accordion>
			);
			panels.push(panel);
		});
		let modalChild = panels;
		if (this.state.showModal)
			modalChild = (
				<Typography variant="h5" className={classes.center}>
					{' '}
					WorkFlow Already Initiated
				</Typography>
			);
		else if (this.state.loading)
			modalChild = (
				<div style={{ minHeight: '25vh' }}>
					{' '}
					<Loader />{' '}
				</div>
			);

		let workflow = (
			<ModalAction
				show={this.state.show}
				modalClosed={this.modalCloseHandler}
				data={this.props.releaseData}
				actionText={'Initiate Approval'}
				title={'ePCN Id ' + this.props.releaseData.externalReleaseId}
				action={this.initiateApprovalHandler}>
				<div className={classes.root} style={{ minHeight: '25vh' }}>
					{modalChild}
				</div>
			</ModalAction>
		);

		return workflow;
	}
}

export default withStyles(useStyles)(WithErrorHandler(Workflow, axios));
