import React, { Component } from "react";
import Table from "../../UI/Table/Table";
import Tooltip from "@material-ui/core/Tooltip";
import Chip from "@material-ui/core/Chip";
import IconButton from "@material-ui/core/IconButton";
import AttachmentIcon from "@material-ui/icons/Attachment";
import { withStyles } from "@material-ui/core/styles";
import Loader from "../../UI/Loader/Loader";
import axios from "../../axios-epc";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import { connect } from "react-redux";
import SaveIcon from "@material-ui/icons/Save";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import Input from "@material-ui/core/Input";
import TextField from "@material-ui/core/TextField";
import KeyboardArrowUpIcon from "@material-ui/icons/KeyboardArrowUp";
import Attachment from "../Dashboard/Attachment";
import Modal from "../../UI/Modal/Modal";
import Typography from "@material-ui/core/Typography";
import SettingsSystemDaydreamIcon from "@material-ui/icons/SettingsSystemDaydream";
import Federation from "./Federation";
import AuditLogs from "../Dashboard/AuditLogs";
import BookIcon from "@material-ui/icons/Book";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";

import Backdrop from "@material-ui/core/Backdrop";
import Title from "../../UI/Typography/Title";
import MaterialTable from "material-table";
import { forwardRef } from "react";
import AddBox from "@material-ui/icons/AddBox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import Check from "@material-ui/icons/Check";
import ChevronLeft from "@material-ui/icons/ChevronLeft";
import ChevronRight from "@material-ui/icons/ChevronRight";
import Clear from "@material-ui/icons/Clear";
import DeleteOutline from "@material-ui/icons/DeleteOutline";
import Edit from "@material-ui/icons/Edit";
import FilterList from "@material-ui/icons/FilterList";
import FirstPage from "@material-ui/icons/FirstPage";
import LastPage from "@material-ui/icons/LastPage";
import Remove from "@material-ui/icons/Remove";
import SaveAlt from "@material-ui/icons/SaveAlt";
import Search from "@material-ui/icons/Search";
import ViewColumn from "@material-ui/icons/ViewColumn";
import { ThemeProvider } from "@material-ui/core";
import { createMuiTheme } from "@material-ui/core/styles";

import Drawer from "@material-ui/core/Drawer";
import Toolbar from "@material-ui/core/Toolbar";
import CloseIcon from "@material-ui/icons/Close";
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import Box from "@material-ui/core/Box";
import * as actionTypes from "../../store/actions/actionTypes";

import InputLabel from "@material-ui/core/InputLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Card from "@material-ui/core/Card";
import CardContent from "@material-ui/core/CardContent";

const tableIcons = {
	Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
	Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
	Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
	Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
	DetailPanel: forwardRef((props, ref) => (
		<ChevronRight {...props} ref={ref} />
	)),
	Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
	Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
	Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
	FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
	LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
	NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
	PreviousPage: forwardRef((props, ref) => (
		<ChevronLeft {...props} ref={ref} />
	)),
	ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
	Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
	SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
	ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
	ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const drawerWidth = "35vw";
const LightTooltip = withStyles((theme) => ({
	tooltip: {
	  backgroundColor: "#525354",
	  color: "white",
	  boxShadow: theme.shadows[1],
	  fontSize: 14,
	},
  }))(Tooltip);
const useStyles = (theme) => ({
	drawer: {
		width: drawerWidth,
		flexShrink: 0,
	},
	drawerPaper: {
		width: drawerWidth,
		height: window.screen.height + 0.2 * window.screen.height,
		zIndex: 1000000,
	},
	backdrop: {
		zIndex: theme.zIndex.drawer + 1,
		height: window.screen.height + 0.2 * window.screen.height,
		color: "#fff",
	},
});
const theme = createMuiTheme({
	overrides: {
		MuiTable: {
			root: {
				tableLayout: "fixed",
			},
		},
		MuiTableCell: {
			root: {
				padding: "0px",
				paddingLeft: "10px",
			},
		},
		MuiPaper: {
			width: "100%",
		},
	},
});

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
	PaperProps: {
		style: {
			maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
			width: 250,
		},
	},
};

class Worklist extends Component {
	_isMounted = false;

	state = {
		relWorkFlowAction: "",
		relWorkRemarks: "",
		releaseEditData: {},
		loadingEdit: false,
		openDrawer: false,
		auditLogs: false,
		federate: false,
		
		approversData: {},
		approverDataRev: {},
		userGroups: [],
		selGrp: null,
		userRole: this.props.userInfo.group[0],
		roleSelected: null,
		show: false,
		modalContent: null,
		relData: {},
		attachment: false,
		loading: true,
		dataTeamItems: [],
		dataMyItems: [],
		columnsMyItemsowner: [
			{
				title: "Release Id",
				field: "externalReleaseId",
			},
			{
				title: 'Product',
				field: 'replicationStatus',
				render: (rowData) => (
				  <Typography
					style={{ fontWeight: '400', fontSize: '14px', color: '#333333' }}
				  >
					
					{rowData.replicationStatus}
				  </Typography>
				),
				sorting: false,
				//cellStyle: { width: '10%' }
			  },
			{
				title: "Release Objective",
				field: "releaseObjective",
				sorting: false,
				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: "12px",
									overflow: "auto",
									maxHeight: "40vh",
									maxWidth: "60vw",
								}}>
								{rowData.releaseObjective}
							</pre>
						}>
						<span>
							{" "}
							{rowData.releaseObjective
								? rowData.releaseObjective.length > 25
									? rowData.releaseObjective.substring(0, 25) + "..."
									: rowData.releaseObjective
								: ""}
						</span>
					</Tooltip>
				),
			},
			{ title: "Created Date", field: "createdAt" },

			{ title: "Release Status", field: "releaseStatus" },
			{ title: "Resubmit To", field: "resubmitTo" },
			{ title: "Action", field: "action" },
			{ title: "Task Created On", field: "taskCreatedOn" },
			{
				title: "Enablers",
				field: "enablers",
				filtering: false,
				//cellStyle: { width: "100px" },
				render: (rowData) => (
				  <React.Fragment>
					<LightTooltip title={"Attachment"} arrow>
					  <IconButton
						onClick={(event) => {
						  event.stopPropagation();
						 
							this.setState({ relData: { ...rowData } });
							this.setState({ attachment: true });
						
						}}
						//style={{ marginRight: "2%" }}
					  >
						<AttachmentIcon />
					  </IconButton>
					</LightTooltip>
					<LightTooltip title={"Audit Logs"} arrow>
					  <IconButton
						onClick={(event) => {
						  event.stopPropagation();
						  this.setState({ relData: { ...rowData } });
						  this.setState({ auditLogs: true });
						}}
						//style={{ marginRight: "2%" }}
					  >
						<BookIcon />
					  </IconButton>
					</LightTooltip>
				  </React.Fragment>
				),
				sorting: false,
				cellStyle: { width: '10%' }
			  },
		],
		columnsTeamItemspm: [
			{
				title: "Self Assign",
				field: "selfAssign",
				render: (rowData) => (
					<IconButton
						onClick={(event) => {
							event.stopPropagation();
							this.selfAssignHandler(rowData);
						}}>
						<KeyboardArrowUpIcon />
					</IconButton>
				),
				cellStyle: { width: "10%" },
				filtering: false,
			},
			{ title: "Release Id", field: "externalReleaseId" },
			{
				title: 'Product',
				field: 'replicationStatus',
				render: (rowData) => (
				  <Typography
					style={{ fontWeight: '400', fontSize: '14px', color: '#333333' }}
				  >
					
					{rowData.replicationStatus}
				  </Typography>
				),
				sorting: false,
				cellStyle: { width: '10%' }
			  },
			{
				title: "Release Objective",
				field: "releaseObjective",
				sorting: false,
				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: "12px",
									overflow: "auto",
									maxHeight: "40vh",
									maxWidth: "60vw",
								}}>
								{rowData.releaseObjective}
							</pre>
						}>
						<span>
							{" "}
							{rowData.releaseObjective
								? rowData.releaseObjective.length > 25
									? rowData.releaseObjective.substring(0, 25) + "..."
									: rowData.releaseObjective
								: ""}
						</span>
					</Tooltip>
				),
			},
			{ title: "Release Status", field: "releaseStatus" },
			{
				title: 'Resubmit To',
				field: 'resubmitTo',
				sorting: false,
				cellStyle: { width: '10%' }
			  },
			{ title: "Created Date", field: "createdAt" },
			{ title: "Created By", field: "createdBy" },
			{ title: "Task Created On", field: "taskCreatedOn" },
			{
				title: "Enablers",
				field: "enablers",
				filtering: false,
				//cellStyle: { width: "100px" },
				render: (rowData) => (
				  <React.Fragment>
					<LightTooltip title={"Attachment"} arrow>
					  <IconButton
						onClick={(event) => {
						  event.stopPropagation();
						 
							this.setState({ relData: { ...rowData } });
							this.setState({ attachment: true });
						
						}}
						//style={{ marginRight: "2%" }}
					  >
						<AttachmentIcon />
					  </IconButton>
					</LightTooltip>
					<LightTooltip title={"Audit Logs"} arrow>
					  <IconButton
						onClick={(event) => {
						  event.stopPropagation();
						  this.setState({ relData: { ...rowData } });
						  this.setState({ auditLogs: true });
						}}
						//style={{ marginRight: "2%" }}
					  >
						<BookIcon />
					  </IconButton>
					</LightTooltip>
				  </React.Fragment>
				),
				sorting: false,
				cellStyle: { width: '10%' }
			  },
		],
		columnsTeamItems: [
			{
				title: "Self Assign",
				field: "selfAssign",
				render: (rowData) => (
					<IconButton
						onClick={(event) => {
							event.stopPropagation();
							this.selfAssignHandler(rowData);
						}}>
						<KeyboardArrowUpIcon />
					</IconButton>
				),
				cellStyle: { width: "10%" },
				filtering: false,
			},
			{ title: "Release Id", field: "externalReleaseId" },
			{
				title: 'Product',
				field: 'replicationStatus',
				render: (rowData) => (
				  <Typography
					style={{ fontWeight: '400', fontSize: '14px', color: '#333333' }}
				  >
					
					{rowData.replicationStatus}
				  </Typography>
				),
				sorting: false,
				cellStyle: { width: '10%' }
			  },
			{
				title: "Release Objective",
				field: "releaseObjective",
				sorting: false,
				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: "12px",
									overflow: "auto",
									maxHeight: "40vh",
									maxWidth: "60vw",
								}}>
								{rowData.releaseObjective}
							</pre>
						}>
						<span>
							{" "}
							{rowData.releaseObjective
								? rowData.releaseObjective.length > 25
									? rowData.releaseObjective.substring(0, 25) + "..."
									: rowData.releaseObjective
								: ""}
						</span>
					</Tooltip>
				),
			},
			{ title: "Release Status", field: "releaseStatus" },
			{ title: "Created Date", field: "createdAt" },
			{ title: "Created By", field: "createdBy" },
			{ title: "Task Created On", field: "taskCreatedOn" },
			{
				title: "Enablers",
				field: "enablers",
				filtering: false,
				//cellStyle: { width: "100px" },
				render: (rowData) => (
				  <React.Fragment>
					<LightTooltip title={"Attachment"} arrow>
					  <IconButton
						onClick={(event) => {
						  event.stopPropagation();
						 
							this.setState({ relData: { ...rowData } });
							this.setState({ attachment: true });
						
						}}
						//style={{ marginRight: "2%" }}
					  >
						<AttachmentIcon />
					  </IconButton>
					</LightTooltip>
					<LightTooltip title={"Audit Logs"} arrow>
					  <IconButton
						onClick={(event) => {
						  event.stopPropagation();
						  this.setState({ relData: { ...rowData } });
						  this.setState({ auditLogs: true });
						}}
						//style={{ marginRight: "2%" }}
					  >
						<BookIcon />
					  </IconButton>
					</LightTooltip>
				  </React.Fragment>
				),
				sorting: false,
				cellStyle: { width: '10%' }
			  },
		],
		columnsMyItemspm: [
			{
				title: "Un Assign",
				filtering: false,
				field: "unAssign",
				render: (rowData) => (
					<IconButton
						onClick={(event) => {
							event.stopPropagation();
							this.unAssignHandler(rowData);
						}}>
						<ExpandMoreIcon />
					</IconButton>
				),
				sorting: false,
				cellStyle: { width: "10%" },
			},
			{
				title: "Release Id",
				field: "externalReleaseId",
			},
			{
				title: 'Product',
				field: 'replicationStatus',
				render: (rowData) => (
				  <Typography
					style={{ fontWeight: '400', fontSize: '14px', color: '#333333' }}
				  >
					{rowData.replicationStatus}
				  </Typography>
				),
				sorting: false,
				cellStyle: { width: '10%' }
			  },
			{
				title: "Release Objective",
				field: "releaseObjective",
				sorting: false,
				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: "12px",
									overflow: "auto",
									maxHeight: "40vh",
									maxWidth: "60vw",
								}}>
								{rowData.releaseObjective}
							</pre>
						}>
						<span>
							{" "}
							{rowData.releaseObjective
								? rowData.releaseObjective.length > 25
									? rowData.releaseObjective.substring(0, 25) + "..."
									: rowData.releaseObjective
								: ""}
						</span>
					</Tooltip>
				),
			},
			

			{ title: "Release Status", field: "releaseStatus" },
			{
				title: 'Resubmit To',
				field: 'resubmitTo',
				sorting: false,
				cellStyle: { width: '10%' }
			  },
			{ title: "Created Date", field: "createdAt" },
			{ title: "Created By", field: "createdBy" },
			{ title: "Task Created On", field: "taskCreatedOn" },
			{
				title: "Enablers",
				field: "enablers",
				filtering: false,
				//cellStyle: { width: "100px" },
				render: (rowData) => (
				  <React.Fragment>
					<LightTooltip title={"Attachment"} arrow>
					  <IconButton
						onClick={(event) => {
						  event.stopPropagation();
						 
							this.setState({ relData: { ...rowData } });
							this.setState({ attachment: true });
						
						}}
						//style={{ marginRight: "2%" }}
					  >
						<AttachmentIcon />
					  </IconButton>
					</LightTooltip>
					<LightTooltip title={"Audit Logs"} arrow>
					  <IconButton
						onClick={(event) => {
						  event.stopPropagation();
						  this.setState({ relData: { ...rowData } });
						  this.setState({ auditLogs: true });
						}}
						//style={{ marginRight: "2%" }}
					  >
						<BookIcon />
					  </IconButton>
					</LightTooltip>
				  </React.Fragment>
				),
				sorting: false,
				cellStyle: { width: '10%' }
			  },
		],
		columnsMyItems: [
			{
				title: "Un Assign",
				filtering: false,
				field: "unAssign",
				render: (rowData) => (
					<IconButton
						onClick={(event) => {
							event.stopPropagation();
							this.unAssignHandler(rowData);
						}}>
						<ExpandMoreIcon />
					</IconButton>
				),
				sorting: false,
				cellStyle: { width: "10%" },
			},
			{
				title: "Release Id",
				field: "externalReleaseId",
			},
			{
				title: 'Product',
				field: 'replicationStatus',
				render: (rowData) => (
				  <Typography
					style={{ fontWeight: '400', fontSize: '14px', color: '#333333' }}
				  >
					{rowData.replicationStatus}
				  </Typography>
				),
				sorting: false,
				cellStyle: { width: '10%' }
			  },
			{
				title: "Release Objective",
				field: "releaseObjective",
				sorting: false,
				render: (rowData) => (
					<Tooltip
						interactive
						title={
							<pre
								style={{
									fontSize: "12px",
									overflow: "auto",
									maxHeight: "40vh",
									maxWidth: "60vw",
								}}>
								{rowData.releaseObjective}
							</pre>
						}>
						<span>
							{" "}
							{rowData.releaseObjective
								? rowData.releaseObjective.length > 25
									? rowData.releaseObjective.substring(0, 25) + "..."
									: rowData.releaseObjective
								: ""}
						</span>
					</Tooltip>
				),
			},
			

			{ title: "Release Status", field: "releaseStatus" },
			{ title: "Created Date", field: "createdAt" },
			{ title: "Created By", field: "createdBy" },
			{ title: "Task Created On", field: "taskCreatedOn" },
			{
				title: "Enablers",
				field: "enablers",
				filtering: false,
				//cellStyle: { width: "100px" },
				render: (rowData) => (
				  <React.Fragment>
					<LightTooltip title={"Attachment"} arrow>
					  <IconButton
						onClick={(event) => {
						  event.stopPropagation();
						 
							this.setState({ relData: { ...rowData } });
							this.setState({ attachment: true });
						
						}}
						//style={{ marginRight: "2%" }}
					  >
						<AttachmentIcon />
					  </IconButton>
					</LightTooltip>
					<LightTooltip title={"Audit Logs"} arrow>
					  <IconButton
						onClick={(event) => {
						  event.stopPropagation();
						  this.setState({ relData: { ...rowData } });
						  this.setState({ auditLogs: true });
						}}
						//style={{ marginRight: "2%" }}
					  >
						<BookIcon />
					  </IconButton>
					</LightTooltip>
				  </React.Fragment>
				),
				sorting: false,
				cellStyle: { width: '10%' }
			  },
		],
	};
	componentWillUnmount() {
		this._isMounted = false;
	}

	showAuditLogsHandler = () => {
		this.setState({ auditLogs: false });
	};

	unAssignHandler = (rowData) => {
		console.log(rowData);
		if (this._isMounted) {
			this.setState({ loading: true });
		}

		if (rowData.releaseStatus === "Assigned For Federation") {
			const groupIndex = this.state.userGroups.indexOf("radB2c");
			axios
				.get(
					`/Workflowcustom/UnasignUserTaskList?groupId=${this.state.userGroups[groupIndex]}&userId=${this.props.userInfo.id}`,
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
							extrnRelId: rowData.externalReleaseId,
						},
					}
				)
				.then((response) => {
					console.log(response);
					if (response) {
						let myItems = [...this.state.dataMyItems];
						var removeIndex = this.state.dataMyItems
							.map(function (item) {
								return item.releaseId;
							})
							.indexOf(rowData.releaseId);

						myItems.splice(removeIndex, 1);
						let newMyitem = {};
						newMyitem = { ...rowData };
						newMyitem.save = "";
						newMyitem.action = "";
						newMyitem.remarks = "";
						newMyitem.releaseStatus = "Ready To Federate";
						this.setState((prevState) => {
							return {
								loading: false,
								dataMyItems: myItems,
								dataTeamItems: [newMyitem].concat(prevState.dataTeamItems),
							};
						});
					} else {
						this.setState({ loading: false });
					}
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else
			axios
				.post(
					"/b2b-workflow/task/" + rowData.taskId + "/unclaim",
					{},
					{
						headers: {
							"Content-Type": "application/json",
							buId: this.props.userInfo.buId,
							opId: this.props.userInfo.opId,
							authUserId:this.props.userInfo.id,
							authGroupId:this.props.userInfo.group[0],
							Authorization: 'Bearer ' + this.props.userInfo.jwt,
						},
					}
				)
				.then((response) => {
					console.log(response);
					if (response) {
						let myItems = [...this.state.dataMyItems];
						var removeIndex = this.state.dataMyItems
							.map(function (item) {
								return item.releaseId;
							})
							.indexOf(rowData.releaseId);

						myItems.splice(removeIndex, 1);
						let newMyitem = {};
						newMyitem = { ...rowData };
						newMyitem.save = "";
						newMyitem.action = "";
						newMyitem.remarks = "";
						this.setState((prevState) => {
							return {
								loading: false,
								dataMyItems: myItems,
								dataTeamItems: [newMyitem].concat(prevState.dataTeamItems),
							};
						});
					} else {
						this.setState({ loading: false });
					}
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
	};

	actionHandlerPM = (event) => {
		event.preventDefault();

		this.setState({ loadingEdit: true });

		
			axios
				.post(
					'b2b-workflow/task/do-action',
					{
						"action":this.state.relWorkFlowAction.toUpperCase(),
						"taskId":this.state.releaseEditData.taskId,
						"remarks" :this.state.relWorkRemarks,
						"medium" : "UI"
					},
					{
						headers: {
							buId: this.props.userInfo.buId,
							opId: this.props.userInfo.opId,
							authUserId:this.props.userInfo.id,
							authGroupId:this.props.userInfo.group[0],
							Authorization: 'Bearer ' + this.props.userInfo.jwt,
						},
					}
				)
				.then((response) => {
					console.log(response);
				})
				.catch((error) => {
					console.log(error);
				});
			let myItems = [...this.state.dataMyItems];

			let removeIndex = this.state.dataMyItems.findIndex(
				(item) =>
					item.releaseId === this.state.releaseEditData.releaseId &&
					item.resubmitName === this.state.releaseEditData.resubmitName
			);

			myItems.splice(removeIndex, 1);
			this.setState({
				dataMyItems: myItems,
				loadingEdit: false,
				openDrawer: false,
				relWorkFlowAction: "",
				relWorkRemarks: "",
			});
	};

	actionHandler = (event) => {
		if (event) {
			event.preventDefault();
		}
		console.log(this.state.relWorkFlowAction);
		console.log(this.state.relWorkRemarks);
		console.log(this.state.releaseEditData.releaseId);
		let variables = {};
		let payload = {};
		this.setState({ loadingEdit: true });
		if (this.state.relWorkFlowAction == "Approve" || !event) {
			variables.approve = { value: true };
			variables.remarks = { value: this.state.relWorkRemarks };
			payload.variables = variables;
			console.log("payload");
			const url = this.state.userGroups.includes("CIT_OPS")
				? "workflowrest/task/" + this.state.relData.taskId + "/complete"
				: "workflowrest/task/" + this.state.releaseEditData.taskId + "/complete";
			console.log(payload);
			axios
				.post(url, payload, {
					headers: {
						"Content-Type": "application/json",
					},
				})
				.then((response) => {
					console.log(response);

					let smsNotiPayload = {};
					let roles = [];

					const approver = JSON.parse(
						localStorage.getItem("approversDataUser")
					);

					let obj = {};
					obj.taskName = approver.grpName;
					obj.primaryMail = approver.primarysignatory[0] ?? null;
					obj.secondaryMail = approver.primarysignatory[1] ?? null;
					obj.varName = approver.varName;
					obj.value = approver.disabled === "true" ? "mandatory" : "fyi";
					obj.medium = "sms";
					obj.group = this.state.userRole;
					roles.push(obj);
					// })
					smsNotiPayload.roleDetailList = roles;
					console.log(smsNotiPayload);
					let myItems = [...this.state.dataMyItems];
					let removeIndex = this.state.dataMyItems
						.map(function (item) {
							return item.releaseId;
						})
						.indexOf(this.state.releaseEditData.releaseId);

					myItems.splice(removeIndex, 1);
					this.setState({
						dataMyItems: myItems,
						loadingEdit: false,
						openDrawer: false,
						relWorkFlowAction: "",
						relWorkRemarks: "",
					});

					axios
						.post(
							"TeleSelectApprovers/send/notification/initiate-approval?releaseId=" +
								this.state.releaseEditData.releaseId,
							{
								roleDetailList: smsNotiPayload.roleDetailList,
							},

							{
								headers: {
									opId: this.props.userInfo.opId,
									buId: this.props.userInfo.buId,
									lob: "Postpaid",
									initiateapproval: false,
								},
							}
						)
						.then((response) => {
							console.log(response);
							if (
								this.state.userGroups.includes("ceoB2c") ||
								this.state.userGroups.includes("ceoB2b")
							) {
								axios
									.get("Workflowcustom/updateForRad", {
										headers: {
											releaseId: this.state.releaseEditData.releaseId,
											opId: this.props.userInfo.opId,
											buId: this.props.userInfo.buId,
										},
									})
									.then((res) => {
										console.log(res);
									});
							}
						})
						.catch((error) => {
							console.log(error);
						});
				})
				.catch((error) => {
					console.log(error);
					this.setState({
						loadingEdit: false,
						openDrawer: false,
						relWorkFlowAction: "",
						relWorkRemarks: "",
					});
				});
		} else {
			axios
				.post(
					'b2b-workflow/task/do-action',
					{
						"action":this.state.relWorkFlowAction.toUpperCase(),
    "taskId":this.state.releaseEditData.taskId,
    "remarks" :this.state.relWorkRemarks,
    "medium" : "UI"

						
					},
					{
						headers: {
							buId: this.props.userInfo.buId,
							opId: this.props.userInfo.opId,
							authUserId:this.props.userInfo.id,
							authGroupId:this.props.userInfo.group[0],
							Authorization: 'Bearer ' + this.props.userInfo.jwt,
						},
					}
				)
				.then((response) => {
					console.log(response);

					if (this.state.relWorkFlowAction.toLowerCase() === "rfc") {
						axios
							.get(
								`/Workflowcustom/statusForRFC?releaseId=${this.state.releaseEditData.releaseId}`,
								{
									headers: {
										opId: this.props.userInfo.opId,
										buId: this.props.userInfo.buId,

										lob: this.state.userRole
											.substr(this.state.userRole.length - 3)
											.toLowerCase(),
									},
								}
							)
							.then((response) => {
								console.log(response);
								let myItems = [...this.state.dataMyItems];
								let removeIndex = this.state.dataMyItems
									.map(function (item) {
										return item.releaseId;
									})
									.indexOf(this.state.releaseEditData.releaseId);

								myItems.splice(removeIndex, 1);
								this.setState({
									dataMyItems: myItems,
									loadingEdit: false,
									openDrawer: false,
									relWorkFlowAction: "",
									relWorkRemarks: "",
								});
							})
							.catch((error) => {
								console.log(error);
								if (this._isMounted) this.setState({ loading: false });
							});
					} else {
						let myItems = [...this.state.dataMyItems];
						let removeIndex = this.state.dataMyItems
							.map(function (item) {
								return item.releaseId;
							})
							.indexOf(this.state.releaseEditData.releaseId);

						myItems.splice(removeIndex, 1);
						this.setState({
							dataMyItems: myItems,
							loadingEdit: false,
							openDrawer: false,
							relWorkFlowAction: "",
							relWorkRemarks: "",
						});
					}
				})
				.catch((error) => {
					console.log(error);
				});
		}
	};
	errorConfirmedHandler = () => {
		this.setState({ show: false });
	};

	selfAssignHandler = (rowData) => {
		console.log(rowData);
		if (this._isMounted) this.setState({ loading: true });

		if (rowData.releaseStatus === "Ready To Federate") {
			const groupIndex = this.state.userGroups.indexOf("radB2c");
			axios
				.get(
					`/Workflowcustom/asignUserTaskList?groupId=${this.state.userGroups[groupIndex]}&userId=${this.props.userInfo.id}`,
					{
						headers: {
							opId: this.props.userInfo.opId,
							buId: this.props.userInfo.buId,
							extrnRelId: rowData.externalReleaseId,
						},
					}
				)
				.then((response) => {
					console.log(response);
					let teamItems = [...this.state.dataTeamItems];
					var removeIndex = this.state.dataTeamItems
						.map(function (item) {
							return item.releaseId;
						})
						.indexOf(rowData.releaseId);

					teamItems.splice(removeIndex, 1);
					let newMyitem = {};
					newMyitem = { ...rowData };
					newMyitem.save = "";
					newMyitem.action = "";
					newMyitem.remarks = "";
					newMyitem.releaseStatus = "Assigned For Federation";
					if (this._isMounted) {
						this.setState((prevState) => {
							return {
								loading: false,
								dataTeamItems: teamItems,
								dataMyItems: [newMyitem].concat(prevState.dataMyItems),
							};
						});
					}
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else {
			axios
				.post(
					
					"/b2b-workflow/task/" + rowData.taskId + "/claim",
					{},
					{
						headers: {
							"Content-Type": "application/json",
							buId: this.props.userInfo.buId,
							opId: this.props.userInfo.opId,
							authUserId:this.props.userInfo.id,
							authGroupId:this.props.userInfo.group[0],
							Authorization: 'Bearer ' + this.props.userInfo.jwt,

						},
					}
				)
				.then((response) => {
					console.log(response);
					let teamItems = [...this.state.dataTeamItems];
					var removeIndex = this.state.dataTeamItems
						.map(function (item) {
							return item.releaseId;
						})
						.indexOf(rowData.releaseId);

					teamItems.splice(removeIndex, 1);
					let newMyitem = {};
					newMyitem = { ...rowData };
					newMyitem.save = "";
					newMyitem.action = "";
					newMyitem.remarks = "";
					if (this._isMounted)
						this.setState((prevState) => {
							return {
								loading: false,
								dataTeamItems: teamItems,
								dataMyItems: [newMyitem].concat(prevState.dataMyItems),
							};
						});
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	};

	myItemsHandler(userRole) {
		userRole = userRole ?? this.state.userGroups[0];
		
		let url=
		'b2b-workflow/get/user/tasks'
		if (this.props.userInfo.group.includes("b2bsales")) {
			url =
			'b2b-workflow/get/owner/tasks'
		}
		return axios
			.get(url, {
				headers: {
					opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
         
		 Authorization: 'Bearer ' + this.props.userInfo.jwt,
					authUserId:this.props.userInfo.id,
					authGroupId:userRole
				},
			})
			.then((res) => {
				console.log("my items");
				console.log(res);
				console.log(res.data.data);
				if (this._isMounted) this.setState({ dataMyItems: res.data.data });
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	}
	teamItemsHandler(userRole) {
		userRole = userRole ?? this.state.userGroups[0];

		if (!this.props.userInfo.group.includes("b2bsales")) {
			return axios
				.get(
					'/b2b-workflow/get/group/tasks',

					{
						headers: {
							opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
			 Authorization: 'Bearer ' + this.props.userInfo.jwt,
					authUserId:this.props.userInfo.id,
					authGroupId:userRole
						},
					}
				)
				.then((res) => {
					console.log("team ");
					console.log(res.data.data);
					let teamItems = [];

					if (res.data.data) {
						console.log('TeamI',res.data.data)
						res.data.data.filter((el) => {
							
							el.selfAssign = "";
							teamItems.push(el);
						});
					}

					if (this._isMounted) {
						console.log('TeamI',teamItems)
						this.setState({ dataTeamItems: teamItems });
					}

					if (
						this.state.userGroups.includes("radB2c") ||
						this.state.userGroups.includes("radB2b")
					) {
						const groupIndex = this.state.userGroups.indexOf(this.state.selGrp);
						axios
							.get(
								`/Workflowcustom/fedUserTaskList?groupId=${this.state.userGroups[groupIndex]}&userId=${this.props.userInfo.id}`,
								{
									headers: {
										opId: this.props.userInfo.opId,
                    buId: this.props.userInfo.buId,
                    lob: "Postpaid",
                    
										
									},
								}
							)
							.then((res) => {
								console.log("RAD specific items");
								console.log(res.data.data);
								let teamItems = [];
								res.data.data.map((element) => {
									const obj = {};
									obj.releaseCreationDate = element.createdOn;
									obj.releaseId = element.releaseid;
									obj.releaseStatus = element.releaseStatus;
									obj.releaseObjective = element.remarks;
									obj.createdBy = "";
									obj.externalReleaseId = element.extrnReleaseId;
									obj.selfAssign = "";
									teamItems.push(obj);
								});
								if (this._isMounted) {
									this.setState({
										dataTeamItems: [...this.state.dataTeamItems, ...teamItems],
									});
								}
							});
					}
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else return Promise.resolve();
	}

	myItemsFederateHandler(userRole) {
		userRole = userRole ?? this.state.userGroups[0];

		const groupIndex = this.state.userGroups.indexOf(userRole);
		if (groupIndex !== -1) {
			return axios
				.get(
					`/Workflowcustom/assignFedUserTaskList?groupId=${this.state.userGroups[groupIndex]}&userId=${this.props.userInfo.id}`,
					{
						headers: {
							opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              lob: "Postpaid",
              Authorization: "Bearer " + this.props.userInfo.jwt,
							
						},
					}
				)
				.then((res) => {
					const myItems = [];
					res.data.data.map((element) => {
						const obj = {};
						obj.releaseCreationDate = element.createdOn;
						obj.releaseId = element.releaseid;
						obj.releaseStatus = element.releaseStatus;
						obj.releaseObjective = element.remarks;
						obj.createdBy = "";
						obj.externalReleaseId = element.extrnReleaseId;
						obj.selfAssign = "";
						myItems.push(obj);
					});
					if (this._isMounted) {
						this.setState({
							dataMyItems: [...this.state.dataMyItems, ...myItems],
						});
					}
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else return Promise.resolve();
	}

	async componentDidMount() {
		this._isMounted = true;

		await this.approversDataHandler();
		axios
			.get("/b2b-workflow/role-mapping", {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,
					authUserId:this.props.userInfo.id,
					authGroupId:this.props.userInfo.group[0],
					//lob: "Postpaid",
					Authorization: "Bearer " + this.props.userInfo.jwt,
				},
			})
			.then((res) => {
				console.log(res);
				let approverData = res.data.data;
				approverData = {
					...approverData,
					//["b2bsales"]: "Product Manager",
				};
				let approverDataRev = {};

				Object.keys(approverData).map((key) => {
					approverDataRev[approverData[key]] = key;
				});
				this.setState(
					{
						approverDataRev: approverDataRev,
						approversData: approverData,
						userGroups: this.props.userInfo.group,
						selGrp: approverData[this.props.userInfo.group[0]]
							? approverData[this.props.userInfo.group[0]]
							: this.props.userInfo.group[0],
					},
					() => {
						this.props.onReleaseExit();
						
							this.teamItemsHandler().then(() => {
								this.myItemsHandler().then(() => {
									//this.myItemsFederateHandler().then(() => {
										
										let columnsMyItems = [...this.state.columnsMyItems];
										//columnsMyItems.push(newCol);
										this.setState({
											columnsMyItems: columnsMyItems,
											
										});
										console.log('colI',this.state.columnsMyItems)
									//});
								});
							});
		
						this.setState({ loading: false });
					}
				);
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	}

	attachmentHandler = (rowData) => {
		console.log(rowData);
		this.setState({ relData: { ...rowData } });
		this.setState({ attachment: true });
	};
	showAttachmentHandler = () => {
		this.setState({ attachment: false });
	};

	showFederationHandler = () => {
		this.setState({ federate: false });
	};

	userRoleHandler = async (event) => {
		const value = event.target?.value ?? event;
		this.setState({
			loading: true,
		});
		await this.approversDataHandler();
		this.myItemsHandler(value).then(() => {
			this.teamItemsHandler(value).then(() => {
				this.myItemsFederateHandler(value).then(() => {
					this.setState({
						userRole: value,
						loading: false,
					});
				});
			});
		});
	};

	approversDataHandler() {
		console.log("fetching approvers for worklist from api");
		const opId = this.props?.userInfo?.opId ?? this.userInfo.opId;
		const buId = this.props?.userInfo?.buId ?? this.userInfo.buId;
		const authUserId = this.props?.userInfo?.id ?? this.userInfo.id;
		const Authorization = this.props?.userInfo?.jwt ?? this.userInfo.jwt;
		const role = this.state.userRole.slice(
			this.state.userRole.length - 3,
			this.state.userRole.length
		);
		return axios
			.get(process.env.REACT_APP_URL + "WorkflowAuthentication/approverUser", {
				headers: {
					opId: opId,
					buId: buId,
					role: role,
					lob: "Postpaid",
					authUserId: authUserId,
					Authorization: "Bearer " + Authorization,
					user: this.state.userRole,
				},
			})
			.then((res) => {
				Object.keys(res.data.data).map(
					(str) => {
						res.data.data[str].map(
							(role) => {
								localStorage.setItem("approversDataUser", JSON.stringify(role));
							},
							[this]
						);
					},
					[this]
				);
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	}

	render() {
		const { classes } = this.props;

		let worklist = (
			<React.Fragment>
				{this.props.userInfo.group.length > 1 &&
				!this.props.hasSelectedService &&
				(!sessionStorage.getItem("hasSelectedService") ||
					sessionStorage.getItem("hasSelectedService") === "false") ? (
					<Card>
						<CardContent>
							<div style={{ textAlign: "center" }}>
								<h2>Select a role that you want to work on below</h2>
								<RadioGroup
									style={{ justifyContent: "center" }}
									row
									onChange={(event) => {
										this.setState({
											roleSelected: event.currentTarget.value,
										});
									}}>
									{this.props.userInfo.group.map((role) => {
										return (
											<FormControlLabel
												style={{
													marginInlineStart: "2rem",
													marginInlineEnd: "2rem",
												}}
												value={role}
												control={<Radio style={{ color: "#ff1921" }} />}
												label={role
													.slice(role.length - 3, role.length)
													.toUpperCase()}
												labelPlacement="end"
											/>
										);
									})}
								</RadioGroup>
								<Button
									onClick={async () => {
										await this.userRoleHandler(this.state.roleSelected);
										this.props.onRoleSelected(true);
										sessionStorage.setItem("hasSelectedService", true);
									}}
									variant="contained"
									disabled={!this.state.roleSelected}
									style={{
										marginTop: "20px",
										background: "#546D7A",
										color: "white",
										textTransform: "none",
									}}>
									Submit
								</Button>
							</div>
						</CardContent>
					</Card>
				) : null}
				{this.props.userInfo.group.length === 1 ||
				this.props.hasSelectedService ||
				sessionStorage.getItem("hasSelectedService") === "true" ? (
					<div>
						{this.props.userInfo.group.includes("b2bsales") ||
						this.props.userInfo.group.length < 2 ? null : (
							<span
								style={{
									display: "block",
									textAlign: "end",
									marginBottom: "1rem",
									marginRight: "1rem",
								}}>
								<FormControl style={{ width: "8rem", textAlign: "start" }}>
									<InputLabel>Role</InputLabel>
									<Select
										value={this.state.userRole}
										onChange={this.userRoleHandler}>
										{this.props.userInfo.group.map((role) => {
											return (
												<MenuItem value={role} key={role}>
													{role}
												</MenuItem>
											);
										})}
									</Select>
								</FormControl>
							</span>
						)}

						<Modal
							show={this.state.show}
							modalClosed={this.errorConfirmedHandler}
							title={"Something Went Wrong!"}>
							{this.state.modalContent}
						</Modal>

						<Backdrop className={classes.backdrop} open={this.state.openDrawer}>
							<Drawer
								className={classes.drawer}
								variant="persistent"
								anchor="right"
								open={this.state.openDrawer}
								classes={{
									paper: classes.drawerPaper,
								}}>
								<Toolbar>
									<IconButton
										edge="start"
										style={{
											position: "absolute",
											right: "0",
											marginRight: "2vw",
										}}
										onClick={() => {
											this.setState({
												openDrawer: false,
												relWorkFlowAction: "",
												relWorkRemarks: "",
											});
										}}>
										<CloseIcon />
									</IconButton>
								</Toolbar>
								{this.state.loadingEdit ? (
									<Loader />
								) : (
									<div style={{ marginLeft: "15px", marginRight: "2vw" }}>
										<div
											style={{
												width: "100%",
												height: "103vh",
												overflowY: "auto",
												overflowX: "hidden",
											}}>
											<Typography
												style={{
													marginTop: "10px",
													fontWeight: "600",
													fontSize: "18px",
													color: "#393939",
												}}>
												{this.state.releaseEditData.externalReleaseId}
											</Typography>
											<Typography
												style={{
													fontWeight: "600",
													fontSize: "12px",
													color: "#696969",
												}}>
												created on:
												{this.state.releaseEditData.createdAt}
											</Typography>

											<Typography
												style={{
													fontWeight: "550",
													fontSize: "16px",
													color: "#393939",
													marginTop: "15px",
												}}>
												Release Objective
											</Typography>
											<div
												style={{
													fontWeight: "600",
													fontSize: "14px",
													color: "#696969",
													marginTop: "5px",
													maxHeight: "15vh",
													overflow: "auto",
												}}>
												{this.state.releaseEditData.releaseObjective}
											</div>

											<form
												onSubmit={
													this.props.userInfo.group.includes("b2bsales")
														? this.actionHandlerPM
														: this.actionHandler
												}
												id="workFlowForm">
												<Grid
													container
													spacing={3}
													style={{ marginTop: "20px", display: "inline-flex" }}>
													<Grid item xs={12}>
														<Box>
															<span
																style={{
																	fontWeight: "600",
																	fontSize: "14px",
																	color: "#696969",
																}}>
																Action
															</span>
															<span
																style={{
																	color: "red",
																	marginLeft: "5px",
																}}>
																*
															</span>
														</Box>
														<Box mt={2}>
															<FormControl style={{ minWidth: "100%" }}>
																<Select
																	name="action"
																	MenuProps={MenuProps}
																	displayEmpty
																	value={this.state.relWorkFlowAction.replaceAll("_"," ")}
																	onChange={(event) =>
																		this.setState({
																			relWorkFlowAction: event.target.value,
																		})
																	}
																	input={<Input required={true} />}
																	renderValue={(selected) => {
																		if (selected) {
																			if (selected.length === 0) {
																				return <em>Action</em>;
																			}
																			return selected;
																		}
																	}}
																	inputProps={{
																		"aria-label": "Without label",
																	}}>
																	<MenuItem disabled value="">
																		<em>Action</em>
																	</MenuItem>
																	{ this.state.releaseEditData.actionList &&(this.state.releaseEditData.actionList.map((name) => (
																				<MenuItem key={name} value={name}>
																					{name.replaceAll("_"," ")}
																				</MenuItem>
																		  )))}
																		  

																</Select>
															</FormControl>
														</Box>
													</Grid>

													<Grid item xs={12}>
														<Box>
															<span
																style={{
																	fontWeight: "600",
																	fontSize: "14px",
																	color: "#696969",
																}}>
																Remarks
															</span>
															<span
																style={{
																	color: "red",
																	marginLeft: "5px",
																}}>
																*
															</span>
														</Box>
														<Box mt={2}>
															<TextField
																inputProps={{
																	maxLength: 255,
																}}
																placeholder="Remarks"
																onChange={(event) => {
																	this.setState({
																		relWorkRemarks: event.target.value,
																	});
																}}
																fullWidth
																value={this.state.relWorkRemarks}
																rows={2}
																rowsMax={5}
																multiline
																required={true}
																variant="outlined"
															/>
														</Box>
														<Box>
														<div
										style={{
											height: "17vh",
											width: "100%",
											background: "#FFFFFF",
											boxShadow: "0px 0px 4px rgba(0, 0, 0, 0.137156)",
											textAlign: "center",
										}}>
										<Button
											form="workFlowForm"
											type="submit"
											style={{
												color: "#0079FF",
												border: "1px solid #0079FF",
												marginTop: "3vh",
											}}
											color="info"
											variant="outlined">
											Submit
										</Button>
									</div>
														</Box>
													</Grid>
												</Grid>
											</form>
										</div>
									</div>
								)}
								
							</Drawer>
						</Backdrop>
						
						{this.props.userInfo.group.includes("b2bsales") ? (
							<ThemeProvider theme={theme}>
								<Title>Work Queue</Title>
								<Table
								clickable
									icons={tableIcons}
									title={"My Items"}
									columns={this.state.columnsMyItemsowner}
									data={this.state.dataMyItems}
									onRowClick={(event, rowData) => {
										console.log(rowData);
										
											this.setState({
												openDrawer: true,
												releaseEditData: rowData,
											});
									}}
									
									pageSize={5}
									fontSize={"14px"}
									// options={{
									// 	filtering: true,
									// 	pageSize: 10,
									// 	pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
									// 	toolbar: true,
									// 	paging: true,
									// 	rowStyle: {
									// 		fontSize: "14px",
									// 		// fontWeight: "600"
									// 	},
									// 	headerStyle: {
									// 		fontWeight: "bold",
									// 	},
									// }}
								/>
								{console.log('Draw',this.state.openDrawer)}
							</ThemeProvider>
						) : (
							<ThemeProvider theme={theme}>
								<Title>My Items</Title>
								<Table
								clickable
									icons={tableIcons}
									title={"My Items"}
									columns={this.state.userGroups.includes('b2bpm')?this.state.columnsMyItemspm
										:this.state.columnsMyItems}
									data={this.state.dataMyItems}
									onRowClick={(event, rowData) => {
										console.log(rowData);
										
											this.setState({
												openDrawer: true,
												releaseEditData: rowData,
											});
									}}
									pageSize={5}
									fontSize={"14px"}
									// options={{
									// 	filtering: true,
									// 	pageSize: 5,
									// 	pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
									// 	toolbar: true,
									// 	paging: true,
									// 	rowStyle: {
									// 		fontSize: "14px",
									// 		// fontWeight: "600"
									// 	},
									// 	headerStyle: {
									// 		fontWeight: "bold",
									// 	},
									// }}
								/>
							</ThemeProvider>
						)}

						{!this.props.userInfo.group.includes("b2bsales") ? (
							
							<div style={{ marginTop: "30px" }}>
								<div><Title>Team Items</Title></div>
								<Table
									title="Team Items"
									data={this.state.dataTeamItems}
									columns={
										this.state.userGroups.includes("b2bpm")
											? this.state.columnsTeamItemspm
											: this.state.columnsTeamItems
									}
									pageSize={5}
									fontSize={"14px"}
								/>
							</div>
						) : null}
						{this.state.federate ? (
							<Federation
								userInfo={this.props.userInfo}
								showFederation={this.showFederationHandler}
								releaseData={this.state.relData}
							/>
						) : null}

						{this.state.auditLogs ? (
							<AuditLogs
								showAuditLogs={this.showAuditLogsHandler}
								releaseData={this.state.relData}
							/>
						) : null}
						{this.state.attachment ? (
							<Attachment
								userInfo={this.props.userInfo}
								showAttachment={this.showAttachmentHandler}
								releaseData={this.state.relData}
								role={this.state.userGroups[0]}
								completeHandler={this.actionHandler}
							/>
						) : null}
					</div>
				) : null}
			</React.Fragment>
		);
		if (this.state.loading) worklist = <Loader />;
		return worklist;
	}
}

const mapStateToProps = (state) => {
	return {
		userInfo: state.login.loggedInUserInfo,
	};
};
const mapDispatchToProps = (dispatch) => {
	return {
		onReleaseExit: () =>
			dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
	};
};

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(WithErrorHandler(withStyles(useStyles)(Worklist), axios));
