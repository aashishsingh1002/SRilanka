import React, { Component } from 'react';
import ModalAction from '../../UI/ModalAction/ModalAction';
import Loader from '../../UI/Loader/Loader';
import genAxios from 'axios';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import SettingsSystemDaydreamIcon from '@material-ui/icons/SettingsSystemDaydream';
import VideoLabelIcon from '@material-ui/icons/VideoLabel';
import Box from '@material-ui/core/Box';
import Table from '../../UI/Table/TablePadded';
import ExportButton from './common/ExportButton';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import MaterialTable, { MTableToolbar } from '@material-table/core';
import { CustomPaginationComponent, TABLE_ICONS } from './common/table-config';
import { TABLE_CONFIG } from '../Dashboard/FederateModal';

const useStyles = (theme) => ({
  root: {
    width: '100%',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '65%',
    flexShrink: 0,
  },
  secondaryHeading: {
    fontSize: theme.typography.pxToRem(15),
  },
});

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

class Federate extends Component {
  _isMounted = false;

  state = {
    dealData: [],
    show: true,
    loading: false,
    federate: ['Siebel'],
    activeTab: 0,
    fedResponse: [],
    columns: [
      { title: 'Deal Id', field: 'dealId', sorting: false },
      { title: 'Status', field: 'status', sorting: false },
      { title: 'Overall Status', field: 'overallStatus', sorting: false },
      { title: 'Message', field: 'errorMessage', sorting: false },
    ],
  };

  modalCloseHandler = () => {
    this.setState({ show: false });
    this.props.showFederate();
  };

  componentWillUnmount() {
    this._isMounted = false;
  }
  getStatusData() {
    this.setState({
      loading: true,
    });
    return genAxios
      .get(
        process.env.REACT_APP_URL +
          'mtn/modification/statusdata?releaseId=' +
          this.props.releaseData.releaseId,
        {}
      )
      .then((res) => {
        if (res) {
          this.setState({
            dealData: res.data.data.map((row) => {
              return { ...row, tableData: '' };
            }),
          });
        }
        this.setState({
          loading: false,
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  fedStatusHandler = () => {
    this.setState({
      loading: true,
    });
    return genAxios
      .post(
        process.env.REACT_APP_URL +
          'mtn/modification/dealsstatus?releaseId=' +
          this.props.releaseData.releaseId,
        {}
      )
      .then((res) => {
        this.getStatusData();
        console.log(res);
        if (res) {
          this.setState({
            fedResponse: res.data.data || [],
          });
        }
        this.setState({
          activeTab: 1,
          loading: false,
        });
      })
      .catch((error) => {
        console.log(error);
        this.setState({
          loading: false,
        });
      });
  };
  componentDidMount() {
    this._isMounted = true;
  }

  handleToggle = (value) => () => {
    const currentIndex = this.state.federate.indexOf(value);
    const newFederate = [...this.state.federate];

    if (currentIndex === -1) {
      newFederate.push(value);
    } else {
      newFederate.splice(currentIndex, 1);
    }
    this.setState({
      federate: newFederate,
    });
  };

  siebelFederation = () => {
    if (this.state.federate.includes('Siebel')) {
      const businessId = this.props.userInfo.group.includes('CBU')
        ? 'CBU'
        : 'EBU'; //TODO: CHANGE TO CBU OR EBU BASED ON GROUP

      return genAxios
        .post(
          process.env.REACT_APP_URL +
            'mtn/modification/dealsinsert?releaseId=' +
            this.props.releaseData.releaseId +
            '&businessId=' +
            businessId,
          {}
        )
        .then((res) => {
          if (res.data.statusMsg !== 'FAILURE') {
            this.getStatusData();
            this.fedStatusHandler();
            console.log(res);
            this.setState({
              activeTab: 1,
            });
          }
        })
        .catch((error) => {
          console.log(error);
          this.setState({
            activeTab: 1,
          });
        });
    } else return Promise.resolve();
  };

  federationHandler = () => {
    if (this.state.federate.length > 0) {
      this.setState({ loading: true });
      this.siebelFederation().then(() => {
        this.setState({
          loading: false,
        });
      });
    }
  };
  statusHanler = () => {
    this.fedStatusHandler();
    this.setState({ activeTab: 1 });
  };

  render() {
    // const { classes } = this.props;
    let federate = (
      <ModalAction
        show={this.state.show}
        modalClosed={this.modalCloseHandler}
        actionText={'Federate'}
        size='md'
        title={'Release Id ' + this.props.releaseData.releaseId}
        action={this.federationHandler}
      >
        {this.state.loading ? (
          <div style={{ minHeight: '35vh' }}>
            <Loader />
          </div>
        ) : (
          <div>
            {/* <Paper square style={{ minHeight: "35vh" }}> */}
            {/* <Tabs
              value={this.state.activeTab}
              onChange={(event, newValue) => {
                if (newValue === 1) {
                  this.fedStatusHandler();
                } else
                  this.setState({
                    activeTab: newValue,
                  });
              }}
              variant="fullWidth"
              indicatorColor="white"
              textColor="primary"
            >
              <Tab icon={<SettingsSystemDaydreamIcon />} label="Federation" />
              <Tab icon={<VideoLabelIcon />} label="Status" />
            </Tabs>
             */}

            <div
              style={{
                background: '#fff',
                marginBottom: '24px',
                maxWidth: '600px',
                borderRadius: '50px',
                padding: '4px',
              }}
            >
              {/* <AppBar position="static"> */}
              <div
                style={{
                  display: 'flex',
                  textAlign: 'center',
                  fontWeight: '600',
                }}
              >
                <div
                  style={{
                    flexBasis: '50%',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                  onClick={() => this.setState({ activeTab: 0 })} //this.fedStatusHandler();
                >
                  <div
                    style={
                      this.state.activeTab === 0
                        ? {
                            background: '#ffc800',
                            padding: '8px',
                            borderRadius: '50px',
                            width: '100%',
                          }
                        : {}
                    }
                  >
                    Federation Status
                  </div>
                </div>
                <div
                  style={{
                    flexBasis: '50%',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                  // onClick={() => {
                  //   //  fedStatusHandler();
                  //   // handleChangeTab(1);
                  // }}
                  onClick={this.statusHanler}
                >
                  <div
                    style={
                      this.state.activeTab === 1
                        ? {
                            background: '#ffc800',
                            padding: '8px',
                            borderRadius: '50px',
                            width: '100%',
                          }
                        : {}
                    }
                  >
                    Status Details
                  </div>
                </div>
              </div>
            </div>

            <TabPanel value={this.state.activeTab} index={0}>
              <List>
                <ListItem
                  dense
                  button
                  // onClick={this.handleToggle("Siebel")}
                >
                  {/* <ListItemIcon>
                    <Checkbox
                      edge="start"
                      checked={this.state.federate.indexOf("Siebel") !== -1}
                      tabIndex={-1}
                      disableRipple
                      disabled
                      style={{ color: "#ff1921" }}
                    />
                  </ListItemIcon> */}
                  <ListItemText primary={'Siebel'} />
                </ListItem>
              </List>
            </TabPanel>

            <TabPanel value={this.state.activeTab} index={1}>
              <MaterialTable
                pageSize={7}
                title=''
                data={this.state.dealData}
                columns={this.state.columns}
                options={(TABLE_CONFIG, { selection: false, showTitle: false })}
                icons={TABLE_ICONS}
                actions={[
                  {
                    icon: () => (
                      <ExportButton
                        schema={this.state.columns.map((s) => ({
                          uiName: s.title,
                          refName: s.field,
                        }))}
                        name={'Federation Status'}
                        data={this.state.dealData}
                      />
                    ),
                    isFreeAction: true,
                  },
                ]}
                components={{
                  Toolbar: (props) => (
                    <div>
                      <div
                        style={{
                          fontSize: '18px',
                          fontWeight: '600',
                          marginLeft: '24px',
                        }}
                      >
                        {props.title}
                      </div>
                      <div>
                        <MTableToolbar {...props} />
                      </div>
                    </div>
                  ),
                  Pagination: (props) => {
                    return <CustomPaginationComponent {...props} />;
                  },
                }}
                localization={{
                  body: {
                    emptyDataSourceMessage: '',
                  },
                }}
              />
            </TabPanel>
            {/* </Paper> */}
          </div>
        )}
      </ModalAction>
    );

    return federate;
  }
}

export default withStyles(useStyles)(WithErrorHandler(Federate, genAxios));
