import React  from 'react';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import CardActions from '@material-ui/core/CardActions';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import TextField from '@material-ui/core/TextField';
import Loader from '../../UI/Loader/Loader';
import { connect } from 'react-redux';
import * as actionTypes from '../../store/actions/actionTypes';
import Popover from '@material-ui/core/Popover';
import moment from "moment";

const useStyles = makeStyles((theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    boldText: {
        // fontWeight: 'bold'
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    btn: {
        textTransform: 'unset !important'
    }

}));


const BasicDetails = (props)=>{
    const classes = useStyles();
    const [remarks, setRemarks] = React.useState(props.releaseData.remarks);
    const [loading, setLoading] = React.useState(false);
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [anchorElDeploy, setAnchorElDeploy] = React.useState(null);

   
    const remarksChangeHandler = (event) => {
        setRemarks(event.target.value);
    };
    const submitBasicDetailsHandler = ()=>{
        console.log(props.userInfo.id)
        console.log(remarks)
        setLoading(true)
        axios
            .post("telemediaDashboard/myReleases/update", {
                releaseNbr: props.releaseData.releaseNbr,
                remarks: remarks,
                updatedBy: props.userInfo.id
            })
            .then( response => {
                console.log(response);
                props.onReleaseEnter({
                    ...props.releaseData,
                    remarks: remarks
                })
                setLoading(false)


            })
            .catch(error => {
                console.log(error);
            });

    }
    const cancelReleaseHandler = ()=> {
        setLoading(true)
        setAnchorEl(null)
        // axios
        //     .post('cancel/release?releaseId=' + props.releaseData.releaseId, {
        //     })
        //     .then(res => {
        //         console.log(res);
        //         props.onReleaseEnter({
        //             ...props.releaseData,
        //             releaseStatus: 'Cancelled'
        //         })
        //        setLoading(false)
        //     })
        //     .catch(error => {
        //         console.log(error);
        //     });
        console.log('cancel1')
        axios
            .post('telemediaCancel/release?releaseId=' + props.releaseData.releaseId, {
                "updatedBy": props.userInfo.opId,
                "updatedDate": moment().format("DD-MMM-YY")
            })
            .then(res => {
                console.log(res);
                if (props.releaseData.pendingWith !== 'WorkFlow Not Initiated') {
                    console.log('cancel2')

                    axios
                        .post('Telecustom/cancelTask?releaseId=' + props.releaseData.releaseId, {
                        })
                        .then(res => {
                            console.log(res);
                            props.onReleaseEnter({
                                ...props.releaseData,
                                releaseStatus: 'Cancelled'
                            })
                            setLoading(false)
                        })
                        .catch(error => {
                            console.log(error);
                                setLoading(false)
                        });
                }
                else {
                    props.onReleaseEnter({
                        ...props.releaseData,
                        releaseStatus: 'Cancelled'
                    })
                    setLoading(false)

                }
            })

            .catch(error => {
                console.log(error);
                    setLoading(false)
            });
    }


    const deployReleaseHandler = () =>{
        setLoading(true)
        setAnchorElDeploy(null)
        console.log('deploy')
        axios
            .post(
                "telemediaDeploy/release?releaseId=" +
            props.releaseData.releaseId,{},
                {
                    headers: {
                        "updatedBy": props.userInfo.id,
                        "Content-Type": "application/json",
                        Accept: "application/json,text/plan,*/*",
                    }
                }
            )
            .then(res => {
                console.log(res);
                props.onReleaseEnter({
                    ...props.releaseData,
                    releaseStatus: 'Deployed'
                })
                setLoading(false)
               
            })
            .catch( error => {
                console.log(error);
                setLoading(false)
            });

    }
    const open = Boolean(anchorEl);
    const openDeploy = Boolean(anchorElDeploy);
    const id = open ? 'simple-popover' : undefined;
    const idDeploy = openDeploy ? 'simple-popover-pkg' : undefined;


    let basicDetails =
        <div >
                <Popover id={id} open={open} anchorEl={anchorEl}
                    onClose={() => {
                        setAnchorEl(null)
                    }}
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                    }}
                    transformOrigin={{
                        vertical: 'top',
                        horizontal: 'right',
                    }}
                >
                    <Card >
                        <CardHeader
                            className={classes.cardHeader}
                            classes={{
                                subheader: classes.subheader,
                            }}
                        subheader={'Do you want to cancel release ' + props.releaseData.externalReleaseId+' ?'}
                        />
                        <CardContent style={{ padding: '4px' }} >

                            <div style={{ marginTop: '10px', display: 'flex', justifyContent: 'flex-end' }}>
                                <Button size="small" color="primary" style={{
                                    textTransform: 'none'
                                }} onClick={() => {
                                    setAnchorEl(null)
                                }}>
                                    Close
                                  </Button>
                                <Button size="small" color="primary" style={{
                                    textTransform: 'none'
                                }} onClick={cancelReleaseHandler}>
                                    Ok
                                  </Button>
                            </div>
                        </CardContent>
                    </Card>
                </Popover>
            <Popover id={idDeploy} open={openDeploy} anchorEl={anchorElDeploy}
                    onClose={() => {
                        setAnchorElDeploy(null)
                    }}
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                    }}
                    transformOrigin={{
                        vertical: 'top',
                        horizontal: 'right',
                    }}
                >
                    <Card >
                        <CardHeader
                            className={classes.cardHeader}
                            classes={{
                                subheader: classes.subheader,
                            }}
                        subheader={'Do you want to deploy release ' + props.releaseData.externalReleaseId+' ?'}
                        />
                        <CardContent style={{ padding: '4px' }} >

                            <div style={{ marginTop: '10px', display: 'flex', justifyContent: 'flex-end' }}>
                                <Button size="small" color="primary" style={{
                                    textTransform: 'none'
                                }} onClick={() => {
                                    setAnchorElDeploy(null)
                                }}>
                                    Close
                                  </Button>
                                <Button size="small" color="primary" style={{
                                    textTransform: 'none'
                            }} onClick={deployReleaseHandler}>
                                    Ok
                                  </Button>
                            </div>
                        </CardContent>
                    </Card>
                </Popover>
          
            <Card style={{ minHeight: '35vh' }}>
                    <CardHeader
                        className={classes.cardHeader}
                        classes={{
                            subheader: classes.subheader,
                        }}
                    subheader={"You are inside release " + props.releaseData.externalReleaseId} />
                <div style={loading ? { display: 'none' } : { display: 'block' }}>

                    <CardContent>

                        <Grid container spacing={3}>

                <Grid item xs={12} md={3} >
                    <Box >
                        <span >Release Objective
        
                        </span>
                        <span style={{
                            marginLeft: '5px',

                        }}>(Max Length 2000)
                       </span>
                    </Box>
                    <Box mt={2} >
                        <TextField
                            inputProps={{
                                maxLength: 2000,
                            }}
                            fullWidth
                            value={remarks}
                            onChange={remarksChangeHandler}
                            // required={true}
                            placeholder="Release Objective"
                            rowsMin={4}
                            rowsMax={5}
                            multiline
                            variant='outlined'
                           />
                    </Box>
                    <span>Max Remaining: {2000 - remarks.length}</span>
                </Grid>
                            <Grid item xs={6} sm={3} md={2}>
                                <Box>
                                    <span className={classes.boldText} >Creation Date</span>
                                </Box>
                                <Box mt={2} >
                                    <span >{props.releaseData.createdOn}</span>
                                </Box> 
                                </Grid>
                            <Grid item xs={6} sm={3} md={2}>
                                <Box>
                                    <span className={classes.boldText}>Created By</span>
                                </Box>
                                <Box mt={2} >
                                    <span >{props.releaseData.createdBy}</span>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={3} md={2}>
                                <Box>
                                    <span className={classes.boldText}>Release Status</span>
                                </Box>
                                <Box mt={2} >
                                    <span >{props.releaseData.releaseStatus}</span>
                                </Box>
                            </Grid>

                        </Grid>

                    </CardContent>
                    <CardActions className={classes.center}>
            <Button variant="contained"
                style={{ background: '#02bfa0' }}
                 onClick={submitBasicDetailsHandler}
                className={classes.btn}
                disabled={props.releaseData.releaseStatus === "Cancelled" ||
                                props.releaseData.releaseStatus === "Deployed"} >
                                    Save
                        </Button>
            {/* <Button variant="contained"
                            disabled={props.releaseData.releaseStatus == "Cancelled" || 
                            props.releaseData.releaseStatus == "Deployed"}
                style={{ background: '#0273bf', color: 'white' }}
                            onClick={(event) => {
                                    setAnchorEl(event.currentTarget)                           
                            }}
                className={classes.btn}>
                            Cancel
                     </Button> */}
                    <Button variant="outlined" color="primary" 
                            onClick={(event) => {
                                setAnchorElDeploy(event.currentTarget)
                            }}
                className={classes.btn}
                variant="contained"
                disabled={props.releaseData.releaseStatus === "Cancelled" ||
                                props.releaseData.releaseStatus === "Deployed"}
                style={{
                    background: '#c46c08'
                   , color: 'white'
                }}>
                                    Deploy
                      </Button>
                       </CardActions>  
                        
        </div>
                {loading && <Loader relative />}

                   </Card>
        </div>



    return basicDetails

}

const mapStateToProps = state => {
    return {
        releaseData: state.releaseData.releaseData,
        userInfo: state.login.loggedInUserInfo,
    };
}

const mapDispatchToProps = dispatch => {
    return {
        onReleaseEnter: (releaseData) => dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: releaseData }),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(WithErrorHandler(BasicDetails, axios));

