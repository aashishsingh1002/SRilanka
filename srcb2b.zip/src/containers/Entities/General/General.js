import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import LoadingButton from "@mui/lab/LoadingButton";
import Grid from "@mui/material/Grid";
import moment from "moment";
import styled from "styled-components";

import GeneralField from "./GeneraField";
import { retrieveFields } from "./generalFunctions";

import useAPI from "../../../hooks/useAPI";
import Input from "../../../UI/Input/Input";
import axios from "axios";

const StyledButtonContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
`;

const StyledButton = styled(LoadingButton)`
  color: #fff;
  padding: 6px 50px;
  font-size: 16px;
  font-weight: 400;
  border-radius: 50px;
  text-transform: capitalize;
  background: rgb(93, 193, 127);
  font-family: "BrighterSans";
  &:hover {
    background: rgba(93, 193, 127, 0.8);
  }
`;

const General = () => {
  const releaseData = useSelector((state) => state.releaseData.releaseData);
  const userInfo = useSelector((state) => state.login.loggedInUserInfo);
  const productData = useSelector((state) => state.productData.productData);

  const detailsAPI = `product/basicDetails?productId=${productData.productId}&releaseID=${releaseData.releaseId}`;
  const [details, detailsLoading] = useAPI(detailsAPI);
  const [data, loading] = useAPI("config/cts");
  const [data2, loading2] = useAPI("config?entityName=product.basicDetails");
  const [formValues, setFormValues] = useState({});
  const [saving, setSaving] = useState(false);

  const parent = "productCategoryId";
  const fields = retrieveFields(data, parent);

  const onSelect = (key, value) => {
    setFormValues({ ...formValues, [key]: value });
  };

  useEffect(() => {
    if (details) {
      setFormValues(details);
    }
  }, [details]);

  const onSubmit = () => {
    setSaving(true);
    const payload = {
      releaseId: releaseData.releaseId,
      tcarePpmProductAud: {
        ...formValues,
        buId: userInfo.buId,
        opId: userInfo.opId,
        createdBy: userInfo.id,
        date: moment().format("DD-MMM-YY"),
        version: "1.0",
      },
    };

    // no id
    axios
      .post(process.env.REACT_APP_URL + "product/basicDetails", payload, {
        headers: { authUserId: userInfo.id },
      })
      .then((response) => {})
      .catch((error) => {});
  };

  if (detailsLoading || loading || loading2) {
    return "Loading...";
  }

  if (!data.length) return null;

  return (
    <div>
      <Grid container spacing={2}>
        {fields.map((field) => (
          <GeneralField
            key={field.entityName}
            field={field}
            onSelect={onSelect}
            filter={formValues[field.parentField]}
            noFilter={parent === field.entityName}
            disabled={saving}
          />
        ))}
        {data2.map((field) => (
          <Input
            {...field}
            value={formValues[field.refName]}
            key={field.refName}
            refLovs={field.refLovs ? field.refLovs.split(",") : []}
            disabled={field.isDisabled === "Y" || saving}
            required={field.isMandatory === "Y" || saving}
            checkChanged={(event) => {
              const checked = event.target.checked ? "Y" : "N";
              onSelect(field.refName, checked);
            }}
            changed={(event) => {
              const value = event.target ? event.target.value : event;
              onSelect(field.refName, value);
            }}
          />
        ))}
      </Grid>
      {releaseData.releaseId && (
        <StyledButtonContainer>
          <StyledButton loading={saving} onClick={() => onSubmit()}>
            Save
          </StyledButton>
        </StyledButtonContainer>
      )}
    </div>
  );
};

export default General;
