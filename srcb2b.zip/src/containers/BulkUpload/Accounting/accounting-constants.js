export const ENTITY_NAME = "accounting";
export const ACCOUNTING_GET_URL = "/mtn/deal/ref/accounting";
export const ACCOUNTING_POST_URL = "/mtn/deal/ref/storeaccounting";
