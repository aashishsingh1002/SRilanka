import * as actionTypes from '../actions/actionTypes';

const initialState = {
    productData: {},
    productKey: 'pro',
    activeStep: 0
};

const insideProduct = (state, action) => {
    return {
        ...state,
        productData: { ...action.productData },
    }
};

const changeProductKey = (state, action) => {
    let key = action.productKey.length > 10 ? 'pro' : action.productKey
    return {
        ...state,
        productKey: key,
    }
};

const changeProductActiveStep = (state, action) => {
    return {
        ...state,
        activeStep: action.activeStep,
    }
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.INSIDE_PRODUCT: return insideProduct(state, action);
        case actionTypes.CHANGE_PRODUCT_KEY: return changeProductKey(state, action);
        case actionTypes.CHANGE_PRODUCT_ACTIVE_STEP: return changeProductActiveStep(state, action);
        default:
            return state;
    }
};

export default reducer;
