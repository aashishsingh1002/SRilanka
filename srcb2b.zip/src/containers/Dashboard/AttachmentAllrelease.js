import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import { withStyles } from '@material-ui/core/styles';
import { createMuiTheme } from '@material-ui/core/styles';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import CustomTable from '../../UI/Table/TablePadded'
import Typography from '@material-ui/core/Typography';
import { connect } from 'react-redux';


const useStyles = (theme) => ({
    formControl: {
        margin: theme.spacing(1),
        minWidth: 250,
        maxWidth: 300,
    },
    center: {
        textAlign: 'center'
    },

});

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
        },
    },
};

const theme = createMuiTheme({
    overrides: {
        MuiTableCell: {
            root: {
                padding: '0px',
                paddingLeft: '10px'
            },
        },
    },
});


class Attachment extends Component {
    _isMounted = false;

    constructor(props) {
        super(props);
        this.state = {
            files: [],
            show: true,
            attachments: {},
            loading: true,
            downloadAttachments: [],
            columns: [
                {
                    title: "File", field: 'fileName', sorting: false, render: rowData =>
                        <span
                            onClick={() => this.downloadAttachmentHandler(rowData.fileName)}
                            style={{
                                cursor: 'pointer',
                                textDecoration: 'underline',
                                color: 'blue'
                            }}> {rowData.fileName}</span>, cellStyle: { width: '30%' }
                },
                {
                    title: "Role", field: 'role', sorting: false, render: rowData =>
                        <span style={{
                            display: 'block',
                            width: '10vw',
                            maxHeight: '100px',
                            overflow: 'auto',
                            wordWrap: 'break-word'
                        }}> {rowData.role}</span>, cellStyle: { width: '40%' }
                },
                { title: "Uploaded By", field: 'createdBy', sorting: false, cellStyle: { width: '15%' } },
                {
                    title: "Time", field: 'creationDate', sorting: false, cellStyle: { width: '15%' }
                }
            ],

        };
    }

    componentWillUnmount() {
        this._isMounted = false;
    }


    attachmentDataHandler = () => {
        let req = ''
        if (this.props.userInfo.group.includes("b2bsales")
            || this.props.userInfo.group.includes("WorkflowAdmin"))
            req = "/b2b-dashboard/attach/fileNames?releaseId=" +
                this.props.releaseData.releaseId
        else
            req =
                "/b2b-dashboard/attach/fileNames?releaseId=" +
                this.props.releaseData.releaseId +
                "&roleName=" +
                this.props.approversData[this.props.userInfo.group[0]]
        console.log(req)
        return axios
            .get(
                req,{headers:{buId: this.props.userInfo.buId,
                    opId: this.props.userInfo.opId,authGroupId:this.props.userInfo.group[0],Authorization: 'Bearer ' + this.props.userInfo.jwt}}
            )
            .then(res => {
                console.log("get files");
                console.log(res);
                if (this._isMounted) {
                    let data = [...res.data.data]
                    this.setState({ downloadAttachments: data })
                }
            })
            .catch(error => {
                console.log(error);
                if (this._isMounted) {
                    this.setState({ loading: false })
                }
            });
    }
    componentDidMount() {
        this._isMounted = true;
        this.attachmentDataHandler().then(() => {
            console.log(this.props.releaseData)

            this.setState({ loading: false })

        })

    }

    handleChange(files) {
        let fileNames = []
        files = [...files.filter((v, i, a) => a.findIndex(t => (t.name === v.name)) === i)]

        files.forEach(file => {
            fileNames.push(file.name)
        })
        let attachments = Object.keys(this.state.attachments)
        let difference = fileNames.filter(x => !attachments.includes(x));

        let newAttachments = {}
        difference.forEach(file => {
            newAttachments[file] = {
                value: 'All',
                roles: [],
                uploaded: false
            }
        })

        this.setState((prevState) => {
            return {
                files: files,
                attachments: { ...prevState.attachments, ...newAttachments }
            };
        });

    }
    handleChangeRole = (event, file) => {
        this.setState((prevState) => {
            return {
                attachments: {
                    ...prevState.attachments,
                    [file]: { roles: event.target.value, value: 'Specific Role', uploaded: false }
                }
            }
        });
        console.log('attachments',this.state.attachments)

    }
    handleAttachmentRoles = (event, file) => {
        this.setState((prevState) => {
            return {
                attachments: {
                    ...prevState.attachments,
                    [file]: { roles: [], value: event.target.value, uploaded: false }
                }
            }
        });
        console.log(this.state.attachments)
    }

    modalCloseHandler = () => {
        this.setState({ show: false })
        this.props.showAttachment()
    }

    saveAttachmentHandler = (file) => {

        let formData = new FormData();
        formData.append("file", file);
        formData.append("releaseId", this.props.releaseData.releaseId);
        formData.append("createdBy", this.props.userInfo.id);
        let selRole = null
        if (this.state.attachments[file.name]['value'] == "All") {
            formData.append("roleName", "All");
            selRole = "All"
        }
        else if (this.state.attachments[file.name]['roles'].length > 0) {

            let roles = this.state.attachments[file.name]['roles']
            console.log(roles)
            if (!roles.includes(this.props.userInfo.group) &&
                !this.props.userInfo.group.includes("WorkflowAdmin")) {
                roles.push(this.props.approversData[this.props.userInfo.group[0]])
            }
            formData.append("roleName", roles.join());
            selRole = roles.join()
            console.log(selRole)

        }
        else {
            formData.append("roleName", "All");
            selRole = "All"
        }
        console.log("formData");
        for (var pair of formData.entries()) {
            console.log(pair[0]);
            console.log(pair[1]);
        }
        axios
            .post("b2b-dashboard/attach/uploadFile", formData, {
                headers: {
                    "Content-Type": "multipart/form-data",
                    opId: this.props.userInfo.opId,
                    buId: this.props.userInfo.buId
                }
            })
            .then(response => {
                console.log(response)
                if (this._isMounted) {
                    this.setState((prevState) => {
                        return {
                            downloadAttachments: [
                                ...prevState.downloadAttachments,
                                {
                                    "releaseId": this.props.releaseData.releaseId,
                                    "createdBy": this.props.userInfo.id,
                                    "fileName": file.name,
                                    "role": selRole,
                                }
                            ]
                        }
                    });
                }

            })
            .catch(error => {
                console.log(error);

            });

        this.setState((prevState) => {
            return {
                attachments: {
                    ...prevState.attachments,
                    [file.name]: { ...prevState.attachments[file.name], uploaded: true }
                }
            }
        });

    }


    downloadAttachmentHandler = (attachment) => {

        axios
            .get(
                "telemediaAttach/downloadFile?fileName=" +
                attachment +
                "&releaseId=" +
                this.props.releaseData.releaseId,
                { responseType: "blob" }
            )
            .then(res => {

                console.log(res);
                var headers = res.headers;
                var blob = new Blob([res.data], {
                    type: headers["content-type"]
                });

                var link = document.createElement("a");
                link.href = window.URL.createObjectURL(blob);
                link.download = attachment;
                link.click();
            })
            .catch(error => {
                console.log(error);

            });

    }
    render() {
        const { classes } = this.props;
        let attachment = <React.Fragment>
            {this.state.downloadAttachments.length > 0 ?
                <div style={{ marginBottom: '2vh' }}>
                    <CustomTable pageSize={5} title='Attachments' data={this.state.downloadAttachments}
                        columns={this.state.columns} />
                </div> :
                < Typography variant="h6" className={classes.center} >
                    No Attachments Found</Typography >}

        </React.Fragment>
        return <Modal show={this.state.show} modalClosed={this.modalCloseHandler}
            title={"Release Id " + this.props.releaseData.externalReleaseId} size='md'>
            {this.state.loading ? <div style={{ minHeight: '30vh' }}> <Loader /> </div> : attachment}
        </Modal>
    }

}

const mapStateToProps = state => {
    return {
        approversData: state.approverData.approversData,
    };
}

export default withStyles(useStyles)(WithErrorHandler(connect(mapStateToProps)(Attachment), axios));