import React, { Component } from 'react';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import AddIcon from '@material-ui/icons/Add';
import LastPageIcon from '@material-ui/icons/LastPage';
import { connect } from 'react-redux';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../UI/Loader/Loader';
import Input from '../../UI/Input/Input';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import moment from "moment";



const LightTooltip = withStyles((theme) => ({
    tooltip: {
        backgroundColor: '#525354',
        color: 'white',
        boxShadow: theme.shadows[1],
        fontSize: 14,
    },
}))(Tooltip);


const useStyles = (theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    boldText: {
        // fontWeight: 'bold'
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '96%',
        flexShrink: 0,
    },

});

class ContractProfile extends Component {

    _isMounted = false;

    state = {
        version: '',
        loading: true,
        schema: [],
        contractProfileData: {},

    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidMount() {
        this._isMounted = true;
        this.versions().then(() => {
            this.uiFields().then(() => {
                this.state.schema.map(formElement => {
                    if (formElement.refType == 'Date')
                        this.setState({
                            [formElement.refName]: formElement.defaultValue ?
                                moment(formElement.defaultValue).format("DD-MMM-YY") : moment().format("DD-MMM-YY")
                        });
                    else if (formElement.refType == 'TextInput' || 'TextArea')
                        this.setState({
                            [formElement.refName]: formElement.defaultValue
                        });
                })
                this.setState({ loading: false })
            })
        })
    }

    backToRelease = () => {
        this.props.history.push('/editRelease')
    }

    versions() {
        return axios
            .get(
                "config/version?entityName=contractProfile",
                {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId
                    }
                }
            )
            .then(res => {
                if (this._isMounted)
                    this.setState({ version: res.data.data.version })

            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });
    }

    uiFields() {
        if (
            localStorage.getItem("contractProfile") &&
            localStorage.contractProfile_version &&
            localStorage.contractProfile_version == this.state.version
        ) {
            console.log("fetching from local storage");
            try {
                this.setState({ schema: JSON.parse(localStorage.getItem("contractProfile")) })

            } catch (e) {
                localStorage.removeItem("contracts");
            }
            return Promise.resolve();
        } else {
            console.log("fetching from api");
            return axios
                .get("config?entityName=contractProfile", {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId
                    }
                })
                .then(res => {
                    let schema = []
                    schema = res.data.data.map(function (el) {
                        if (el.refType == "SelectInput" || el.refType == "MultiSelect") {
                            if (el.refLovs != null) el.refLovs = el.refLovs.split(",");
                            else if (el.refLovs == null) el.refLovs = [];
                        }
                        return el;
                    });
                    if (this._isMounted)
                        this.setState({ schema: schema })
                    localStorage.setItem("contractProfile", JSON.stringify(schema));
                    localStorage.contractProfile_version = this.state.version;
                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });
        }
    }

    saveContractProfileHandler = (event) => {
        event.preventDefault();
        this.setState({ loading: true });
        let payload = {};
        let date = moment().format("DD-MMM-YY");
        let ppmContractProfileAud = {};
        if (Object.keys(this.state.contractProfileData).length > 0) {
            ppmContractProfileAud = { ...this.state.contractProfileData }
        }

        this.state.schema.map(formElement => {
            if (formElement.refType == 'Date')
                ppmContractProfileAud[formElement.refName] = moment(this.state[formElement.refName]).format("DD-MMM-YY");
            else if (formElement.refType == 'Checkbox')
                ppmContractProfileAud[formElement.refName] = this.state[formElement.refName] ? 'Y' : 'N'
            else if (formElement.refType == 'TextInput' || 'TextArea')
                ppmContractProfileAud[formElement.refName] = this.state[formElement.refName] ? this.state[formElement.refName].trim() : null
            else
                ppmContractProfileAud[formElement.refName] = this.state[formElement.refName]
        })

        ppmContractProfileAud.buId = this.props.userInfo.buId;
        ppmContractProfileAud.catalogId = "DEF_CATALOG";
        ppmContractProfileAud.datasetId = "PPM_ATTR_SET01";
        ppmContractProfileAud.opId = this.props.userInfo.opId;
        ppmContractProfileAud.createdBy = this.props.userInfo.id;
        ppmContractProfileAud.createdDate = date;
        payload.releaseId = this.props.releaseData.releaseId
        console.log(payload);
        if (!Object.keys(this.state.contractProfileData).length > 0) {
            payload.ppmContractProfileAud = ppmContractProfileAud;
            console.log("post request");
            axios
                .post("contractProfile/create", payload)
                .then(response => {
                    this.setState({ loading: false, contractProfileData: response.data.data });
                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });
        } else {
            console.log("put request");

            ppmContractProfileAud.contractProfileNbr = this.state.contractProfileData.productNbr;
            payload.ppmContractProfileAud = ppmContractProfileAud;

            axios
                .post("contractProfile/update", payload)
                .then(response => {
                    console.log(response);
                    this.setState({ loading: false, contractProfileData: response.data.data });

                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });
        }

    }

    render() {
        const { classes } = this.props;

        let contractProfile = <Card style={{ overflow: 'visible' }}>
            <CardHeader
                className={classes.cardHeader}
                classes={{
                    subheader: classes.subheader,
                }}
                action={
                    this.props.releaseData.releaseId &&
                    <React.Fragment>
                        <div>
                            <LightTooltip title='New Contract Profile' arrow>
                                <AddIcon onClick={() => {
                                    this.setState({
                                        contractProfileData: {}
                                    })

                                    this.state.schema.map(formElement => {
                                        if (formElement.refType == 'Date')
                                            this.setState({
                                                [formElement.refName]: formElement.defaultValue ?
                                                    moment(formElement.defaultValue).format("DD-MMM-YY") : moment().format("DD-MMM-YY")
                                            })
                                        else if (formElement.refType == 'Checkbox')
                                            this.setState({
                                                [formElement.refName]: 'N'
                                            })
                                        else if (formElement.refType == 'MultiSelect')
                                            this.setState({
                                                [formElement.refName]: []
                                            })
                                        else
                                            this.setState({
                                                [formElement.refName]: ''
                                            })
                                    })
                                }}
                                    style={{ color: 'white', marginRight: '10px', cursor: 'pointer' }} />
                            </LightTooltip>

                            <LightTooltip title='Back To Release' arrow>

                                <LastPageIcon onClick={this.backToRelease}
                                    style={{ color: 'white', cursor: 'pointer' }} />
                            </LightTooltip>

                        </div>
                    </React.Fragment>
                }
                subheader={this.props.releaseData.releaseId ? "Contract Profile You are inside release " + this.props.releaseData.releaseId : 'Contract Profile'} />

            <CardContent style={{ marginTop: '2%', marginBottom: '2%' }}>
                <form onSubmit={this.saveContractProfileHandler}>
                    <Grid container alignItems="flex-end" spacing={2}>
                        {this.state.schema.map(formElement => (
                            <Input
                                key={formElement.refName}
                                {...formElement}
                                disabled={formElement.isDisabled == 'Y' ? true : false}
                                required={formElement.isMandatory == 'Y' ? true : false}
                                value={this.state[formElement.refName]}
                                changed={(event) => {
                                    if (!event.target) {
                                        this.setState({
                                            [formElement.refName]:
                                                event
                                        })
                                    } else {
                                        if (event.target.type !== 'checkbox')
                                            this.setState({
                                                [formElement.refName]:
                                                    event.target.value
                                            })
                                        else this.setState({
                                            [formElement.refName]:
                                                event.target.checked
                                        })
                                    }
                                }}
                            />
                        ))}
                    </Grid>
                    {this.props.releaseData.releaseId && <div className={classes.center}>
                        <Button variant="outlined"
                            style={{
                                color: 'green', border: '1px solid green'
                                , marginTop: '3%'
                            }}
                            type='submit'
                        >
                            Save
                        </Button>
                    </div>}
                </form>
            </CardContent>
        </Card>

        if (this.state.loading)
            contractProfile = <Loader />

        return contractProfile;
    }


}


const mapStateToProps = state => {
    return {
        releaseData: state.releaseData.releaseData,
        userInfo: state.login.loggedInUserInfo,
    };
}



export default connect(mapStateToProps)(withStyles(useStyles)(WithErrorHandler(ContractProfile, axios)));


