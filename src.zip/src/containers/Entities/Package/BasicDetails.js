import React, { Component } from 'react';
import axios from '../../../axios-epc';
import Input from '../../../UI/Input/Input';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../../UI/Loader/Loader';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import moment from 'moment';
import { connect } from 'react-redux';
import * as actionTypes from '../../../store/actions/actionTypes';

const useStyles = () => ({
	center: {
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
	},
});

class BasicDetails extends Component {
	_isMounted = false;

	state = {
		basicDetailsFields: [],
		version: '',
		loading: true,
		postRequest: true,
	};

	componentWillUnmount() {
		this._isMounted = false;
	}
	componentDidMount() {
		this._isMounted = true;
		this.versions().then(() => {
			this.uiFields().then(() => {
				console.log(this.state.basicDetailsFields);
				this.state.basicDetailsFields.map((formElement) => {
					if (formElement.refType == 'Date')
						this.setState({
							[formElement.refName]: formElement.defaultValue
								? moment(formElement.defaultValue).format('DD-MMM-YY')
								: moment().format('DD-MMM-YY'),
						});
					else if (formElement.refType == 'TextInput' || 'TextArea')
						this.setState({
							[formElement.refName]: formElement.defaultValue,
						});
				});
				this.packageData().then(() => {
					this.setState({ loading: false });
				});
			});
		});
	}

	packageData() {
		if (this.props.packageData.packageId) {
			return axios
				.get(
					'package/basicDetails?packageId=' +
						this.props.packageData.packageId +
						'&releaseID=' +
						this.props.releaseData.releaseId,
					{
						headers: {
							createdBy: this.props.userInfo.id,
							opId: this.props.userInfo.opId,
						},
					}
				)
				.then((res) => {
					console.log('inside package');
					console.log(res);
					Object.keys(res.data.data).forEach((key) => {
						this.setState({ [key]: res.data.data[key] });
					});
					this.setState({ postRequest: false });
					this.props.onPackageEnter(res.data.data);
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else {
			return Promise.resolve();
		}
	}
	versions() {
		return axios
			.get('config/version?entityName=package.basicDetails', {
				headers: {
					opId: this.props.userInfo.opId,
					buId: this.props.userInfo.buId,
				},
			})
			.then((res) => {
				if (this._isMounted) this.setState({ version: res.data.data.version });
			})
			.catch((error) => {
				console.log(error);
				if (this._isMounted) this.setState({ loading: false });
			});
	}

	uiFields = () => {
		if (
			localStorage.getItem('packageBundle') &&
			localStorage.packageBundle_version &&
			localStorage.packageBundle_version == this.state.version
		) {
			console.log('fetching from local storage');
			try {
				this.setState({
					basicDetailsFields: JSON.parse(localStorage.getItem('packageBundle')),
				});
			} catch (e) {
				localStorage.removeItem('packageBundle');
			}
			return Promise.resolve();
		} else {
			console.log('fetching from api');

			return axios
				.get('config?entityName=package.basicDetails', {
					headers: {
						opId: this.props.userInfo.opId,
						buId: this.props.userInfo.buId,
					},
				})
				.then((res) => {
					let basicDetailsFields = [];
					basicDetailsFields = res.data.data.map(function (el) {
						if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
							if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
							else if (el.refLovs == null) el.refLovs = [];
						}
						return el;
					});
					if (this._isMounted)
						this.setState({ basicDetailsFields: basicDetailsFields });
					localStorage.setItem(
						'packageBundle',
						JSON.stringify(basicDetailsFields)
					);
					localStorage.packageBundle_version = this.state.version;
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	};

	savePkgDetailsHandler = (event) => {
		event.preventDefault();
		this.setState({ loading: true });
		let payload = {};
		let date = moment().format('DD-MMM-YY');
		let tcarePpmPackageAud = {};
		if (this.props.packageData.packageNbr) {
			tcarePpmPackageAud = { ...this.props.packageData };
		}
		this.state.basicDetailsFields.map((formElement) => {
			if (formElement.refType == 'Date')
				tcarePpmPackageAud[formElement.refName] = moment(
					this.state[formElement.refName]
				).format('DD-MMM-YY');
			else if (formElement.refType == 'Checkbox')
				tcarePpmPackageAud[formElement.refName] = this.state[
					formElement.refName
				]
					? 'Y'
					: 'N';
			else if (formElement.refType == 'TextInput' || 'TextArea')
				tcarePpmPackageAud[formElement.refName] = this.state[
					formElement.refName
				]
					? this.state[formElement.refName].trim()
					: null;
			else
				tcarePpmPackageAud[formElement.refName] =
					this.state[formElement.refName];
		});
		tcarePpmPackageAud.buId = this.props.userInfo.buId;
		tcarePpmPackageAud.opId = this.props.userInfo.opId;
		tcarePpmPackageAud.createdBy = this.props.userInfo.id;
		tcarePpmPackageAud.createdDate = date;

		if (this.state.postRequest) {
			tcarePpmPackageAud.version = '1.0';
			payload.tcarePpmPackageAud = tcarePpmPackageAud;
			payload.releaseId = this.props.releaseData.releaseId;
			console.log('post');
			console.log(payload);
			axios
				.post('package/basicDetails', payload)
				.then((response) => {
					console.log('pkgcreated');
					let pkgDetails = { ...response.data.data };
					this.props.onPackageEnter(pkgDetails);
					let searchItems = [
						response.data.data.packageId + '/' + response.data.data.packageDesc,
					].concat(this.props.searchItems);

					this.props.setSearchItems(searchItems);

					this.state.basicDetailsFields.map((formElement) => {
						this.setState({
							[formElement.refName]: response.data.data[formElement.refName],
						});
					});
					this.setState({ postRequest: false, loading: false });
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		} else {
			tcarePpmPackageAud.updatedDate = date;
			tcarePpmPackageAud.updatedBy = this.props.userInfo.id;
			tcarePpmPackageAud.packageNbr = this.props.packageData.packageNbr;
			payload.tcarePpmPackageAud = tcarePpmPackageAud;
			payload.releaseId = this.props.releaseData.releaseId;

			console.log(payload);
			axios
				.post('package/basicDetails/update', payload)
				.then((response) => {
					console.log(response);
					let pkgDetails = { ...response.data.data };
					this.setState({ loading: false });
					this.props.onPackageEnter(pkgDetails);
				})
				.catch((error) => {
					console.log(error);
					if (this._isMounted) this.setState({ loading: false });
				});
		}
	};

	render() {
		const { classes } = this.props;

		let basicDetails = (
			<form
				onSubmit={this.savePkgDetailsHandler}
				style={{ overflow: 'visible' }}>
				<Grid
					container
					alignContent="flex-start"
					spacing={2}
					style={{ overflow: 'visible' }}>
					{this.state.basicDetailsFields.map((formElement) => (
						<Input
							key={formElement.refName}
							{...formElement}
							disabled={formElement.isDisabled == 'Y' ? true : false}
							required={formElement.isMandatory == 'Y' ? true : false}
							value={this.state[formElement.refName]}
							changed={(event) => {
								if (!event.target) {
									this.setState({
										[formElement.refName]: event,
									});
								} else {
									if (event.target.type !== 'checkbox')
										this.setState({
											[formElement.refName]: event.target.value,
										});
									else
										this.setState({
											[formElement.refName]: event.target.checked,
										});
								}
							}}
						/>
					))}
				</Grid>
				{this.props.releaseData.releaseId && (
					<div className={classes.center}>
						<Button
							variant="outlined"
							style={{
								color: 'green',
								border: '1px solid green',
								marginTop: '3%',
							}}
							type="submit">
							Save
						</Button>
					</div>
				)}
			</form>
		);

		if (this.state.loading) basicDetails = <Loader />;
		return basicDetails;
	}
}

const mapStateToProps = (state) => {
	return {
		searchItems: state.searchData.searchItems,
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		onPackageEnter: (packageData) =>
			dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
		setSearchItems: (searchItems) =>
			dispatch({
				type: actionTypes.SET_SEARCH_ITEMS,
				searchItems: searchItems,
				entity: 'PACKAGE',
			}),
	};
};

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(BasicDetails, axios)));
