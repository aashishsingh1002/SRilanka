import React, { Component } from 'react';
import Modal from '../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from '@material-ui/lab/Alert';

function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
}

const WithErrorHandler = (WrappedComponent, axios) => {
    return class extends Component {
        state = {
            error: null,
            openSnack: false,
            message: '',
        }

       
        handleClose = (event, reason) => {
            if (reason === 'clickaway') {
                return;
            }
            this.setState({ openSnack: false })
        };


        componentWillMount() {

            this.reqInterceptor = axios.interceptors.request.use(req => {
                console.log('req')
                console.log(req)
                this.setState({ error: null });
                return req;
            });
            this.resInterceptor = axios.interceptors.response.use(res => {
                console.log(res)

                if (res.data.statusMsg === "FAILURE") {
                    let error = <React.Fragment>
                        <p><span style={{ fontWeight: 'bold' }}> Error Description: </span> {res.data.statusDescription + '.'}</p>
                        <p><span style={{ fontWeight: 'bold' }}> Api Details: </span> {res.config.url}</p>
                    </React.Fragment>
                    let obj = {
                        message: error
                    }
                    this.setState({ error: obj });
                }
                else if (res.data.statusMsg === "SUCCESS") {
                    console.log('success')
                    if (res.config.method === 'post') {
                        document.documentElement.scrollTop = 0;
                        this.setState({ openSnack: true, message: "Success" })
                    }
                    return res
                }
                else
                    return res
            }, error => {
                this.setState({ error: error });
            });
        }

        componentWillUnmount() {
            axios.interceptors.request.eject(this.reqInterceptor);
            axios.interceptors.response.eject(this.resInterceptor);
        }

        errorConfirmedHandler = () => {
            this.setState({ error: null });
        }

        render() {
            const vertical = 'top';
            const horizontal = 'center';
            return (
                <React.Fragment>
                   
                    <Snackbar anchorOrigin={{ vertical, horizontal }}
                        open={this.state.openSnack} autoHideDuration={3000} onClose={this.handleClose}>
                        <Alert onClose={this.handleClose} severity="success">
                            {this.state.message}
                        </Alert>
                    </Snackbar>
                    <Modal
                        show={this.state.error != null}
                        modalClosed={this.errorConfirmedHandler}
                        title={'Something Went Wrong!'}
                    >
                        {this.state.error ?
                            < Typography variant="h6"> {this.state.error.message}</Typography >
                            : null}
                    </Modal>
                    <WrappedComponent {...this.props} />
                </React.Fragment>
            );
        }
    }
}

export default WithErrorHandler;