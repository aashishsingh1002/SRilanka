import React from 'react';
import ExpansionPanel from '../../UI/ExpansionPanel/ExpansionPanel';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';


const PricingData = (props) => {
    return (
        <ExpansionPanel heading='Pricing'>
            {(props.pricing && props.pricing.length > 0) ?
                < List
                    component="nav"
                    aria-labelledby="nested-list-subheader"
                    style={{ width: '100%', maxHeight: '30vh', overflow: 'auto' }}
                >
                    <React.Fragment >
                        {props.pricing[0].rcPrice &&
                            <React.Fragment>
                                <ListItem >
                                    <ListItemText primary='RC' secondary={props.pricing[0].rcPrice} />
                                </ListItem>
                                <Divider />
                            </React.Fragment>}
                        {props.pricing[0].nrcPrice &&
                            <React.Fragment>
                                <ListItem >
                                    <ListItemText primary='NRC' secondary={props.pricing[0].nrcPrice} />
                                </ListItem>
                                <Divider />
                            </React.Fragment>}
                    </React.Fragment>


                </List>
                : null}
        </ExpansionPanel>


    );
}

export default PricingData;