import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import backgroundImage from "../../assests/images/background.jpg";
import Typography from "@material-ui/core/Typography";
import AccountCircle from "@material-ui/icons/AccountCircle";
import TextField from "@material-ui/core/TextField";
import Avatar from "@material-ui/core/Avatar";
import Button from "@material-ui/core/Button";
import Hidden from "@material-ui/core/Hidden";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import InputLabel from "@material-ui/core/InputLabel";
import InputAdornment from "@material-ui/core/InputAdornment";
import FormControl from "@material-ui/core/FormControl";
import IconButton from "@material-ui/core/IconButton";
import Input from "@material-ui/core/Input";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import axios from "../../axios-epc";
import Loader from "../../UI/Loader/Loader";
import WithErrorHandler from "../../HOC/WithErrorHandler/WithErrorHandler";
import { connect } from "react-redux";
import * as actionTypes from "../../store/actions/actionTypes";
import Modal from "../../UI/Modal/Modal";
import LanguageSwitcher from "../LanguageSwitcher/LanguageSwitcher";
import { Translate } from "react-redux-i18n";
import { store, persistor } from "../../store/store";
import {
  setLocale,
  loadTranslations,
  syncTranslationWithStore,
} from "react-redux-i18n";
import translations from "../../l10n/translations";
import genAxios from "axios";

const useStyles = (theme) => ({
  background: {
    height: "100vh",
    backgroundImage: "url(" + backgroundImage + ") ",
    backgroundSize: "auto 100%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    color: "white",
  },
  large: {
    width: theme.spacing(17),
    height: theme.spacing(17),
  },
  avatarColor: {
    color: "#fff",
    backgroundColor: "#546D7A",
  },
  center: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  iconColor: {
    color: "#546D7A",
  },
  AppBar: {
    backgroundColor: "#ff1921",
  },
});

class Login extends Component {
  _isMounted = false;

  state = {
    userName: "",
    password: "",
    showPassword: false,
    loading: false,
    show: false,
    modalContent: null,
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;

    syncTranslationWithStore(store);
    store.dispatch(loadTranslations(translations));
    store.dispatch(setLocale("en"));
    this.props.changeLocale("en");
  }
  valueChangeHandler = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };

  loginHandler = () => {
    this.setState({ loading: true });

    genAxios
      .post(process.env.REACT_APP_URL + "WorkflowAuthentication/login", {
        userName: this.state.userName,
        password: this.state.password,
      })
      .then((res) => {
        console.log(res);
        let obj = res.data.data;
        obj.id = this.state.userName;
        console.log(obj);
        console.log(obj.authenticated);

        if (obj.authenticated) {
          genAxios
            .get(
              process.env.REACT_APP_URL +
                "rest/identity/groups?userId=" +
                obj.id,
              {
                headers: {
                 // Authorization: 'Bearer ' + obj.jwt
                },
              }
            )
            .then((res) => {
              console.log(res);
              obj.group = [];
              if (res.data.groups.length > 0) {
                res.data.groups.filter((el) => {
                  console.log(el);
                  obj.group.push(el.id);
                });
              } else obj.group.push("b2bsales");
              console.log(obj);
              this.props.onLogin(obj);
              console.log(this.props);
              console.log(obj.group);
              axios
                .get("/b2b-workflow/role-mapping", {
                  headers: {
                    opId: obj.opId,
                    buId: obj.buId,
                   // Authorization: 'Bearer ' + this.props.userInfo.jwt
                    //lob: "Postpaid",
                    authGroupId: obj.group[0],
                    Authorization: 'Bearer ' + obj.jwt
                  },
                })
                .then((res) => {
                  console.log(res);
                  let approverData = res.data.data;
                  approverData = {
                    ...approverData,
                   // ["b2bsales"]: "Product Manager",
                  };
                  console.log(approverData);

                  this.setState({ loading: false, password: "" });
                  this.props.onApproversData(approverData);
                  if (obj.group.includes("b2bsales")) {
                    this.props.history.push("/");
                  } else this.props.history.push("/worklist");
                })
                .catch((error) => {
                  console.log(error);
                  if (this._isMounted) this.setState({ loading: false });
                });
              //  else if (obj.group.includes("Admin")) {
              //     this.setAdminLayout(true);
              //     this.$router.push("/AdminDashboard");
              // } else this.$router.push("/workItem");
            })
            .catch((error) => {
              console.log(error);
              if (this._isMounted)
                this.setState({ loading: false, password: "" });
            });
        } else {
          let modalContent = (
            <Typography variant="h6">
              {" "}
              Please check your credentials and try again.
            </Typography>
          );
          this.setState({
            modalContent: modalContent,
            show: true,
            loading: false,
            password: "",
          });
        }
      })

      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false, password: "" });
      });
  };
  clickShowPasswordHandler = () => {
    this.setState((prevState) => {
      return { showPassword: !prevState.showPassword };
    });
  };

  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };

  mouseDownPasswordHandler = (event) => {
    event.preventDefault();
  };
  render() {
    const { classes } = this.props;
    let loginPage = (
      <React.Fragment>
        <Modal
          show={this.state.show}
          modalClosed={this.errorConfirmedHandler}
          title={"Something Went Wrong!"}
        >
          {this.state.modalContent}
        </Modal>

        <Grid container>
          <Hidden smDown>
            <Grid item md={8} className={classes.background}>
              <Typography
                variant="h1"
                fontWeight="fontWeightBold"
                className={classes.heading}
              >
                HOBS PPMS
              </Typography>
            </Grid>
          </Hidden>

          <Hidden mdUp>
            <AppBar
              position="static"
              style={{ marginBottom: 100 }}
              className={classes.AppBar}
            >
              <Toolbar>
                <Typography variant="h6">HOBS PPMS</Typography>
              </Toolbar>
            </AppBar>
          </Hidden>
          <Grid item xs={12} md={4}>
            {/* <div style={{ marginTop: '1vh', marginRight: '2vh' }}>
                        <LanguageSwitcher />
                    </div> */}
            <Grid
              container
              className={classes.center}
              style={{ marginTop: "25vh" }}
            >
              <Grid item xs={4} sm={5}></Grid>
              <Grid item xs={7}>
                <Avatar
                  className={[classes.avatarColor, classes.large].join(" ")}
                >
                  <AccountCircle className={classes.large} />
                </Avatar>
              </Grid>
              <Grid container style={{ marginTop: 14 }}>
                <Grid item xs={1}></Grid>
                <Grid item xs={10}>
                  <TextField
                    label={<Translate value="loginPage.userName" />}
                    name="userName"
                    value={this.state.userName}
                    onChange={this.valueChangeHandler}
                    fullWidth
                  />
                </Grid>
              </Grid>

              <Grid container style={{ marginTop: 14 }}>
                <Grid item xs={1}></Grid>
                <Grid item xs={10}>
                  <FormControl style={{ width: "100%" }}>
                    <InputLabel htmlFor="standard-adornment-password">
                      {<Translate value="loginPage.password" />}
                    </InputLabel>
                    <Input
                      id="standard-adornment-password"
                      type={this.state.showPassword ? "text" : "password"}
                      value={this.state.Password}
                      onChange={this.valueChangeHandler}
                      name="password"
                      endAdornment={
                        <InputAdornment position="end">
                          <IconButton
                            aria-label="toggle password visibility"
                            onClick={this.clickShowPasswordHandler}
                            onMouseDown={this.mouseDownPasswordHandler}
                          >
                            {this.state.showPassword ? (
                              <Visibility />
                            ) : (
                              <VisibilityOff />
                            )}
                          </IconButton>
                        </InputAdornment>
                      }
                    />
                  </FormControl>
                </Grid>
              </Grid>
              <Grid container style={{ marginTop: 24 }}>
                <Grid item xs={9}></Grid>
                <Grid item xs={2}>
                  <Button
                    variant="outlined"
                    color="primary"
                    onClick={this.loginHandler}
                  >
                    {<Translate value="loginPage.login" />}
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </React.Fragment>
    );

    if (this.state.loading) loginPage = <Loader />;

    return loginPage;
  }
}

const mapDispatchToProps = (dispatch) => {
  
  return {
    onApproversData: (approversData) => {console.log('appdata',approversData); return dispatch({
      type: actionTypes.APPROVER_MAP,
      approversData: approversData,
    })},
     
    onLogin: (loggedInUserInfo) =>
      dispatch({
        type: actionTypes.LOGIN_SUCCESS,
        loggedInUserInfo: loggedInUserInfo,
      }),
    changeLocale: (locale) => dispatch(setLocale(locale)),
  };
};

export default connect(
  null,
  mapDispatchToProps
)(withStyles(useStyles)(withRouter(Login), axios));
