import * as actionTypes from "./actionTypes";

export function fetchDealCaptureDD(payload) {
  return { type: actionTypes.FETCH_DEAL_CAPTURE_DD_REQUEST, payload: payload };
}

export function selectView(payload) {
  return { type: actionTypes.SELECT_VIEW, payload: payload };
}

export function fetchSummaryGeneral(payload) {
  return { type: actionTypes.FETCH_GENERAL, payload: payload };
}

export function fetchSummaryBundle(payload) {
  return { type: actionTypes.FETCH_BUNDLE, payload: payload };
}

export function selectGroup(payload) {
  return { type: actionTypes.SELECT_GROUP, payload: payload };
}
