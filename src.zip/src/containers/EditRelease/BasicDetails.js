import React  from 'react';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import Grid from '@material-ui/core/Grid';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import Box from '@material-ui/core/Box';
import CardActions from '@material-ui/core/CardActions';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import TextField from '@material-ui/core/TextField';

const useStyles = makeStyles((theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    boldText: {
        // fontWeight: 'bold'
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },

}));


const BasicDetails = (props)=>{
    const classes = useStyles();
    const [remarks, setRemarks] = React.useState(props.releaseData.remarks);

    const remarksChangeHandler = (event) => {
        setRemarks(event.target.value);
    };
    const submitBasicDetailsHandler = ()=>{
        console.log(props.userInfo.id)
        console.log(remarks)
        axios
            .post("dashboard/myReleases/update", {
                releaseNbr: props.releaseData.releaseNbr,
                remarks: remarks,
                updatedBy: props.userInfo.id
            })
            .then( response => {
                console.log(response);
            })
            .catch(error => {
                console.log(error);
            });

    }
    const cancelReleaseHandler = ()=> {
        axios
            .post('cancel/release?releaseId=' + props.releaseData.releaseId, {
            })
            .then(res => {
                console.log(res);
             
            })
            .catch(error => {
                console.log(error);
            });
    }

    const deployReleaseHandler = () =>{
        axios
            .post(
                "deploy/release?releaseId=" +
            props.releaseData.releaseId,
                {
                    headers: {
                        "Content-Type": "application/json",
                        Accept: "application/json,text/plan,*/*"
                    }
                }
            )
            .then(res => {
                console.log(res);
               
            })
            .catch( error => {
                console.log(error);
            });

    }

    return  <Card >
                    <CardHeader
                        className={classes.cardHeader}
                        classes={{
                            subheader: classes.subheader,
                        }}
                        subheader={"You are inside ePCN " + props.releaseData.releaseId} />

                    <CardContent>
                        <Grid container spacing={3}>

                            {/* <Grid item xs={12} md={4}>
                                <Box>
                                    <span className={classes.boldText}>ePCN Objective</span>
                                </Box>
                                <Box mt={2} >
                                    <TextareaAutosize
                                        rowsMin={8}
                                        placeholder="ePCN Objective"
                                        style={{ width: '100%' }}
                                        name='remarks' value={remarks}
                                        onChange={remarksChangeHandler}  />;
                
                                </Box>
                            </Grid> */}

                <Grid item xs={12} md={3} >
                    <Box mt={2}>
                        <span style={{
                            fontWeight: 'bold'
                        }}>ePCN Objective
        
                        </span>
                        <span style={{
                            marginLeft: '5px',

                        }}>(Max Length 2000)
                       </span>
                    </Box>
                    <Box mt={2} >
                        <TextField
                            inputProps={{
                                maxLength: 2000,
                            }}
                            fullWidth
                            value={remarks}
                            onChange={remarksChangeHandler}
                            // required={true}
                            placeholder="ePCN Objective"
                            rowsMin={4}
                            rowsMax={5}
                            multiline
                            variant='outlined'
                           />
                    </Box>
                    <span>Max Remaining: {2000 - remarks.length}</span>
                </Grid>
                            <Grid item xs={6} sm={3} md={2}>
                                <Box>
                                    <span className={classes.boldText} >Creation Date</span>
                                </Box>
                                <Box mt={2} >
                                    <span >{props.releaseData.createdOn}</span>
                                </Box> 
                                </Grid>
                            <Grid item xs={6} sm={3} md={2}>
                                <Box>
                                    <span className={classes.boldText}>Created By</span>
                                </Box>
                                <Box mt={2} >
                                    <span >{props.releaseData.createdBy}</span>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={3} md={2}>
                                <Box>
                                    <span className={classes.boldText}>ePCN Status</span>
                                </Box>
                                <Box mt={2} >
                                    <span >{props.releaseData.releaseStatus}</span>
                                </Box>
                            </Grid>

                        </Grid>
                        
                    </CardContent>
                    <CardActions className={classes.center}>
                        <Button variant="outlined" 
                        style={{color:'green',border:'1px solid green'}}
                        onClick={submitBasicDetailsHandler} >
                                    Save
                        </Button>
                    <Button variant="outlined" color="secondary"
                onClick={cancelReleaseHandler}>
                            Cancel
                     </Button>
                    <Button variant="outlined" color="primary" 
                    onClick={deployReleaseHandler}>
                                    Deploy
                      </Button>
                       </CardActions>  
                        
                    
                   </Card>

}

export default WithErrorHandler(BasicDetails,axios);
