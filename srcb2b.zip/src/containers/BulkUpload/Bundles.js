import React, { Component } from 'react';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import Loader from '../../UI/Loader/Loader';
import MaterialTable, { MTableToolbar } from '@material-table/core';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import moment from 'moment';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import Upload from './CustomUpload';
import ExportButton from './common/ExportButton';
import { CustomPaginationComponent } from './common/table-config';
import GetAppIcon from '@material-ui/icons/GetApp';
import { saveAsExcel } from './common/utils';
import ButtonNew from '../../UI/Button/Button';
import { objAppendOnUpdate } from '../../helpers/functions';
import Snackbar from '../../UI/Snackbar/Snackbar';
import { Autocomplete } from '@material-ui/lab';

const tableIcons = {
  Add: forwardRef((props, ref) => (
    <ButtonNew {...props} ref={ref} style={{ padding: '6px 32px' }}>
      Add
    </ButtonNew>
  )),
  // Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const theme = createMuiTheme({
  overrides: {
    MuiTableCell: {
      root: {
        padding: '0px',
        paddingLeft: '10px',
      },
    },
    MuiPaper: {
      width: '100%',
    },
    MuiInputBase: {
      input: {
        fontSize: 14,
      },
    },
  },
});
const noneditable = (rowData) => {
  if (rowData.refName === 'bundle') {
    return 'onAdd';
  }
  return 'always';
};
const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4.5vh',
  },
  subheader: {
    color: 'white',
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
});

class Bundles extends Component {
  constructor(props) {
    super(props);
    this.selectTable = React.createRef();
  }

  _isMounted = false;

  state = {
    loading: true,
    bundleData: [],
    version: '',
    schema: [],
    columns: [],
    uploadModal: false,
    selectedRows: [],
    openSnack: false,
    messageSnack: '',
  };
  checkKeyDown(refName) {
    if (refName === 'subsidy') {
      return true;
    }
    if (refName === 'rate') {
      return true;
    }
    return false;
  }
  valueCheck(val) {
    if (val < 0) {
      return 0;
    }
    return val;
  }
  typeCheck(refName) {
    if (refName === 'units') {
      return 'number';
    }
    if (refName === 'rate') {
      return 'number';
    }
    if (refName === 'rate') {
      return 'number';
    }
    if (refName === 'subsidy') {
      return 'number';
    }
    if (refName === 'actRate') {
      return 'number';
    }
    if (refName === 'actCost') {
      return 'number';
    }
    if (refName === 'subsidy2') {
      return 'number';
    }
    if (refName === 'rate3') {
      return 'number';
    }
    if (refName === 'actRate5') {
      return 'number';
    }
    if (refName === 'actCost6') {
      return 'number';
    }
    if (refName === 'units7') {
      return 'number';
    }
    if (refName === 'exclVat') {
      return 'number';
    }
    if (refName === 'inclVat') {
      return 'number';
    }
  }
  validation(rowData) {
    console.log(rowData);

    if (!rowData.bundle) {
      return false;
    }

    return '';
  }
  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    this.versions().then(() => {
      this.uiFields().then(() => {
        this.getBundleData().then(() => {
          let columns = this.state.schema.map((row) => {
            return {
              title: row.uiName,
              field: row.refName,
              validate: this.validation,
              sorting: false,
              cellStyle: { width: '20%' },
              editable: noneditable(row),
              render: (rowData) => {
                return (
                  row.refName &&
                  rowData[row.refName] && (
                    <span
                      style={{
                        display: 'block',
                        width: row.maxLength ? row.maxLength + 'vw' : '15vw',
                      }}
                    >
                      {' '}
                      {rowData[row.refName]}
                    </span>
                  )
                );
              },
              editComponent: (props) => {
                let isRequired = false;

                if (row.refName === 'activeFlag') {
                  if (!row.refLovs) return '';
                  const isSelectRequired = !props.value;
                  return (
                    <FormControl error={isSelectRequired}>
                      <Autocomplete
                        defaultValue={props.value}
                        style={{ width: '10vw' }}
                        options={row.refLovs}
                        renderInput={(params) => <TextField {...params} />}
                        onChange={(event, value) => {
                          props.onChange(value);
                        }}
                      />
                      {isSelectRequired && (
                        <FormHelperText>Required</FormHelperText>
                      )}
                    </FormControl>
                  );
                }

                if (
                  ['device1Reference', 'device2Reference'].includes(row.refName)
                ) {
                  const isSelectRequired = !props.value;
                  return (
                    <FormControl error={isSelectRequired}>
                      <Autocomplete
                        style={{ width: '10vw', fontSize: '30px' }}
                        options={this.props.dropdowns.devnumber.map((q) => {
                          return q.deviceNumber;
                        })}
                        renderInput={(params) => <TextField {...params} />}
                        onChange={(event, value) => {
                          props.onChange(value);
                        }}
                      />
                      {isSelectRequired && (
                        <FormHelperText>Required</FormHelperText>
                      )}
                    </FormControl>
                  );
                }

                if (['bundle'].includes(row.refName)) {
                  isRequired = true;
                }

                if (['activeFlag'].includes(row.refName)) {
                  isRequired = true;
                }

                return (
                  <TextField
                    error={isRequired && !props.value}
                    helperText={isRequired && !props.value && 'Required'}
                    type={this.typeCheck(row.refName)}
                    onKeyDown={(e) =>
                      this.checkKeyDown(row.refName)
                        ? ['+', '-'].includes(e.key) && e.preventDefault()
                        : ''
                    }
                    style={{
                      width: '20vw',
                      margin: 10,
                      fontSize: 12,
                    }}
                    fullWidth
                    value={this.valueCheck(props.value)}
                    onChange={(event) => {
                      props.onChange(event.target.value);
                    }}
                  />
                );
              },
            };
          });
          console.log(columns);
          this.setState({ columns, loading: false });
        });
      });
    });
  }

  versions() {
    return axios
      .get('config/version?entityName=bulkUploadBundles', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields() {
    if (
      localStorage.getItem('bulkUploadBundles') &&
      localStorage.bulkUploadBundles_version &&
      localStorage.bulkUploadBundles_version === this.state.version
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem('bulkUploadBundles')),
        });
      } catch (e) {
        localStorage.removeItem('bulkUploadBundles');
      }
      return Promise.resolve();
    } else {
      console.log('fetching from api');
      return axios
        .get('config?entityName=bulkUploadBundles', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          let schema = [];
          schema = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted) this.setState({ schema: schema });
          localStorage.setItem('bulkUploadBundles', JSON.stringify(schema));
          localStorage.bulkUploadBundles_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  getBundleData() {
    return axios
      .get('mtn/deal/ref/bundle')
      .then((res) => {
        console.log(res);
        if (res) {
          this.setState({
            bundleData: res.data.data.map((row) => {
              return { ...row, tableData: '' };
            }),
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  render() {
    const { classes } = this.props;
    const createdByuser =
      'mtn/deal/ref/uploadbundles?createdBy=' + this.props.userInfo.id;
    let bundles = (
      <div
        style={{
          margin: '0 auto',
          width: this.props.openDrawer
            ? `calc(100vw - 343px)`
            : 'calc(100vw - 141px)',
        }}
      >
        <Snackbar
          open={this.state.openSnack}
          message={this.state.messageSnack}
          onClose={(event, reason) => {
            if (reason === 'clickaway') {
              return;
            }
            this.setState({ openSnack: false });
          }}
        />
        {/* <Grid container spacing={10} style={{ marginBottom: '1px' }}>

                <Grid item md={3}>
                    < FormControl style={{ minWidth: '100%', float: 'right' }}>
                        <InputLabel >No of Rows</InputLabel>
                        <Select
                            labelId='No of Rows'
                            name='No of Rows'
                            value={this.state.noOfRows}
                            onChange={(event) => {
                                this.setState({
                                    noOfRows: event.target.value
                                })
                            }}
                            input={<Input />}
                            renderValue={(selected) => {
                                if (selected) {
                                    if (selected.length === 0) {
                                        return <em>No of Rows</em>;
                                    }

                                    return selected

                                }
                            }}
                            inputProps={{ 'aria-label': 'Without label' }}
                        >
                            <MenuItem disabled value="">
                                <em>No of Rows</em>
                            </MenuItem>
                            {[1, 2, 3, 4].map((name) => (
                                <MenuItem key={name} value={name} >
                                    {name}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item md={3}>
                    <Button
                        variant="contained"
                        style={{ background: '#02bfa0', color: 'white', marginTop: '10px' }}
                        className={classes.btn}
                        onClick={() => {
                            if (this.state.noOfRows) {
                                let bundleData = [...this.state.bundleData]
                                for (let cnt = 0; cnt < Number(this.state.noOfRows); cnt++) {
                                    bundleData.unshift({})
                                }
                                this.setState({
                                    bundleData,
                                    noOfRows: null
                                })
                            }
                        }}>
                        Add
                        </Button>
                </Grid>
            </Grid> */}

        {this.state.uploadModal && (
          <Upload
            uploadUrl={createdByuser}
            title='Bundles'
            worksheetName='XMtnDcBundlesTab'
            fileName='Bundles'
            schema={this.state.schema}
            loadData={() => {
              this.setState({
                loadingTable: true,
              });
              this.getBundleData().then(() => {
                this.setState({
                  loadingTable: false,
                  openSnack: true,
                  messageSnack:
                    'Data being Uploaded, Please Check the Validation Logs for Completion and Errors.',
                });
              });
            }}
            show={this.state.uploadModal}
            showUpload={() => {
              this.setState({
                uploadModal: false,
              });
            }}
          />
        )}

        <ThemeProvider theme={theme}>
          <div
            style={{ padding: '20px 0', fontSize: '24px', fontWeight: '600' }}
          ></div>
          <MaterialTable
            style={{ padding: '20px' }}
            tableRef={this.selectTable}
            isLoading={this.state.loadingTable}
            icons={tableIcons}
            title={'Bundles'}
            columns={this.state.columns}
            data={this.state.bundleData}
            actions={[
              {
                tooltip: 'Export',
                icon: GetAppIcon,
                onClick: () => {
                  saveAsExcel({
                    schema: this.state.schema,
                    name: 'Bundles',
                    data: this.state.selectedRows,
                  });
                },
              },

              {
                icon: () => (
                  <Button
                    variant='contained'
                    style={{
                      textTransform: 'capitalize',
                      background: '#ffcc00',
                      // border: "2px solid #ffcc00",
                      letterSpacing: '-1px',
                      fontWeight: '600',
                      color: '#000',
                      fontSize: '16px',
                      borderRadius: '50px',
                      padding: '6px 32px',
                      '&:hover': {
                        opacity: 0.8,
                        background: '#ffcc00',
                      },
                    }}
                    onClick={() => {
                      this.setState({
                        uploadModal: true,
                      });
                    }}
                  >
                    Upload
                  </Button>
                ),
                isFreeAction: true,
              },
              {
                icon: () => (
                  <ExportButton
                    schema={this.state.schema}
                    name={'Bundles'}
                    data={
                      this.selectTable.current &&
                      this.selectTable.current.state.data
                    }
                  />
                ),
                isFreeAction: true,
              },
            ]}
            onSelectionChange={(rowSelection) => {
              console.log(rowSelection);

              this.setState({
                selectedRows: rowSelection,
              });
            }}
            editable={{
              onBulkUpdate: (changes) =>
                new Promise((resolve, reject) => {
                  setTimeout(() => {
                    console.log(changes);
                    if (Object.keys(changes).length > 0) {
                      let payload = [];
                      this.setState({ loadingTable: true });
                      Object.keys(changes).map((row) => {
                        let payloadData = { ...changes[row].newData };
                        payloadData.createdBy = this.props.userInfo.id;
                        payloadData.createdDate = moment().format('DD-MM-YYYY');
                        payload.push(payloadData);
                      });
                      console.log(payload);
                      axios
                        .post('mtn/deal/ref/storebundle', payload)
                        .then((response) => {
                          console.log(response);
                          this.getBundleData().then(() => {
                            this.setState({
                              loadingTable: false,
                              openSnack: true,
                              messageSnack: 'Saved Successfully!',
                            });
                            resolve();
                          });
                        })
                        .catch((error) => {
                          console.log(error);
                          this.setState({
                            loadingTable: false,
                          });
                          resolve();
                        });
                    } else resolve();
                  }, 1000);
                }),
              onRowAdd: (newData) =>
                new Promise((resolve, reject) => {
                  let payload = { ...newData };
                  console.log(newData);
                  payload.createdBy = this.props.userInfo.id;
                  payload.createdDate = moment().format('DD-MM-YYYY');
                  this.setState({ loadingTable: true });
                  console.log(payload);
                  axios
                    .post('mtn/deal/ref/storebundle', [payload])
                    .then((response) => {
                      console.log(response);
                      if (response) {
                        let bundleData = [...this.state.bundleData, newData];
                        this.setState({
                          bundleData,
                        });
                      }
                      this.getBundleData().then(() => {
                        this.setState({
                          loadingTable: false,
                          openSnack: true,
                          messageSnack: 'Saved Successfully!',
                        });
                      });

                      resolve();
                    })
                    .catch((error) => {
                      console.log(error);
                      this.setState({
                        loadingTable: false,
                      });
                      resolve();
                    });
                }),
              onRowUpdate: (newData, oldData) =>
                new Promise((resolve, reject) => {
                  let payload = { ...newData };
                  const modPayloadData = objAppendOnUpdate(
                    payload,
                    this.props.userInfo.id,
                    {
                      oldArr: this.state.bundleData,
                      identifier: 'bundle',
                      val: payload['bundle'],
                    }
                  );
                  console.log(newData);
                  payload.createdBy = this.props.userInfo.id;
                  payload.createdDate = moment().format('DD-MM-YYYY');
                  this.setState({ loadingTable: true });
                  console.log(payload);
                  axios
                    .post('mtn/deal/ref/storebundle', [modPayloadData])
                    .then((response) => {
                      console.log(response);
                      const dataUpdate = [...this.state.bundleData];
                      const index = oldData.tableData.id;
                      dataUpdate[index] = newData;
                      this.setState({
                        bundleData: dataUpdate,
                        loadingTable: false,
                        openSnack: true,
                        messageSnack: 'Saved Successfully!',
                      });
                      resolve();
                    })
                    .catch((error) => {
                      console.log(error);
                      this.setState({
                        loadingTable: false,
                      });
                      resolve();
                    });
                }),
            }}
            options={{
              selection: true,
              pageSize: 5,
              pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
              toolbar: true,
              paging: true,
              rowStyle: {
                fontSize: '14px',
                padding: 10,
                background: 'rgba(0,0,0,0.04)',
              },
              headerStyle: {
                fontSize: '13px',
                fontWeight: 'bold',
                textTransform: 'capitalize',
                lineHeight: '1.2em',
              },
              // search: false,
              searchFieldAlignment: 'left',
              searchFieldVariant: 'outlined',
              showTitle: false,
              searchFieldStyle: {
                borderRadius: 50,
                border: '1px solid rgba(0, 0, 0, 0.04)',
                background: 'rgba(0, 0, 0, 0.04)',
                height: 40,
                width: 320,
              },
            }}
            components={{
              Toolbar: (props) => (
                <div>
                  <div
                    style={{
                      fontSize: '18px',
                      fontWeight: '600',
                      marginLeft: '24px',
                    }}
                  >
                    {props.title}
                  </div>

                  <div>
                    <MTableToolbar {...props} />
                  </div>
                </div>
              ),
              Pagination: (props) => {
                return <CustomPaginationComponent {...props} />;
              },
            }}
            localization={{
              body: {
                emptyDataSourceMessage: '',
              },
            }}
          />
        </ThemeProvider>
      </div>
    );

    if (this.state.loading) bundles = <Loader />;

    return bundles;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
    openDrawer: state.drawerData.open,
  };
};

export default connect(mapStateToProps)(
  withStyles(useStyles)(WithErrorHandler(Bundles, axios))
);
