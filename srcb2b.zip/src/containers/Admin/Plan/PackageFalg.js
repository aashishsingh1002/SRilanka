import React, { useEffect, useState } from 'react';
import CreatableSelect from 'react-select/creatable';

function PackageFalg({ rowData, flagLovs, onChange, styles }) {
  return (
    <div>
      {rowData.dispMsgCode === flagLovs.dispMsgCode ? (
        <div style={{ width: '200px' }}>
          <CreatableSelect
            styles={styles}
            isMulti
            onChange={(selectedOptions) => {
              let lovs = [];
              if (selectedOptions) {
                selectedOptions.map((lov) => {
                  lovs.push(lov.value);
                });
              }
              onChange({
                ...flagLovs,
                lovs: lovs.toString().replace(/,/gi, '|'),
                count: lovs.length - 1,
              });
            }}
            defaultValue={Object(flagLovs.lovs)
              .split('|')
              .map((lov) => {
                return {
                  value: lov,
                  label: lov,
                };
              })}
            options={Object(flagLovs.lovs)
              .split('|')
              .map((lov) => {
                return {
                  value: lov,
                  label: lov,
                };
              })}
          />
        </div>
      ) : (
        'N/A'
      )}
    </div>
  );
}

export default PackageFalg;
