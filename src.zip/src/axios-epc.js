import axios from 'axios';
import { store } from './store/store'

store.subscribe(() => {
    let authUserId = store.getState().login.loggedInUserInfo.id
    let token = store.getState().login.loggedInUserInfo.jwt

    instance.defaults.headers.common['authUserId'] = authUserId;
    instance.defaults.headers.common['Authorization'] = 'Bearer ' + token;

})


const instance = axios.create({
    baseURL: process.env.REACT_APP_URL,
});

export default instance;