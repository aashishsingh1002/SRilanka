import React, { Component, useEffect } from 'react';
// import React, { useState, useEffect, useRef } from "react";
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import Loader from '../../UI/Loader/Loader';
import MaterialTable, { MTableToolbar } from '@material-table/core';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import {
  FormControlLabel,
  FormLabel,
  Radio,
  RadioGroup,
  ThemeProvider,
} from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import moment from 'moment';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import Checkbox from '@material-ui/core/Checkbox';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import Modal from '../../UI/Modal/Modal';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableBody from '@material-ui/core/TableBody';
import TableHead from '@material-ui/core/TableHead';
import Table from '@material-ui/core/Table';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import Tooltip from '@material-ui/core/Tooltip';
import Box from '@material-ui/core/Box';
import LastPageIcon from '@material-ui/icons/LastPage';
import CardContent from '@material-ui/core/CardContent';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import * as actionTypes from '../../store/actions/actionTypes';
import { Autocomplete } from '@material-ui/lab';
import { useLocation } from 'react-router-dom';
import { CustomPaginationComponent } from '../BulkUpload/common/table-config';
import GetAppIcon from '@material-ui/icons/GetApp';
import DateFnsUtils from '@date-io/date-fns';
import { KeyboardDatePicker } from '@material-ui/pickers';
import { MuiPickersUtilsProvider } from '@material-ui/pickers';
import MTNButton from '../../UI/Button/Button';

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);
const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
  CheckBoxIcon: forwardRef((props, ref) => (
    <CheckBoxIcon {...props} ref={ref} />
  )),
};

const theme = createMuiTheme({
  // palette: {
  //   primary: {
  //     main: '#ffcc00',
  //     color:'#000',
  //   },
  //   secondary: {
  //     main: '#ffcc00',
  //     color:'#000'
  //   },
  // },
  overrides: {
    MuiTableCell: {
      root: {
        padding: '0px',
        paddingLeft: '10px',
      },
    },
    MuiPaper: {
      width: '100%',
    },
    MuiInputBase: {
      input: {
        fontSize: 14,
      },
    },
  },
});

const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4.5vh',
  },
  subheader: {
    color: 'white',
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
  table: {
    minWidth: 650,
  },
});

class DealModification extends Component {
  _isMounted = false;

  state = {
    rowAdd: false,
    loading: true,
    dealData: [],
    derivedData: [],
    version: '',
    schema: [],
    columns: [],
    isSelected: false,
    modalOpen: false,
    dealId: [],
    dealCaptureUpload: false,
    allColumns: [],
    location: this.props.location,
    selectedRows: [],
    selectedFilter: 'dateAndMonth',
    selectedYear: null,
    selectedMonth: [],
    selectedDealId: null,
    dataLoaded: false,
  };
  typeCheck(refName) {
    if (refName === 'ucId') {
      return 'number';
    }

    return 'text';
  }

  handleOpen() {
    this.setState({ modalOpen: true });
  }
  handleClose = () => {
    this.setState({ modalOpen: false });
  };
  componentWillUnmount() {
    this._isMounted = false;
  }

  constructor(props) {
    super(props);
    this.selectTable = React.createRef();
    this.selectRowsTable = React.createRef();
  }

  async saveAsExcel() {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('All Deals');
    let sheetColumns = [];
    this.state.schema
      .filter((x) => {
        if (
          x.refName !== 'errorMessage' &&
          x.refName !== 'overallStatus' &&
          x.refName !== 'status'
        ) {
          return true;
        }
      })
      .forEach((row) => {
        sheetColumns.push({
          header: row.uiName,
          key: row.refName,
          width: 25,
        });
      });

    worksheet.columns = sheetColumns;
    this.selectTable.current.state.data.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), 'All_Deals.xlsx');
  }

  async saveAsSelectedExcel() {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('xmtndealmodificationtab');
    let sheetColumns = [];
    this.state.schema
      .filter((x) => x.groupName === 'UI Input')
      .forEach((row) => {
        sheetColumns.push({
          header: row.uiName,
          key: row.refName,
          width: 25,
        });
      });
    //Need to Change
    worksheet.columns = sheetColumns;
    this.state.selectedRows.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    const buf = await workbook.xlsx.writeBuffer();

    saveAs(new Blob([buf]), 'DealModification.xlsx');
  }

  componentDidMount() {
    this._isMounted = true;
    this.versions().then(() => {
      this.uiFields().then(() => {
        // this.getDealData().then(() => {
        let columns = this.state.schema
          .filter((x) => x.groupName === 'UI Input')
          .map((row) => {
            console.log(row.refName);
            return {
              title: row.uiName,
              field: row.refName,
              validate: this.validation,
              sorting: false,
              cellStyle: { width: '20%' },

              // editable:'onAdd',
              render: (rowData) => {
                return (
                  row.refName &&
                  rowData[row.refName] && (
                    <span
                      style={{
                        // lookup:row.lifeCycle
                        display: 'block',
                        width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                      }}
                    >
                      {' '}
                      {rowData[row.refName]}
                    </span>
                  )
                );
              },
              editComponent: (props) => {
                return (
                  <TextField
                    type={this.typeCheck(row.refName)}
                    style={{
                      width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                      margin: 10,
                      fontSize: 12,
                    }}
                    fullWidth
                    value={props.value}
                    onChange={(event) => {
                      props.onChange(event.target.value);
                    }}
                  />
                );
              },
            };
          });

        let allColumns = this.state.schema.map((row) => {
          return row.refName === 'ucId'
            ? {
                title: row.uiName,
                field: row.refName,
                sorting: false,
                cellStyle: { width: '20%' },

                // lookup: { flag: 'İstanbul', flag: 'Şanlıurfa' },
                render: (rowData) => {
                  return (
                    row.refName &&
                    rowData[row.refName] && (
                      <span
                        style={{
                          display: 'block',
                          width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                        }}
                      >
                        {' '}
                        {rowData[row.refName]}
                      </span>
                    )
                  );
                },
                editComponent: (props) => (
                  <TextField
                    // editable='onAdd'
                    style={{
                      width: '20vw',
                      margin: 10,
                      fontSize: 12,
                    }}
                    fullWidth
                    value={props.value}
                    onChange={(event) => {
                      props.onChange(event.target.value);
                    }}
                  />
                ),
              }
            : {
                title: row.uiName,
                field: row.refName,
                sorting: false,
                cellStyle: { width: '20%' },

                // lookup: { flag: 'İstanbul', flag: 'Şanlıurfa' },
                render: (rowData) => {
                  return (
                    row.refName &&
                    rowData[row.refName] && (
                      <span
                        style={{
                          display: 'block',
                          width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                        }}
                      >
                        {' '}
                        {rowData[row.refName]}
                      </span>
                    )
                  );
                },
                editComponent: (props) => (
                  <TextField
                    style={{
                      width: '20vw',
                      margin: 10,
                      fontSize: 12,
                    }}
                    fullWidth
                    value={props.value}
                    onChange={(event) => {
                      props.onChange(event.target.value);
                    }}
                  />
                ),
              };
        });
        let dropdowncolumns = this.state.schema
          .filter((x) => x.refLovs === '')
          .map((row) => {
            return {
              title: row.uiName,
              field: row.refName,
              sorting: false,
              cellStyle: { width: '20%' },

              render: (rowData) => {
                return (
                  row.refName &&
                  rowData[row.refName] && (
                    <span
                      style={{
                        display: 'block',
                        width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                      }}
                    >
                      {' '}
                      {rowData[row.refName]}
                    </span>
                  )
                );
              },
              editComponent: (props) => (
                <TextField
                  style={{
                    width: '20vw',
                    margin: 10,
                    fontSize: 12,
                  }}
                  fullWidth
                  value={props.value}
                  onChange={(event) => {
                    props.onChange(event.target.value);
                  }}
                />
              ),
            };
          });

        this.setState({ columns, loading: false });
        this.setState({ allColumns, loading: false });
        // });
      });
    });
  }

  versions() {
    return axios
      .get('config/version?entityName=dealModification', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields() {
    if (
      localStorage.getItem('DealModification') &&
      localStorage.DealModification_version &&
      localStorage.DealModification_version == this.state.version
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem('DealModification')),
        });
      } catch (e) {
        localStorage.removeItem('DealModification');
      }
      return Promise.resolve();
    } else {
      return axios
        .get('config?entityName=dealModification', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          let schema = [];
          schema = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted) this.setState({ schema: schema });
          localStorage.setItem('DealModification', JSON.stringify(schema));
          localStorage.DealModification_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  getDealData() {
    return axios
      .get('mtn/modification')
      .then((res) => {
        console.log('deal response', res);

        if (res) {
          this.setState({
            dealData: res.data.data.map((row) => {
              return { ...row, tableData: '' };
            }),
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  getFilteredDealData() {
    const { selectedMonth, selectedYear, selectedDealId } = this.state;
    const { releaseId } = this.props.releaseData;
    const { id } = this.props.userInfo;

    let url = `mtn/modification?releaseId=${releaseId}&createdBy=${id}`;
    // url += selectedMonth.length ? `&months=${selectedMonth.toString()}` : "";
    url += selectedYear ? `&year=${selectedYear}` : '';
    url += selectedDealId ? `&dealIdPattern=${selectedDealId}` : '';
    console.log('https://react-select.com/creatable', selectedMonth);
    return axios
      .get(url, {
        headers: {
          months: JSON.stringify(selectedMonth),
        },
      })
      .then((res) => {
        console.log('deal response', res);

        if (res) {
          this.setState({
            dealData: res.data.data.map((row) => {
              return { ...row, tableData: '' };
            }),
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  async onClickSearch() {
    // TODO: dataloaded & isSearching
    this.setState({ dataLoaded: false, isSearching: true });
    await this.getFilteredDealData();
    this.setState({ dataLoaded: true, isSearching: false });
  }

  render() {
    const { classes } = this.props;

    let dealCapture = (
      <div
        style={{
          margin: '0 auto',
          width: this.props.openDrawer
            ? `calc(100vw - 343px)`
            : 'calc(100vw - 141px)',
        }}
      >
        {/* {this.props.userInfo.group.indexOf("PricingAnalyst")===0 ?( */}
        {this.props.releaseData.releaseId ? (
          <ThemeProvider theme={theme}>
            <div
              style={{
                padding: '10px 0',
                fontSize: '24px',
                fontWeight: '600',
              }}
            >
              Deal Modification
            </div>

            {/* FILTER */}
            <Paper style={{ padding: '20px', width: '100%' }}>
              <Grid container spacing={4}>
                <Grid item xs={3}>
                  <TextField
                    label='Deal ID Pattern'
                    disabled={this.state.isSearching}
                    value={this.state.selectedDealId}
                    InputLabelProps={{ shrink: true }}
                    style={{ width: '100%' }}
                    onChange={(e) =>
                      this.setState({ selectedDealId: e.target.value })
                    }
                  />
                </Grid>
                <Grid item xs={6}>
                  <Autocomplete
                    multiple
                    style={{
                      width: '100%',
                      fontSize: '30px',
                    }}
                    size='small'
                    id='combo-box-demo'
                    options={[
                      'JAN',
                      'FEB',
                      'MAR',
                      'APR',
                      'MAY',
                      'JUN',
                      'JUL',
                      'AUG',
                      'SEP',
                      'OCT',
                      'NOV',
                      'DEC',
                    ]}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label='Month'
                        variant='standard'
                        InputLabelProps={{ shrink: true }}
                      />
                    )}
                    onChange={(event, value) => {
                      this.setState({ selectedMonth: value });
                    }}
                    disabled={this.state.isSearching}
                  />
                </Grid>
                <Grid item xs={3}>
                  <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <KeyboardDatePicker
                      disabled={this.state.isSearching}
                      multiselect
                      label={'Year'}
                      ToolbarComponent={() => null}
                      views={['year']}
                      variant='inline'
                      format='yyyy'
                      InputLabelProps={{ shrink: true }}
                      value={this.state.selectedYear}
                      onChange={(val) => {
                        this.setState({
                          selectedYear: moment(val).format('yyyy'),
                        });
                      }}
                    />
                  </MuiPickersUtilsProvider>
                </Grid>

                <Grid item xs={12}>
                  <div style={{ textAlign: 'right' }}>
                    <MTNButton
                      style={{ padding: '6px 32px' }}
                      onClick={() => this.onClickSearch()}
                      disabled={this.state.isSearching}
                    >
                      {this.state.isSearching ? 'Searching...' : 'Search'}
                    </MTNButton>
                  </div>
                </Grid>
              </Grid>
            </Paper>
            {/* END FILTER */}

            {this.state.dataLoaded && (
              <MaterialTable
                //   editable={​​​​​{​​​​​isEditable: rowData => rowData.name !== 'ucId'}​​​​​}​​​​​
                style={{ padding: '20px', marginTop: '10px' }}
                tableRef={this.selectTable}
                isLoading={this.state.loadingTable}
                icons={{
                  Add: forwardRef((props, ref) => (
                    <AddBox {...props} ref={ref} />
                  )),
                  Check: forwardRef((props, ref) => (
                    <Check {...props} ref={ref} />
                  )),
                  Clear: forwardRef((props, ref) => (
                    <Clear {...props} ref={ref} />
                  )),
                  Delete: forwardRef((props, ref) => (
                    <DeleteOutline {...props} ref={ref} />
                  )),
                  DetailPanel: forwardRef((props, ref) => (
                    <ChevronRight {...props} ref={ref} />
                  )),
                  Edit: forwardRef((props, ref) => (
                    <Edit {...props} ref={ref} />
                  )),
                  Export: forwardRef((props, ref) => (
                    <SaveAlt {...props} ref={ref} />
                  )),
                  Filter: forwardRef((props, ref) => (
                    <FilterList {...props} ref={ref} />
                  )),
                  FirstPage: forwardRef((props, ref) => (
                    <FirstPage {...props} ref={ref} />
                  )),
                  LastPage: forwardRef((props, ref) => (
                    <LastPage {...props} ref={ref} />
                  )),
                  NextPage: forwardRef((props, ref) => (
                    <ChevronRight {...props} ref={ref} />
                  )),
                  PreviousPage: forwardRef((props, ref) => (
                    <ChevronLeft {...props} ref={ref} />
                  )),
                  ResetSearch: forwardRef((props, ref) => (
                    <Clear {...props} ref={ref} />
                  )),
                  Search: forwardRef((props, ref) => (
                    <Search {...props} ref={ref} />
                  )),
                  SortArrow: forwardRef((props, ref) => (
                    <ArrowDownward {...props} ref={ref} />
                  )),
                  ThirdStateCheck: forwardRef((props, ref) => (
                    <Remove {...props} ref={ref} />
                  )),
                  ViewColumn: forwardRef((props, ref) => (
                    <ViewColumn {...props} ref={ref} />
                  )),
                  CheckBoxIcon: forwardRef((props, ref) => (
                    <CheckBoxIcon {...props} ref={ref} />
                  )),
                }}
                title={`Deal Modification: ${this.props.releaseData.releaseId}`}
                columns={this.state.columns}
                data={this.state.dealData}
                lookup={this.state.columns.map((x) => {
                  return x.refLovs;
                })}
                actions={[
                  {
                    tooltip: 'Export',
                    icon: GetAppIcon,
                    onClick: (evt, data) => {
                      this.saveAsSelectedExcel();
                    },
                  },
                  {
                    icon: () => (
                      <Button
                        variant='contained'
                        style={{
                          textTransform: 'capitalize',
                          background: '#ffcc00',
                          letterSpacing: '-1px',
                          fontWeight: '600',
                          color: '#000',
                          fontSize: '16px',
                          borderRadius: '50px',
                          padding: '6px 32px',
                          '&:hover': {
                            opacity: 0.8,
                            background: '#ffcc00',
                          },
                        }}
                        onClick={() => {
                          this.saveAsExcel();
                        }}
                      >
                        <SaveAlt style={{ marginRight: '10px' }} />
                        Export
                      </Button>
                    ),
                    isFreeAction: true,
                  },
                ]}
                editable={{}}
                options={{
                  selection: true,
                  pageSize: 5,
                  pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
                  toolbar: true,
                  paging: true,
                  rowStyle: {
                    fontSize: '14px',
                    padding: 10,
                    background: 'rgba(0,0,0,0.04)',
                  },
                  headerStyle: {
                    fontSize: '13px',
                    fontWeight: 'bold',
                    textTransform: 'capitalize',
                    lineHeight: '1.2em',
                  },
                  // search: false,
                  searchFieldAlignment: 'left',
                  searchFieldVariant: 'outlined',
                  showTitle: false,
                  searchFieldStyle: {
                    borderRadius: 50,
                    border: '1px solid rgba(0, 0, 0, 0.04)',
                    background: 'rgba(0, 0, 0, 0.04)',
                    height: 40,
                    width: 320,
                  },
                }}
                onSelectionChange={(selection) => {
                  console.log(selection);
                  this.setState({
                    selectedRows: selection,
                  });
                  console.log(this.state.selectedRows);
                  this.setState({ isSelected: !!selection.length });
                }}
                components={{
                  Toolbar: (props) => (
                    <div>
                      <div
                        style={{
                          fontSize: '18px',
                          fontWeight: '600',
                          marginLeft: '24px',
                        }}
                      >
                        {props.title}
                      </div>
                      <div>
                        <MTableToolbar {...props} />
                      </div>
                    </div>
                  ),
                  Pagination: (props) => {
                    return <CustomPaginationComponent {...props} />;
                  },
                }}
              />
            )}
          </ThemeProvider>
        ) : (
          'Outside Release'
        )}
        <div>
          <Modal
            show={this.state.modalOpen}
            modalClosed={this.handleClose}
            title={'Derived Data'}
          >
            <MaterialTable
              tableRef={this.selectDrivedTable}
              isLoading={this.state.loadingTable}
              icons={tableIcons}
              title={'Drived Data'}
              columns={this.state.allColumns}
              data={this.state.derivedData}
              actions={[
                {
                  icon: () => (
                    <Button
                      variant='contained'
                      style={{
                        marginLeft: '20px',
                        background: '#546D7A',
                        color: 'white',
                        textTransform: 'none',
                      }}
                      onClick={() => {
                        this.saveAsDrivedExcel();
                      }}
                    >
                      <SaveAlt style={{ marginRight: '10px' }} />
                      Export
                    </Button>
                  ),
                  isFreeAction: true,
                },
              ]}
              options={{
                pageSize: 1,
                search: false,
                paging: true,
                toolbar: true,
                rowStyle: {
                  fontSize: '15px',
                  padding: 8,
                },
                headerStyle: {
                  fontWeight: 'bold',
                },
              }}
            />
          </Modal>
        </div>
      </div>
    );

    if (this.state.loading) dealCapture = <Loader />;

    return dealCapture;
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    setUCId: (data) => dispatch({ type: actionTypes.SET_UCID, data: data }),
    setDealModification: (data) =>
      dispatch({ type: actionTypes.Deal_Modification, data: data }),
  };
};
const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
    openDrawer: state.drawerData.open,
    dropdowns: state.dropdownData,
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(DealModification, axios)));
