import React from "react";
import Typography from "@material-ui/core/Typography";
import { withStyles } from "@material-ui/core/styles";

const StyledTypoHeading = withStyles((theme) => ({
  root: {
    fontWeight: "bold",
    fontSize: "24px",
    color: "#393939",
    padding: "8px 0",
    letterSpacing: "-1px",
  },
}))(Typography);

const Title = ({ children }) => {
  return <StyledTypoHeading>{children}</StyledTypoHeading>;
};
export default Title;
