import React, { Component } from 'react';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../../axios-epc';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../../UI/Loader/Loader';
import Grid from '@material-ui/core/Grid';
// import Button from "@material-ui/core/Button";
import Button from '../../../UI/Button/Button';
import InputAdornment from '@material-ui/core/InputAdornment';
import TextField from '@material-ui/core/TextField';
import MoneyIcon from '@material-ui/icons/Money';
import IconButton from '@material-ui/core/IconButton';
import SearchIcon from '@material-ui/icons/Search';
import Modal from '../../../UI/Modal/Modal';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Typography from '@material-ui/core/Typography';
import ExpandMore from '@material-ui/icons/ExpandMore';
import Divider from '@material-ui/core/Divider';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ListSubheader from '@material-ui/core/ListSubheader';
import AppsIcon from '@material-ui/icons/Apps';
import SaveIcon from '@material-ui/icons/Save';
import moment from 'moment';
import { connect } from 'react-redux';
import * as actionTypes from '../../../store/actions/actionTypes';

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
    paddingBottom: 0,
  },
  subheader: {
    color: 'rgba(0, 0, 0, 0.87)',
    fontSize: '16px',
    fontWeight: '600',
    // color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
  root: {
    width: '100%',
    maxWidth: '99%',
    backgroundColor: theme.palette.background.paper,
    position: 'relative',
    overflow: 'auto',
    maxHeight: 300,
  },
  listSection: {
    backgroundColor: 'inherit',
  },
  ul: {
    backgroundColor: 'inherit',
    padding: 0,
  },
});

class Tarrif extends Component {
  _isMounted = false;

  state = {
    loading: true,
    show: false,
    ratePlans: [],
    searchRatePlans: '',
    showratePlans: [],
    selRatePlan: '',
    productComponentId: '',
    showModal: false,
    modalContent: null,
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    this.getRatePlans().then(() => {
      this.getBundledRateplan().then(() => {
        this.setState({
          loading: false,
        });
      });
    });
  }
  modalCloseHandler = () => {
    this.setState({
      show: false,
    });
  };

  searchHandlerUpgrade = (event) => {
    this.setState({ searchRatePlans: event.target.value });
    let searchItems = [];
    if (event.target.value.length == 0) {
      searchItems = [...this.state.ratePlans];
      this.setState({ showratePlans: searchItems });
    } else {
      searchItems = this.state.ratePlans.filter(function (item) {
        return (
          item.ccmCode
            .toUpperCase()
            .includes(event.target.value.toUpperCase()) ||
          item.ccmDesc.toUpperCase().includes(event.target.value.toUpperCase())
        );
      });
      this.setState({ showratePlans: searchItems });
    }
  };

  getRatePlans() {
    return axios
      .get('ratePlan/CRPView?releaseId=' + this.props.releaseData.releaseId, {
        headers: {
          opId: this.props.userInfo.opId,
        },
      })
      .then((res) => {
        console.log(res);
        let ratePlans = [];
        res.data.data.filter((el) => {
          let obj = { ...el };
          obj.show = false;
          obj.content = {};
          ratePlans.push(obj);
        });
        this.setState({
          ratePlans: ratePlans,
          showratePlans: ratePlans,
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  showRates(item) {
    let showItem = !item.show;
    if (!item.show) {
      axios
        .get(
          'ratePlan/RPView?releaseId=' +
            this.props.releaseData.releaseId +
            '&ccmId=' +
            item.ccmId,
          {
            headers: {
              opId: this.props.userInfo.opId,
            },
          }
        )
        .then((res) => {
          console.log(res);
          let content = {};
          res.data.data.filter((el) => {
            content[
              el.icmRateplanCategory +
                '-' +
                el.icmSubCategory +
                '-' +
                el.ugcSubType2
            ] = el;
          });
          this.setState({
            showratePlans: this.state.showratePlans.map((el) =>
              el.ccmId === item.ccmId
                ? {
                    ...el,
                    show: showItem,
                    content: content,
                  }
                : el
            ),
          });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else
      this.setState({
        showratePlans: this.state.showratePlans.map((el) =>
          el.ccmId === item.ccmId
            ? {
                ...el,
                show: showItem,
              }
            : el
        ),
      });
  }

  getBundledRateplan() {
    return axios
      .get('package/crp/id?packageId=' + this.props.id, {
        headers: {
          opId: this.props.userInfo.opId,
        },
      })
      .then((res) => {
        console.log(res);
        this.setState({
          selRatePlan: res.data.data[Object.keys(res.data.data)[0]],
          productComponentId: Object.keys(res.data.data)[0],
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  saveRatePlan = () => {
    if (this.props.id) {
      this.setState({
        loading: true,
      });
      let payload = {};
      let date = moment().format('DD-MMM-YY');
      payload.componentType = this.props.entity + 'Components';
      payload.id = this.props.id;
      payload.releaseId = this.props.releaseData.releaseId;
      let componentDetails = {};
      if (this.state.productComponentId) {
        componentDetails.productComponentId = this.state.productComponentId;
        console.log('update rp');
      }

      componentDetails.productComponentRefId = this.state.selRatePlan;
      componentDetails.currency = 'INR';
      componentDetails.createdBy = this.props.userInfo.id;
      componentDetails.createdDate = date;
      componentDetails.startDate = date;
      componentDetails.endDate = '30-DEC-30';
      componentDetails.opId = this.props.userInfo.opId;
      componentDetails.buId = this.props.userInfo.buId;
      componentDetails.customerSegmentId = 'ANY';
      componentDetails.customerMarketCode = 'ANY';
      componentDetails.customerTypeId = 'ANY';
      componentDetails.channelId = 'ANY';
      componentDetails.minimum = 0;
      componentDetails.maximum = 0;
      componentDetails.payNow = 'N';
      componentDetails.chargeType = 'PO';
      componentDetails.productId = this.props.id;
      componentDetails.serviceTypeId = '/account';
      componentDetails.componentTypeId = 'USAGE';
      componentDetails.priceCompMethod = 'DIRECT';

      payload.componentDetails = componentDetails;

      console.log(payload);
      axios
        .post('', payload)
        .then((response) => {
          console.log(response);
          this.setState({
            productComponentId: response.data.data,
            loading: false,
          });
          let obj = {};
          obj.productComponentId = this.state.productComponentId;
          obj.componentType = 'USAGE';
          obj.productComponentRefId = this.state.selRatePlan;
          obj.rcFrequency = 'MONTHLY';
          this.props.addComponent(obj);
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      let modalContent = (
        <Typography variant='h6'>
          {' '}
          Submit Basic {this.props.entity} Details first.{' '}
        </Typography>
      );
      this.setState({ modalContent: modalContent, showModal: true });
    }
  };

  errorConfirmedHandler = () => {
    this.setState({ showModal: false });
  };

  render() {
    const { classes } = this.props;

    let tarrif = (
      <Card>
        <Modal
          show={this.state.showModal}
          modalClosed={this.errorConfirmedHandler}
          title={'Something Went Wrong!'}
        >
          {this.state.modalContent}
        </Modal>
        <Modal
          show={this.state.show}
          modalClosed={this.modalCloseHandler}
          title={'Rate Plans'}
        >
          <List style={{ width: '100%', maxHeight: '30vh', overflow: 'auto' }}>
            <TextField
              onChange={this.searchHandlerUpgrade}
              fullWidth
              value={this.state.searchRatePlans}
              InputProps={{
                startAdornment: (
                  <InputAdornment position='start'>
                    <SearchIcon style={{ color: '#ff1921' }} />
                  </InputAdornment>
                ),
              }}
            />
            {this.state.showratePlans.length > 0 ? (
              this.state.showratePlans.map((rp) => {
                return (
                  <React.Fragment>
                    <ListItem key={rp.ccmCode}>
                      <ListItemIcon className={classes.navIcon}>
                        {rp.show ? (
                          <ExpandLess
                            style={{ cursor: 'pointer' }}
                            onClick={() => this.showRates(rp)}
                          />
                        ) : (
                          <ExpandMore
                            style={{ cursor: 'pointer' }}
                            onClick={() => this.showRates(rp)}
                          />
                        )}
                      </ListItemIcon>
                      <ListItemText
                        style={{ cursor: 'pointer' }}
                        onClick={() => this.showRates(rp)}
                        primary={rp.ccmCode + ' (' + rp.ccmDesc + ')'}
                      />
                      <SaveIcon
                        style={{ cursor: 'pointer', color: 'green' }}
                        onClick={() => {
                          this.setState({
                            selRatePlan: rp.ccmCode,
                          });
                        }}
                      />
                    </ListItem>
                    {rp.show && (
                      <List className={classes.root} subheader={<li />}>
                        {Object.keys(rp.content).map((type) => (
                          <li
                            key={`section-${type}`}
                            className={classes.listSection}
                          >
                            <ul className={classes.ul}>
                              <ListSubheader>{type}</ListSubheader>
                              {rp.content[type]['cgdRates'].map((item) => (
                                <ListItem key={`item-${item.usageGroup}`}>
                                  <ListItemIcon className={classes.navIcon}>
                                    <AppsIcon />
                                  </ListItemIcon>
                                  <ListItemText
                                    primary={item.usageGroup + ':' + item.rates}
                                  />
                                </ListItem>
                              ))}
                            </ul>
                          </li>
                        ))}
                      </List>
                    )}
                    <Divider />
                  </React.Fragment>
                );
              })
            ) : (
              <Typography
                variant='h6'
                className={classes.center}
                style={{
                  marginTop: '1.5%',
                }}
              >
                {' '}
                No Rate Plans Found.
              </Typography>
            )}
          </List>{' '}
        </Modal>
        <CardHeader
          className={classes.cardHeader}
          classes={{
            subheader: classes.subheader,
          }}
          subheader={'Rate Plans'}
        />

        <CardContent>
          <Grid container spacing={1} alignItems='flex-end'>
            <Grid item sm={4}>
              <TextField
                fullWidth
                disabled
                value={this.state.selRatePlan}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position='start'>
                      <MoneyIcon style={{ color: '#ff1921' }} />
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
            <Grid item xs={1}>
              <IconButton
                onClick={() => {
                  this.setState({
                    show: true,
                  });
                }}
              >
                <SearchIcon />
              </IconButton>
            </Grid>
          </Grid>
          {this.props.releaseData.releaseId && (
            <div
              style={{
                display: 'flex',
                // justifyContent: "center",
                alignItems: 'center',
              }}
            >
              <Button
                // variant="contained"
                onClick={() => {
                  if (this.props.entity === 'Package')
                    this.props.changePackageActiveStep(2);
                  else this.props.changeProductActiveStep(1);
                }}
                style={{
                  marginTop: '1%',
                  marginBottom: '1%',
                  textTransform: 'none',
                  paddingLeft: 0,
                  background: '#fff',
                  color: '#ff1921',
                }}
                className={classes.btn}
              >
                Back
              </Button>
              <Button
                // variant="contained"
                onClick={() => {
                  if (this.props.entity === 'Package')
                    this.props.changePackageActiveStep(4);
                  else this.props.changeProductActiveStep(3);
                }}
                style={{
                  textTransform: 'none',
                  background: '#fff',
                  color: '#ff1921',
                  marginLeft: 'auto',
                  padding: '6px',
                  //   background: "blue",
                  marginTop: '1%',
                  //   color: "white",
                  //   marginLeft: "20px",
                  marginBottom: '1%',
                }}
                className={classes.btn}
              >
                Next
              </Button>
              <Button
                // variant="contained"
                onClick={this.saveRatePlan}
                style={{
                  //   background: "#02bfa0",
                  textTransform: 'none',
                  marginTop: '1%',
                  marginBottom: '1%',
                  marginLeft: '20px',
                }}
              >
                Save
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    );

    if (this.state.loading) tarrif = <Loader relative />;

    return tarrif;
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    changeProductActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
        activeStep: activeStep,
      }),
  };
};

export default connect(
  null,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(Tarrif, axios)));
