import React, { Component, useEffect } from 'react';
// import React, { useState, MuseEffect, useRef } from "react";
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import Loader from '../../UI/Loader/Loader';
import MaterialTable, { MTableToolbar } from '@material-table/core';
import { forwardRef } from 'react';
import AddBox from '@material-ui/icons/AddBox';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import Check from '@material-ui/icons/Check';
import ChevronLeft from '@material-ui/icons/ChevronLeft';
import ChevronRight from '@material-ui/icons/ChevronRight';
import Clear from '@material-ui/icons/Clear';
import DeleteOutline from '@material-ui/icons/DeleteOutline';
import Edit from '@material-ui/icons/Edit';
import FilterList from '@material-ui/icons/FilterList';
import FirstPage from '@material-ui/icons/FirstPage';
import LastPage from '@material-ui/icons/LastPage';
import Remove from '@material-ui/icons/Remove';
import SaveAlt from '@material-ui/icons/SaveAlt';
import Search from '@material-ui/icons/Search';
import ViewColumn from '@material-ui/icons/ViewColumn';
import { ThemeProvider } from '@material-ui/core';
import { createMuiTheme } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import moment from 'moment';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
// import Button from "@material-ui/core/Button";
import Button from '../../UI/Button/Button';
import InputLabel from '@material-ui/core/InputLabel';
import Checkbox from '@material-ui/core/Checkbox';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import Modal from '../../UI/Modal/Modal';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableBody from '@material-ui/core/TableBody';
import TableHead from '@material-ui/core/TableHead';
import Table from '@material-ui/core/Table';
import ExcelJS from 'exceljs/dist/es5/exceljs.browser.js';
import { saveAs } from 'file-saver';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import Tooltip from '@material-ui/core/Tooltip';
import Box from '@material-ui/core/Box';
import LastPageIcon from '@material-ui/icons/LastPage';
import CardContent from '@material-ui/core/CardContent';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import * as actionTypes from '../../store/actions/actionTypes';
import { Autocomplete } from '@material-ui/lab';
import { useLocation } from 'react-router-dom';
import DealModificationUpload from './DealModificationUpload';
import { CustomPaginationComponent } from './common/table-config';
import DealData from './DealModificationDealData';
import Federate from './DealModificationFederate';
import genAxios from 'axios';

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);
const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
  CheckBoxIcon: forwardRef((props, ref) => (
    <CheckBoxIcon {...props} ref={ref} />
  )),
};

const theme = createMuiTheme({
  overrides: {
    MuiTableCell: {
      root: {
        padding: '0px',
        paddingLeft: '10px',
      },
    },
    MuiPaper: {
      width: '100%',
    },
    MuiInputBase: {
      input: {
        fontSize: 14,
      },
    },
  },
});

const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4.5vh',
  },
  subheader: {
    color: 'white',
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
  table: {
    minWidth: 650,
  },
});

class DealModification extends Component {
  _isMounted = false;

  state = {
    rowAdd: false,
    loading: true,
    dealData: [],
    derivedData: [],
    version: '',
    schema: [],
    columns: [],
    isSelected: false,
    modalOpen: false,
    dealId: [],
    dealModificaitonUpload: false,
    allColumns: [],
    location: this.props.location,
    showDealData: false,
    showFederate: false,
  };
  typeCheck(refName) {
    if (refName === 'ucId') {
      return 'number';
    }

    return 'text';
  }

  handleOpen() {
    this.setState({ modalOpen: true });
  }
  handleClose = () => {
    this.setState({ modalOpen: false });
  };
  componentWillUnmount() {
    this._isMounted = false;
  }

  constructor(props) {
    super(props);
    this.selectTable = React.createRef();
    this.selectDrivedTable = React.createRef();
  }

  async saveAsExcel() {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Deal Capture');
    let sheetColumns = [];
    this.state.schema.forEach((row) => {
      if (row.groupName === 'UI Input') {
        sheetColumns.push({
          header: row.uiName,
          key: row.refName,
          width: 25,
        });
      }
    });

    worksheet.columns = sheetColumns;
    this.selectTable.current.state.data.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    this.setState({ loading: true });
    const buf = await workbook.xlsx.writeBuffer();
    this.setState({ loading: false });

    saveAs(new Blob([buf]), 'Deal Capture.xlsx');
  }

  async saveAsDrivedExcel() {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Drived Data');
    let sheetColumns = [];
    this.state.schema.forEach((row) => {
      sheetColumns.push({
        header: row.uiName,
        key: row.refName,
        width: 25,
      });
    });

    worksheet.columns = sheetColumns;

    this.selectDrivedTable.current.state.data.map((row) => {
      worksheet.addRow(row);
    });

    worksheet.getRow(1).font = {
      bold: true,
    };

    const buf = await workbook.xlsx.writeBuffer();

    saveAs(new Blob([buf]), 'Deal Capture Drived Data.xlsx');
  }

  componentDidMount() {
    this._isMounted = true;
    this.versions().then(() => {
      this.uiFields().then(() => {
        this.fedStatusHandler().then(() => {
          this.getDealData().then(() => {
            let columns = this.state.schema
              .filter((x) => x.isDisplay === 'Y')
              .map((row) => {
                console.log(row.refName);
                return {
                  title: row.uiName,
                  field: row.refName,
                  validate: this.validation,
                  sorting: false,
                  cellStyle: { width: '20%' },

                  // editable:'onAdd',
                  render: (rowData) => {
                    return (
                      row.refName &&
                      rowData[row.refName] && (
                        <span
                          style={{
                            // lookup:row.lifeCycle
                            paddingTop: '12px',
                            paddingBottom: '12px',
                            display: 'block',
                            width: row.maxLength
                              ? row.maxLength + 'vw'
                              : '10vw',
                          }}
                        >
                          {' '}
                          {rowData[row.refName]}
                        </span>
                      )
                    );
                  },
                  editComponent: (props) => {
                    return (
                      <TextField
                        type={this.typeCheck(row.refName)}
                        style={{
                          width: row.maxLength ? row.maxLength + 'vw' : '10vw',
                          margin: 10,
                          fontSize: 12,
                        }}
                        fullWidth
                        value={props.value}
                        onChange={(event) => {
                          props.onChange(event.target.value);
                        }}
                      />
                    );
                  },
                };
              });

            let allColumns = this.state.schema.map((row) => {
              return row.refName === 'ucId'
                ? {
                    title: row.uiName,
                    field: row.refName,
                    sorting: false,
                    cellStyle: { width: '20%' },

                    // lookup: { flag: 'İstanbul', flag: 'Şanlıurfa' },
                    render: (rowData) => {
                      return (
                        row.refName &&
                        rowData[row.refName] && (
                          <span
                            style={{
                              display: 'block',
                              width: row.maxLength
                                ? row.maxLength + 'vw'
                                : '10vw',
                            }}
                          >
                            {' '}
                            {rowData[row.refName]}
                          </span>
                        )
                      );
                    },
                    editComponent: (props) => (
                      <TextField
                        // editable='onAdd'
                        style={{
                          width: '20vw',
                          margin: 10,
                          fontSize: 12,
                        }}
                        fullWidth
                        value={props.value}
                        onChange={(event) => {
                          props.onChange(event.target.value);
                        }}
                      />
                    ),
                  }
                : {
                    title: row.uiName,
                    field: row.refName,
                    sorting: false,
                    cellStyle: { width: '20%' },

                    // lookup: { flag: 'İstanbul', flag: 'Şanlıurfa' },
                    render: (rowData) => {
                      return (
                        row.refName &&
                        rowData[row.refName] && (
                          <span
                            style={{
                              display: 'block',
                              width: row.maxLength
                                ? row.maxLength + 'vw'
                                : '10vw',
                            }}
                          >
                            {' '}
                            {rowData[row.refName]}
                          </span>
                        )
                      );
                    },
                    editComponent: (props) => (
                      <TextField
                        style={{
                          width: '20vw',
                          margin: 10,
                          fontSize: 12,
                        }}
                        fullWidth
                        value={props.value}
                        onChange={(event) => {
                          props.onChange(event.target.value);
                        }}
                      />
                    ),
                  };
            });
            let dropdowncolumns = this.state.schema
              .filter((x) => x.refLovs === '')
              .map((row) => {
                return {
                  title: row.uiName,
                  field: row.refName,
                  sorting: false,
                  cellStyle: { width: '20%' },

                  render: (rowData) => {
                    return (
                      row.refName &&
                      rowData[row.refName] && (
                        <span
                          style={{
                            display: 'block',
                            width: row.maxLength
                              ? row.maxLength + 'vw'
                              : '10vw',
                          }}
                        >
                          {' '}
                          {rowData[row.refName]}
                        </span>
                      )
                    );
                  },
                  editComponent: (props) => (
                    <TextField
                      style={{
                        width: '20vw',
                        margin: 10,
                        fontSize: 12,
                      }}
                      fullWidth
                      value={props.value}
                      onChange={(event) => {
                        props.onChange(event.target.value);
                      }}
                    />
                  ),
                };
              });
            console.log(columns);
            this.setState({ columns, loading: false });
            this.setState({ allColumns, loading: false });
          });
        });
      });
    });
  }

  versions() {
    return axios
      .get('config/version?entityName=dealModification', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  uiFields() {
    if (
      localStorage.getItem('dealModification') &&
      localStorage.dealModification_version &&
      localStorage.dealModification_version == this.state.version
    ) {
      console.log('fetching from local storage');
      try {
        this.setState({
          schema: JSON.parse(localStorage.getItem('dealModification')),
        });
      } catch (e) {
        localStorage.removeItem('dealModification');
      }
      return Promise.resolve();
    } else {
      return axios
        .get('config?entityName=dealModification', {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        })
        .then((res) => {
          let schema = [];
          schema = res.data.data.map(function (el) {
            if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
              if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
              else if (el.refLovs == null) el.refLovs = [];
            }
            return el;
          });
          if (this._isMounted) this.setState({ schema: schema });
          localStorage.setItem('dealModification', JSON.stringify(schema));
          localStorage.dealModification_version = this.state.version;
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }
  fedStatusHandler = () => {
    this.setState({
      loading: true,
    });
    return genAxios
      .post(
        process.env.REACT_APP_URL +
          'mtn/modification/dealsstatus?releaseId=' +
          this.props.releaseData.releaseId,
        {}
      )
      .then((res) => {
        this.getStatusData();
        console.log(res);
        if (res) {
          this.setState({
            fedResponse: res.data.data || [],
          });
        }
        this.setState({
          activeTab: 1,
          loading: false,
        });
      })
      .catch((error) => {
        console.log(error);
        this.setState({
          loading: false,
        });
      });
  };
  getDealData() {
    return axios
      .get(
        'mtn/modification/modifydata?releaseId=' +
          this.props.releaseData.releaseId
      )
      .then((res) => {
        console.log('deal response', res);

        if (res) {
          this.setState({
            dealData: res.data.data.map((row) => {
              return { ...row, tableData: '' };
            }),
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  modifyDeals() {
    let payload = [];
    console.log(this.state.dealData);
    payload.push(this.state.dealData);
    console.log(payload);
    this.setState({ loading: true });
    axios
      .post(
        'mtn/modification/update?releaseId=' + this.props.releaseData.releaseId,
        this.state.dealData
      )
      .then((response) => {
        console.log(response);
        // this.props.history.push("/editRelease")
        this.setState({ loading: false });
      })
      .catch((error) => {
        console.log(error);
        this.setState({ loading: false });
      });
  }

  render() {
    {
      console.log(
        'LoginInfo',
        this.props.userInfo.group.indexOf('PricingAnalyst')
      );
      console.log(this.props.releaseData.releaseId);
    }
    const { classes } = this.props;

    // {this.state.dealModificationUpload && (
    //   <DealModificationUpload
    //     schema={this.state.schema}
    //     loadDealCapture={() => {
    //       this.setState({
    //         loadingTable: true,
    //       });
    //       this.getDealData().then(() => {
    //         this.setState({
    //           loadingTable: false,
    //         });
    //       });
    //     }}
    //     show={this.state.dealModificationUpload}
    //     showDealModificationUpload={() => {
    //       this.setState({
    //         dealModificationUpload: false,
    //       });
    //     }}
    //   />
    // )}
    let dealCapture = (
      <div
        style={{
          margin: '0 auto',
          width: this.props.openDrawer
            ? `calc(100vw - 343px)`
            : 'calc(100vw - 141px)',
        }}
      >
        {this.state.dealModificaitonUpload && (
          <DealModificationUpload
            schema={this.state.schema}
            loadDealCapture={() => {
              this.setState({
                loadingTable: true,
              });
              this.getDealData().then(() => {
                this.setState({
                  loadingTable: false,
                });
              });
            }}
            show={this.state.dealModificaitonUpload}
            showDealModifictionUpload={() => {
              this.setState({
                dealModificaitonUpload: false,
              });
            }}
          />
        )}

        {/* {this.props.userInfo.group.indexOf("PricingAnalyst")===0 ?( */}
        {this.props.releaseData.releaseId ? (
          <ThemeProvider theme={theme}>
            <div
              style={{
                padding: '10px 0',
                fontSize: '24px',
                fontWeight: '600',
              }}
            >
              Deal Modification
            </div>
            <MaterialTable
              //   editable={​​​​​{​​​​​isEditable: rowData => rowData.name !== 'ucId'}​​​​​}​​​​​
              style={{ padding: '20px', marginTop: '10px' }}
              tableRef={this.selectTable}
              isLoading={this.state.loadingTable}
              icons={{
                Add: forwardRef((props, ref) => (
                  <AddBox {...props} ref={ref} />
                )),
                Check: forwardRef((props, ref) => (
                  <Check {...props} ref={ref} />
                )),
                Clear: forwardRef((props, ref) => (
                  <Clear {...props} ref={ref} />
                )),
                Delete: forwardRef((props, ref) => (
                  <DeleteOutline {...props} ref={ref} />
                )),
                DetailPanel: forwardRef((props, ref) => (
                  <ChevronRight {...props} ref={ref} />
                )),
                Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
                Export: forwardRef((props, ref) => (
                  <SaveAlt {...props} ref={ref} />
                )),
                Filter: forwardRef((props, ref) => (
                  <FilterList {...props} ref={ref} />
                )),
                FirstPage: forwardRef((props, ref) => (
                  <FirstPage {...props} ref={ref} />
                )),
                LastPage: forwardRef((props, ref) => (
                  <LastPage {...props} ref={ref} />
                )),
                NextPage: forwardRef((props, ref) => (
                  <ChevronRight {...props} ref={ref} />
                )),
                PreviousPage: forwardRef((props, ref) => (
                  <ChevronLeft {...props} ref={ref} />
                )),
                ResetSearch: forwardRef((props, ref) => (
                  <Clear {...props} ref={ref} />
                )),
                Search: forwardRef((props, ref) => (
                  <Search {...props} ref={ref} />
                )),
                SortArrow: forwardRef((props, ref) => (
                  <ArrowDownward {...props} ref={ref} />
                )),
                ThirdStateCheck: forwardRef((props, ref) => (
                  <Remove {...props} ref={ref} />
                )),
                ViewColumn: forwardRef((props, ref) => (
                  <ViewColumn {...props} ref={ref} />
                )),
                CheckBoxIcon: forwardRef((props, ref) => (
                  <CheckBoxIcon {...props} ref={ref} />
                )),
              }}
              title={`Deal Modification: ${this.props.releaseData.releaseId}`}
              columns={this.state.columns}
              data={this.state.dealData}
              lookup={this.state.columns.map((x) => {
                return x.refLovs;
              })}
              actions={[
                {
                  icon: () => (
                    <Button
                      variant='contained'
                      style={{
                        textTransform: 'capitalize',
                        background: '#ffcc00',
                        letterSpacing: '-1px',
                        fontWeight: '600',
                        color: '#000',
                        fontSize: '16px',
                        borderRadius: '50px',
                        padding: '6px 32px',
                        '&:hover': {
                          opacity: 0.8,
                          background: '#ffcc00',
                        },
                      }}
                      onClick={() => {
                        this.setState({
                          dealModificaitonUpload: true,
                        });
                      }}
                    >
                      <CloudUploadIcon style={{ marginRight: '10px' }} />
                      Upload
                    </Button>
                  ),
                  isFreeAction: true,
                },
              ]}
              editable={
                {
                  // onBulkUpdate: (changes) =>
                  // new Promise((resolve, reject) => {
                  //   setTimeout(() => {
                  //     console.log(changes);
                  //     if (Object.keys(changes).length > 0) {
                  //       let arr = [];
                  //       let payload = {};
                  //       payload.releaseId = this.props.releaseData.releaseId;
                  //       payload.createdBy = this.props.userInfo.id;
                  //       payload.createdDate = moment().format("DD-MM-YYYY");
                  //       this.setState({ loadingTable: true });
                  //       Object.keys(changes).map((row) => {
                  //         let payloadData = { ...changes[row].newData };
                  //         arr.push(payloadData);
                  //       });
                  //       payload= arr;
                  //       console.log(payload);
                  //       axios
                  //         .post("mtn/modification/update?releaseId="+this.props.releaseData.releaseId,payload)
                  //         .then((response) => {
                  //           console.log(response);
                  //           this.getDealData().then(() => {
                  //             this.setState({
                  //               loadingTable: false,
                  //             });
                  //             resolve();
                  //           });
                  //         })
                  //         .catch((error) => {
                  //           console.log(error);
                  //           this.setState({
                  //             loadingTable: false,
                  //           });
                  //           resolve();
                  //         });
                  //     } else resolve();
                  //   }, 1000);
                  // }),
                  //   onRowAdd: (newData) =>
                  //     new Promise((resolve, reject) => {
                  //       console.log("Addbutton");
                  //       console.log(this.state.rowAdd);
                  //       let payload = {
                  //         sim: "Free",
                  //         ibIncluded: "Yes",
                  //         ib: "Free",
                  //         cli: "Charge",
                  //         ...newData,
                  //       };
                  //       let request = {};
                  //       // this.state.schema.map(formElement => {
                  //       //     if (formElement.refName == 'promoStartDate'){
                  //       //         payload[formElement.refName] = moment(newData[formElement.refName]).format("DD-MM-YYYY");
                  //       //         console.log("Check")
                  //       //         console.log(formElement.refName)
                  //       //         console.log(moment(newData[formElement.refName]).format("DD-MM-YYYY"))
                  //       //     }
                  //       //     else
                  //       //         payload[formElement.refName] = newData[formElement.refName]
                  //       // })
                  //       // this.state.schema.map(formElement => {
                  //       //     if (formElement.refName == 'promoEndDate'){
                  //       //         payload[formElement.refName] = moment(newData[formElement.refName]).format("DD-MM-YYYY");
                  //       //         console.log("Check")
                  //       //         console.log(formElement.refName)
                  //       //         console.log(moment(newData[formElement.refName]).format("DD-MM-YYYY"))
                  //       //     }
                  //       //     else
                  //       //         payload[formElement.refName] = newData[formElement.refName]
                  //       // })
                  //       request.opId = this.props.userInfo.opId;
                  //       request.buId = this.props.userInfo.buId;
                  //       request.releaseId = this.props.releaseData.releaseId;
                  //       request.createdBy = this.props.userInfo.id;
                  //       request.createdDate = moment().format("DD-MM-YYYY");
                  //       // requestAdd.opId = this.props.userInfo.opId
                  //       // requestAdd.buId = this.props.userInfo.buId
                  //       // requestAdd.releaseId = this.props.releaseData.releaseId
                  //       // requestAdd.createdBy = this.props.userInfo.id
                  //       console.log(newData);
                  //       // payload.createdBy = this.props.userInfo.id
                  //       // payload.createdDate = moment().format("DD-MM-YYYY")
                  //       payload.ucId = null;
                  //       payload.releaseId = this.props.releaseData.releaseId;
                  //       request.dcBasicInfoAud = [payload];
                  //       this.setState({ loadingTable: true });
                  //       console.log(payload);
                  //       console.log(request);
                  //       axios
                  //         .post("mtn/deal/basicInfo", request)
                  //         .then((response) => {
                  //           console.log(response);
                  //           if (response) {
                  //             let dealData = [...this.state.dealData, newData];
                  //             this.setState({
                  //               dealData,
                  //             });
                  //           }
                  //           this.getDealData().then(() => {
                  //             this.setState({
                  //               loadingTable: false,
                  //             });
                  //           });
                  //           this.setState({
                  //             loadingTable: false,
                  //           });
                  //           resolve();
                  //         })
                  //         .catch((error) => {
                  //           console.log(error);
                  //           this.setState({
                  //             loadingTable: false,
                  //           });
                  //           resolve();
                  //         });
                  //     }),
                  // onRowUpdate: (newData, oldData) =>
                  //   new Promise((resolve, reject) => {
                  //     let payload = { ...newData };
                  //     let request = {};
                  //   //   console.log(newData);
                  //   payload.releaseId = this.props.releaseData.releaseId;
                  //   payload.createdBy = this.props.userInfo.id;
                  //   payload.createdDate = moment().format("DD-MM-YYYY");
                  //     this.setState({ loadingTable: true });
                  //     console.log(payload);
                  //     axios
                  //       .post("mtn/modification/update?releaseId="+this.props.releaseData.releaseId,[payload])
                  //       .then((response) => {
                  //           this.getDealData().then(() => {
                  //               this.setState({
                  //                 loadingTable: false,
                  //               });
                  //               resolve();
                  //             });
                  //         const dataUpdate = [...this.state.dealData];
                  //         const index = oldData.tableData.id;
                  //         dataUpdate[index] = newData;
                  //         this.setState({
                  //           dealData: dataUpdate,
                  //           loadingTable: false,
                  //         });
                  //         resolve();
                  //       })
                  //       .catch((error) => {
                  //         console.log(error);
                  //         this.setState({
                  //           loadingTable: false,
                  //         });
                  //         resolve();
                  //       });
                  //   }),
                }
              }
              options={{
                // selection: true,
                pageSize: 5,
                pageSizeOptions: [5, 10, 20, 30, 50, 75, 100],
                toolbar: true,
                paging: true,
                rowStyle: {
                  fontSize: '14px',
                  padding: 10,
                  background: 'rgba(0,0,0,0.04)',
                },
                headerStyle: {
                  fontSize: '13px',
                  fontWeight: 'bold',
                  textTransform: 'capitalize',
                  lineHeight: '1.2em',
                },
                // search: false,
                searchFieldAlignment: 'left',
                searchFieldVariant: 'outlined',
                showTitle: false,
                searchFieldStyle: {
                  borderRadius: 50,
                  border: '1px solid rgba(0, 0, 0, 0.04)',
                  background: 'rgba(0, 0, 0, 0.04)',
                  height: 40,
                  width: 320,
                },
              }}
              onSelectionChange={(selection) => {
                console.log(selection);
                this.setState({ isSelected: !!selection.length });
                this.props.setUCId(
                  selection.map((x) => {
                    return x.ucId; //&& localStorage.setItem("UcId",x.ucId)
                  })
                );
              }}
              components={{
                Toolbar: (props) => (
                  <div>
                    <div
                      style={{
                        fontSize: '18px',
                        fontWeight: '600',
                        marginLeft: '24px',
                      }}
                    >
                      {props.title}
                    </div>
                    <div>
                      <MTableToolbar {...props} />
                    </div>
                  </div>
                ),
                Pagination: (props) => {
                  return <CustomPaginationComponent {...props} />;
                },
              }}
            />
            <div style={{ textAlign: 'center', margin: '20px 0' }}>
              {/* <Button
                variant="contained"
                style={{
                  marginRight: "20px",
                }}
                type="submit"
                className={classes.btn}
                // onClick={() => this.props.history.push("/editRelease",this.props.setDealModification(this.state.location))}
                onClick={(event, data) => {
                  this.modifyDeals();
                }}
              >
                Validate and Transform
              </Button> */}
              <Button
                // disabled={!this.state.isSelected}
                disabled={!this.state.dealData.length}
                style={{
                  marginRight: '20px',
                }}
                onClick={(event) => {
                  // setLoading(true);
                  let group = axios //+ '&businessId=' +  this.props.userInfo.group[0]
                    .post(
                      'mtn/modification/dealsval?releaseId=' +
                        this.props.releaseData.releaseId +
                        '&businessId=' +
                        this.props.userInfo.group[0],
                      {}
                    )
                    .then((response) => {
                      // console.log(response);
                      //     setLoading(false);
                      this.setState({ showDealData: true });
                    })
                    .catch((error) => {
                      console.log(error);
                      // setLoading(false);
                    });
                }}
              >
                Validate Deals
              </Button>
              <Button
                // disabled={!this.state.isSelected}
                disabled={
                  !this.state.dealData.length
                  // &&
                  // this.props.releaseData.releaseStatus !==
                  //   'Validated And Transformed'
                }
                onClick={(event) => {
                  this.setState({ showFederate: true });
                }}
                style={{
                  marginRight: '20px',
                }}
              >
                Federate Deals
              </Button>
            </div>
          </ThemeProvider>
        ) : (
          'Outside Release'
        )}
        <div>
          <Modal
            show={this.state.modalOpen}
            modalClosed={this.handleClose}
            title={'Derived Data'}
          >
            <MaterialTable
              tableRef={this.selectDrivedTable}
              isLoading={this.state.loadingTable}
              icons={tableIcons}
              title={'Drived Data'}
              columns={this.state.allColumns}
              data={this.state.derivedData}
              actions={[
                {
                  icon: () => (
                    <Button
                      variant='contained'
                      style={{
                        textTransform: 'capitalize',
                        background: '#ffcc00',
                        letterSpacing: '-1px',
                        fontWeight: '600',
                        color: '#000',
                        fontSize: '16px',
                        borderRadius: '50px',
                        padding: '6px 32px',
                        '&:hover': {
                          opacity: 0.8,
                          background: '#ffcc00',
                        },
                      }}
                      onClick={() => {
                        this.saveAsDrivedExcel();
                      }}
                    >
                      <SaveAlt style={{ marginRight: '10px' }} />
                      Export
                    </Button>
                  ),
                  isFreeAction: true,
                },
              ]}
              options={{
                pageSize: 1,
                search: false,
                paging: true,
                toolbar: true,
                rowStyle: {
                  fontSize: '15px',
                  padding: 8,
                },
                headerStyle: {
                  fontWeight: 'bold',
                },
              }}
            />
          </Modal>
        </div>

        {this.state.showDealData ? (
          <DealData
            showDealData={() => this.setState({ showDealData: false })}
            releaseData={this.props.releaseData}
            userInfo={this.props.userInfo}
          />
        ) : null}

        {this.state.showFederate ? (
          <Federate
            showFederate={() => this.setState({ showFederate: false })}
            releaseData={this.props.releaseData}
            userInfo={this.props.userInfo}
          />
        ) : null}
      </div>
    );

    if (this.state.loading) dealCapture = <Loader />;

    return dealCapture;
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    setUCId: (data) => dispatch({ type: actionTypes.SET_UCID, data: data }),
    setDealModification: (data) =>
      dispatch({ type: actionTypes.Deal_Modification, data: data }),
  };
};
const mapStateToProps = (state) => {
  return {
    releaseData: state.releaseData.releaseData,
    userInfo: state.login.loggedInUserInfo,
    openDrawer: state.drawerData.open,
    dropdowns: state.dropdownData,
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(DealModification, axios)));
