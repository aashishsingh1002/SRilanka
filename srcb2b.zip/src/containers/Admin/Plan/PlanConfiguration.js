import React, { Component } from 'react';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../../axios-epc';
import { connect } from 'react-redux';
import TextField from '@material-ui/core/TextField';
import CustomTable from '../../../UI/Table/Table';
import Loader from '../../../UI/Loader/Loader';
import Select from 'react-select';
import CreatableSelect from 'react-select/creatable';
import EditIcon from '@material-ui/icons/Edit';
import IconButton from '@material-ui/core/IconButton';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import SaveIcon from '@material-ui/icons/Save';

const useStyles = (theme) => ({
  cardHeader: {
    background: '#546D7A',
    height: '4vh',
  },
  subheader: {
    color: 'white',
  },
  heading: {
    // fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
  selectMenuOuter: { top: 'auto', bottom: '100%' },
});

const options = [
  { value: 'NumberInput', label: 'NumberInput' },
  { value: 'TextInput', label: 'TextInput' },
  { value: 'Checkbox', label: 'Checkbox' },
  { value: 'TextArea', label: 'TextArea' },
  { value: 'Date', label: 'Date' },
  { value: 'SelectInput', label: 'SelectInput' },
  { value: 'MultiSelect', label: 'MultiSelect' },
  { value: 'Range', label: 'Range' },
];

class PlanConfiguration extends Component {
  _isMounted = false;

  state = {
    loading: true,
    columns: [
      {
        title: 'UI Name',
        field: 'uiName',
        sorting: false,
        render: (rowData) => (
          <TextField
            fullWidth
            value={rowData.uiName}
            onChange={(event) => {
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.refId === rowData.refId
                    ? {
                        ...el,
                        uiName: event.target.value,
                      }
                    : el
                ),
              });
            }}
          />
        ),
        cellStyle: { width: '15%' },
      },
      {
        title: 'Reference Name',
        field: 'refName',
        sorting: false,
        render: (rowData) => (
          <TextField
            fullWidth
            value={rowData.refName}
            onChange={(event) => {
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.refId === rowData.refId
                    ? {
                        ...el,
                        refName: event.target.value,
                      }
                    : el
                ),
              });
            }}
          />
        ),
        cellStyle: { width: '15%' },
      },
      {
        title: 'Reference Type',
        field: 'refType',
        sorting: false,
        render: (rowData) => (
          <Select
            menuPortalTarget={document.body}
            styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
            onChange={(selectedOption) => {
              console.log(selectedOption);
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.refId === rowData.refId
                    ? {
                        ...el,
                        refType: selectedOption.value,
                      }
                    : el
                ),
              });
            }}
            options={options}
            value={{
              value: rowData.refType,
              label: rowData.refType,
            }}
            menuPortalTarget={document.body}
            styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
          />
        ),
        cellStyle: { width: '20%' },
      },
      {
        title: 'Reference Lovs',
        field: 'refLovs',
        sorting: false,
        render: (rowData) =>
          rowData.refType === 'SelectInput' ||
          rowData.refType === 'MultiSelect' ? (
            <CreatableSelect
              isMulti
              onChange={(selectedOptions) => {
                console.log(selectedOptions);
                let lovs = [];
                if (selectedOptions) {
                  selectedOptions.map((lov) => {
                    lovs.push(lov.value);
                  });
                }
                this.setState({
                  schema: this.state.schema.map((el) =>
                    el.refId === rowData.refId
                      ? {
                          ...el,
                          refLovs: lovs,
                        }
                      : el
                  ),
                });
              }}
              value={
                rowData.refLovs
                  ? rowData.refLovs.map((lov) => {
                      return {
                        value: lov,
                        label: lov,
                      };
                    })
                  : []
              }
              options={
                rowData.refLovs
                  ? rowData.refLovs.map((lov) => {
                      return {
                        value: lov,
                        label: lov,
                      };
                    })
                  : []
              }
            />
          ) : (
            'N/A'
          ),
        cellStyle: { width: '30%' },
      },
      {
        title: 'Order',
        field: 'displayOrder',
        sorting: false,
        render: (rowData) => (
          <TextField
            fullWidth
            value={rowData.displayOrder}
            onChange={(event) => {
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.refId === rowData.refId
                    ? {
                        ...el,
                        displayOrder: event.target.value,
                      }
                    : el
                ),
              });
            }}
          />
        ),
        cellStyle: { width: '5%' },
      },
      {
        title: 'Display',
        field: 'isDisplay',
        sorting: false,
        render: (rowData) => (
          <Select
            menuPortalTarget={document.body}
            styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
            onChange={(selectedOption) => {
              console.log(selectedOption);
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.refId === rowData.refId
                    ? {
                        ...el,
                        isDisplay: selectedOption.value,
                      }
                    : el
                ),
              });
            }}
            options={[
              {
                value: 'Y',
                label: 'Y',
              },
              {
                value: 'N',
                label: 'N',
              },
            ]}
            value={{
              value: rowData.isDisplay,
              label: rowData.isDisplay,
            }}
            menuPortalTarget={document.body}
            styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
          />
        ),
        cellStyle: { width: '5%' },
      },
      {
        title: 'Mandatory',
        field: 'isMandatory',
        sorting: false,
        render: (rowData) => (
          <Select
            menuPortalTarget={document.body}
            styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
            onChange={(selectedOption) => {
              console.log(selectedOption);
              this.setState({
                schema: this.state.schema.map((el) =>
                  el.refId === rowData.refId
                    ? {
                        ...el,
                        isMandatory: selectedOption.value,
                      }
                    : el
                ),
              });
            }}
            options={[
              {
                value: 'Y',
                label: 'Y',
              },
              {
                value: 'N',
                label: 'N',
              },
            ]}
            value={{
              value: rowData.isMandatory,
              label: rowData.isMandatory,
            }}
            menuPortalTarget={document.body}
            styles={{ menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
          />
        ),
        cellStyle: { width: '5%' },
      },
      {
        title: 'Edit',
        field: 'edit',
        render: (rowData) => (
          <IconButton
            onClick={() => {
              let payload = { ...rowData };
              if (
                payload.refType === 'SelectInput' ||
                payload.refType === 'MultiSelect'
              )
                payload.refLovs = payload.refLovs.join();
              else payload.refLovs = null;
              payload.opId = this.props.userInfo.opId;
              payload.buId = this.props.userInfo.buId;
              this.setState({ loading: true });
              axios
                .post('config', payload)
                .then((response) => {
                  console.log(response);
                  this.setState({ loading: false });
                })
                .catch((error) => {
                  console.log(error);
                  if (this._isMounted) this.setState({ loading: false });
                });
            }}
          >
            <EditIcon />
          </IconButton>
        ),
        sorting: false,
      },
    ],
    schema: [],
    addField: {
      refId: null,
      entityName: 'package.basicDetails',
      refName: '',
      uiName: '',
      refLovs: [],
      refType: '',
      displayOrder: null,
      isDisplay: '',
      isMandatory: '',
      uiGroup: null,
      groupName: null,
    },
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    console.log('moued');
    console.log(this.state.schema);
    this.uiFields().then(() => {
      this.setState({ loading: false });
    });
  }

  uiFields() {
    return axios
      .get('config/entity?entityName=package.basicDetails', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        let schema = [];
        schema = res.data.data.map(function (el) {
          if (el.refType === 'SelectInput' || el.refType === 'MultiSelect') {
            if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
            else if (el.refLovs == null) el.refLovs = [];
          }
          return el;
        });
        console.log(schema);
        if (this._isMounted) this.setState({ schema: schema });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  render() {
    const { classes } = this.props;

    let planConfiguration = (
      <div>
        <div
          style={
            this.state.loading ? { display: 'none' } : { display: 'block' }
          }
        >
          <CustomTable
            pageSize={10}
            title='Package Configuration'
            data={this.state.schema}
            columns={this.state.columns}
          />

          <Card style={{ overflow: 'visible', marginTop: '3vh' }}>
            <CardHeader
              className={classes.cardHeader}
              classes={{
                subheader: classes.subheader,
              }}
              subheader={'Add Field'}
            />

            <CardContent>
              <TableContainer component={Paper}>
                <Table className={classes.table} size='small'>
                  <TableHead>
                    <TableRow>
                      <TableCell>UI Name</TableCell>
                      <TableCell>Reference Name</TableCell>
                      <TableCell>Reference Type</TableCell>
                      <TableCell>Reference Lovs</TableCell>
                      <TableCell>Display</TableCell>
                      <TableCell>Mandatory</TableCell>
                      <TableCell>Save</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableRow>
                      <TableCell style={{ width: '15%' }}>
                        <TextField
                          fullWidth
                          value={this.state.addField.uiName}
                          onChange={(event) => {
                            let val = event.target.value;
                            this.setState((prevState) => {
                              return {
                                addField: {
                                  ...prevState.addField,
                                  uiName: val,
                                },
                              };
                            });
                          }}
                        />
                      </TableCell>
                      <TableCell style={{ width: '15%' }}>
                        <TextField
                          fullWidth
                          value={this.state.addField.refName}
                          onChange={(event) => {
                            let val = event.target.value;

                            this.setState((prevState) => {
                              return {
                                addField: {
                                  ...prevState.addField,
                                  refName: val,
                                },
                              };
                            });
                          }}
                        />
                      </TableCell>
                      <TableCell style={{ width: '20%' }}>
                        <Select
                          menuPlacement='top'
                          menuPortalTarget={document.body}
                          styles={{
                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                          }}
                          onChange={(selectedOption) => {
                            this.setState((prevState) => {
                              return {
                                addField: {
                                  ...prevState.addField,
                                  refType: selectedOption.value,
                                },
                              };
                            });
                          }}
                          options={options}
                          value={{
                            value: this.state.addField.refType,
                            label: this.state.addField.refType,
                          }}
                          menuPortalTarget={document.body}
                          styles={{
                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                          }}
                        />
                      </TableCell>
                      <TableCell style={{ width: '30%' }}>
                        {this.state.addField.refType === 'SelectInput' ||
                        this.state.addField.refType === 'MultiSelect' ? (
                          <CreatableSelect
                            isMulti
                            onChange={(selectedOptions) => {
                              console.log(selectedOptions);
                              let lovs = [];
                              if (selectedOptions) {
                                selectedOptions.map((lov) => {
                                  lovs.push(lov.value);
                                });
                              }
                              this.setState((prevState) => {
                                return {
                                  addField: {
                                    ...prevState.addField,
                                    refLovs: lovs,
                                  },
                                };
                              });
                            }}
                            value={
                              this.state.addField.refLovs
                                ? this.state.addField.refLovs.map((lov) => {
                                    return {
                                      value: lov,
                                      label: lov,
                                    };
                                  })
                                : []
                            }
                            options={
                              this.state.addField.refLovs
                                ? this.state.addField.refLovs.map((lov) => {
                                    return {
                                      value: lov,
                                      label: lov,
                                    };
                                  })
                                : []
                            }
                          />
                        ) : (
                          'N/A'
                        )}
                      </TableCell>
                      <TableCell style={{ width: '7%' }}>
                        <Select
                          menuPlacement='top'
                          menuPortalTarget={document.body}
                          styles={{
                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                          }}
                          onChange={(selectedOption) => {
                            this.setState((prevState) => {
                              return {
                                addField: {
                                  ...prevState.addField,
                                  isDisplay: selectedOption.value,
                                },
                              };
                            });
                          }}
                          options={[
                            {
                              value: 'Y',
                              label: 'Y',
                            },
                            {
                              value: 'N',
                              label: 'N',
                            },
                          ]}
                          value={{
                            value: this.state.addField.isDisplay,
                            label: this.state.addField.isDisplay,
                          }}
                          menuPortalTarget={document.body}
                          styles={{
                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                          }}
                        />
                      </TableCell>

                      <TableCell style={{ width: '7%' }}>
                        <Select
                          menuPlacement='top'
                          menuPortalTarget={document.body}
                          styles={{
                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                          }}
                          onChange={(selectedOption) => {
                            console.log(selectedOption);
                            this.setState((prevState) => {
                              return {
                                addField: {
                                  ...prevState.addField,
                                  isMandatory: selectedOption.value,
                                },
                              };
                            });
                          }}
                          options={[
                            {
                              value: 'Y',
                              label: 'Y',
                            },
                            {
                              value: 'N',
                              label: 'N',
                            },
                          ]}
                          value={{
                            value: this.state.addField.isMandatory,
                            label: this.state.addField.isMandatory,
                          }}
                          menuPortalTarget={document.body}
                          styles={{
                            menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                          }}
                        />
                      </TableCell>

                      <TableCell>
                        <IconButton
                          onClick={() => {
                            let payload = { ...this.state.addField };
                            console.log(payload);

                            if (
                              payload.refType == 'SelectInput' ||
                              payload.refType == 'MultiSelect'
                            )
                              payload.refLovs = payload.refLovs.join();
                            else payload.refLovs = null;
                            payload.opId = this.props.userInfo.opId;
                            payload.buId = this.props.userInfo.buId;
                            this.setState({ loading: true });
                            axios
                              .post('config', payload)
                              .then((response) => {
                                let item = {
                                  refId: null,
                                  entityName: 'package.basicDetails',
                                  refName: '',
                                  uiName: '',
                                  refLovs: [],
                                  refType: '',
                                  displayOrder: null,
                                  isDisplay: '',
                                  isMandatory: '',
                                  uiGroup: null,
                                  groupName: null,
                                };
                                console.log(response.data.data);
                                let newField = response.data.data;
                                if (
                                  newField.refType == 'SelectInput' ||
                                  newField.refType == 'MultiSelect'
                                )
                                  newField.refLovs =
                                    newField.refLovs.split(',');
                                let schema = [...this.state.schema];
                                schema.push(newField);
                                this.setState({
                                  loading: false,
                                  schema: schema,
                                  addField: item,
                                });
                              })
                              .catch((error) => {
                                console.log(error);
                                if (this._isMounted)
                                  this.setState({ loading: false });
                              });
                          }}
                        >
                          <SaveIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </div>
        {this.state.loading && <Loader />}
      </div>
    );
    return planConfiguration;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
  };
};

export default connect(mapStateToProps)(
  withStyles(useStyles)(WithErrorHandler(PlanConfiguration, axios))
);
