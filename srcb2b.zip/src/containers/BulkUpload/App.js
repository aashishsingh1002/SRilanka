import React, { Component } from 'react';
import { Route, Switch, Redirect, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Login from './containers/Login/Login';
import Dashboard from './containers/Dashboard/Dashboard';
import Layout from './HOC/Layout/Layout';
import Worklist from './containers/Worklist/Worklist';
import EditRelease from './containers/EditRelease/EditRelease';
import PlanConfiguration from './containers/Entities/Package/PlanConfiguration';
import * as actionTypes from './store/actions/actionTypes';
import ProductConfiguration from './containers/Entities/Product/ProductConfiguration';
import Contract from './containers/EntityCreation/Contract';
import ContractProfile from './containers/EntityCreation/ContractProfile';
import Attribute from './containers/EntityCreation/Attribute';
import RatePlan from './containers/EntityCreation/RatePlan/RatePlan';
import WorkflowAdmin from './containers/WorkflowAdmin/WorkflowAdmin';
import Admin from './containers/Admin/Admin';
import ProductPerformance from './containers/ProductPerformance/ProductPerformance';
import Events from './containers/EntityCreation/Events';
import AdminPlanConfiguration from './containers/Admin/Plan/PlanConfiguration';
import AdminProductConfiguration from './containers/Admin/Product/ProductConfiguration';
import AdminOfferabilityConfiguration from './containers/Admin/Offerability/OfferabilityConfiguration';
import BundleContractConfiguration from './containers/Admin/Contract/BundleContractConfiguration';
import ContractCreationConfiguration from './containers/Admin/Contract/ContractCreationConfiguration';
import ContractProfileConfiguration from './containers/Admin/ContractProfile/ContractProfileConfiguration';
import AttributeConfiguration from './containers/Admin/Attribute/AttributeConfiguration';
import AttributeGroupConfiguration from './containers/Admin/Attribute/AttributeGroupConfiguration';
import RatePlanConfiguration from './containers/Admin/RatePlan/RatePlanConfiguration';
import RentalConfiguration from './containers/Admin/Rental/RentalConfiguration';
import DiscountConfiguration from './containers/Admin/Discount/DiscountConfiguration';
import CtsConfiguration from './containers/Admin/Product/CtsConfiguration';
import UserConfiguration from './containers/Admin/User/UserConfiguration';
import AdvanceSearch from './containers/AdvanceSearch/AdvanceSearch';
import DependencyMatrix from './containers/Admin/DependencyMatrix/DependencyMatrix';
import PlanReport from './containers/Library/PlanReport';
import DealReport from './containers/Library/DealReport';
import Devices from './containers/BulkUpload/Devices';
import Bundles from './containers/BulkUpload/Bundles';
import DealCapture from './containers/BulkUpload/DealCapture';
import DevMarket from './containers/BulkUpload/DevMarket';
import ExtendedDeals from './containers/BulkUpload/ExtendedDeals';
import IlulaDeals from './containers/BulkUpload/IlulaDeals';
import PackageProfile from './containers/BulkUpload/PackageProfile';
import Tiers from './containers/BulkUpload/Tiers';
import BasePackages from './containers/BulkUpload/BasePackages';
import Setup from './containers/BulkUpload/Setup';
import CsvTable from './containers/EditRelease/CsvTable';
import SvConfiguration from './containers/EditRelease/SvConfiguration';
import DealModification from './containers/BulkUpload/DealModification';
import AllDeals from './containers/BulkUpload/AllDeals';
import TariffMigration from './containers/TariffMigration';
import YellowTrader from './containers/YellowTrader';
import Decommission from './containers/Decommissioning';
import ValidateTransformRelease from './containers/EditRelease/ValidateTransformRelease';
import FederateScreen from './containers/EditRelease/FederateScreen';

class App extends Component {
  componentDidMount() {
    console.log('enviroment variable');
    console.log(process.env.REACT_APP_URL);
  }

  render() {
    let routes = (
      <Switch>
        <Route path='/login' component={Login} />
        <Redirect to='/login' />
      </Switch>
    );

    //"Admin"
    if (Object.keys(this.props.userInfo).length > 0) {
      if (this.props.userInfo.group.includes('PricingAnalyst')) {
        routes = (
          <Switch>
            <Route
              path='/'
              exact
              render={() => {
                this.props.onReleaseExit();
                return <Dashboard />;
              }}
            />
            <Route
              path='/login'
              render={() => {
                console.log('logout');
                console.log(Object.keys(this.props.userInfo).length);

                if (Object.keys(this.props.userInfo).length > 0)
                  return <Dashboard />;
                else return <Login />;
              }}
            />
            <Route path='/worklist' exact component={Worklist} />
            <Route path='/editRelease' exact component={EditRelease} />
            <Route
              path='/validateTransformRelease'
              exact
              component={ValidateTransformRelease}
            />
            <Route path='/federate' exact component={FederateScreen} />
            <Route path='/siebelConfiguration' exact component={CsvTable} />
            <Route path='/svCongiguration' exact component={SvConfiguration} />
            <Route path='/tariff' exact component={TariffMigration} />
            <Route
              path='/planConfiguration'
              exact
              component={PlanConfiguration}
            />
            <Route
              path='/productConfiguration'
              exact
              component={ProductConfiguration}
            />
            <Route path='/contractsCreation' exact component={Contract} />
            <Route
              path='/contractProfileCreation'
              exact
              component={ContractProfile}
            />
            <Route path='/attributeConfiguration' exact component={Attribute} />
            <Route path='/ratePlanConfiguration' exact component={RatePlan} />
            <Route
              path='/productPerformance'
              exact
              component={ProductPerformance}
            />
            <Route path='/events' exact component={Events} />
            <Route path='/advanceSearch' exact component={AdvanceSearch} />
            <Route path='/libraryPlanReport' exact component={PlanReport} />
            <Route path='/libraryDealReport' exact component={DealReport} />
            <Route path='/bulkUploadDevices' exact component={Devices} />
            <Route
              path='/bulkUploadDealCapture'
              exact
              component={DealCapture}
            />
            <Route
              path='/dealModification'
              exact
              component={DealModification}
            />
            <Route path='/allDeals' exact component={AllDeals} />
            <Route
              path='/bulkUploadBasePackages'
              exact
              component={BasePackages}
            />
            <Route path='/bulkUploadDevMarket' exact component={DevMarket} />
            <Route path='/bulkUploadBundles' exact component={Bundles} />
            <Route
              path='/bulkUploadPackageProfile'
              exact
              component={PackageProfile}
            />
            <Route path='/bulkUploadTiers' exact component={Tiers} />
            <Route path='/bulkUploadDevices' exact component={Devices} />
            <Route path='/bulkUploadSetup' exact component={Setup} />
            <Route path='/extendedDeals' exact component={ExtendedDeals} />
            <Route path='/ilulaDeals' exact component={IlulaDeals} />
            <Route path='/tariff' exact component={TariffMigration} />
            <Route path='/yellowTrader' exact component={YellowTrader} />
            <Route path='/decommission' exact component={Decommission} />
            <Redirect to='/' />
          </Switch>
        );
      } else if (this.props.userInfo.group.includes('Admin')) {
        routes = (
          <Switch>
            <Route
              path='/login'
              render={() => {
                console.log('logout');
                console.log(Object.keys(this.props.userInfo).length);

                if (Object.keys(this.props.userInfo).length > 0)
                  return <Admin />;
                else return <Login />;
              }}
            />
            <Route path='/adminDashboard' exact component={Admin} />
            <Route
              path='/adminPlanConfiguration'
              exact
              component={AdminPlanConfiguration}
            />
            <Route
              path='/adminProductConfiguration'
              exact
              component={AdminProductConfiguration}
            />
            <Route
              path='/adminOfferabilityConfiguration'
              exact
              component={AdminOfferabilityConfiguration}
            />
            <Route
              path='/adminBundleContractConfiguration'
              exact
              component={BundleContractConfiguration}
            />
            <Route
              path='/adminContractCreationConfiguration'
              exact
              component={ContractCreationConfiguration}
            />
            <Route
              path='/adminContractProfileConfiguration'
              exact
              component={ContractProfileConfiguration}
            />
            <Route
              path='/adminAttrConfiguration'
              exact
              component={AttributeConfiguration}
            />
            <Route
              path='/adminAttrGrpConfiguration'
              exact
              component={AttributeGroupConfiguration}
            />
            <Route
              path='/adminRatePlanConfiguration'
              exact
              component={RatePlanConfiguration}
            />
            <Route
              path='/adminRentalConfiguration'
              exact
              component={RentalConfiguration}
            />
            <Route
              path='/adminDiscountConfiguration'
              exact
              component={DiscountConfiguration}
            />
            <Route
              path='/adminCtsConfiguration'
              exact
              component={CtsConfiguration}
            />
            <Route
              path='/adminuserConfiguration'
              exact
              component={UserConfiguration}
            />
            <Route path='/adminWorklist' exact component={WorkflowAdmin} />
            <Route
              path='/dependencyMatrix'
              exact
              component={DependencyMatrix}
            />

            <Redirect to='/adminDashboard' />
          </Switch>
        );
      } else {
        routes = (
          <Switch>
            <Route path='/worklist' exact component={Worklist} />
            <Route
              path='/login'
              render={() => {
                console.log('logout');
                console.log(Object.keys(this.props.userInfo).length);

                if (Object.keys(this.props.userInfo).length > 0)
                  return <Worklist />;
                else return <Login />;
              }}
            />
            <Redirect to='/worklist' />
          </Switch>
        );
      }
    }

    return (
      <div
      // style={
      //   ["/siebelConfiguration", "/events"].includes(
      //     this.props.location.pathname
      //   )
      //     ? {
      //         transform: "scale(.8)",
      //         width: "125vw",
      //         height: "100vh",
      //         marginLeft: "-12.7vw",
      //         // marginRight: '-10vw',
      //         marginTop: "-10vh",
      //       }
      //     : null
      // }
      >
        <Layout>{routes}</Layout>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onReleaseExit: () =>
      dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: {} }),
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(App));
