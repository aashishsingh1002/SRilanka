import React, { Component } from "react";
import Box from "@material-ui/core/Box";
import Grid from "@material-ui/core/Grid";
import CustomInput from "../../../UI/Input/Input";
import TextField from "@material-ui/core/TextField";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import { withStyles } from "@material-ui/core/styles";
import IconButton from "@material-ui/core/IconButton";
import SearchIcon from "@material-ui/icons/Search";
import WithErrorHandler from "../../../HOC/WithErrorHandler/WithErrorHandler";
import axios from "axios";
import Loader from "../../../UI/Loader/Loader";
import Button from "../../../UI/Button/Button";
// import Button from "@material-ui/core/Button";
import Modal from "../../../UI/Modal/Modal";
import Typography from "@material-ui/core/Typography";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import DeleteIcon from "@material-ui/icons/Delete";
import Paper from "@material-ui/core/Paper";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import moment from "moment";
import { connect } from "react-redux";
import * as actionTypes from "../../../store/actions/actionTypes";
import { withRouter } from "react-router-dom";
import MultiSelect from "../../../UI/Input/MultiSelect";
import Snackbar from "../../../UI/Snackbar/Snackbar";
import FormHelperText from "@material-ui/core/FormHelperText";

const useStyles = (theme) => ({
  cardHeader: {
    // background: '#546D7A',
    // height: '4vh',
    paddingBottom: 0,
  },
  subheader: {
    color: "rgba(0, 0, 0, 0.87)",
    fontSize: "18px",
    fontWeight: "600",
    // color: 'white',
    // fontWeight: 'bold'
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "96%",
    flexShrink: 0,
  },
  table: {
    minWidth: 650,
  },
});

class BundleItems extends Component {
  _isMounted = false;

  state = {
    loading: true,
    version: "",
    categories: [],
    categoryOptions: [],
    types: [],
    typesOptions: [],
    subTypes: [],
    subTypesOptions: [],
    selCategories: ["Inclusive Product"],
    selTypes: [],
    selSubtypes: [],
    products: [],
    show: false,
    modalContent: null,
    selProduct: "",
    bundleItemsProducts: {},
    bundleType: "Product",
    bundleItems: [],
    selbundleItem: null,
    openSnack: false,
    messageSnack: "",
    isRequired: true,
  };
  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    this.versionsHandler().then(() => {
      this.fieldsLov().then(() => {
        let categoryOptions = [];
        let typesOptions = [];
        let subTypesOptions = [];

        this.state.categories.map((category) => {
          categoryOptions.push(category.uiName);
        });
        this.state.types.map((type) => {
          typesOptions.push(type.uiName);
        });
        this.state.subTypes.map((subType) => {
          subTypesOptions.push(subType.uiName);
        });

        this.setState({
          categoryOptions: Array.from(new Set(categoryOptions)),
          typesOptions: Array.from(new Set(typesOptions)),
          subTypesOptions: Array.from(new Set(subTypesOptions)),
        });
        this.packageBundleItemsData().then(() => {
          this.setState({ loading: false });
        });
      });
    });
  }
  //   isDisabled() {
  //     let unitVlaid = false;
  //     let uomValid = false;

  //     if (this.state.email === "") {
  //         this.setState({
  //             email_error_text: null
  //         });
  //     }
  // }
  fieldsLov() {
    if (
      localStorage.getItem("bundleCategories") &&
      localStorage.getItem("bundleSubTypes") &&
      localStorage.getItem("bundleTypes") &&
      localStorage.productCts_version &&
      localStorage.productCts_version == this.state.version
    ) {
      console.log("fetching cts from local storage");
      try {
        this.setState({
          categories: JSON.parse(localStorage.getItem("bundleCategories")),
          subTypes: JSON.parse(localStorage.getItem("bundleSubTypes")),
          types: JSON.parse(localStorage.getItem("bundleTypes")),
        });
      } catch (e) {
        localStorage.removeItem("bundleCategories");
        localStorage.removeItem("bundleSubTypes");
        localStorage.removeItem("bundleTypes");
      }
      return Promise.resolve();
    } else {
      console.log("fetching cst from api");
      return axios
        .all([
          axios.get(
            process.env.REACT_APP_URL +
              "config?entityName=bundleItems.categoryList",
            {
              headers: {
                opId: this.props.userInfo.opId,
                buId: this.props.userInfo.buId,
              },
            }
          ),
          axios.get(
            process.env.REACT_APP_URL +
              "config?entityName=bundleItems.subTypeList",
            {
              headers: {
                opId: this.props.userInfo.opId,
                buId: this.props.userInfo.buId,
              },
            }
          ),
          axios.get(
            process.env.REACT_APP_URL +
              "config?entityName=bundleItems.typeList",
            {
              headers: {
                opId: this.props.userInfo.opId,
                buId: this.props.userInfo.buId,
              },
            }
          ),
        ])
        .then(
          axios.spread((resCategories, resSubTypes, resTypes) => {
            let types = resTypes.data.data;
            localStorage.setItem("bundleTypes", JSON.stringify(types));
            let subTypes = resSubTypes.data.data;
            localStorage.setItem("bundleSubTypes", JSON.stringify(subTypes));
            let categories = resCategories.data.data;
            localStorage.setItem(
              "bundleCategories",
              JSON.stringify(categories)
            );
            if (this._isMounted)
              this.setState({
                categories: categories,
                subTypes: subTypes,
                types: types,
              });
            localStorage.productCts_version = this.state.version;
          })
        )
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  }

  versionsHandler() {
    return axios
      .get(
        process.env.REACT_APP_URL + "config/version?entityName=bundles.cts",
        {
          headers: {
            opId: this.props.userInfo.opId,
            buId: this.props.userInfo.buId,
          },
        }
      )
      .then((res) => {
        if (this._isMounted) this.setState({ version: res.data.data.version });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  searchProducts = () => {
    this.setState({
      loading: false,
      selProduct: null,
    });
    let payload = {};
    payload.releaseId = this.props.releaseData.releaseId;
    payload.categoryList = this.state.selCategories;
    payload.typeList = this.state.selTypes;
    payload.subTypeList = this.state.selSubtypes;
    console.log(payload);
    // .post(process.env.REACT_APP_URL + "package/bundle/ctsProducts", payload, {
    axios
      .post(
        process.env.REACT_APP_URL + "mtn/product/bundle/ctsProducts",
        payload,
        {
          headers: {
            opId: this.props.userInfo.opId,
          },
        }
      )
      .then((res) => {
        // const res = {
        //   data: {
        //     data: [
        //       {
        //         productId: "Id",
        //         ruleCode: "Rule Code",
        //         productDesc: "desccc[300]",
        //       },
        //       {
        //         productId: "Id",
        //         ruleCode: "Rule Code",
        //         productDesc: "desccc",
        //       },
        //     ],
        //   },
        // };
        // console.log(res.data.data);
        let products = [];
        if (res.data.data.length > 0) {
          res.data.data.map((product) => {
            products.push(product.productId + "/" + product.productDesc);
          });
          if (this._isMounted)
            // this.setState({ loading: false, products: products });
            this.setState({ loading: false, products: res.data.data });
        } else {
          let modalContent = (
            <Typography variant="h6">No Products Found.</Typography>
          );
          if (this._isMounted)
            this.setState({
              modalContent: modalContent,
              show: true,
              loading: false,
              products: [],
            });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  modifyColor = (description) => {
    var matches = description.match(/\[(.*?)\]/);

    if (matches) {
      var submatch = matches[0];
      var submatch0 = description.split(submatch)[0];
    }

    return (
      <>
        {submatch0 || description}{" "}
        <span style={{ color: "#ff0000" }}>{submatch}</span>
      </>
    );
  };

  errorConfirmedHandler = () => {
    this.setState({ show: false });
  };

  saveBundleItem = () => {
    if (this.props.packageData.packageId) {
      if (this._isMounted) this.setState({ loading: true });
      let payload = {};
      let date = moment().format("DD-MMM-YY");
      let listOfPpmPackageProdMapAud = [];
      payload.packageId = this.props.packageData.packageId;
      payload.releaseId = this.props.releaseData.releaseId;
      Object.keys(this.state.bundleItemsProducts).forEach((key) => {
        let bundleItem = {};
        bundleItem.buId = this.props.userInfo.buId;
        bundleItem.createdBy = this.props.userInfo.id;
        bundleItem.createdDate = date;
        bundleItem.opId = this.props.userInfo.opId;
        bundleItem.startDate = date;
        bundleItem.endDate = "31-dec-31";
        bundleItem.version = "1.0";
        bundleItem.packageId = this.props.packageData.packageId;
        bundleItem.packageProductId = key;
        bundleItem.productId = key;
        // bundleItem.defaultState =
        //   this.state.bundleItemsProducts[key].formData.defaultState;
        // if (
        //   this.state.bundleItemsProducts[key].formData.defaultState ==
        //   'Mandatory'
        // )
        //   bundleItem.mandatory = 'Y';
        // else bundleItem.mandatory = 'N';
        bundleItem.mandatory = "Y";
        bundleItem.defaultState =
          this.state.bundleItemsProducts[key].formData.defaultState;
        bundleItem.catalogId =
          this.state.bundleItemsProducts[key].formData.catalogId;
        bundleItem.ruleCode = this.state.bundleItemsProducts[key].ruleCode;
        bundleItem.maximum =
          this.state.bundleItemsProducts[key].formData.maximum;
        bundleItem.minimum =
          this.state.bundleItemsProducts[key].formData.minimum;
        bundleItem.datasetId =
          this.state.bundleItemsProducts[key].formData.datasetId;
        listOfPpmPackageProdMapAud.push(bundleItem);
      });
      payload.listOfPpmPackageProdMapAud = listOfPpmPackageProdMapAud;
      console.log(payload);
      axios
        .post(process.env.REACT_APP_URL + "package/bundle/", payload)
        .then((response) => {
          console.log(response);
          if (this._isMounted)
            this.setState({
              loading: false,
              openSnack: true,
              messageSnack: "Bundle Items Details Saved Successfully",
            });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      let modalContent = (
        <Typography variant="h6">
          Submit Basic Package Details first on General screen.
        </Typography>
      );
      this.setState({
        modalContent: modalContent,
        show: true,
      });
    }
  };

  packageBundleItemsData() {
    if (this.props.releaseData.releaseId) {
      if (this.props.packageData.packageId) {
        // process.env.REACT_APP_URL +
        // "package/bundle?id=" +
        // this.props.packageData.packageId +
        // "&releaseId=" +
        // this.props.releaseData.releaseId,

        return axios
          .get(
            process.env.REACT_APP_URL +
              "mtn/product/bundle?id=" +
              this.props.packageData.packageId +
              "&releaseId=" +
              this.props.releaseData.releaseId,
            {
              headers: {
                opId: this.props.userInfo.opId,
              },
            }
          )

          .then((res) => {
            console.log(res.data.data);
            if (res.data.data.length > 0) {
              let bundleItems = {};
              res.data.data.map((product) => {
                console.log(product);
                let proDetails = {};
                let formData = {};
                formData.defaultState = product.defaultState;
                formData.catalogId = product.catalogId;
                formData.minimum = product.minimum;
                formData.maximum = product.maximum;
                formData.datasetId = product.datasetId;
                proDetails.ruleCode = product.ruleCode;
                proDetails.productDesc = product.description;
                let productId = product.productId;
                proDetails.formData = formData;
                bundleItems[productId] = proDetails;
              });
              if (this._isMounted)
                this.setState({ bundleItemsProducts: bundleItems });
            }
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      } else {
        return Promise.resolve();
      }
    } else {
      return Promise.resolve();
    }
  }
  render() {
    const { classes, access } = this.props;
    const isDisabled = access && access === "R";

    let bundleItems = (
      <React.Fragment>
        <Modal
          show={this.state.show}
          modalClosed={this.errorConfirmedHandler}
          title={"Something Went Wrong!"}
        >
          {this.state.modalContent}
        </Modal>
        <Grid
          container
          spacing={2}
          style={{ display: !this.state.loading ? "block" : "none" }}
        >
          <Snackbar
            open={this.state.openSnack}
            message={this.state.messageSnack}
            onClose={(event, reason) => {
              if (reason === "clickaway") {
                return;
              }
              this.setState({ openSnack: false });
            }}
          />
          <Grid item xs={12} sm={6} style={{ display: "none" }}>
            <Box>
              <span style={{}}>Select the Type of Item to Bundle</span>
            </Box>
            <Box my={2}>
              <CustomInput
                disabled
                resize
                access={"R"}
                refType="SelectInput"
                value={this.state.bundleType}
                changed={(value) => {
                  this.setState({
                    bundleType: value,
                  });
                  let url = "";
                  if (value == "Package")
                    url = "package/basicDetails/searchPackages?releaseID=";
                  else if (value == "Bundle")
                    url = "package/basicDetails/searchBundles?releaseID=";
                  else if (value == "Promotion")
                    url = "package/basicDetails/searchPromotions?releaseID=";

                  if (value != "Product") {
                    this.setState({ loading: true });
                    axios
                      .get(
                        process.env.REACT_APP_URL +
                          url +
                          this.props.releaseData.releaseId,
                        {
                          headers: {
                            opId: this.props.userInfo.opId,
                          },
                        }
                      )

                      .then((res) => {
                        console.log(res);
                        let bundleItems = [];
                        Object.keys(res.data.data).map((item) => {
                          bundleItems.push(item + "/" + res.data.data[item]);
                        });
                        if (this._isMounted)
                          this.setState({
                            loading: false,
                            bundleItems: bundleItems,
                          });
                      })
                      .catch((error) => {
                        console.log(error);
                        if (this._isMounted) this.setState({ loading: false });
                      });
                  }
                }}
                //  refLovs={['Product', 'Bundle', 'Package', 'Promotion']}
                refLovs={["Product"]}
              />
            </Box>
          </Grid>
          <Grid item xs={12}>
            <Grid item xs={12} style={{ marginTop: "2vh" }}>
              <form onSubmit={this.saveBundleItem}>
                <TableContainer component={Paper} style={{ height: "30vh" }}>
                  <Table className={classes.table} size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Item Id</TableCell>
                        <TableCell>Item Description</TableCell>
                        {/* <TableCell>Unit</TableCell>
                        <TableCell>UOM</TableCell> */}
                        <TableCell>Min</TableCell>
                        <TableCell>Max</TableCell>
                        <TableCell>Delete</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {Object.keys(this.state.bundleItemsProducts).map(
                        (key) => {
                          console.log(key);
                          const isSelectRequired = key;
                          let type = "text";

                          return (
                            <TableRow key={key}>
                              <TableCell
                                style={{
                                  width: "25%",
                                  cursor: "pointer",
                                  textDecoration: "underline",
                                  color: "#3f74c5",
                                }}
                                onClick={() => {
                                  console.log(
                                    this.state.bundleItemsProducts[key]
                                  );
                                  if (
                                    this.state.bundleItemsProducts[key][
                                      "formData"
                                    ]["datasetId"] &&
                                    this.state.bundleItemsProducts[key][
                                      "formData"
                                    ]["datasetId"] == "Product"
                                  ) {
                                    this.props.changeProductActiveStep(0);
                                    let proData = {
                                      ...this.props.productData,
                                    };
                                    proData["productId"] = key;
                                    this.props.onProductEnter(proData);
                                    this.props.changeProductKey(
                                      this.props.productKey + "1"
                                    );
                                    this.props.history.push(
                                      "/productConfiguration"
                                    );
                                  } else {
                                    this.props.changePackageActiveStep(0);
                                    let pkgData = {
                                      ...this.props.packageData,
                                    };
                                    pkgData["packageId"] = key;
                                    this.props.onPackageEnter(pkgData);
                                    this.props.changePackageKey(
                                      this.props.pkgKey + "1"
                                    );
                                    this.props.history.push(
                                      "/planConfiguration"
                                    );
                                  }
                                }}
                              >
                                {/* {key} */}
                                {this.state.bundleItemsProducts[key].ruleCode}
                              </TableCell>
                              <TableCell style={{ width: "25%" }}>
                                {this.modifyColor(
                                  this.state.bundleItemsProducts[key]
                                    .productDesc
                                )}
                              </TableCell>
                              <TableCell style={{ width: "25%" }}>
                                <TextField
                                  error={
                                    this.state.isRequired &&
                                    this.state.bundleItemsProducts[key]
                                      .formData["catalogId"] !== null &&
                                    this.state.bundleItemsProducts[key]
                                      .formData["catalogId"].length === 0
                                  }
                                  helperText={
                                    this.state.isRequired &&
                                    this.state.bundleItemsProducts[key]
                                      .formData["catalogId"] !== null &&
                                    this.state.bundleItemsProducts[key]
                                      .formData["catalogId"].length === 0 &&
                                    "Required"
                                  }
                                  onKeyDown={(e) =>
                                    ["e", "E", "+", "-"].includes(e.key) &&
                                    e.preventDefault()
                                  }
                                  value={
                                    this.state.bundleItemsProducts[key]
                                      .formData["catalogId"]
                                  }
                                  type="number"
                                  onChange={(event) => {
                                    let changedData = {
                                      ...this.state.bundleItemsProducts[key],
                                    };
                                    changedData.formData["catalogId"] =
                                      event.target.value;
                                    this.setState((prevState) => {
                                      return {
                                        bundleItemsProducts: {
                                          ...prevState.bundleItemsProducts,
                                          [key]: changedData,
                                        },
                                      };
                                    });
                                  }}
                                />
                              </TableCell>
                              <TableCell style={{ width: "25%" }}>
                                <FormControl
                                  style={{ minWidth: "100%" }}
                                  error={
                                    this.state.bundleItemsProducts[key]
                                      .formData["defaultState"] !== null &&
                                    this.state.bundleItemsProducts[key]
                                      .formData["defaultState"].length === 0 &&
                                    isSelectRequired
                                  }
                                >
                                  <Select
                                    value={
                                      this.state.bundleItemsProducts[key]
                                        .formData["defaultState"]
                                    }
                                    onChange={(event) => {
                                      // event.target.value !== null
                                      //   ? this.setState({ isRequired: false })
                                      //   : this.setState({ isRequired: true });

                                      console.log(event.target.value);

                                      let changedData = {
                                        ...this.state.bundleItemsProducts[key],
                                      };
                                      changedData.formData["defaultState"] =
                                        event.target.value;
                                      this.setState((prevState) => {
                                        return {
                                          bundleItemsProducts: {
                                            ...prevState.bundleItemsProducts,
                                            [key]: changedData,
                                          },
                                        };
                                      });
                                    }}
                                  >
                                    {[
                                      "Rand",
                                      "MB",
                                      "GB",
                                      "TB",
                                      "SMS",
                                      "Minutes",
                                    ]
                                      .filter((lov) => {
                                        const prod =
                                          this.state.bundleItemsProducts[key];
                                        const desc =
                                          prod.productDesc.toLowerCase();
                                        if (desc.includes("data")) {
                                          return ["GB", "MB", "TB"].includes(
                                            lov
                                          );
                                        } else if (desc.includes("voice")) {
                                          return ["Minutes"].includes(lov);
                                        } else if (desc.includes("sms")) {
                                          return ["SMS"].includes(lov);
                                        } else {
                                          return true;
                                        }
                                      })
                                      .map((lov) => {
                                        const desc =
                                          this.state.bundleItemsProducts[key]
                                            .productDesc;
                                        return (
                                          <MenuItem key={lov} value={lov}>
                                            {lov}
                                          </MenuItem>
                                        );
                                      })}
                                  </Select>
                                  {this.state.bundleItemsProducts[key].formData[
                                    "defaultState"
                                  ] !== null &&
                                    this.state.bundleItemsProducts[key]
                                      .formData["defaultState"].length ===
                                      0 && (
                                      <FormHelperText>Required</FormHelperText>
                                    )}
                                </FormControl>
                                {/* <TextField
                                    value={
                                      this.state.bundleItemsProducts[key]
                                        .formData["defaultState"]
                                    }
                                    type="text"
                                    onChange={(event) => {
                                      let changedData = {
                                        ...this.state.bundleItemsProducts[key],
                                      };
                                      changedData.formData["defaultState"] =
                                        event.target.value;
                                      this.setState((prevState) => {
                                        return {
                                          bundleItemsProducts: {
                                            ...prevState.bundleItemsProducts,
                                            [key]: changedData,
                                          },
                                        };
                                      });
                                    }}
                                  /> */}
                              </TableCell>
                              <TableCell style={{ width: "10%" }}>
                                <TextField
                                  value={
                                    this.state.bundleItemsProducts[key]
                                      .formData["minimum"]
                                  }
                                  type="number"
                                  onChange={(event) => {
                                    let changedData = {
                                      ...this.state.bundleItemsProducts[key],
                                    };
                                    changedData.formData["minimum"] =
                                      event.target.value;
                                    this.setState((prevState) => {
                                      return {
                                        bundleItemsProducts: {
                                          ...prevState.bundleItemsProducts,
                                          [key]: changedData,
                                        },
                                      };
                                    });
                                  }}
                                />
                              </TableCell>
                              <TableCell style={{ width: "10%" }}>
                                <TextField
                                  type="number"
                                  value={
                                    this.state.bundleItemsProducts[key]
                                      .formData["maximum"]
                                  }
                                  onChange={(event) => {
                                    let changedData = {
                                      ...this.state.bundleItemsProducts[key],
                                    };
                                    changedData.formData["maximum"] =
                                      event.target.value;
                                    this.setState((prevState) => {
                                      return {
                                        bundleItemsProducts: {
                                          ...prevState.bundleItemsProducts,
                                          [key]: changedData,
                                        },
                                      };
                                    });
                                  }}
                                />
                              </TableCell>
                              <TableCell style={{ width: "5%" }}>
                                <DeleteIcon
                                  disabled={isDisabled}
                                  onClick={(event) => {
                                    event.stopPropagation();
                                    let bundleItemsProducts = {
                                      ...this.state.bundleItemsProducts,
                                    };
                                    delete bundleItemsProducts[key];
                                    this.setState({
                                      bundleItemsProducts: bundleItemsProducts,
                                    });
                                  }}
                                  style={{
                                    color: "red",
                                    cursor: "pointer",
                                  }}
                                />
                              </TableCell>
                            </TableRow>
                          );
                        }
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </form>
            </Grid>
          </Grid>
        </Grid>
      </React.Fragment>
    );
    if (this.state.loading) bundleItems = <Loader />;
    return bundleItems;
  }
}

const mapStateToProps = (state) => {
  return {
    productKey: state.productData.productKey,
    productData: state.productData.productData,
    packageData: state.packageData.packageData,
    pkgKey: state.packageData.pkgKey,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    changeProductKey: (productKey) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_KEY,
        productKey: productKey,
      }),
    onProductEnter: (productData) =>
      dispatch({ type: actionTypes.INSIDE_PRODUCT, productData: productData }),
    changeProductActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PRODUCT_ACTIVE_STEP,
        activeStep: activeStep,
      }),
    changePackageKey: (pkgKey) =>
      dispatch({ type: actionTypes.CHANGE_PACKAGE_KEY, pkgKey: pkgKey }),
    onPackageEnter: (packageData) =>
      dispatch({ type: actionTypes.INSIDE_PACKAGE, packageData: packageData }),
    changePackageActiveStep: (activeStep) =>
      dispatch({
        type: actionTypes.CHANGE_PACKAGE_ACTIVE_STEP,
        activeStep: activeStep,
      }),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(useStyles)(WithErrorHandler(withRouter(BundleItems), axios)));
