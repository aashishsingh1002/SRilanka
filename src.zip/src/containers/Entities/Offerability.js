import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../UI/Loader/Loader';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import AppsIcon from '@material-ui/icons/Apps';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import MultiSelect from '../../UI/Input/MultiSelect'
import Input from '../../UI/Input/Input';

import Button from '@material-ui/core/Button';
import Modal from '../../UI/Modal/Modal';
import Typography from '@material-ui/core/Typography';
import moment from "moment";
import Divider from '@material-ui/core/Divider';


const useStyles = (theme) => ({
    cardHeader: {
        background: '#546D7A',
        height: '4.5vh'
    },
    subheader: {
        color: 'white',
        // fontWeight: 'bold'
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '96%',
        flexShrink: 0,
    },


});

class Offerability extends Component {
    _isMounted = false;
    state = {
        loading: true,
        version: '',
        offerKeys: [],
        schema: [],
        refUiMap: {},
        selectedIndex: 0,
        selOfferability: '',
        show: false,
        modalContent: null,
        packageOfferData: {}
    }
    componentWillUnmount() {
        this._isMounted = false;
    }

    versions() {
        return axios
            .get(
                "config/version?entityName=offerability",
                {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId

                    }
                }
            )
            .then(res => {
                console.log("version is" + res.data.data.version);
                this.setState({ version: res.data.data.version })
            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false });

            });
    }

    uiFields() {
        if (
            localStorage.getItem("offerability") &&
            localStorage.getItem("offerabilityKeys") &&
            localStorage.offerability_version &&
            localStorage.offerability_version == this.state.version
        ) {
            console.log("fetching from local storage");
            try {
                this.setState({
                    schema: JSON.parse(localStorage.getItem("offerability")),
                    offerKeys: JSON.parse(localStorage.getItem("offerabilityKeys")),
                    refUiMap: JSON.parse(
                        localStorage.getItem("offerabilityUiRefMap"))
                });

            } catch (e) {
                localStorage.removeItem("offerability");
                localStorage.removeItem("offerabilityKeys");
                localStorage.removeItem("offerabilityUiRefMap");
            }
            return Promise.resolve();
        } else {
            console.log("fetching from api");
            return axios
                .get("config?entityName=offerability", {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId
                    }
                })
                .then(res => {
                    let schema = []
                    schema = res.data.data.map(function (el) {
                        if (el.refType == "SelectInput" || el.refType == "MultiSelect") {
                            if (el.refLovs != null) el.refLovs = el.refLovs.split(",");
                            else if (el.refLovs == null) el.refLovs = [];
                        }
                        return el;
                    });

                    let offerKeys = []
                    let refUiMap = {}
                    console.log(res.data.data)
                    res.data.data.forEach((el) => {
                        let offerabilityType = {};
                        offerabilityType.value = el.refLovs ? el.refLovs : "";
                        offerabilityType.type = el.refType;
                        offerKeys.push(el.refName);
                        refUiMap[el.refName] = el.uiName;
                    });

                    this.setState({
                        schema: schema,
                        offerKeys: offerKeys,
                        refUiMap: refUiMap
                    });
                    localStorage.setItem("offerability", JSON.stringify(schema));
                    localStorage.setItem(
                        "offerabilityKeys",
                        JSON.stringify(offerKeys)
                    );
                    localStorage.setItem(
                        "offerabilityUiRefMap",
                        JSON.stringify(refUiMap)
                    );
                    localStorage.offerability_version = this.state.version;
                })
                .catch(error => {
                    console.log(error);
                    if (this._isMounted)
                        this.setState({ loading: false });

                });
        }
    }

    componentDidMount = () => {
        this._isMounted = true;
        this.setState({ loading: true });
        this.versions().then(() => {
            this.uiFields().then(() => {
                this.state.schema.map(formElement => {
                    if (formElement.refType == 'Date')
                        this.setState({
                            [formElement.uiName]: formElement.defaultValue ?
                                moment(formElement.defaultValue).format("DD-MMM-YY") : moment().format("DD-MMM-YY")
                        });
                    else if (formElement.refType == 'TextInput' || 'TextArea' || 'SelectInput') {
                        console.log(formElement.uiName)
                        console.log([formElement.defaultValue])

                        this.setState({
                            [formElement.uiName]: [formElement.defaultValue]
                        });
                    }

                })
                this.packageOfferabilityData().then(() => {
                    if (this._isMounted) {
                        this.state.schema.map(obj => {
                            if (obj.refType == "MultiSelect")
                                this.setState({ [obj.uiName]: [] })
                            // else
                            //     this.setState({ [obj.uiName]: null })


                        });
                        if (Object.keys(this.state.packageOfferData).length > 0) {
                            Object.keys(this.state.refUiMap).forEach(key => {
                                if (this.state.packageOfferData[key]) {
                                    let offer = this.state.refUiMap[key]
                                    console.log(offer)
                                    if (this.state.packageOfferData[key].length > 0 && this.state.packageOfferData[key][0])
                                        this.setState((prevState) => {
                                            return {
                                                [offer]: [...prevState.packageOfferData[key]]
                                            };
                                        });
                                }

                            });
                        }

                        this.setState({
                            loading: false,
                            selOfferability: this.state.schema[0].uiName
                        });
                    }
                })
            })
        })

    }

    handleListItemClick = (event, index, key) => {
        this.setState({ selectedIndex: index, selOfferability: key.uiName })
    }

    cartesianProduct(arr) {
        return arr.reduce(
            function (a, b) {
                return a
                    .map(function (x) {
                        return b.map(function (y) {
                            return x.concat([y]);
                        });
                    })
                    .reduce(function (a, b) {
                        return a.concat(b);
                    }, []);
            },
            [[]]
        );
    }

    packageOfferabilityData() {
        if (this.props.releaseData.releaseId) {
            if (this.props.id) {
                return axios
                    .get(
                        "/package/offerability?id=" +
                        this.props.id +
                        "&releaseId=" +
                        this.props.releaseData.releaseId,
                        {
                            headers: {
                                createdBy: this.props.userInfo.id,
                                opId: this.props.userInfo.opId
                            }
                        }
                    )
                    .then(res => {
                        console.log(res.data.data);
                        this.setState({
                            packageOfferData: res.data.data
                        })
                    })
                    .catch(error => {
                        console.log(error)
                        if (this._isMounted)
                            this.setState({ loading: false })
                    });
            } else {
                return Promise.resolve();
            }
        } else {
            return Promise.resolve();
        }
    }

    savePkgOfferDetailsHandler = (event) => {
        event.preventDefault();
        if (this.props.id) {
            let offerabilitiesValues = [];
            this.state.schema.forEach(key => {
                offerabilitiesValues.push(this.state[key.uiName])
            })
            console.log(offerabilitiesValues)
            offerabilitiesValues.forEach((part, index, theArray) => {
                if (theArray[index] instanceof Array && theArray[index].length == 0) {
                    theArray[index][0] = "ANY";
                    this.setState({
                        [part]: ['ANY']
                    })
                }
                else if (typeof theArray[index] === "string") {
                    theArray[index] = [theArray[index]];
                } else if (theArray[index] == null) theArray[index] = ["ANY"];
            });
            let crossMatrix = this.cartesianProduct(offerabilitiesValues);
            let offerJson = [];
            crossMatrix.filter(row => {
                let oneOfferRule = {};
                let date = moment().format("DD-MMM-YY");
                oneOfferRule.opid = this.props.userInfo.opId;
                oneOfferRule.buid = this.props.userInfo.buId;
                oneOfferRule.createdBy = this.props.userInfo.id;
                oneOfferRule.createdDate = date;
                oneOfferRule.startDate = date;
                oneOfferRule.endDate = "31-Dec-31";
                oneOfferRule.version = "1.0";
                oneOfferRule.offerabilityRuleId = "OFPK1";
                oneOfferRule.offerabilityRule = "OFPK1";
                oneOfferRule.packageProductId = this.props.id;
                oneOfferRule.packageId = this.props.id;
                oneOfferRule.packageProductIdentifier = this.props.entity;

                row.forEach((val, index) => {
                    let key = this.state.offerKeys[index];
                    oneOfferRule[key] = val;
                });
                offerJson.push(oneOfferRule);
            });
            console.log(offerJson)
            let payload = {};
            let listOfPPmOfferabilityAud = [];
            listOfPPmOfferabilityAud = offerJson;
            payload.id = this.props.id;
            payload.releaseId = this.props.releaseData.releaseId;
            payload.listOfPPmOfferabilityAud = listOfPPmOfferabilityAud;
            console.log(payload);
            this.setState({ loading: true })
            axios
                .post("/package/offerability", payload)
                .then(response => {
                    console.log(response.data.data);
                    // if (this._isMounted)
                    let payloadRelData = {};
                    payloadRelData.releaseId = this.props.releaseData.releaseId;
                    payloadRelData.id = this.props.id;
                    payloadRelData.listOfOfferabilities = response.data.data;
                    axios
                        .post(
                            "/package/offerability/releaseEntity",
                            payloadRelData
                        )
                        .then(response => {
                            console.log(response);
                            this.setState({ loading: false })

                        });
                })
                .catch(error => {
                    console.log(error)
                    if (this._isMounted)
                        this.setState({ loading: false })
                });
        }
        else {
            let modalContent = < Typography variant="h6"> Submit Basic {this.props.entity} Details first. </ Typography>
            this.setState({ modalContent: modalContent, show: true })

        }
    }

    errorConfirmedHandler = () => {
        this.setState({ show: false });
    }

    deleteOfferabilityHandler = () => {

        this.setState({
            loading: true,
        })
        axios
            .get(
                "package/offerability/delete?id=" +
                this.props.id +
                "&releaseID=" +
                this.props.releaseData.releaseId
            )
            .then(res => {
                console.log(res.data.data);
                if (this._isMounted) {
                    this.state.schema.map(obj => {
                        if (obj.refType == "MultiSelect")
                            this.setState({ [obj.uiName]: [] })
                        else
                            this.setState({ [obj.uiName]: null })
                    });
                    this.setState({
                        loading: false,
                    })
                }

            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });
    }

    inputHelper(formElement) {
        console.log(formElement)
        formElement = formElement[0]
        if (formElement) {
            if (formElement.refType == 'MultiSelect')
                return < MultiSelect
                    refLovs={formElement.refLovs}
                    value={this.state[formElement.uiName]}

                    {...formElement}
                    changed={(selected) => {
                        console.log(selected)
                        if (!(selected instanceof Array))
                            selected = [selected]

                        this.setState({
                            [formElement.uiName]:
                                selected
                        })
                    }
                    }
                />
            else
                return <Input
                    table
                    key={formElement.refName}
                    {...formElement}
                    value={this.state[formElement.uiName]}
                    disabled={formElement.isDisabled == 'Y' ? true : false}
                    required={formElement.isMandatory == 'Y' ? true : false}
                    changed={(event) => {
                        if (!event.target) {
                            this.setState({
                                [formElement.uiName]:
                                    event
                            })
                        } else {
                            if (event.target.type !== 'checkbox')
                                this.setState({
                                    [formElement.uiName]:
                                        event.target.value
                                })
                            else {
                                console.log(event.target.checked)
                                this.setState({
                                    [formElement.uiName]:
                                        event.target.checked
                                })
                            }
                        }
                    }} />
        }
    }

    render() {
        const { classes } = this.props;
        let offerability = <Loader />
        let selectedOfferability = null

        if (!this.state.loading) {

            selectedOfferability = this.inputHelper(this.state.schema.filter(obj => {
                if (obj.uiName == this.state.selOfferability) {
                    return obj
                }
            }))
            offerability = <React.Fragment>
                <Modal
                    show={this.state.show}
                    modalClosed={this.errorConfirmedHandler}
                    title={'Something Went Wrong!'}
                >
                    {this.state.modalContent}
                </Modal>
                <form onSubmit={this.savePkgOfferDetailsHandler} style={{ overflow: 'visible' }}>
                    <Grid container spacing={3}  >
                        <Grid item xs={12} sm={6} >
                            <Card style={{ height: '100%' }}>
                                <CardHeader
                                    className={classes.cardHeader}
                                    classes={{
                                        subheader: classes.subheader,
                                    }}
                                    subheader={'Offerability List'} />

                                <CardContent style={{ maxHeight: '40vh', overflow: 'auto' }}>
                                    <div className={classes.root}>
                                        <List component="nav" >

                                            {
                                                this.state.schema.map((key, index) => {
                                                    return <ListItem
                                                        key={key.refName}
                                                        button
                                                        selected={this.state.selectedIndex === index}
                                                        onClick={(event) => this.handleListItemClick(event, index, key)}
                                                    > <ListItemIcon>
                                                            <AppsIcon />
                                                        </ListItemIcon>
                                                        <ListItemText primary={key.uiName} />
                                                    </ListItem>
                                                })
                                            }
                                        </List>
                                    </div>

                                </CardContent>
                            </Card>
                        </Grid>

                        <Grid item xs={12} sm={6} >
                            <Card style={{ height: '100%', overflow: 'visible' }}>
                                <CardHeader
                                    className={classes.cardHeader}
                                    classes={{
                                        subheader: classes.subheader,
                                    }}
                                    subheader={this.state.selOfferability} />

                                <CardContent style={{ maxHeight: '40vh', overflow: 'visible' }}>
                                    {selectedOfferability}
                                </CardContent>
                            </Card>
                        </Grid>
                        <Grid item xs={12}  >
                            <Card >
                                <CardHeader
                                    className={classes.cardHeader}
                                    classes={{
                                        subheader: classes.subheader,
                                    }}
                                    subheader={'Selected Offerability'} />

                                <CardContent >
                                    {< List
                                        component="nav"
                                        aria-labelledby="nested-list-subheader"
                                        style={{ width: '100%', maxHeight: '20vh', overflow: 'auto' }}
                                    >
                                        {this.state.schema.map(key => {
                                            return <React.Fragment key={key.refName}>
                                                {<ListItem >
                                                    <ListItemText primary={key.uiName}
                                                        secondary={
                                                            key.refType == 'MultiSelect' ? this.state[key.uiName].join()
                                                                : this.state[key.uiName]
                                                        }

                                                    />
                                                </ListItem>}
                                                <Divider />
                                            </React.Fragment>

                                        })}
                                    </List>
                                    }
                                </CardContent>

                            </Card>

                        </Grid>

                        {this.props.releaseData.releaseId && <div style={{
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                            width: '100%',
                            marginTop: '1%'
                        }}>
                            <Button variant="outlined"
                                type='submit'
                                style={{
                                    color: 'green', border: '1px solid green'
                                    , marginRight: '1%'
                                }}
                            >
                                Save
                        </Button>

                            <Button variant="outlined" color="secondary"
                                onClick={this.deleteOfferabilityHandler}
                            >
                                Delete
                     </Button>
                        </div>}
                    </Grid >
                </form>

            </React.Fragment>
        }
        return offerability
    }
}



export default withStyles(useStyles)(WithErrorHandler(Offerability, axios));