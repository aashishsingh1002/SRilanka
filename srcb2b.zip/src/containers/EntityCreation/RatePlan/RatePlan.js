import React, { Component } from 'react';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../../axios-epc';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import HomeIcon from '@material-ui/icons/Home';
import { connect } from 'react-redux';
import Loader from '../../../UI/Loader/Loader';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Tooltip from '@material-ui/core/Tooltip';
import Box from '@material-ui/core/Box';
import CreateRatePlan from './CreateRatePlan';
import GetRatePlans from './GetRatePlans';
import ModalAction from '../../../UI/ModalAction/ModalAction';
import Typography from '@material-ui/core/Typography';
import Title from "../../../UI/Typography/Title";
const LightTooltip = withStyles((theme) => ({
	tooltip: {
		backgroundColor: '#525354',
		color: 'white',
		boxShadow: theme.shadows[1],
		fontSize: 14,
	},
}))(Tooltip);

const useStyles = (theme) => ({
	cardHeader: {
		background: 'white',
		borderBottom: '4px solid #fafafa',
		height: '4.5vh',
		margin:'1rem 0'
	},
	subheader: {
		color: '#000000de',
		// fontWeight: 'bold'
	},
	boldText: {
		// fontWeight: 'bold'
	},
	center: {
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
	},
	heading: {
		fontSize: theme.typography.pxToRem(15),
		flexBasis: '96%',
		flexShrink: 0,
	},
});

class RatePlan extends Component {
	_isMounted = false;

	state = {
		loading: false,
		typeRatePlan: 'create',
		editRpData: {},
		getLatestData: 'key',
		show: false,
		isEdit: false,
	};

	componentWillUnmount() {
		this._isMounted = false;
	}

	componentDidMount() {
		this._isMounted = true;
	}

	backToRelease = () => {
		this.props.history.push('/editRelease');
	};

	editCrp = (data) => {
		this.setState({
			isEdit: true,
			typeRatePlan: 'create',
			editRpData: data,
		});
	};

	actionHandler = () => {
		this.setState({
			typeRatePlan: 'use',
			show: false,
		});
	};

	render() {
		const { classes } = this.props;

		let ratePlanComponent = null;
		if (this.state.typeRatePlan === 'create')
			ratePlanComponent = (
				<CreateRatePlan
        userInfo={this.props.userInfo}
        releaseData={this.props.releaseData}
					typeRatePlan={this.state.isEdit ? 'edit' : 'create'}
					changeToActive= {() => this.setState({typeRatePlan : "use"})}
					editRpData={
						this.state.typeRatePlan === 'create' && this.state.isEdit
							? this.state.editRpData
							: {}
					}
					getLatestData={this.state.getLatestData}
					sendLatestData={(val) => {
						if (Object.keys(val[0]).length > 0 && !val[1]) {
							this.setState({
								show: true,
							});
						} else
							this.setState({
								typeRatePlan: 'use',
							});
					}}
				/>
			);
		else if (this.state.typeRatePlan === 'use')
			ratePlanComponent = (
				<GetRatePlans
					userInfo={this.props.userInfo}
					releaseData={this.props.releaseData}
					editCrp={this.editCrp}
				/>
			);

		let ratePlan = (
			<>
				<ModalAction
					show={this.state.show}
					modalClosed={() => {
						this.setState({
							show: false,
						});
					}}
					closeText={'No'}
					actionText={'Yes'}
					title={'Alert!'}
					action={this.actionHandler}
					size={'md'}>
					<Typography variant="h6">
						You have not saved your changes.Do you want to navigate?
					</Typography>
				</ModalAction>
        <Title>
{this.props.releaseData.releaseId
          ? "Rate Plan Configuration  You are inside release " +
            this.props.releaseData.externalReleaseId
           : "Rate Plan Configuration"}
      </Title>
					<RadioGroup
						row
						aria-label="position"
						name="position"
						value={this.state.typeRatePlan}
						onChange={(event) => {
							if (event.target.value === 'use') {
								let getLatestData =
									this.state.getLatestData.length > 10
										? 'key'
										: this.state.getLatestData + 1;
								this.setState({
									getLatestData,
								});
								console.log(getLatestData);
							} else {
								this.setState({
									isEdit: false,
									typeRatePlan: event.target.value,
								});
							}
						}}
						style={{ marginBottom: '2%' }}>
						<FormControlLabel
							value={'create'}
							control={<Radio style={{ color: '#ff1921' }} />}
							label="Create/Edit Rate Plan"
						/>
						<FormControlLabel
							value="use"
							control={<Radio style={{ color: '#ff1921' }} />}
							label="Use Existing Rate Plan"
						/>
						{/* <FormControlLabel
							disabled
							value={'edit'}
							control={<Radio style={{ color: '#ff1921' }} />}
							label="Edit/Clone Rate Plan"
						/> */}
					</RadioGroup>

					<Box mt={2}>{ratePlanComponent}</Box>
          </>
		);

		if (this.state.loading) ratePlan = <Loader />;

		return ratePlan;
	}
}

const mapStateToProps = (state) => {
	return {
		releaseData: state.releaseData.releaseData,
		userInfo: state.login.loggedInUserInfo,
	};
};

export default connect(mapStateToProps)(
	withStyles(useStyles)(WithErrorHandler(RatePlan, axios))
);
