import React, { Component } from 'react';
import WithErrorHandler from '../../../HOC/WithErrorHandler/WithErrorHandler';
import axios from 'axios';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import { withStyles } from '@material-ui/core/styles';
import Loader from '../../../UI/Loader/Loader';
import Grid from '@material-ui/core/Grid';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import RentalPricing from './RentalPricing';
import RentalMatrix from './RentalMatrix';
import DiscountMatrix from './DiscountMatrix';
import DiscountPricing from './DiscountPricing';
import PricingComponents from './PricingComponents';
import Tarrif from './Tarrif';
import StyledButton from '../../../UI/Button/Button';
import ModalAction from "../../../UI/ModalAction/ModalAction";
import Input from "../../../UI/Input/Input";
import moment from 'moment';

const useStyles = (theme) => ({
  cardHeader: {
    // background: "#546D7A",
    // height: "4.5vh",
    paddingBottom: 0,
  },
  subheader: {
    color: 'rgba(0, 0, 0, 0.87)',
    fontSize: '16px',
    fontWeight: '600',
    // color: "white",
    // fontWeight: 'bold'
  },
  boldText: {
    // fontWeight: 'bold'
  },
  center: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '96%',
    flexShrink: 0,
  },
});

class Pricing extends Component {
  _isMounted = false;

  state = {
    loading: true,
    componentType: 'Rental',
    computationType: 'Direct',
    rentalVersion: '',
    offerVersion: '',
    discountVersion: '',
    discountedItemsDataVersion: '',
    discountUsageGroupVersion: '',
    allPricingComponents: [],
    compKey: 'app',
    rentalData: {},
    discountData: {},
    matrixComponent: [],
    showExtension: false,
    templateDataItems: null,
    isEdit: true,
    disabled: true,
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  componentDidMount() {
    this._isMounted = true;
    this.versions().then(() => {
      this.getMatrixComponents().then(() => {
        this.getAllComponents().then(() => {
          this.setState({ loading: false });
        });
      });
    });
  }
  getMatrixComponents() {
    if (this.props.releaseData.releaseId) {
      if (this.props.id) {
        return axios
          .get(process.env.REACT_APP_URL + 'pricing/matrix?id=' + this.props.id)
          .then((res) => {
            console.log('Matrix Data', res.data.data);
            let matrixComponent = [];
            Object.keys(res.data.data).forEach((key) => {
              var arr = {};
              arr.componentValue = res.data.data[key].listPrice;
              arr.componentFrequency = res.data.data[key].rcFrequency;
              arr.componentSubType = res.data.data[key].priceType;
              arr.computationType = 'MATRIX';
              arr.componentType = 'RENTAL';
              console.log(arr);
              matrixComponent.push(arr);
            });
            this.setState({ matrixComponent: matrixComponent });
            // let matrixRows = [];
            // if (Object.keys(res.data.data).length > 0) {
            //   Object.keys(res.data.data).forEach((key) => {
            //     let arr = {};
            //     arr.price = res.data.data[key].listPrice;
            //     arr.Delete = 'delete';
            //     arr.down = 'mdi-chevron-down';
            //     arr.chargeType = res.data.data[key].priceType;
            //     arr.frequency = res.data.data[key].rcFrequency;
            //     arr.attributes = Object.keys(res.data.data[key].attributes);
            //     let arrOffer = [];
            //     let objOffer = {};
            //     let objattr = {};
            //     Object.keys(res.data.data[key].offerabilities).forEach(
            //       (keyoffer) => {
            //         arrOffer.push(this.state.refUiMap[keyoffer]);
            //         if (
            //           res.data.data[key].offerabilities[keyoffer] !== null &&
            //           res.data.data[key].offerabilities[keyoffer].indexOf(',') >
            //             -1
            //         )
            //           objOffer[this.state.refUiMap[keyoffer]] =
            //             res.data.data[key].offerabilities[keyoffer].split(',');
            //         else
            //           objOffer[this.state.refUiMap[keyoffer]] =
            //             res.data.data[key].offerabilities[keyoffer];
            //       }
            //     );
            //     Object.keys(res.data.data[key].attributes).forEach(
            //       (keyattr) => {
            //         if (
            //           res.data.data[key].attributes[keyattr] !== null &&
            //           res.data.data[key].attributes[keyattr].indexOf(',') > -1
            //         )
            //           objattr[keyattr] =
            //             res.data.data[key].attributes[keyattr].split(',');
            //         else
            //           objattr[keyattr] = res.data.data[key].attributes[keyattr];
            //       }
            //     );
            //     arr.offerability = arrOffer;
            //     arr.id = crrMatrixRowId++;
            //     arr.show = false;
            //     arr.selattributes = objattr;
            //     arr.selOfferabilities = objOffer;
            //     matrixRows.push(arr);
            //   });
            // } else {
            //   let obj = {
            //     attributes: [],
            //     offerability: [],
            //     price: '',
            //     chargeType: '',
            //     frequency: '',
            //     Delete: 'delete',
            //     down: 'mdi-chevron-down',
            //     selattributes: {},
            //     selOfferabilities: {},
            //     id: crrMatrixRowId++,
            //     show: false,
            //   };
            //   matrixRows.push(obj);
            // }
            // this.setState({
            //   matrixRows: matrixRows,
            // });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      } else {
        return Promise.resolve();
      }
    } else {
      return Promise.resolve();
    }
  }
  getAllComponents() {
    if (this.props.releaseData.releaseId) {
      if (this.props.id) {
        return axios
          .get(
            process.env.REACT_APP_URL +
              'postpaid/pricing/direct?id=' +
              this.props.id +
              '&releaseId=' +
              this.props.releaseData.releaseId,
            {
              headers: {
                authUserId: this.props.userInfo.id,
                // Authorization: 'Bearer ' + this.props.userInfo.jwt
              },
            }
          )
          .then((res) => {
            console.log('response getAllComponents');
            console.log(res.data.data);
            let allPricingComponents = [];
            allPricingComponents.push(
              ...res.data.data.listOfDiscountComponents
            );
            //-- New code --
            if (res.data.data.listOfDiscountComponents.length > 0) {
              this.setState({
                componentType:  'Discount',
                // discountData: res.data.data.listOfDiscountComponents
                discountData: res.data.data.listOfMatrixDiscountComponents
              });
            }
            console.log(allPricingComponents);
            allPricingComponents.push(...res.data.data.listOfRentalComponents);
            console.log(allPricingComponents);
            if (res.data.data.listOfUsageComponents) {
              allPricingComponents.push(...res.data.data.listOfUsageComponents);
            }

            if (this.state.matrixComponent) {
              this.state.matrixComponent.map((x) =>
                allPricingComponents.push(x)
              );
            }
            console.log(allPricingComponents);

            this.setState({
              allPricingComponents: allPricingComponents,
            });
          })
          .catch((error) => {
            console.log(error);
            if (this._isMounted) this.setState({ loading: false });
          });
      } else {
        return Promise.resolve();
      }
    } else {
      return Promise.resolve();
    }
  }

  versions() {
    return axios
      .all([
        axios.get(
          process.env.REACT_APP_URL + 'config/version?entityName=offerability',
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              authUserId: this.props.userInfo.id,
              // Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        ),
        axios.get(
          process.env.REACT_APP_URL +
            'config/version?entityName=package.rental',
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              authUserId: this.props.userInfo.id,
              // Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        ),
        axios.get(
          process.env.REACT_APP_URL +
            'config/version?entityName=package.discount',
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              authUserId: this.props.userInfo.id,
              // Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        ),
        axios.get(
          process.env.REACT_APP_URL +
            'config/version?entityName=discountedItemsData',
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              authUserId: this.props.userInfo.id,
              // Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        ),
        axios.get(
          process.env.REACT_APP_URL +
            'config/version?entityName=discountUsageGroup',
          {
            headers: {
              opId: this.props.userInfo.opId,
              buId: this.props.userInfo.buId,
              authUserId: this.props.userInfo.id,
              // Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        ),
      ])
      .then(
        axios.spread(
          (
            offerVersion,
            rentalVersion,
            discountVersion,
            discountedItemsDataVersion,
            discountUsageGroupVersion
          ) => {
            this.setState({
              rentalVersion: rentalVersion.data.data.version,
              offerVersion: offerVersion.data.data.version,
              discountVersion: discountVersion.data.data.version,
              discountedItemsDataVersion:
                discountedItemsDataVersion.data.data.version,
              discountUsageGroupVersion:
                discountUsageGroupVersion.data.data.version,
            });
          }
        )
      )
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  delRentalComp = (delCompID) => {
    this.setState({
      loading: true,
    });
    console.log(
      process.env.REACT_APP_URL +
        '/pricing/direct/delete?componentId=' +
        delCompID +
        '&packageId=' +
        this.props.id +
        '&releaseID=' +
        this.props.releaseData.releaseId
    );
    axios
      .get(
        process.env.REACT_APP_URL +
          '/pricing/direct/delete?componentId=' +
          delCompID +
          '&packageId=' +
          this.props.id +
          '&releaseID=' +
          this.props.releaseData.releaseId,
        {
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            authUserId: this.props.userInfo.id,
            // Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        }
      )
      .then((res) => {
        console.log(res);
        let allPricingComponents = this.state.allPricingComponents;
        let removeIndex = allPricingComponents
          .map(function (item) {
            return item.componentId;
          })
          .indexOf(delCompID);
        allPricingComponents.splice(removeIndex, 1);
        let compKey =
          this.state.compKey.length > 10 ? 'app' : this.state.compKey + '1';
        this.setState({
          allPricingComponents: allPricingComponents,
          compKey: compKey,
          loading: false,
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  delMatrixComp = (delCompID) => {
    this.setState({
      loading: true,
    });

    axios
      .get(
        process.env.REACT_APP_URL +
          'pricing/matrix/delete?packageId=' +
          this.props.id +
          '&&releaseID=' +
          this.props.releaseData.releaseId,
        {}
      )
      .then((res) => {
        console.log(res);

        this.setState({
          loading: false,
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  delDiscComp = (delCompID) => {
    this.setState({
      loading: true,
    });

    axios
      .get(
        process.env.REACT_APP_URL +
          'discount/direct/delete?componentId=' +
          delCompID +
          '&packId=' +
          this.props.id +
          '&releaseID=' +
          this.props.releaseData.releaseId,
        {
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            authUserId: this.props.userInfo.id,
            // Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        }
      )
      .then((res) => {
        console.log(res);
        let allPricingComponents = this.state.allPricingComponents;
        let removeIndex = allPricingComponents
          .map(function (item) {
            return item.discountId;
          })
          .indexOf(delCompID);
        allPricingComponents.splice(removeIndex, 1);
        let compKey =
          this.state.compKey.length > 10 ? 'app' : this.state.compKey + '1';
        this.setState({
          allPricingComponents: allPricingComponents,
          compKey: compKey,
          loading: false,
        });
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };

  updateComponentDiscount = (obj, delCompId) => {
    let allPricingComponents = this.state.allPricingComponents;

    let removeIndex = allPricingComponents
      .map(function (item) {
        return item.discountId;
      })
      .indexOf(delCompId);
    allPricingComponents.splice(removeIndex, 1);
    console.log(removeIndex);

    let compKey =
      this.state.compKey.length > 10 ? 'app' : this.state.compKey + '1';
    allPricingComponents.push(obj);
    this.setState({
      allPricingComponents: allPricingComponents,
      compKey: compKey,
    });
  };

  updateComponent = (obj, delCompId) => {
    let allPricingComponents = this.state.allPricingComponents

    let removeIndex = allPricingComponents
      .map(function (item) {
        console.log(item.componentId);
        return item.componentId;
      })
      .indexOf(delCompId);
    allPricingComponents.splice(removeIndex, 1);
    console.log(removeIndex);

    let compKey =
      this.state.compKey.length > 10 ? 'app' : this.state.compKey + '1';
    allPricingComponents.push(obj);
    this.setState({
      allPricingComponents: allPricingComponents,
      compKey: compKey,
    });
  };

  addComponent = (obj) => {
    let allPricingComponents = this.state.allPricingComponents;
    let compKey =
      this.state.compKey.length > 10 ? 'app' : this.state.compKey + '1';
    allPricingComponents.push(obj);
    this.setState({
      allPricingComponents: allPricingComponents,
      compKey: compKey,
    });
  };
  editMatrixComp = () => {
    this.setState({
      computationType: 'Matrix',
      
    });
  };
  editComponent = (component) => {
    if (component.componentType) {
      this.setState({
        loading: true,
        componentType: 'Rental',
        computationType: 'Direct',
        disabled: false,
      });
      axios
        .get(
          process.env.REACT_APP_URL +
            'pricing/direct/component?id=' +
            this.props.id +
            '&compId=' +
            component.componentId +
            '&releaseId=' +
            this.props.releaseData.releaseId,
          {
            headers: {
              authUserId: this.props.userInfo.id,
              // Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        )
        .then((res) => {
          console.log(res.data.data);
          if (this._isMounted)
            this.setState({ loading: false, rentalData: res.data.data });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    } else {
      this.setState({
        loading: true,
        componentType: 'Discount',
        computationType: 'Direct',
        disabled: false,
      });
      axios
        .get(
          process.env.REACT_APP_URL +
            'discountIr/direct/component?componentId=' +
            component.discountId +
            '&packId=' +
            this.props.id +
            '&releaseID=' +
            this.props.releaseData.releaseId,
          {
            headers: {
              opId: this.props.userInfo.opId,
              authUserId: this.props.userInfo.id,
               Authorization: 'Bearer ' + this.props.userInfo.jwt
            },
          }
        )
        .then((res) => {
          console.log(res.data.data);
          if (res.data.data) {
            // this.disableWatchers();
            // this.componentIdDiscount = componentId;
            // Object.keys(res.data.data).forEach(key => {
            //     this.$set(this.formDataDiscount, key, res.data.data[key]);
            // });
            // if (this.formDataDiscount.discountAppliedOn == 'RC' || this.formDataDiscount.discountAppliedOn == 'NRC') {

            //     let discountedItem = this.formDataDiscount.discountedItem.substring(0, this.formDataDiscount.discountedItem.lastIndexOf('_', this.formDataDiscount.discountedItem.lastIndexOf('_') - 1))
            //     this.$set(this.formDataDiscount, 'discountedItem', discountedItem + '/' + this.formDataDiscount.discountedItem);
            // }
            console.log(res.data.data);
            let obj = {
              ...res.data.data,
              componentIdDiscount: component.discountId,
            };
            if (this._isMounted)
              this.setState({ loading: false, discountData: obj });
          }
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }
  };


  //http://10.5.198.89/product/external/getTemplates

  
  templateNameData = ()=>{
    return axios.get(`${process.env.REACT_APP_URL}product/external/getTemplates`, {headers: {
      opId: this.props.userInfo.opId,
      buId: this.props.userInfo.buId,
      authUserId: this.props.userInfo.id,
      Authorization: 'Bearer ' + this.props.userInfo.jwt
    }}).then(res=>{
      // this.setState({
      //   templateNameLovs: res.data.data.map(item=>item.templateName)
      // })
      
      console.log(res);
      if (this._isMounted) {
       
        this.setState({
           templateItems: res.data.data ,
           templateNameLovs: res.data.data.map(item=>item.templateName)
          });
        let templateMap = {}
        res.data.data.map((template) => {
          templateMap[template.templateName] = template.templateId;
          
        });
        this.setState({  templateMap });

      }



    })
  }
  // extensionHandler = () => {
  //   debugger;
  // }



  saveHandler = (event,templateName) => {
    event.preventDefault();
    console.log(this.state);
    this.setState({ loading: true });
    let payload = {};
    let date = moment().format('DD-MMM-YY');
    payload.releaseId = this.props.releaseData.releaseId;
    if(this.state.componentType === 'Rental'){
      payload.componentId = this.state.rentalData.componentName;
    }else{
      payload.componentId = this.state.discountData.componentIdDiscount;
    }
    //payload.componentId = this.state.rentalData.componentName;
    payload.templateId = this.state.templateMap[this.state.extensionAttributeTemplate];
    let ppmExtAttrMapAud=[];
    let ppmExtAttrMap = {};
   this.state.templateDataItems.map((formElement) => {
    ppmExtAttrMap.attrId = formElement.attrId;
    if (formElement.attrType == 'Date')
    ppmExtAttrMap.attrValue = moment(
        this.state[formElement.attrValue]
      ).format('DD-MMM-YY');
    else if (formElement.attrType == 'Checkbox')
    ppmExtAttrMap.attrValue =
        this.state[formElement.attrDefaultValue] === null ||
          this.state[formElement.attrValue] === undefined
          ? 'N'
          : this.state[formElement.refName];
    else
    ppmExtAttrMap.attrValue =
        this.state[formElement.attrId];
  // });



    ppmExtAttrMap.buId = this.props.userInfo.buId;
    ppmExtAttrMap.opId = this.props.userInfo.opId;
    ppmExtAttrMap.startDate = date;
    ppmExtAttrMap.endDate = '30-DEC-2030'
    ppmExtAttrMap.createdBy = 'pmir';
    ppmExtAttrMap.createdDate = date;
    ppmExtAttrMap.catalogId = 'B2C'
    ppmExtAttrMapAud.push({...ppmExtAttrMap});
    
  });




    console.log(ppmExtAttrMap);
    if (this.state.isEdit) {
      // ppmExtAttrMap.version = '1.0';
      
      payload.ppmExtAttrMapAud = ppmExtAttrMapAud;
      // payload.releaseId = this.props.releaseData.releaseId;
      console.log('post');
      console.log(payload);
     
      axios
        .post(process.env.REACT_APP_URL + 'product/external/mapping', payload, {
          headers: {
            // authUserId: this.props.userInfo.id,
            // Authorization: 'Bearer ' + this.props.userInfo.jwt
          },
        })
        .then((response) => {
          console.log('new gen product');
          console.log(response);
          let proDetails = { ...response.data.data };
          this.props.onProductEnter(proDetails);

          let searchItems = [
            response.data.data.productId + '/' + response.data.data.productDesc,
          ].concat(this.props.searchItems);
          this.props.setSearchItems(searchItems);

          this.state.schema.map((formElement) => {
            this.setState({
              [formElement.refName]: formElement.refName === 'defaultState' ? response.data.data[formElement.refName].split(',') : response.data.data[formElement.refName],
            });
          });
          this.setState({ postRequest: false, loading: false });
        })
        .catch((error) => {
          console.log(error);
          if (this._isMounted) this.setState({ loading: false });
        });
    }

  };

  

  templateItemDataHandler = (templateName, urlPartial) => {
    console.log(this.state);
    console.log(this.state.templateMap);
    console.log(templateName);
    console.log(urlPartial);

   // if(templateName)
    // //this.state.templateMap[this.state.templateName]
    // if (!urlPartial) {
      // urlPartial=  'product/external/getAll/attribute?templateId='
    // } 
    
    // else{
    //  // urlPartial= 'product/external/getMapping?componentId='+this.state.rentalData.componentName+'&templateId='
    //  templateName = "EXST_22"
    // }
   
    const url=  `product/external/getAll/attribute?templateId=${this.state.templateMap[templateName]}`
    //product/external/getMapping?componentId=PRD_113194_COMP_2&templateId=
    return axios
      .get(url, {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {

        console.log(res);
        if (this._isMounted) {
          let response = res.data.data;
          response.forEach((el) => {
            el['attrValue'] = null;
            el['refLovs'] = el.attrAllowedValues ? el.attrAllowedValues.split(',') : null;
          })
          this.setState({ templateDataItems: response });

        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
    // } else return Promise.resolve();
  };




  templateItemEditHandler = (templateName, urlPartial) => {
  
    if(this.state.componentType === 'Rental'){
    return axios.get(
      process.env.REACT_APP_URL + 'product/external/getMapping?componentId='+this.state.rentalData.componentName,
    {headers: {
      
    }})
  }else if(this.state.componentType === 'Discount'){
    return axios.get(
      process.env.REACT_APP_URL + 'product/external/getMapping?componentId='+this.state.discountData.componentIdDiscount,
    {headers: {
      
    }})
  }
    // .then(res=>{

        // console.log(res);
        // if (this._isMounted) {
        //   let response = res.data.data;
        //   // res1.map((el) => {
        //   //   el['attrValue'] = null;
        //   //   el['refLovs'] = el.attrAllowedValues ? el.attrAllowedValues.split(',') : null;
        //   // })
        //   this.setState({ 

        // attrId : response.attrId,
        // attrValue :  response.attrValue
      // });
     

        // }
      // })
      // .catch((error) => {
      //   console.log(error);
      //   if (this._isMounted) this.setState({ loading: false });
      // });
    // } else return Promise.resolve();
  };

  render() {
    const { classes } = this.props;
    let pricingComponent = null;
    if (
      this.state.componentType == 'Rental' &&
      this.state.computationType == 'Direct'
    )
      pricingComponent = (
        <RentalPricing
          rentalVersion={this.state.rentalVersion}
          userInfo={this.props.userInfo}
          releaseData={this.props.releaseData}
          id={this.props.id}
          entity={this.props.entity}
          addComponent={this.addComponent}
          rentalData={this.state.rentalData}
          updateComponent={this.updateComponent}
        />
      );
    else if (
      this.state.componentType == 'Rental' &&
      this.state.computationType == 'Matrix'
    )
      pricingComponent = (
        <RentalMatrix
          offerVersion={this.state.offerVersion}
          userInfo={this.props.userInfo}
          releaseData={this.props.releaseData}
          id={this.props.id}
          entity={this.props.entity}
        />
      );
    else if (
      this.state.componentType == 'Discount' &&
      this.state.computationType == 'Matrix'
    )
      pricingComponent = (
        <DiscountMatrix
          offerVersion={this.state.offerVersion}
          userInfo={this.props.userInfo}
          releaseData={this.props.releaseData}
          id={this.props.id}
          entity={this.props.entity}
        />
      );
    else if (
      this.state.componentType == 'Discount' &&
      this.state.computationType == 'Direct'
    )
      pricingComponent = (
        <DiscountPricing
          discountVersion={this.state.discountVersion}
          discountedItemsDataVersion={this.state.discountedItemsDataVersion}
          discountUsageGroupVersion={this.state.discountUsageGroupVersion}
          userInfo={this.props.userInfo}
          releaseData={this.props.releaseData}
          id={this.props.id}
          productData={this.props.productData}
          entity={this.props.entity}
          discountData={this.state.discountData}
          addComponent={this.addComponent}
          updateComponentDiscount={this.updateComponentDiscount}
        />
      );
    else if (this.state.componentType == 'Tariff')
      pricingComponent = (
        <Tarrif
          releaseData={this.props.releaseData}
          userInfo={this.props.userInfo}
          entity={this.props.entity}
          addComponent={this.addComponent}
          id={this.props.id}
        />
      );

    let pricing = (
      <React.Fragment>
        <ModalAction show={this.state.showExtension}
        modalClosed={()=> {
          this.setState({
            showExtension: false,
            loading: false
          })
        }}
        size="md"
        actionText={"Save"}
        title={"Extesion Attribute"}
        action={this.extensionHandler}>
          <Input 
            uiName="Template Name"
            refType="SelectInput"
            value={this.state.extensionAttributeTemplate}
            refLovs={this.state.templateNameLovs ?? []}
            disabled={false}
            required={true}
            changed={(e)=>{
              this.setState({extensionAttributeTemplate : e.target?.value ?? e})
              this.templateItemDataHandler(e);
           
            }}
          />
          <form
          onSubmit={this.saveHandler}
          style={{ overflow: 'visible' }}
        >
          <Grid
            container
            alignItems='flex-start'
            spacing={5}
            style={{ overflow: 'visible' }}
          >
            {this.state.templateDataItems && this.state.templateDataItems.map((formElement) => {
             
              return (
                <Input
                  key={formElement.attrValue}
                  uiName={formElement.attrLabel}
                  refType={formElement.attrType}
                  {...formElement}
                  value={this.state[formElement.attrId]}
                  //value={formElement.attrValue}
                  // disabled={formElement.isDisabled == 'Y' ? true : false}
                  required={formElement.attrMandatory == 'Y' ? true : false}
                  checkChanged={(event) => {
                    this.setState({
                      [formElement.attrId]: event.target.checked ? 'Y' : 'N',
                    });
                  }}
                  changed={(event) => {
                    if (!event.target) {
                      this.setState({
                        [formElement.attrId]: event,
                      });
                    } else {
                      // if (event.target.type !== 'checkbox')
                      this.setState({
                        [formElement.attrId]: event.target.value,
                      });

                    }
                  }}
                />
              )
            })}
          </Grid>
          {/* {this.props.releaseData.releaseId && ( */}
          <div
            style={{
              display: 'flex',
              justifyContent: 'flex-end',
              alignItems: 'center',
            }}
          >

            <StyledButton
              style={{
                marginLeft: '20px',
                marginTop: '3%',
                background: '#5dc17f',
              }}
              type='submit'

            // className={classes.btn}
            >
              Save
              </StyledButton>
          </div>

        </form>

        </ModalAction>
        <Card style={{ overflow: 'visible' }}>
          <CardHeader
            className={classes.cardHeader}
            classes={{
              subheader: classes.subheader,
            }}
            subheader={'Exisiting Components'}
          />

          <CardContent style={{ overflow: 'visible' }}>
            {console.log(this.state.allPricingComponents)}
            {console.log('Matrix Component', this.state.matrixComponent)}

            <PricingComponents
              pricingComponents={this.state.allPricingComponents}
              key={this.state.compKey}
              editComp={this.editComponent}
              editMatrixComp={this.editMatrixComp}
              delRentalComp={this.delRentalComp}
              delDiscComp={this.delDiscComp}
              delMatrixComp={this.delMatrixComp}
            />
          </CardContent>
        </Card>
        <Card style={{ overflow: 'visible', marginTop: '1%' }}>
          <CardHeader
            className={classes.cardHeader}
            classes={{
              subheader: classes.subheader,
            }}
            subheader={'Create New Component'}
          />

          <CardContent style={{ overflow: 'visible' }}>
            <Grid
              container
              alignContent='flex-end'
              spacing={2}
              style={{ overflow: 'visible' }}
            >
              <Grid
                item
                xs={4}
                sm={4}
                md={2}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                }}
              >
                <Typography variant='subtitle1'> Type of component</Typography>
              </Grid>
              <Grid item xs={8} sm={8} md={10}>
                <RadioGroup
                  row
                  aria-label='position'
                  name='position'
                  defaultValue='top'
                  value={this.state.componentType}
                  onChange={(event) => {
                    this.setState({
                      componentType: event.target.value,
                    });
                  }}
                >
                  <FormControlLabel
                    value={'Rental'}
                    control={<Radio style={{ color: '#ff1921' }} />}
                    label='Rental'
                  />
                  <FormControlLabel
                    value='Discount'
                    control={<Radio style={{ color: '#ff1921' }} />}
                    label='Discount'
                  />
                  <FormControlLabel
                    value='Tariff'
                    control={<Radio style={{ color: '#ff1921' }} />}
                    label='Tariff'
                  />
                </RadioGroup>
              </Grid>
            </Grid>

            <Grid container alignContent='flex-end' spacing={2}>
              {/* <Grid
                item
                xs={4}
                sm={4}
                md={2}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                }}
              >
                <Typography variant='subtitle1'> Computation Type</Typography>
              </Grid>
              <Grid item xs={8} sm={8} md={10}>
                <RadioGroup
                  row
                  aria-label='position'
                  name='position'
                  defaultValue='top'
                  value={this.state.computationType}
                  onChange={(event) => {
                    this.setState({
                      computationType: event.target.value,
                    });
                  }}
                >
                  <FormControlLabel
                    value={'Direct'}
                    control={<Radio style={{ color: '#ff1921' }} />}
                    label='Direct'
                  />
                  <FormControlLabel
                    value='Matrix'
                    control={<Radio style={{ color: '#ff1921' }} />}
                    label='Matrix'
                  />
                </RadioGroup>
              </Grid> */}


              <Grid item xs={8} sm={8} md={10}>
              <StyledButton
                  //   variant="contained"
                  type='button'
                  disabled = {this.state.disabled}
                  style={{
                    // background: "#02bfa0",
                    textTransform: 'none',
                    marginTop: '1%',
                    marginLeft: '20px',
                    background: '#5dc17f',
                  }}
                  onClick= {()=> {
                    this.setState({
                      loading: true
                    })


                    this.templateNameData().then(async () => {
                      let res = null;
                      let templateName = null;
                      try {
                        res = await this.templateItemEditHandler();
                        for (let item in this.state.templateMap) {
                          if (this.state.templateMap[item] === res.data.data.extensionAttributeId) {
                            templateName = item;
                          }
                        }
                      } catch(err) {
                        res = null
                      }
                     // let fields = res.data.data.extensionAttributeFields;

                      // fields.map((field) =>{
                      //   this.setState({aa: field.extAttrField});
                          
                      // })

                        this.setState({
                          loading:false,
                          showExtension:true,
                      
                          extensionAttributeTemplate: res?.data?.data?.extensionAttributeId 
                          ? templateName: null,
                      
                      })

                      if(res?.data?.data?.extensionAttributeFields) {
                        const {extensionAttributeFields = []} = res?.data?.data;

                        extensionAttributeFields.map(attr=>{

                        this.setState({
                          [attr.extAttrField] : attr.extAttrValue,
                        })

                      })
                    }

                     this.templateItemDataHandler(templateName)
                    });



                    // this.templateNameData().then(res=>this.setState({
                    //   loading:false,
                    //   showExtension:true
                    // }))
                    // this.teamItemEditHandler().then(res=>this.setState({
                    //   // attrId:
                    //   // attrValue:
                    // }))

                  }}
                  
                >
                  Add Extension
                </StyledButton>
              </Grid>




            </Grid>
          </CardContent>
        </Card>

        <Box mt={2}>{pricingComponent}</Box>
      </React.Fragment>
    );

    if (this.state.loading) pricing = <Loader relative />;

    return pricing;
  }
}

export default withStyles(useStyles)(WithErrorHandler(Pricing, axios));
