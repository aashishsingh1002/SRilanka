import React, { Component } from 'react';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import axios from '../../axios-epc';
import { connect } from 'react-redux';
import Loader from '../../UI/Loader/Loader';
import Table from '../../UI/Table/Table'
import Tooltip from '@material-ui/core/Tooltip';
import Chip from '@material-ui/core/Chip';
import IconButton from '@material-ui/core/IconButton';
import AttachmentIcon from '@material-ui/icons/Attachment'
import SaveIcon from '@material-ui/icons/Save';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';
import TextField from '@material-ui/core/TextField';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Modal from '../../UI/Modal/Modal';
import Attachment from '../Dashboard/Attachment';


const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
        },
    },
};

const LightTooltip = withStyles((theme) => ({
    tooltip: {
        backgroundColor: '#525354',
        color: 'white',
        boxShadow: theme.shadows[1],
        fontSize: 14,
    },
}))(Tooltip);

const getColor = {
    Deployed: "#1565c0",
    "InProgress": "#528548",
    Cancelled: "#fc0a5b",
    "Approval In Progress": "#f26933",
    'Design InProgress': "#528548",
    Approved: '#1565c0'
}

class WorkflowAdmin extends Component {

    _isMounted = false;

    state = {
        relData: {},
        attachment: false,
        show: false,
        modalContent: null,
        dataMyItems: [],
        dataTeamItems: [],
        loading: true,
        columnsTeamItems: [
            {
                title: "Self Assign", field: 'selfAssign', render: rowData => <IconButton onClick={() => this.selfAssignHandler(rowData)} >
                    <KeyboardArrowUpIcon />
                </IconButton>
            },
            { title: "Release No.", field: 'releaseId' },
            {
                title: 'Release Objective', field: 'releaseObjective', sorting: false,
                render: rowData =>
                    <LightTooltip title={rowData.releaseObjective} arrow>
                        <span> {rowData.releaseObjective ? rowData.releaseObjective.length > 25 ? rowData.releaseObjective.substring(0, 25) + "..." : rowData.releaseObjective : ''}</span>
                    </LightTooltip>
            },
            { title: 'Creation Date', field: 'releaseCreationDate' },
            { title: 'Created By', field: 'createdBy' },

            {
                title: 'Pending With',
                field: 'pendingWith',
            },

            {
                title: 'Attachment',
                field: 'attachment',
                render: rowData => <IconButton onClick={() => {
                    this.setState({ relData: { ...rowData } })
                    this.setState({ attachment: true })

                }} >
                    <AttachmentIcon />
                </IconButton>, sorting: false
            },

        ],
        columnsMyItems: [
            {
                title: "Release No.", field: 'releaseId'
            },
            {
                title: 'Release Objective', field: 'releaseObjective', sorting: false,
                render: rowData =>
                    <LightTooltip title={rowData.releaseObjective} arrow>
                        <span> {rowData.releaseObjective ? rowData.releaseObjective.length > 25 ? rowData.releaseObjective.substring(0, 25) + "..." : rowData.releaseObjective : ''}</span>
                    </LightTooltip>
            },
            { title: 'Creation Date', field: 'releaseCreationDate' },
            {
                title: 'Attachment',
                field: 'attachment',
                render: rowData => <IconButton onClick={() => {
                    this.setState({ relData: { ...rowData } })
                    this.setState({ attachment: true })

                }} >
                    <AttachmentIcon />
                </IconButton>, sorting: false
            },
            {
                title: 'Action',
                field: 'action',
                render: rowData => <FormControl style={{ minWidth: 200, }}>
                    <Select
                        name='action'
                        MenuProps={MenuProps}
                        displayEmpty
                        value={this.state['releaseAction' + rowData.releaseId]}
                        onChange={(event) => this.setState({ ['releaseAction' + rowData.releaseId]: event.target.value })}
                        input={<Input required={true}
                            id={rowData.releaseId + 'ip'} />}
                        renderValue={(selected) => {
                            if (selected) {
                                if (selected.length === 0) {
                                    return <em>Action</em>;
                                }

                                return selected

                            }
                        }}
                        inputProps={{ 'aria-label': 'Without label' }}
                    >
                        <MenuItem disabled value="">
                            <em>Action</em>
                        </MenuItem>
                        {['Approve', 'RFI', 'RFC'].map((name) => (
                            <MenuItem key={name} value={name} >
                                {name}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
                , sorting: false, cellStyle: { width: '15%' }
            },
            {
                title: 'Remarks',
                field: 'remarks',
                render: rowData => <TextField placeholder='remarks' name='remarks' fullWidth
                    value={this.state['release' + rowData.releaseId]}
                    onChange={(event) => this.setState({ ['release' + rowData.releaseId]: event.target.value })}
                />, sorting: false, cellStyle: { width: '25%' }
            },
            {
                title: 'Save',
                field: 'save',
                render: rowData => <IconButton style={{ marginLeft: '10' }} onClick={() => this.actionHandler(rowData)}>
                    <SaveIcon />
                </IconButton >, sorting: false, cellStyle: { width: '7%' }
            }

        ]

    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    componentDidMount() {
        this._isMounted = true;
        this.adminTaskList().then(() => {
            this.myItemsHandler().then(() => {
                this.setState({
                    loading: false
                })
            })
        })
    }

    actionHandler = (rowData) => {
        if (document.getElementById(rowData.releaseId + 'ip').validity.valid) {
            let variables = {};
            let payload = {};
            this.setState({ loading: true })

            if (this.state['releaseAction' + rowData.releaseId] == "Approve") {

                variables.approve = { value: true };
                variables.remarks = { value: this.state['release' + rowData.releaseId] };
                payload.variables = variables;
                console.log("payload");

                console.log(payload);
                axios
                    .post(
                        "rest/task/" + rowData.taskId + "/complete",
                        payload,
                        {
                            headers: {
                                "Content-Type": "application/json"
                            }
                        }
                    )
                    .then(response => {
                        console.log(response);

                        axios
                            .post(
                                "TeleSmsNotificationService/sendsms?releaseId=" +
                                rowData.releaseId,
                                {
                                    "roles": []
                                },
                                {
                                    headers: {
                                        opId: this.props.userInfo.opId,
                                        buId: this.props.userInfo.buId,
                                        lob: "Postpaid",
                                        initiateapproval: false
                                    }
                                }
                            )
                            .then(response => {
                                console.log(response);
                                // this.setState({ loading: false })
                                let myItems = [...this.state.dataMyItems]
                                let removeIndex = this.state.dataMyItems
                                    .map(function (item) {
                                        return item.releaseId;
                                    })
                                    .indexOf(rowData.releaseId);

                                myItems.splice(removeIndex, 1);
                                if (this._isMounted)
                                    this.setState({ loading: false, dataMyItems: myItems }
                                    );

                            })
                            .catch(error => {
                                console.log(error);
                                this.setState({ loading: false })
                            });

                    })
                    .catch(error => {
                        console.log(error);
                        if (this._isMounted)
                            this.setState({ loading: false })
                    });

            }
            else if (this.state['releaseAction' + rowData.releaseId] != "Approve") {
                axios
                    .post("TeleSelectApprovers/" +
                        this.state['releaseAction' + rowData.releaseId].toLowerCase() + "/" + rowData.releaseId, {
                            remarks: this.state['release' + rowData.releaseId]
                                ? this.state['release' + rowData.releaseId] : ''
                        })
                    .then(response => {
                        console.log(response);
                        let myItems = [...this.state.dataMyItems]
                        let removeIndex = this.state.dataMyItems
                            .map(function (item) {
                                return item.releaseId;
                            })
                            .indexOf(rowData.releaseId);

                        myItems.splice(removeIndex, 1);
                        if (this._isMounted)
                            this.setState({ loading: false, dataMyItems: myItems }
                            );

                    })
                    .catch(error => {
                        console.log(error);
                        this.setState({ loading: false })
                    });

            }
        }
        else {
            let modalContent = < Typography variant="h6">Action is required.
                 </ Typography>
            this.setState({ modalContent: modalContent, show: true })

        }


    }

    myItemsHandler() {
        let url = "Telecustom/userTaskList?groupId=" +
            this.props.userInfo.group[0] +
            "&userId=" +
            this.props.userInfo.id
        console.log(url)
        return axios
            .get(
                'Telecustom/adminUserTaskList?workflowId=swf&userId=' + this.props.userInfo.id,
                {
                    headers: {
                        opId: this.props.userInfo.opId,
                        buId: this.props.userInfo.buId
                    }
                }
            )
            .then(res => {
                console.log("my items");
                console.log(res)
                console.log(res.data.data);
                let myItems = [];
                res.data.data.filter(el => {
                    if (el.releaseDetails.length > 0) {
                        let obj = {};
                        obj.taskId = el.taskId;
                        el.releaseDetails.filter(element => {
                            if (element.varName == "releaseCreationDate") {
                                obj.releaseCreationDate = element.releaseDetails;
                            } else if (element.varName == "releaseId") {
                                obj.releaseId = element.releaseDetails;
                            } else if (element.varName == "releaseStatus") {
                                obj.releaseStatus = element.releaseDetails;
                            } else if (element.varName == "releaseObjective") {
                                obj.releaseObjective = element.releaseDetails;
                            } else if (element.varName == "releaseCreatedBy") {
                                obj.createdBy = element.releaseDetails;
                            } else if (element.varName == "releaseExternalId") {
                                obj.externalReleaseId = element.releaseDetails;
                            }
                        });
                        obj.action = "";
                        obj.remarks = "";
                        obj.save = "";

                        myItems.push(obj);
                    }
                });
                if (this._isMounted)
                    this.setState({ dataMyItems: myItems })

            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false })
            });
    }


    selfAssignHandler = (rowData) => {
        console.log(rowData)
        if (this._isMounted)
            this.setState({ loading: true })
        axios
            .post(
                "rest/task/" + rowData.taskId + "/claim",
                { userId: this.props.userInfo.id },
                {
                    headers: {
                        "Content-Type": "application/json"
                    }
                }
            )
            .then(response => {
                console.log(response);
                let teamItems = [...this.state.dataTeamItems]
                var removeIndex = this.state.dataTeamItems
                    .map(function (item) {
                        return item.releaseId;
                    })
                    .indexOf(rowData.releaseId);

                teamItems.splice(removeIndex, 1);
                let newMyitem = {};
                newMyitem = { ...rowData };
                newMyitem.save = "";
                newMyitem.action = "";
                newMyitem.remarks = "";
                if (this._isMounted)
                    this.setState((prevState) => {
                        return { loading: false, dataTeamItems: teamItems, dataMyItems: [newMyitem].concat(prevState.dataMyItems) };
                    });


            })
            .catch(error => {
                console.log(error);
                if (this._isMounted)
                    this.setState({ loading: false })
            });

    }

    adminTaskList() {
        return axios
            .get(
                "Telecustom/adminTaskList?workflowId=swf"
            )
            .then(res => {
                console.log(res)
                console.log("team ");
                console.log(res.data.data);
                let teamItems = []
                res.data.data.filter((el, i) => {
                    let obj = {};
                    obj.taskId = el.taskId;
                    el.releaseDetails.map((element) => {
                        if (element.varName == "releaseCreationDate") {
                            obj.releaseCreationDate = element.releaseDetails;
                        } else if (element.varName == "releaseId") {
                            obj.releaseId = element.releaseDetails;
                        } else if (element.varName == "releaseStatus") {
                            obj.releaseStatus = element.releaseDetails;
                        } else if (element.varName == "releaseObjective") {
                            obj.releaseObjective = element.releaseDetails;
                        } else if (element.varName == "releaseCreatedBy") {
                            obj.createdBy = element.releaseDetails;
                        }
                        else if (element.varName == "releaseExternalId") {
                            obj.externalReleaseId = element.releaseDetails;
                        }

                    });
                    obj.selfAssign = ''
                    obj.pendingWith = el.pendingWith
                    if (obj.releaseId) {
                        teamItems.push(obj);
                    }
                });
                console.log(teamItems)
                if (this._isMounted)
                    this.setState({ dataTeamItems: teamItems })

            })
            .catch(error => {
                console.log(error)
                if (this._isMounted)
                    this.setState({ loading: false })
            });
    }

    errorConfirmedHandler = () => {
        this.setState({ show: false });
    }

    showAttachmentHandler = () => {
        this.setState({ attachment: false })
    }

    render() {
        let workflowAdmin = <React.Fragment>

            <Modal
                show={this.state.show}
                modalClosed={this.errorConfirmedHandler}
                title={'Something Went Wrong!'}
            >
                {this.state.modalContent}
            </Modal>

            <Table title='My Items' data={this.state.dataMyItems}
                columns={this.state.columnsMyItems} pageSize={5} fontSize={'14px'} />

            <div style={{ marginTop: '30px' }}>
                <Table title='Team Items' data={this.state.dataTeamItems}
                    columns={this.state.columnsTeamItems} pageSize={5} fontSize={'14px'} />
            </div>

            {this.state.attachment ? <Attachment userInfo={this.props.userInfo}
                showAttachment={this.showAttachmentHandler}
                releaseData={this.state.relData} /> : null
            }
        </React.Fragment>


        if (this.state.loading)
            workflowAdmin = <Loader />

        return workflowAdmin
    }

}



const mapStateToProps = state => {
    return {
        userInfo: state.login.loggedInUserInfo,
    };
}




export default connect(mapStateToProps)(WithErrorHandler(WorkflowAdmin, axios));
