import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import TableNew from '../../UI/Table/TableNew';
import axios from '../../axios-epc';
import WithErrorHandler from '../../HOC/WithErrorHandler/WithErrorHandler';
import Tooltip from '@material-ui/core/Tooltip';
import Loader from '../../UI/Loader/Loader';
import { withStyles } from '@material-ui/core/styles';
import ModalAction from '../../UI/ModalAction/ModalAction';
import moment from 'moment';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import { Translate } from 'react-redux-i18n';
import Typography from '@material-ui/core/Typography';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Paper from '@material-ui/core/Paper';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';
import DescriptionOutlinedIcon from '@material-ui/icons/DescriptionOutlined';
import StyledButton from '../../UI/Button/Button';
import * as actionTypes from '../../store/actions/actionTypes';
import MenuIcon from '@material-ui/icons/Menu';
import CloseIcon from '@material-ui/icons/Close';
import AttachFileIcon from '@material-ui/icons/AttachFile';
import AccountTreeOutlinedIcon from '@material-ui/icons/AccountTreeOutlined';
import LibraryBooksOutlinedIcon from '@material-ui/icons/LibraryBooksOutlined';
import CheckCircleOutlineOutlinedIcon from '@material-ui/icons/CheckCircleOutlineOutlined';
import Title from '../../UI/Typography/Title';
import LibraryBooksIcon from '@material-ui/icons/LibraryBooks';
//import { saveAsExcel } from '../BulkUpload/common/utils';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: '#525354',
    color: 'white',
    boxShadow: theme.shadows[1],
    fontSize: 14,
  },
}))(Tooltip);

const getColor = {
  Deployed: '#1565c0',
  InProgress: '#009337',
  InConfiguration: '#CF4405',
  'ApprovalInProgress': '#ff9100', //"#C62828",
  InVerification:"rgb(201 25 233)"
};

const StyledMenu = withStyles({
  paper: {
    background: '#FFFFFF',
    border: '1px solid #EAEAEA',
    boxSizing: 'border-box',
    boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.08)',
    borderRadius: '8px',
  },
})((props) => <Menu elevation={0} getContentAnchorEl={null} {...props} />);

const StyledMenuItem = withStyles((theme) => ({
  root: {
    fontWeight: '600',
    fontSize: '12px',
    linHeight: '16px',
    color: '#0079FF',
  },
}))(MenuItem);

const StyledPaper = withStyles((theme) => ({
  root: {
    padding: '20px',
    '&:hover': {
      background: '#ebebeb',
    },
  },
}))(Paper);

const StyledTypoHeading = withStyles((theme) => ({
  root: {
    fontWeight: 'regular',
    fontSize: '14px',
    color: '#393939',
  },
}))(Typography);

const StyledTypoValue = withStyles((theme) => ({
  root: {
    fontWeight: 'bold',
    fontSize: '22px',
    color: '#000',
    marginTop: '5px',
  },
}))(Typography);

const StyledInfoIcon = withStyles((theme) => ({
  root: {
    fontSize: '16px',
    position: 'absolute',
    right: 0,
    top: 0,
  },
}))(InfoOutlinedIcon);

class Releases extends Component {
  _isMounted = false;
  state = {
    inVerificationReleases:[],
    inConfigurationReleases: [],
    approvedReleases: [],
    inProgressReleases: [],
    inApprovalReleases: [],
    anchorEls: [],
    remarks: '',
    data: [],
    deployed: [],
    approval: [],
    allReleases: [],
    inVerification:[],
    configurationReleases: [],
    inProgress: [],
    show: false,
    loading: false,
    schema: [],
    svData: [],
    currState: 'allReleases',
    productlists:[],
    productName:'',
    tileIdSelected:1,
    tileIdSelectedColor:'#dfe4ec',
    errordiscription:'',
    errordiscriptionRelease:'',
  };

  columns = [
    {
      title: <Translate value='dashboard.releaseObj' />,
      field: 'remarks',
      render: (rowData) => (
        <Typography
          style={{
            fontWeight: '600',
            fontSize: '14px',
            color: '#393939',
            minHeight: '42px',

            display: 'flex',
            alignItems: 'center',
          }}
        >
          {rowData.remarks
            ? rowData.remarks.length > 30
              ? rowData.remarks.substring(0, 30) + '...'
              : rowData.remarks
            : ''}
        </Typography>
      ),
      sorting: false,
      cellStyle: { width: '25%' }
    },
    {
      title: 'Release Id',
      field: 'externalReleaseId',
      render: (rowData) => (
        <Typography
          style={{ fontWeight: '400', fontSize: '14px', color: '#333333' }}
        >
          {/* Release Id {rowData.externalReleaseId} */}
          {rowData.externalReleaseId}
        </Typography>
      ),
      sorting: false,
      cellStyle: { width: '23%' }
    },
    {
      title: 'Product',
      field: 'replicationStatus',
      render: (rowData) => (
        <Typography
          style={{ fontWeight: '400', fontSize: '14px', color: '#333333' }}
        >
          {/* Release Id {rowData.externalReleaseId} */}
          {rowData.replicationStatus}
        </Typography>
      ),
      sorting: false,
      cellStyle: { width: '12%' }
    },
    {
      title: 'Created Date',
      field: 'createdOn',
      render: (rowData) => (
        <Typography
          style={{ fontWeight: '400', fontSize: '14px', color: '#333333' }}
        >
          {rowData.createdOn}
        </Typography>
      ),
      sorting: false,
      cellStyle: { width: '20%' }
    },
    {
      title: <Translate value='dashboard.status' />,
      field: 'releaseStatus',
      render: (rowData) => (
        <Typography
          style={{
            fontWeight: '600',
            fontSize: '14px',
            color: getColor[rowData.releaseStatus],
          }}
        >
          {rowData.releaseStatus}
        </Typography>
      ),
      sorting: false,
      cellStyle: { width: '20%' }
    },
    // {
    //   //title: 'Literature',
    //   title: <Translate value='dashboard.Literature' />,
    //   field: 'literature',
    //   sorting: false,
    //   filtering: false,
    //   render: (rowData) => (
    //     <LibraryBooksIcon
    //       style={{ color: 'black',alignItems: 'center', }}
    //       onClick={(event) => {
    //         event.stopPropagation();
    //         if (rowData.releaseStatus !== 'Deployed')
    //           this.props.literature(rowData);
    //       }}
    //     />
    //   ),
    //   cellStyle: { width: '4%' }
    // },



  ];

  menuHandleClose = (releaseId) => {
    let anchorEls = [...this.state.anchorEls];
    anchorEls[releaseId] = null;
    this.setState({ anchorEls });
  };

  modalCloseHandler = () => {
    this.setState({ show: false, remarks: '',productName:'',errordiscription:'',errordiscriptionRelease:'', });
  };

  toggleMenu = (toggle) => {
    this.setState({ toggleActions: toggle });
  };

  dashboardOverview = () => {
    let inConfigurationReleases = [];
    let approvedReleases = [];
    let inProgressReleases = [];
    let inApprovalReleases = [];
    let inVerificationReleases=[]
    this.state.data.map((release) => {
      if (release.releaseStatus == 'InProgress')
        inProgressReleases.push(release);
      else if (release.releaseStatus == 'InConfiguration')
        inConfigurationReleases.push(release);
      else if (release.releaseStatus == 'InVerification')
      inVerificationReleases.push(release);
      else if (release.releaseStatus == 'ApprovalInProgress')
        inApprovalReleases.push(release);
      else if (release.releaseStatus == 'Deployed')
        approvedReleases.push(release);
    });
    this.setState({
      inVerificationReleases,
      inConfigurationReleases,
      approvedReleases,
      inProgressReleases,
      inApprovalReleases,
    });

    return Promise.resolve();
  };
 
  actionHandler = () => {
    if(this.state.productName.length>0 && this.state.remarks.trimStart().length>0){
      let date = moment().format('YYYY-MM-DD');
    let payload = {
      buId: this.props.userInfo.buId,
      createdBy: this.props.userInfo.id,
      createdOn: date,
      remarks: this.state.remarks,
      catalogId: 'DEF_CATALOG',
      opId: this.props.userInfo.opId,
      releaseDate: date,
      replicationStatus: this.state.productName
    };
    //this.setState({ loading: true });

    axios
      .post('/b2b-dashboard/myReleases/create', payload, {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
          Authorization: "Bearer " + this.props.userInfo.jwt,
        },
      })
      .then((response) => {
        let obj = {};
        obj = { ...response.data.data.ppmReleaseMaster };
        obj.pendingWith = response.data.data.pendingWith;
        let data = [...this.state.data];
        data.unshift(obj);
        this.setState({
          data: data,
          //loading: false,
          show: false,
          remarks: '',
          productName:'',
          errordiscription:'',
          errordiscriptionRelease:''
        });
        window.location.reload();
      })
      .catch((error) => {
        console.log(error);
        this.setState({ show: false, remarks: '', loading: false, productName:'',errordiscription:'',errordiscriptionRelease:'' });
      });
    }
    else{ if(!this.state.productName)
      {this.setState({errordiscription:'Select Product'})}
      if(this.state.remarks.trimStart().length===0)
      {this.setState({errordiscriptionRelease:'Release Objective Mandatory'})}
    return Promise.resolve();
  }
    
  };
  newReleaseHandler = () => {
    this.setState({ show: true });
  };
  valueChangeHandler = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };
  svExport() {
    return axios
      .get('config?entityName=svExport', {
        headers: {
          opId: this.props.userInfo.opId,
          buId: this.props.userInfo.buId,
        },
      })
      .then((res) => {
        let schema = [];
        schema = res.data.data.map(function (el) {
          if (el.refType == 'SelectInput' || el.refType == 'MultiSelect') {
            if (el.refLovs != null) el.refLovs = el.refLovs.split(',');
            else if (el.refLovs == null) el.refLovs = [];
          }
          return el;
        });
        if (this._isMounted) this.setState({ schema: schema });
        localStorage.setItem('svExport', JSON.stringify(schema));
        localStorage.svExport_version = this.state.version;
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }

  allReleasesHandler = () => {
    return axios
      .get('/b2b-dashboard/myReleases?createdBy=' + this.props.userInfo.id, {
        headers: {
          Accept: 'application/json,text/plan,*/*',
          buId: this.props.userInfo.buId,
          channelId: 'CSA',
          language: 'ENG',
          opId: this.props.userInfo.opId,
          Authorization: "Bearer " + this.props.userInfo.jwt,
        },
      })
      .then((res) => {
        console.log(res.data.data);
        let data = [];
        res.data.data.filter((element) => {
          var obj = {};
          obj = { ...element.myReleases };
          obj.pendingWith = element.pendingWith;
          data.push(obj);
        });
        console.log(
          data.filter((x) => x.releaseStatus === 'Approval In Progress')
        );
        if (this._isMounted) {
          this.setState({
            inProgress: data,
            allReleases: data,
            data: data,
            deployed: data,
            approval: data,
            configurationReleases: data,
            inVerification:data,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  };
  componentDidMount = () => {
    this._isMounted = true;
    this.setState({ loading: true });
    this.allReleasesHandler().then(() => {
      this.dashboardOverview().then(() => {
        this.svExport().then(() => {
         this.productlist().then(()=>{
          if (this._isMounted) {
            this.setState({ loading: false });
          }
        });
        });
      });
    });
  };
  componentDidUpdate = (previousProps, previousState) => {
    console.log('previousState', previousState);
    console.log('previousProps', previousProps);
  };

  // shouldComponentUpdate = (nextProps, nextState) => {
  //   // return this.props.value !== nextProps.value;
  //   console.log("n", nextProps);
  //   console.log("a", nextState);
  //   return true;
  // };

  componentWillUnmount() {
    this._isMounted = false;
  }
  productlist=()=>{
    return axios
      .get("/b2b-workflow/product-list", {
        headers: {
          buId: this.props.userInfo.buId,
          opId: this.props.userInfo.opId,
          authUserId:this.props.userInfo.id,
          authGroupId:this.props.userInfo.group[0],
          Authorization: 'Bearer ' + this.props.userInfo.jwt,
        },
      })
      .then((res) => {
        console.log(res);
        let productlists = [];
        res.data.data.map((element) => {
          productlists.push(element);
          
        });
        if (this._isMounted) {
          this.setState({ productlists:productlists });
          console.log("Product",productlists)
        }
      })
      .catch((error) => {
        console.log(error);
        if (this._isMounted) this.setState({ loading: false });
      });
  }
  render() {
    let myReleases = (
      <React.Fragment>
        <div
          style={{
            marginTop: '10px',
            maxWidth: 1200,
            width: '100%',
            paddingBottom: '10px',
          }}
        >
          <Grid container spacing={1}>
            
            <Grid
              item
              xs={2}
              style={{
                
                cursor: 'pointer'
              }}
              onClick={() =>
                this.setState({
                  data: this.state.allReleases,
                  currState: 'allReleases',
                  tileIdSelected: 1,
                  selected:false
                })
              }
            >
              <StyledPaper style={this.state.tileIdSelected === 1 ? {backgroundColor:this.state.tileIdSelectedColor} :{}}>
                <div
                  style={{
                    minHeight:'60px',
                    position: 'relative'
                  }}
                >
                  <StyledTypoHeading>My Releases</StyledTypoHeading>
                  <Tooltip
                    title='Total number of My Releases'
                    aria-label='Total number of Releases'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue>
                  {this.state.allReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>
            <Grid
              item
              xs={2}
              style={{
               
                cursor: 'pointer',
                '&:hover': {
                  background: '#efefef',
                },
              }}
              onClick={() =>
                this.setState({
                  data: this.state.inProgress.filter(
                    (x) => x.releaseStatus === 'InProgress'
                  ),
                  currState: 'InProgress',
                  tileIdSelected: 2,
                  selected:false
                })
              }
            >
              <StyledPaper style={this.state.tileIdSelected === 2 ? {backgroundColor:this.state.tileIdSelectedColor} :{}}>
                <div
                  style={{
                    minHeight:'60px',
                    position: 'relative',
                  }}
                >
                  <StyledTypoHeading>In Progress   </StyledTypoHeading>
                  <Tooltip
                    title='Total number of InProgress Releases'
                    aria-label='Releases in Progress'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue style={{ color: '#009337' }}>
                  {this.state.inProgressReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>
            <Grid
              item
              xs={2}
              style={{
                
                cursor: 'pointer',
                '&:hover': {
                  background: '#efefef',
                },
              }}
              onClick={() =>
                this.setState({
                  data: this.state.inVerification.filter(
                    (x) => x.releaseStatus === 'InVerification'
                  ),
                  currState: 'InVerification',
                  tileIdSelected: 3,
                  selected:false
                })
              }
            >
              <StyledPaper style={this.state.tileIdSelected === 3 ? {backgroundColor:this.state.tileIdSelectedColor} :{}}>
                <div
                  style={{
                    minHeight:'60px',
                    position: 'relative',
                  }}
                >
                  <StyledTypoHeading>In Verification   </StyledTypoHeading>
                  <Tooltip
                    title='Total number of InVerification Releases'
                    aria-label='Releases in Verification'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue style={{ color: 'rgb(201 25 233)' }}>
                  {this.state.inVerificationReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>
            <Grid
              item
            xs={2}
              style={{
               
                cursor: 'pointer',
              }}
              onClick={() =>
                this.setState({
                  data: this.state.approval.filter(
                    (x) => x.releaseStatus === 'ApprovalInProgress'
                  ),
                  currState: 'InApproval',
                  tileIdSelected: 4,
                  selected:false
                })
              }
            >
              <StyledPaper style={this.state.tileIdSelected === 4 ? {backgroundColor:this.state.tileIdSelectedColor} :{}}>
                <div
                  style={{minHeight:'60px',
                    position: 'relative',
                  }}
                >
                  <StyledTypoHeading>Approval In Progress</StyledTypoHeading>
                  <Tooltip
                    title='Total number of InApproval Releases'
                    aria-label='Releases in Approval'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue style={{ color: '#ff9100' }}>
                  {this.state.inApprovalReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>
            <Grid
              item
              xs={2}
              style={{
                
                cursor: 'pointer',
              }}
              onClick={() =>
                this.setState({
                  data: this.state.configurationReleases.filter(
                    (x) => x.releaseStatus === 'InConfiguration'
                  ),
                  currState: 'InConfiguration',
                  tileIdSelected: 5,
                  selected:false
                })
              }
            >
              <StyledPaper style={this.state.tileIdSelected === 5 ? {backgroundColor:this.state.tileIdSelectedColor} :{}}>
                <div
                  style={{
                    minHeight:'60px',
                    position: 'relative',
                    cursor: 'pointer',
                  }}
                >
                  <StyledTypoHeading>In Configuration</StyledTypoHeading>
                  <Tooltip
                    title='Total number of InConfiguration Releases'
                    aria-label='Number of InConfiguration Releases'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue style={{ color: '#CF4405' }}>
                  {this.state.inConfigurationReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>
            <Grid
              item
              xs={2}
              style={{
                
                cursor: 'pointer',
              }}
              onClick={() =>
                this.setState({
                  data: this.state.deployed.filter(
                    (x) => x.releaseStatus === 'Deployed'
                  ),
                  currState: 'Deployed',
                  tileIdSelected: 6,
                  selected:false
                })
              }
            >
              <StyledPaper style={this.state.tileIdSelected === 6 ? {backgroundColor:this.state.tileIdSelectedColor} :{}}>
                <div
                  style={{
                    minHeight:'60px',
                    position: 'relative',
                  }}
                >
                  <StyledTypoHeading>Deployed</StyledTypoHeading>
                  <Tooltip
                    title='Total number of Deployed Releases'
                    aria-label='Releases Deployed'
                  >
                    <StyledInfoIcon />
                  </Tooltip>
                </div>
                <StyledTypoValue style={{ color: '#1565c0' }}>
                  {this.state.approvedReleases.length}
                </StyledTypoValue>
              </StyledPaper>
            </Grid>
            
            
          </Grid>
          
          <div>
            <Grid xs={12} style={{display:'flex',marginTop:'10px'}}> 
            <Grid item xs={6}>
               <Typography
              style={{
                fontWeight: 'bold',
                fontSize: '20px',
                color: '#393939',
                // marginBottom: "20px",
              }}
            >
              <span>
                <DescriptionOutlinedIcon />
               <Translate value='dashboard.myReleases' />
              </span>
            </Typography></Grid>
           
              <Grid item xs={6}>
              <StyledButton
                  style={{
                    padding: '6px 16px',
                    marginLeft:'24em',
                    background: '#5dc17f',
                  }}
                  onClick={() => this.newReleaseHandler()}
                >
                  New release
                </StyledButton>
              </Grid>

              </Grid>
            <Typography
              style={{
                //   fontWeight: "bold",
                fontSize: '16px',
                color: '#393939',
                marginBottom: '2px',
              }}
            >
              Search and create new releases below and review or edit them in
              the right hand panel.
            </Typography>
            <div style={{ display: 'flex' }}>
              <div style={{ maxWidth: 760, width: '100%' }}>
                <TableNew
                  clickable
                  onRowClick={(event, data) => {
                    this.setState({ selected: data });
                  }}
                  selected={
                    this.state.selected && this.state.selected.releaseId
                  }
                  data={this.state.data}
                  columns={this.columns}
                  pageSize={7}
                  fontSize={'14px'}
                  style={{
                    background: 'none',
                    boxShadow: 'none',
                    // boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.08)",
                  }}
                />
              </div>
              {this.state.selected && (
                <div
                  style={{
                    marginTop: '64px',
                    background: '#F5F5F5',
                    flexGrow: 1,
                    display: 'flex',
                    flexDirection: 'column',
                    borderRadius: '0 4px 4px 0',
                    borderLeft: '1px solid #ddd',
                    position: 'relative',
                  }}
                >
                  {this.state.toggleActions ? (
                    <React.Fragment>
                      <div
                        style={{
                          borderBottom: '1px solid #eee',
                          padding: '16px',
                        }}
                      >
                        <div
                          style={{
                            fontSize: '22px',
                            fontWeight: 'bold',
                            letterSpacing: '-1px',
                            height: '20px',
                            marginBottom: '14px',
                          }}
                        >
                          Release Actions
                          <span
                            style={{ position: 'absolute', right: 16, top: 16 }}
                          >
                            <CloseIcon
                              style={{ cursor: 'pointer' }}
                              onClick={() => {
                                this.toggleMenu(false);
                              }}
                            />
                          </span>
                        </div>
                      </div>
                      
                        <div
                          style={{
                            cursor: 'pointer',
                            fontSize: '16px',
                            letterSpacing: '-1px',
                            borderBottom: '1px solid #eee',
                            padding: '10px 16px',
                          }}
                          onClick={() => {
                            this.props.attachmentUpload(this.state.selected);
                          }}
                        >
                          <div
                            style={{
                              display: 'flex',
                            }}
                          >
                            <AttachFileIcon style={{ marginRight: '10px' }} />
                            <Translate value='dashboard.attachment' />
                          </div>
                        </div>
                      
                      <div
                        style={{
                          cursor: 'pointer',
                          fontSize: '16px',
                          letterSpacing: '-1px',
                          borderBottom: '1px solid #eee',
                          padding: '10px 16px',
                        }}
                        onClick={(event) => {
                          this.props.auditLogs(this.state.selected);
                        }}
                      >
                        <div
                          style={{
                            display: 'flex',
                          }}
                        >
                          <LibraryBooksOutlinedIcon
                            style={{ marginRight: '10px' }}
                          />
                          <Translate value='dashboard.auditLogs' />
                        </div>
                      </div>
                      {this.state.selected.releaseStatus === 'InProgress' && (
                        <div
                          style={{
                            cursor: 'pointer',
                            fontSize: '16px',
                            letterSpacing: '-1px',
                            borderBottom: '1px solid #eee',
                            padding: '10px 16px',
                          }}
                          onClick={(event) => {
                            event.stopPropagation();
                            this.menuHandleClose(this.state.selected.releaseId);
                            this.props.workflow(this.state.selected);
                          }}
                        >
                          <div
                            style={{
                              display: 'flex',
                            }}
                          >
                            <AccountTreeOutlinedIcon
                              style={{ marginRight: '10px' }}
                            />
                            <Translate value='dashboard.SelectApprover' />
                          </div>
                        </div>
                      )}
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      <div
                        style={{
                          borderBottom: '1px solid #eee',
                          padding: '16px',
                        }}
                      >
                        <div>
                          

                          <span
                            style={{ position: 'absolute', right: 16, top: 16 }}
                          >
                            <MenuIcon
                              style={{ cursor: 'pointer' }}
                              onClick={() => {
                                this.toggleMenu(true);
                              }}
                            />
                          </span>
                        </div>
                        <div>
                          {/* <div 
                            style={{
                              fontSize: '15px',
                              fontWeight: 'bold',
                              letterSpacing: '-1px',
                              // height: '20px',
                              marginBottom: '15px',
                            }}
                          >
                           {this.state.selected.remarks}
                          </div> */}

                          <div
                          style={{
                            fontSize: '15px',
                            fontWeight: 'bold'
                          }}
                        >
                          Release Objective
                        </div>

                          <p>{this.state.selected.remarks.length > 30
              ? this.state.selected.remarks.substring(0, 30) + '...'
              : this.state.selected.remarks
            }</p>
                          </div>

                          
                        <div>
                          <span style={{ fontSize: '12px', display: 'block' }}>
                            Release Id: {this.state.selected.externalReleaseId}
                          </span>
                          <span style={{ fontSize: '12px', display: 'block' }}>
                            Created on: {this.state.selected.createdOn}
                          </span>
                        </div>
                        
                      </div>
                      <div
                        style={{
                          borderBottom: '1px solid #eee',
                          padding: '16px',
                        }}
                      >

                        <div
                          style={{
                            fontSize: '14px',
                            fontWeight: 'bold',
                            color: getColor[this.state.selected.releaseStatus],
                          }}
                        >
                          {this.state.selected.releaseStatus}
                        </div>
                        <span style={{ fontSize: '12px', display: 'block' }}>
                          {this.state.selected.pendingWith}
                        </span>
                      </div>
                    </React.Fragment>
                  )}
                  { this.state.selected.releaseStatus === 'InProgress' ? 
                  <div style={{ padding: '16px 32px', marginTop: 'auto' }}>
                    <StyledButton
                      style={{ width: '100%' }}
                      // disabled
                      onClick={() => {
                        this.props.onReleaseEnter(this.state.selected);
                        this.props.history.push('/editRelease');
                      }}
                    >
                      Edit release details
                    </StyledButton>
                  </div>
                  : null
                  }
                </div>
              )}
            </div>
          
          </div>
        </div>
        <ModalAction
          label={'Required'}
          show={this.state.show}
          modalClosed={this.modalCloseHandler}
         // actionDisabled={this.state.remarks.length===0}  
          actionText={'Create'}
          title={'Create New Release'}
          action={this.actionHandler}
          size={'md'}
        >
          <Grid item xs={12}> 
            <Box mt={2}>
              <span
                style={{
                  fontWeight: 'bold',
                }}
              >
                Release Objective<span style={{ color: '#ff0000' }}>*</span>
              </span>
              <span
                style={{
                  marginLeft: '5px',
                }}
              >
                (Max Length 2000)
              </span>
            </Box>
            <Box mt={2}>
              <TextField
                inputProps={{
                  maxLength: 2000,
                }}
                name='remarks'
                fullWidth
                value={this.state.remarks.trimStart()}
                onChange={this.valueChangeHandler}
                placeholder='Release Objective'
                rows={5}
                multiline
                variant='outlined'
               
              />
              {this.state.remarks.trimStart().length===0 &&(<div style={{color:'#ff0000',fontWeight:'bold'}}>{this.state.errordiscriptionRelease}</div>)}
            </Box>
            <span>Max Remaining: {2000 - this.state.remarks.length}</span>
            <Box mt={2}>
              <span
                style={{
                  fontWeight: 'bold',
                }}
              >
                Product Type<span style={{ color: '#ff0000' }}>*</span>
              </span>
            </Box>
            <Box >
            <FormControl style={{width:'35%'}}>
							{console.log('PName',this.state.productName)}
							<Select
              name='productName'
								value={this.state.productName}
                onChange={(e) => this.setState({productName:e.target.value})
                }
                displayEmpty
                renderValue={(selected) => {
                  if (selected) {
                    if (selected.length === 0) {
                      return <em>Action</em>;
                    }
                    return selected;
                  }
                }}
                inputProps={{
								"aria-label": "Without label",
								}}
                style={{fontSize:'18px'}}
              >
                <MenuItem disabled value="">
										<em>Product Type</em>
								</MenuItem>
									{this.state.productlists.map((name,i) => {
									return (
										<MenuItem value={name.productCode} key={i}>
											{name.productName}
										</MenuItem>
									);
								})}
							</Select>
						</FormControl>
            {this.state.productName.length===0 &&(<div style={{color:'#ff0000',fontWeight:'bold'}}>{this.state.errordiscription}</div>)}
            </Box>
          </Grid>
        </ModalAction>
      </React.Fragment>
    );

    if (this.state.loading) myReleases = <Loader />;
    return myReleases;
  }
}

const mapStateToProps = (state) => {
  return {
    userInfo: state.login.loggedInUserInfo,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onReleaseEnter: (releaseData) =>
      dispatch({ type: actionTypes.INSIDE_RELEASE, releaseData: releaseData }),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(WithErrorHandler(withRouter(Releases), axios));
